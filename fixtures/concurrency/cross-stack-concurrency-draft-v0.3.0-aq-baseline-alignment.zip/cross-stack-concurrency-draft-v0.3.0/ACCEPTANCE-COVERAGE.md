# Acceptance coverage — v0.3.0

This sidecar explicitly binds 76 original WP/EE cases plus 48 additional AQ-baseline cases. All are unresolved. Full original parent obligations (including other security/developmental cases) remain mandatory independently of these mappings.

## Original worker/execution cases

| Case | Parent owner | Evidence producers | Checkpoint | Kata host |
|---|---|---|---|---|
| WP-001 | wi/WI-09 | wi/WI-09/domain | WI-WORKER-G1 | False |
| WP-002 | wi/WI-02 | wi/WI-02/domain | WI-WORKER-G1 | False |
| WP-003 | wi/WI-09 | wi/WI-09/domain | WI-WORKER-G1 | False |
| WP-004 | wi/WI-09 | wi/WI-09/domain | WI-WORKER-G1 | False |
| WP-005 | wi/WI-09 | wi/WI-09/domain | WI-WORKER-G1 | False |
| WP-006 | wi/WI-09 | wi/WI-09/domain | WI-WORKER-G1 | False |
| WP-007 | wi/WI-10 | wi/WI-10/domain | WI-WORKER-G1 | False |
| WP-008 | wi/WI-09 | wi/WI-09/domain | WI-WORKER-G1 | False |
| WP-009 | wi/WI-04 | wi/WI-04/domain | WI-WORKER-G2 | False |
| WP-010 | wi/WI-04 | wi/WI-04/domain | WI-WORKER-G2 | False |
| WP-011 | wi/WI-04 | wi/WI-04/domain | WI-WORKER-G2 | False |
| WP-012 | wi/WI-04 | wi/WI-04/domain | WI-WORKER-G2 | False |
| WP-013 | wi/WI-04 | wi/WI-04/domain | WI-WORKER-G2 | False |
| WP-014 | wi/WI-04 | wi/WI-04/domain | WI-WORKER-G2 | False |
| WP-015 | wi/WI-05 | wi/WI-05/domain | WI-WORKER-G2 | False |
| WP-016 | wi/WI-05 | wi/WI-05/domain | WI-WORKER-G2 | False |
| WP-017 | wi/WI-09 | wi/WI-09/process-provider | WI-WORKER-G3 | False |
| WP-018 | wi/WI-06 | wi/WI-09/process-provider | WI-WORKER-G3 | False |
| WP-019 | wi/WI-06 | wi/WI-09/process-provider | WI-WORKER-G3 | False |
| WP-020 | wi/WI-09 | wi/WI-09/process-provider | WI-WORKER-G3 | False |
| WP-021 | wi/WI-09 | wi/WI-09/process-provider | WI-WORKER-G3 | False |
| WP-022 | wi/WI-09 | wi/WI-09/process-provider | WI-WORKER-G3 | False |
| WP-023 | wi/WI-09 | wi/WI-09/process-provider | WI-WORKER-G3 | False |
| WP-024 | wi/WI-08 | wi/WI-09/process-provider | WI-WORKER-G3 | False |
| WP-025 | wi/WI-08 | wi/WI-09/process-provider | WI-WORKER-G3 | False |
| WP-026 | wi/WI-09 | wi/WI-09/process-provider | WI-WORKER-G3 | False |
| WP-027 | wi/WI-09 | wi/WI-09/process-provider | WI-WORKER-G4 | False |
| WP-028 | wi/WI-09 | wi/WI-09/process-provider | WI-WORKER-G4 | False |
| WP-029 | wi/WI-11 | wi/WI-11/embedded-runtime | WI-WORKER-G4 | False |
| WP-030 | wi/WI-11 | wi/WI-11/embedded-runtime | WI-WORKER-G4 | False |
| WP-031 | wi/WI-09 | wi/WI-09/process-provider | WI-WORKER-G4 | False |
| WP-032 | wi/WI-10 | wi/WI-10/process-catalog | WI-WORKER-G4 | False |
| WP-033 | wi/WI-13 | wi/WI-13/worker-conformance | WI-WORKER-G4 | False |
| WP-034 | wi/WI-14 | wi/WI-14/worker-handoff | WI-WORKER-G4 | False |
| WP-035 | wi/WI-06 | wi/WI-13/supervisor-conformance | WI-WORKER-G5 | False |
| WP-036 | wi/WI-06 | wi/WI-13/supervisor-conformance | WI-WORKER-G5 | False |
| WP-037 | wi/WI-06 | wi/WI-13/supervisor-conformance | WI-WORKER-G5 | False |
| WP-038 | wi/WI-08 | wi/WI-13/supervisor-conformance | WI-WORKER-G5 | False |
| WP-039 | wi/WI-11 | wi/WI-13/supervisor-conformance | WI-WORKER-G5 | False |
| WP-040 | wi/WI-13 | wi/WI-13/supervisor-conformance | WI-WORKER-G5 | False |
| EE-001 | exo/EXO-18 | exo/EXO-18/instance-design | EXO-ENV-G1 | False |
| EE-002 | exo/EXO-18 | exo/EXO-18/instance-qualification | EXO-ENV-G2 | True |
| EE-003 | exo/EXO-18 | exo/EXO-18/instance-qualification | EXO-ENV-G2 | True |
| EE-004 | exo/EXO-18 | exo/EXO-18/instance-qualification | EXO-ENV-G2 | True |
| EE-005 | exo/EXO-18 | exo/EXO-18/instance-qualification | EXO-ENV-G2 | True |
| EE-006 | exo/EXO-18 | exo/EXO-18/instance-qualification | EXO-ENV-G2 | True |
| EE-007 | exo/EXO-16 | exo/EXO-16/embedded-recovery | EXO-ENV-G4 | True |
| EE-008 | exo/EXO-16 | exo/EXO-16/embedded-recovery | EXO-ENV-G4 | True |
| EE-009 | exo/EXO-18 | exo/EXO-18/instance-design | EXO-ENV-G1 | False |
| EE-010 | exo/EXO-18 | exo/EXO-18/instance-qualification | EXO-ENV-G2 | True |
| EE-011 | exo/EXO-19 | exo/EXO-19/embedded-viability | EXO-ENV-G5 | False |
| EE-012 | exo/EXO-12 | exo/EXO-12/embedded-worker | EXO-ENV-G3 | False |
| EE-013 | exo/EXO-12 | exo/EXO-12/embedded-worker | EXO-ENV-G3 | False |
| EE-014 | exo/EXO-12 | exo/EXO-12/embedded-worker | EXO-ENV-G3 | False |
| EE-015 | exo/EXO-12 | exo/EXO-12/embedded-worker | EXO-ENV-G3 | False |
| EE-016 | exo/EXO-12 | exo/EXO-12/embedded-worker | EXO-ENV-G3 | False |
| EE-017 | exo/EXO-12 | exo/EXO-12/embedded-worker | EXO-ENV-G3 | False |
| EE-018 | exo/EXO-12 | exo/EXO-12/embedded-worker | EXO-ENV-G3 | False |
| EE-019 | exo/EXO-12 | exo/EXO-12/embedded-worker | EXO-ENV-G3 | False |
| EE-020 | exo/EXO-12 | exo/EXO-12/embedded-worker | EXO-ENV-G3 | False |
| EE-021 | exo/EXO-12 | exo/EXO-12/embedded-worker | EXO-ENV-G3 | False |
| EE-022 | exo/EXO-12 | exo/EXO-12/embedded-worker | EXO-ENV-G5 | False |
| EE-023 | exo/EXO-12 | exo/EXO-12/embedded-worker | EXO-ENV-G5 | False |
| EE-024 | exo/EXO-12 | exo/EXO-12/embedded-worker | EXO-ENV-G3 | False |
| EE-025 | exo/EXO-16 | exo/EXO-16/embedded-recovery | EXO-ENV-G4 | True |
| EE-026 | exo/EXO-16 | exo/EXO-16/embedded-recovery | EXO-ENV-G4 | True |
| EE-027 | exo/EXO-15 | exo/EXO-15/embedded-lifecycle | EXO-ENV-G4 | True |
| EE-028 | exo/EXO-15 | exo/EXO-15/embedded-lifecycle | EXO-ENV-G4 | False |
| EE-029 | exo/EXO-16 | exo/EXO-16/embedded-recovery | EXO-ENV-G4 | True |
| EE-030 | exo/EXO-14 | exo/EXO-14/embedded-provenance | EXO-ENV-G5 | False |
| EE-031 | exo/EXO-19 | exo/EXO-19/embedded-viability | EXO-ENV-G5 | True |
| EE-032 | exo/EXO-19 | exo/EXO-19/embedded-viability | EXO-ENV-G5 | False |
| EE-033 | exo/EXO-13 | exo/EXO-13/embedded-acceptance | EXO-ENV-G3 | False |
| EE-034 | exo/EXO-15 | exo/EXO-15/embedded-lifecycle | EXO-ENV-G4 | True |
| EE-035 | exo/EXO-18 | exo/EXO-18/instance-qualification | EXO-ENV-G2 | True |
| EE-036 | exo/EXO-03 | exo/EXO-03/domain | EXO-ENV-G1 | False |

## Additional source-bound AQ cases

| Case | Owner | Producing slice | Capability review |
|---|---|---|---|
| AB-WI-001 | wi/WI-02 | wi/WI-02/integration | WI-AQ-G1 |
| AB-WI-002 | wi/WI-04 | wi/WI-04/integration | WI-AQ-G2 |
| AB-WI-003 | wi/WI-04 | wi/WI-04/integration | WI-AQ-G2 |
| AB-WI-004 | wi/WI-04 | wi/WI-04/integration | WI-AQ-G2 |
| AB-WI-005 | wi/WI-07 | wi/WI-07/integration | WI-AQ-G4 |
| AB-WI-006 | wi/WI-03 | wi/WI-03/integration | WI-AQ-G3 |
| AB-WI-007 | wi/WI-03 | wi/WI-03/integration | WI-AQ-G3 |
| AB-WI-008 | wi/WI-08 | wi/WI-08/integration | WI-AQ-G3 |
| AB-WI-009 | wi/WI-03 | wi/WI-03/integration | WI-AQ-G3 |
| AB-WI-010 | wi/WI-07 | wi/WI-07/integration | WI-AQ-G3 |
| AB-WI-011 | wi/WI-08 | wi/WI-08/integration | WI-AQ-G3 |
| AB-WI-012 | wi/WI-06 | wi/WI-06/integration | WI-AQ-G4 |
| AB-WI-013 | wi/WI-07 | wi/WI-07/integration | WI-AQ-G4 |
| AB-WI-014 | wi/WI-06 | wi/WI-06/integration | WI-AQ-G4 |
| AB-WI-015 | wi/WI-02 | wi/WI-02/integration | WI-AQ-G1 |
| AB-WI-016 | wi/WI-02 | wi/WI-02/integration | WI-AQ-G1 |
| AB-WI-017 | wi/WI-11 | wi/WI-11/integration | WI-AQ-G4 |
| AB-WI-018 | wi/WI-11 | wi/WI-11/integration | WI-AQ-G4 |
| AB-WI-019 | wi/WI-11 | wi/WI-11/embedded-runtime | WI-AQ-G1 |
| AB-WI-020 | wi/WI-06 | wi/WI-06/integration | WI-AQ-G4 |
| AB-WI-021 | wi/WI-09 | wi/WI-09/process-provider | WI-AQ-G3 |
| AB-WI-022 | wi/WI-03 | wi/WI-03/integration | WI-AQ-G3 |
| AB-WI-023 | wi/WI-06 | wi/WI-06/integration | WI-AQ-G4 |
| AB-WI-024 | wi/WI-13 | wi/WI-13/conformance | WI-AQ-G5 |
| AB-EXO-001 | exo/EXO-11 | exo/EXO-11/embedded-runtime | EXO-AQ-G1 |
| AB-EXO-002 | exo/EXO-11 | exo/EXO-11/embedded-runtime | EXO-AQ-G2 |
| AB-EXO-003 | exo/EXO-11 | exo/EXO-11/embedded-runtime | EXO-AQ-G2 |
| AB-EXO-004 | exo/EXO-11 | exo/EXO-11/embedded-runtime | EXO-AQ-G2 |
| AB-EXO-005 | exo/EXO-11 | exo/EXO-11/embedded-runtime | EXO-AQ-G4 |
| AB-EXO-006 | exo/EXO-11 | exo/EXO-11/embedded-runtime | EXO-AQ-G3 |
| AB-EXO-007 | exo/EXO-11 | exo/EXO-11/embedded-runtime | EXO-AQ-G3 |
| AB-EXO-008 | exo/EXO-11 | exo/EXO-11/embedded-runtime | EXO-AQ-G3 |
| AB-EXO-009 | exo/EXO-11 | exo/EXO-11/embedded-runtime | EXO-AQ-G3 |
| AB-EXO-010 | exo/EXO-11 | exo/EXO-11/embedded-runtime | EXO-AQ-G3 |
| AB-EXO-011 | exo/EXO-11 | exo/EXO-11/embedded-runtime | EXO-AQ-G3 |
| AB-EXO-012 | exo/EXO-11 | exo/EXO-11/embedded-runtime | EXO-AQ-G4 |
| AB-EXO-013 | exo/EXO-11 | exo/EXO-11/embedded-runtime | EXO-AQ-G4 |
| AB-EXO-014 | exo/EXO-11 | exo/EXO-11/integration | EXO-AQ-G4 |
| AB-EXO-015 | exo/EXO-11 | exo/EXO-11/embedded-runtime | EXO-AQ-G1 |
| AB-EXO-016 | exo/EXO-11 | exo/EXO-11/embedded-runtime | EXO-AQ-G1 |
| AB-EXO-017 | exo/EXO-11 | exo/EXO-11/integration | EXO-AQ-G4 |
| AB-EXO-018 | exo/EXO-11 | exo/EXO-11/integration | EXO-AQ-G4 |
| AB-EXO-019 | exo/EXO-16 | exo/EXO-16/embedded-recovery | EXO-AQ-G1 |
| AB-EXO-020 | exo/EXO-16 | exo/EXO-16/embedded-recovery | EXO-AQ-G4 |
| AB-EXO-021 | exo/EXO-12 | exo/EXO-12/embedded-worker | EXO-AQ-G3 |
| AB-EXO-022 | exo/EXO-16 | exo/EXO-16/embedded-recovery | EXO-AQ-G3 |
| AB-EXO-023 | exo/EXO-16 | exo/EXO-16/embedded-recovery | EXO-AQ-G4 |
| AB-EXO-024 | exo/EXO-17 | exo/EXO-17/integration | EXO-AQ-G5 |
