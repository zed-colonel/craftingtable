# Checkpoint catalog — v0.3.0

**95 definitions, including 58 WI/EXO ADR decisions and one AQ baseline acceptance review.** Every checkpoint imports unresolved. Prerequisites make a review eligible; they never prove a pass.

## STACK-PLAN-ACCEPTED — Approved concurrency sidecar and application bindings

Kind: `plan_approval`; owner: `stack`; evidence: `plan-approval`.

Prerequisites: None.

- Map structure is valid, source hashes match, and the expanded state graph is acyclic.
- All draft decisions are explicitly approved for this map digest.
- Application resolves exact project/plan-version bindings atomically; missing bindings fail closed.

## AQ-BASELINE-ACCEPTED — Accepted exact completed AQ source/build and upstream proof binding

Kind: `baseline_acceptance`; owner: `stack`; evidence: `upstream-baseline`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`.

- Verify the supplied AQ archive and complete source-tree hashes from aq_baseline_binding; historical pre-contract commit is not a current implementation pin.
- Resolve and independently verify the exact immutable implementation/build identity, toolchain/features and source conformance package revision 16; attach actual upstream build/test/conformance evidence or record a reviewed unresolved gap rather than passing.
- Accept the completed source as an upstream dependency without scheduling AQ-01..AQ-14 or reopening frozen AQ ADRs. Any future AQ defect/change requires a separately reviewed work item and new baseline revision.
- Consumer G1..G5 and actual publication remain independent unresolved attestations; source availability and this checkpoint do not auto-pass them.

## WI-ADR-001 — Protocol version envelope, canonical serialization, hash input, unknown-field rules

Kind: `architecture_decision`; owner: `wi`; evidence: `decision-review`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `wi/WI-01@accepted`.

- Protocol version envelope, canonical serialization, hash input, unknown-field rules
- The source recommended default is not proof that this ADR has been accepted.

## WI-ADR-002 — Identifier generation and stable client-request idempotency mapping

Kind: `architecture_decision`; owner: `wi`; evidence: `decision-review`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `wi/WI-01@accepted`.

- Identifier generation and stable client-request idempotency mapping
- The source recommended default is not proof that this ADR has been accepted.

## WI-ADR-003 — Fresh store topology, SQLite transaction boundaries, backup/restore contract

Kind: `architecture_decision`; owner: `wi`; evidence: `decision-review`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `wi/WI-01@accepted`.

- Fresh store topology, SQLite transaction boundaries, backup/restore contract
- The source recommended default is not proof that this ADR has been accepted.

## WI-ADR-004 — Principal authentication, actor binding, accountable-principal derivation

Kind: `architecture_decision`; owner: `wi`; evidence: `decision-review`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `wi/WI-01@accepted`.

- Principal authentication, actor binding, accountable-principal derivation
- The source recommended default is not proof that this ADR has been accepted.

## WI-ADR-005 — Canonical resource URI grammar and resolver registry

Kind: `architecture_decision`; owner: `wi`; evidence: `decision-review`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `wi/WI-01@accepted`.

- Canonical resource URI grammar and resolver registry
- The source recommended default is not proof that this ADR has been accepted.

## WI-ADR-006 — Authorization grammar, attenuation rules, decision explanation schema

Kind: `architecture_decision`; owner: `wi`; evidence: `decision-review`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `wi/WI-01@accepted`.

- Authorization grammar, attenuation rules, decision explanation schema
- The source recommended default is not proof that this ADR has been accepted.

## WI-ADR-007 — Effect state machine, commit-point vocabulary, `Uncertain`, and terminal outcomes

Kind: `architecture_decision`; owner: `wi`; evidence: `decision-review`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `wi/WI-01@accepted`.

- Effect state machine, commit-point vocabulary, `Uncertain`, and terminal outcomes
- The source recommended default is not proof that this ADR has been accepted.

## WI-ADR-008 — Boundary receipt canonical form, content hashing, signing profile, and key rotation

Kind: `architecture_decision`; owner: `wi`; evidence: `decision-review`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `wi/WI-01@accepted`.

- Boundary receipt canonical form, content hashing, signing profile, and key rotation
- The source recommended default is not proof that this ADR has been accepted.

## WI-ADR-009 — ContextStore versus artifact-store responsibility and publication atomicity

Kind: `architecture_decision`; owner: `wi`; evidence: `decision-review`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `wi/WI-01@accepted`.

- ContextStore versus artifact-store responsibility and publication atomicity
- The source recommended default is not proof that this ADR has been accepted.

## WI-ADR-010 — Connector resolve/invoke/reconcile SPI and idempotency classes

Kind: `architecture_decision`; owner: `wi`; evidence: `decision-review`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `wi/WI-01@accepted`.

- Connector resolve/invoke/reconcile SPI and idempotency classes
- The source recommended default is not proof that this ADR has been accepted.

## WI-ADR-011 — HTTP redirect, DNS, credential, SSRF, and replay policy

Kind: `architecture_decision`; owner: `wi`; evidence: `decision-review`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `wi/WI-01@accepted`.

- HTTP redirect, DNS, credential, SSRF, and replay policy
- The source recommended default is not proof that this ADR has been accepted.

## WI-ADR-012 — Ingress provider identity, deduplication, ordering, gap evidence, and retention

Kind: `architecture_decision`; owner: `wi`; evidence: `decision-review`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `wi/WI-01@accepted`.

- Ingress provider identity, deduplication, ordering, gap evidence, and retention
- The source recommended default is not proof that this ADR has been accepted.

## WI-ADR-013 — Subscriber delivery acknowledgment, retry, dead-letter, and privacy policy

Kind: `architecture_decision`; owner: `wi`; evidence: `decision-review`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `wi/WI-01@accepted`.

- Subscriber delivery acknowledgment, retry, dead-letter, and privacy policy
- The source recommended default is not proof that this ADR has been accepted.

## WI-ADR-014 — Common `ExecutionPlan`, plan hash, transform determinism, and Flow versioning

Kind: `architecture_decision`; owner: `wi`; evidence: `decision-review`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `wi/WI-01@accepted`.

- Common `ExecutionPlan`, plan hash, transform determinism, and Flow versioning
- The source recommended default is not proof that this ADR has been accepted.

## WI-ADR-015 — Flow wait/timer lowering to `AQ-CONT-1`

Kind: `architecture_decision`; owner: `wi`; evidence: `decision-review`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `wi/WI-01@accepted`.

- Flow wait/timer lowering to `AQ-CONT-1`
- The source recommended default is not proof that this ADR has been accepted.

## WI-ADR-016 — Agent Host transport, run credential, authoritative process-managed-proof-1 profile, executable/image representation, supported controls, artifact exchange and external-provider seam

Kind: `architecture_decision`; owner: `wi`; evidence: `decision-review`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `wi/WI-01@accepted`.

- Agent Host transport, run credential, authoritative process-managed-proof-1 profile, executable/image representation, supported controls, artifact exchange and external-provider seam
- The source recommended default is not proof that this ADR has been accepted.

## WI-ADR-017 — Capability admission checklist and connector quarantine

Kind: `architecture_decision`; owner: `wi`; evidence: `decision-review`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `wi/WI-01@accepted`.

- Capability admission checklist and connector quarantine
- The source recommended default is not proof that this ADR has been accepted.

## WI-ADR-018 — Daemon authentication profiles, tenancy, organizational grants, and secret brokerage

Kind: `architecture_decision`; owner: `wi`; evidence: `decision-review`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `wi/WI-01@accepted`.

- Daemon authentication profiles, tenancy, organizational grants, and secret brokerage
- The source recommended default is not proof that this ADR has been accepted.

## WI-ADR-019 — External identifier/identity-binding SPI, historical key state, and disclosure profiles

Kind: `architecture_decision`; owner: `wi`; evidence: `decision-review`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `wi/WI-01@accepted`.

- External identifier/identity-binding SPI, historical key state, and disclosure profiles
- The source recommended default is not proof that this ADR has been accepted.

## WI-ADR-020 — Proof-bundle composition, issuer/executor/witness roles, and transparency publication

Kind: `architecture_decision`; owner: `wi`; evidence: `decision-review`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `wi/WI-01@accepted`.

- Proof-bundle composition, issuer/executor/witness roles, and transparency publication
- The source recommended default is not proof that this ADR has been accepted.

## EXO-ADR-001 — One authoritative transactional `vessel.db`; artifacts and rebuildable indexes are separate.

Kind: `architecture_decision`; owner: `exo`; evidence: `decision-review`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-01@accepted`.

- One authoritative transactional `vessel.db`; artifacts and rebuildable indexes are separate.
- The source recommended default is not proof that this ADR has been accepted.

## EXO-ADR-002 — Monotonic `VesselRevision` and serialized authoritative reducer with optimistic episode snapshot checks.

Kind: `architecture_decision`; owner: `exo`; evidence: `decision-review`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-01@accepted`.

- Monotonic `VesselRevision` and serialized authoritative reducer with optimistic episode snapshot checks.
- The source recommended default is not proof that this ADR has been accepted.

## EXO-ADR-003 — Canonical domain-event envelope, digest rules, and event versioning.

Kind: `architecture_decision`; owner: `exo`; evidence: `decision-review`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-01@accepted`.

- Canonical domain-event envelope, digest rules, and event versioning.
- The source recommended default is not proof that this ADR has been accepted.

## EXO-ADR-004 — Vessel Blueprint, pinned Manifest, atomic Genesis, commissioning, activation, and lifecycle semantics.

Kind: `architecture_decision`; owner: `exo`; evidence: `decision-review`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-01@accepted`.

- Vessel Blueprint, pinned Manifest, atomic Genesis, commissioning, activation, and lifecycle semantics.
- The source recommended default is not proof that this ADR has been accepted.

## EXO-ADR-005 — Purpose Charter, role assignment, acting capacity, stewardship, Mission Offer, and commitment distinctions.

Kind: `architecture_decision`; owner: `exo`; evidence: `decision-review`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-01@accepted`.

- Purpose Charter, role assignment, acting capacity, stewardship, Mission Offer, and commitment distinctions.
- The source recommended default is not proof that this ADR has been accepted.

## EXO-ADR-006 — Semantic-time model and historical “as of” query semantics.

Kind: `architecture_decision`; owner: `exo`; evidence: `decision-review`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-01@accepted`.

- Semantic-time model and historical “as of” query semantics.
- The source recommended default is not proof that this ADR has been accepted.

## EXO-ADR-007 — Epistemic claim, support/defeat, belief revision, contradiction, and dependent-plan review semantics.

Kind: `architecture_decision`; owner: `exo`; evidence: `decision-review`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-01@accepted`.

- Epistemic claim, support/defeat, belief revision, contradiction, and dependent-plan review semantics.
- The source recommended default is not proof that this ADR has been accepted.

## EXO-ADR-008 — Schema registry, semantic digests, compatibility, deprecation, and fail-closed consequential handling.

Kind: `architecture_decision`; owner: `exo`; evidence: `decision-review`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-01@accepted`.

- Schema registry, semantic digests, compatibility, deprecation, and fail-closed consequential handling.
- The source recommended default is not proof that this ADR has been accepted.

## EXO-ADR-009 — Integrity classes and instruction-authority admission grammar.

Kind: `architecture_decision`; owner: `exo`; evidence: `decision-review`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-01@accepted`.

- Integrity classes and instruction-authority admission grammar.
- The source recommended default is not proof that this ADR has been accepted.

## EXO-ADR-010 — `ContextManifest` and `EpisodeSecurityEnvelope` compilation, sensitive-reference policy, and version pinning.

Kind: `architecture_decision`; owner: `exo`; evidence: `decision-review`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-01@accepted`.

- `ContextManifest` and `EpisodeSecurityEnvelope` compilation, sensitive-reference policy, and version pinning.
- The source recommended default is not proof that this ADR has been accepted.

## EXO-ADR-011 — Derivation propagation, integrity endorsement, declassification, quarantine, and release semantics.

Kind: `architecture_decision`; owner: `exo`; evidence: `decision-review`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-01@accepted`.

- Derivation propagation, integrity endorsement, declassification, quarantine, and release semantics.
- The source recommended default is not proof that this ADR has been accepted.

## EXO-ADR-012 — Explicit plan amendment, authority/disclosure delta evaluation, and `InfluenceTrace`.

Kind: `architecture_decision`; owner: `exo`; evidence: `decision-review`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-01@accepted`.

- Explicit plan amendment, authority/disclosure delta evaluation, and `InfluenceTrace`.
- The source recommended default is not proof that this ADR has been accepted.

## EXO-ADR-013 — Interaction ledger, conversation projection, response obligation, communication intent, and attention transaction boundaries.

Kind: `architecture_decision`; owner: `exo`; evidence: `decision-review`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-01@accepted`.

- Interaction ledger, conversation projection, response obligation, communication intent, and attention transaction boundaries.
- The source recommended default is not proof that this ADR has been accepted.

## EXO-ADR-014 — Initiative and attention are separate reducers; neither is initially a general graph engine.

Kind: `architecture_decision`; owner: `exo`; evidence: `decision-review`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-01@accepted`.

- Initiative and attention are separate reducers; neither is initially a general graph engine.
- The source recommended default is not proof that this ADR has been accepted.

## EXO-ADR-015 — Faculty invocation/emission contract and strict separation of structural fields from rationale artifacts.

Kind: `architecture_decision`; owner: `exo`; evidence: `decision-review`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-01@accepted`.

- Faculty invocation/emission contract and strict separation of structural fields from rationale artifacts.
- The source recommended default is not proof that this ADR has been accepted.

## EXO-ADR-016 — Influence graph grammar, policy versioning, stable ordering, and unavailable-source behavior.

Kind: `architecture_decision`; owner: `exo`; evidence: `decision-review`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-01@accepted`.

- Influence graph grammar, policy versioning, stable ordering, and unavailable-source behavior.
- The source recommended default is not proof that this ADR has been accepted.

## EXO-ADR-017 — Concern, commitment, goal, plan, interest, question, maintenance, portfolio conflict, and quiescence lifecycles.

Kind: `architecture_decision`; owner: `exo`; evidence: `decision-review`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-01@accepted`.

- Concern, commitment, goal, plan, interest, question, maintenance, portfolio conflict, and quiescence lifecycles.
- The source recommended default is not proof that this ADR has been accepted.

## EXO-ADR-018 — Evidence taxonomy and provenance shared by epistemics, memory, relationships, narrative, verification, and cognition.

Kind: `architecture_decision`; owner: `exo`; evidence: `decision-review`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-01@accepted`.

- Evidence taxonomy and provenance shared by epistemics, memory, relationships, narrative, verification, and cognition.
- The source recommended default is not proof that this ADR has been accepted.

## EXO-ADR-019 — Narrative version admission, historical immutability, tension preservation, and disclosure projections.

Kind: `architecture_decision`; owner: `exo`; evidence: `decision-review`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-01@accepted`.

- Narrative version admission, historical immutability, tension preservation, and disclosure projections.
- The source recommended default is not proof that this ADR has been accepted.

## EXO-ADR-020 — Purpose-bound information use, retention, derivation, disclosure, and deletion obligations.

Kind: `architecture_decision`; owner: `exo`; evidence: `decision-review`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-01@accepted`.

- Purpose-bound information use, retention, derivation, disclosure, and deletion obligations.
- The source recommended default is not proof that this ADR has been accepted.

## EXO-ADR-021 — Two-stage authorization: Exoskeleton local upper bound and WorldInterface final executable decision.

Kind: `architecture_decision`; owner: `exo`; evidence: `decision-review`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-01@accepted`.

- Two-stage authorization: Exoskeleton local upper bound and WorldInterface final executable decision.
- The source recommended default is not proof that this ADR has been accepted.

## EXO-ADR-022 — External persona and identity-binding model; no root-key custody in Exoskeleton.

Kind: `architecture_decision`; owner: `exo`; evidence: `decision-review`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-01@accepted`.

- External persona and identity-binding model; no root-key custody in Exoskeleton.
- The source recommended default is not proof that this ADR has been accepted.

## EXO-ADR-023 — Delegated work order, run, progress, steering, completion-proposal, and Agent Host boundaries.

Kind: `architecture_decision`; owner: `exo`; evidence: `decision-review`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-01@accepted`.

- Delegated work order, run, progress, steering, completion-proposal, and Agent Host boundaries.
- The source recommended default is not proof that this ADR has been accepted.

## EXO-ADR-024 — Independent verification, criterion evidence, acceptance reducer, and epistemic consequence.

Kind: `architecture_decision`; owner: `exo`; evidence: `decision-review`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-01@accepted`.

- Independent verification, criterion evidence, acceptance reducer, and epistemic consequence.
- The source recommended default is not proof that this ADR has been accepted.

## EXO-ADR-025 — Skill and `BehavioralComponent` provenance, compatibility, calibration, activation, degradation, and retirement.

Kind: `architecture_decision`; owner: `exo`; evidence: `decision-review`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-01@accepted`.

- Skill and `BehavioralComponent` provenance, compatibility, calibration, activation, degradation, and retirement.
- The source recommended default is not proof that this ADR has been accepted.

## EXO-ADR-026 — Improvement mutability rings, frozen `EvaluationPlan`, protected criteria, separated roles, and non-amplifying authority.

Kind: `architecture_decision`; owner: `exo`; evidence: `decision-review`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-01@accepted`.

- Improvement mutability rings, frozen `EvaluationPlan`, protected criteria, separated roles, and non-amplifying authority.
- The source recommended default is not proof that this ADR has been accepted.

## EXO-ADR-027 — External lifecycle-supervisor activation, rollback, quarantine, and continuity-assessment protocol.

Kind: `architecture_decision`; owner: `exo`; evidence: `decision-review`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-01@accepted`.

- External lifecycle-supervisor activation, rollback, quarantine, and continuity-assessment protocol.
- The source recommended default is not proof that this ADR has been accepted.

## EXO-ADR-028 — Viability projection, operational modes, protected reserves, recovery demand, and compromised-component handling.

Kind: `architecture_decision`; owner: `exo`; evidence: `decision-review`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-01@accepted`.

- Viability projection, operational modes, protected reserves, recovery demand, and compromised-component handling.
- The source recommended default is not proof that this ADR has been accepted.

## EXO-ADR-029 — Clean deletion inventory and forbidden-symbol/static-architecture checks.

Kind: `architecture_decision`; owner: `exo`; evidence: `decision-review`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-01@accepted`.

- Clean deletion inventory and forbidden-symbol/static-architecture checks.
- The source recommended default is not proof that this ADR has been accepted.

## EXO-ADR-030 — Operator authentication, mutation attribution, backup/restore, audit access, and protected release roots.

Kind: `architecture_decision`; owner: `exo`; evidence: `decision-review`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-01@accepted`.

- Operator authentication, mutation attribution, backup/restore, audit access, and protected release roots.
- The source recommended default is not proof that this ADR has been accepted.

## EXO-ADR-031 — Task Distribution versioning, sampling, holdout, expiry, and workload-integrity rules.

Kind: `architecture_decision`; owner: `exo`; evidence: `decision-review`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-01@accepted`.

- Task Distribution versioning, sampling, holdout, expiry, and workload-integrity rules.
- The source recommended default is not proof that this ADR has been accepted.

## EXO-ADR-032 — Capability Profile, Representation Profile, and Component Fingerprint canonicalization, compatibility, completeness, and calibration.

Kind: `architecture_decision`; owner: `exo`; evidence: `decision-review`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-01@accepted`.

- Capability Profile, Representation Profile, and Component Fingerprint canonicalization, compatibility, completeness, and calibration.
- The source recommended default is not proof that this ADR has been accepted.

## EXO-ADR-033 — Developmental metric vector, protected hard gates, normalization, missing evidence, and evaluator independence.

Kind: `architecture_decision`; owner: `exo`; evidence: `decision-review`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-01@accepted`.

- Developmental metric vector, protected hard gates, normalization, missing evidence, and evaluator independence.
- The source recommended default is not proof that this ADR has been accepted.

## EXO-ADR-034 — Controlled-probe fixed-dimension tolerances, pairing/randomization, confound treatment, and interaction estimation.

Kind: `architecture_decision`; owner: `exo`; evidence: `decision-review`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-01@accepted`.

- Controlled-probe fixed-dimension tolerances, pairing/randomization, confound treatment, and interaction estimation.
- The source recommended default is not proof that this ADR has been accepted.

## EXO-ADR-035 — Capability Frontier Assessment confidence, `Unknown`/`Mixed` policy, saturation threshold, and invalidation events.

Kind: `architecture_decision`; owner: `exo`; evidence: `decision-review`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-01@accepted`.

- Capability Frontier Assessment confidence, `Unknown`/`Mixed` policy, saturation threshold, and invalidation events.
- The source recommended default is not proof that this ADR has been accepted.

## EXO-ADR-036 — Developmental Campaign admission, resource ceilings, stagnation, stop/switch/defer policy, and portfolio priority.

Kind: `architecture_decision`; owner: `exo`; evidence: `decision-review`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-01@accepted`.

- Developmental Campaign admission, resource ceilings, stagnation, stop/switch/defer policy, and portfolio priority.
- The source recommended default is not proof that this ADR has been accepted.

## WI-AQ-G1 — Core vocabulary and fresh persistence lineage

Kind: `contract`; owner: `aq`; evidence: `contract-checkpoint`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `AQ-BASELINE-ACCEPTED@passed`.

- Target reference, data/artifact and causal mappings reconciled.
- Fresh persistence and rejection/replay checks pass.
- wi reviews its own mappings and applicable assumptions; a similarly named gate for another consumer is not an automatic pass.
- Historical AQ-NN references identify retained capability/evidence obligations of the completed source; they are not runnable work. Review actual consumer candidate-branch fixtures on the exact accepted AQ build; independent gate attestation is still required and is not inferred from source presence.

Historical evidence coverage, **not schedulable dependencies**: aq/AQ-02, aq/AQ-03.

## WI-AQ-G2 — Idempotent compound task admission

Kind: `contract`; owner: `aq`; evidence: `contract-checkpoint`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `AQ-BASELINE-ACCEPTED@passed`.

- Created/AlreadyExists preserve durable identities; mismatched digest conflicts.
- Admission and local outbox retry behavior pass race/crash tests.
- wi reviews its own mappings and applicable assumptions; a similarly named gate for another consumer is not an automatic pass.
- Historical AQ-NN references identify retained capability/evidence obligations of the completed source; they are not runnable work. Review actual consumer candidate-branch fixtures on the exact accepted AQ build; independent gate attestation is still required and is not inferred from source presence.

Historical evidence coverage, **not schedulable dependencies**: aq/AQ-04.

## WI-AQ-G3 — Durable signals, waits, deadlines, checkpoints and resume

Kind: `contract`; owner: `aq`; evidence: `contract-checkpoint`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `AQ-BASELINE-ACCEPTED@passed`.

- Early/late/duplicate signals, wait establishment, deadline/cancel races and restart converge.
- Checkpoint and matched-signal references survive; no process-local fallback.
- wi reviews its own mappings and applicable assumptions; a similarly named gate for another consumer is not an automatic pass.
- Historical AQ-NN references identify retained capability/evidence obligations of the completed source; they are not runnable work. Review actual consumer candidate-branch fixtures on the exact accepted AQ build; independent gate attestation is still required and is not inferred from source presence.

Historical evidence coverage, **not schedulable dependencies**: aq/AQ-05, aq/AQ-06, aq/AQ-07.

## WI-AQ-G4 — Attempt disposition and transactional child workflow

Kind: `contract`; owner: `aq`; evidence: `contract-checkpoint`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `AQ-BASELINE-ACCEPTED@passed`.

- Lease-fenced dispositions and atomic child-admission/parent-wait behavior pass.
- Completion, cancellation, and output publication recover without semantic reinterpretation.
- wi reviews its own mappings and applicable assumptions; a similarly named gate for another consumer is not an automatic pass.
- Historical AQ-NN references identify retained capability/evidence obligations of the completed source; they are not runnable work. Review actual consumer candidate-branch fixtures on the exact accepted AQ build; independent gate attestation is still required and is not inferred from source presence.

Historical evidence coverage, **not schedulable dependencies**: aq/AQ-08, aq/AQ-09.

## EXO-AQ-G1 — Core vocabulary and fresh persistence lineage

Kind: `contract`; owner: `aq`; evidence: `contract-checkpoint`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `AQ-BASELINE-ACCEPTED@passed`.

- Target reference, data/artifact and causal mappings reconciled.
- Fresh persistence and rejection/replay checks pass.
- exo reviews its own mappings and applicable assumptions; a similarly named gate for another consumer is not an automatic pass.
- Historical AQ-NN references identify retained capability/evidence obligations of the completed source; they are not runnable work. Review actual consumer candidate-branch fixtures on the exact accepted AQ build; independent gate attestation is still required and is not inferred from source presence.

Historical evidence coverage, **not schedulable dependencies**: aq/AQ-02, aq/AQ-03.

## EXO-AQ-G2 — Idempotent compound task admission

Kind: `contract`; owner: `aq`; evidence: `contract-checkpoint`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `AQ-BASELINE-ACCEPTED@passed`.

- Created/AlreadyExists preserve durable identities; mismatched digest conflicts.
- Admission and local outbox retry behavior pass race/crash tests.
- exo reviews its own mappings and applicable assumptions; a similarly named gate for another consumer is not an automatic pass.
- Historical AQ-NN references identify retained capability/evidence obligations of the completed source; they are not runnable work. Review actual consumer candidate-branch fixtures on the exact accepted AQ build; independent gate attestation is still required and is not inferred from source presence.

Historical evidence coverage, **not schedulable dependencies**: aq/AQ-04.

## EXO-AQ-G3 — Durable signals, waits, deadlines, checkpoints and resume

Kind: `contract`; owner: `aq`; evidence: `contract-checkpoint`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `AQ-BASELINE-ACCEPTED@passed`.

- Early/late/duplicate signals, wait establishment, deadline/cancel races and restart converge.
- Checkpoint and matched-signal references survive; no process-local fallback.
- exo reviews its own mappings and applicable assumptions; a similarly named gate for another consumer is not an automatic pass.
- Historical AQ-NN references identify retained capability/evidence obligations of the completed source; they are not runnable work. Review actual consumer candidate-branch fixtures on the exact accepted AQ build; independent gate attestation is still required and is not inferred from source presence.

Historical evidence coverage, **not schedulable dependencies**: aq/AQ-05, aq/AQ-06, aq/AQ-07.

## EXO-AQ-G4 — Attempt disposition and transactional child workflow

Kind: `contract`; owner: `aq`; evidence: `contract-checkpoint`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `AQ-BASELINE-ACCEPTED@passed`.

- Lease-fenced dispositions and atomic child-admission/parent-wait behavior pass.
- Completion, cancellation, and output publication recover without semantic reinterpretation.
- exo reviews its own mappings and applicable assumptions; a similarly named gate for another consumer is not an automatic pass.
- Historical AQ-NN references identify retained capability/evidence obligations of the completed source; they are not runnable work. Review actual consumer candidate-branch fixtures on the exact accepted AQ build; independent gate attestation is still required and is not inferred from source presence.

Historical evidence coverage, **not schedulable dependencies**: aq/AQ-08, aq/AQ-09.

## WI-AQ-G5 — ActionQueue RC and full conformance for WorldInterface

Kind: `release_candidate`; owner: `aq`; evidence: `contract-checkpoint`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `AQ-BASELINE-ACCEPTED@passed`.

- AQ-13 full conformance passes against the exact immutable RC.
- The exact immutable AQ release candidate artifact is published to authorized consumers and independently verified; a branch name or unverified Git pin is insufficient.
- AQ-14 publication is not required by this gate.
- Historical AQ-NN references identify retained capability/evidence obligations of the completed source; they are not runnable work. Review actual consumer candidate-branch fixtures on the exact accepted AQ build; independent gate attestation is still required and is not inferred from source presence.

Historical evidence coverage, **not schedulable dependencies**: aq/AQ-13.

## AQ-PUBLISHED — Published AQ-CONT-1 release

Kind: `release`; owner: `aq`; evidence: `release-publication`.

Prerequisites: `AQ-BASELINE-ACCEPTED@passed`.

- The original AQ-14 release exit obligations are independently reviewed against the accepted exact implementation/build and conformance revision 16.
- Actual immutable published artifact, digest, retrieval verification and release authority approval are evidenced; neither source completion, a tag, an empty blockers file nor Python planning tests proves publication.

Historical evidence coverage, **not schedulable dependencies**: aq/AQ-14.

## EXO-AQ-G5 — ActionQueue release-grade pin for Exoskeleton

Kind: `contract`; owner: `aq`; evidence: `contract-checkpoint`.

Prerequisites: `AQ-PUBLISHED@passed`; `AQ-BASELINE-ACCEPTED@passed`.

- Preserve both AQ-13 and AQ-14 prerequisites from the EXO plan.
- Exact AQ implementation, conformance revision and fixtures are accepted by Exoskeleton.
- Historical AQ-NN references identify retained capability/evidence obligations of the completed source; they are not runnable work. Review actual consumer candidate-branch fixtures on the exact accepted AQ build; independent gate attestation is still required and is not inferred from source presence.

Historical evidence coverage, **not schedulable dependencies**: aq/AQ-13, aq/AQ-14.

## EXO-WI-G1 — Fabric protocol and fresh persistence

Kind: `contract`; owner: `wi`; evidence: `contract-checkpoint`.

Prerequisites: `wi/WI-02@accepted`.

- Protocol, IDs, resources, principal/persona and artifact/evidence mappings compile and replay.
- Foundational commissioning, acting-capacity, information-use, lifecycle and provenance profiles are reconciled where applicable.

## EXO-WI-G2 — Ingress, egress, authorization and receipts

Kind: `contract`; owner: `wi`; evidence: `contract-checkpoint`.

Prerequisites: `wi/WI-03@accepted`; `wi/WI-04@accepted`; `wi/WI-05@accepted`.

- Observation delivery/acknowledgment and intent-first dispatch pass.
- Receipt/outcome semantics and source-to-sink authorization/information-use fixtures are reconciled.

## EXO-WI-G3 — Connector, Flow and continuation runtime

Kind: `contract`; owner: `wi`; evidence: `contract-checkpoint`.

Prerequisites: `wi/WI-06@accepted`; `wi/WI-07@accepted`; `wi/WI-08@accepted`.

- Connector ambiguity/reconciliation, common ExecutionPlan and AQ continuations pass.
- Uncertain effects and callbacks resume from already committed authoritative results.

## EXO-WI-G4 — Workers, sandbox, catalog, deployment and identity/proof seams

Kind: `contract`; owner: `wi`; evidence: `contract-checkpoint`.

Prerequisites: `wi/WI-09@accepted`; `wi/WI-10@accepted`; `wi/WI-11@accepted`; `wi/WI-12@accepted`.

- Worker/candidate environment isolation, lifecycle events and artifact exchange pass.
- Capability catalog, real deployment clients, and optional identity/proof interfaces pass.
- WI-12 is required; optional providers do not erase the work item.

## EXO-WI-G5 — WorldInterface release-grade pin for Exoskeleton

Kind: `contract`; owner: `wi`; evidence: `contract-checkpoint`.

Prerequisites: `wi/WI-13@accepted`; `wi/WI-14@accepted`; `WI-PUBLISHED@passed`.

- Preserve WI-13 and WI-14 prerequisites, including published release evidence.
- Exact WI and AQ implementation/conformance tuples and lifecycle/developmental evidence profiles are frozen.

## WI-PUBLISHED — Published WI-FABRIC-2 release pinned to published AQ

Kind: `release`; owner: `wi`; evidence: `release-publication`.

Prerequisites: `wi/WI-14@accepted`; `AQ-PUBLISHED@passed`.

- WI-14 publication manifest pins the exact published AQ implementation and conformance package.

## EXO-PUBLISHED — Published EXO-V3 release pinned to both published upstreams

Kind: `release`; owner: `exo`; evidence: `release-publication`.

Prerequisites: `exo/EXO-19@accepted`; `AQ-PUBLISHED@passed`; `WI-PUBLISHED@passed`.

- EXO-19 publishable/accepted is not itself publication.
- Verify actual immutable EXO release publication and its exact upstream manifests.

## WI-DEPLOYMENT-PARITY — Actual embedded and authenticated daemon profiles available

Kind: `integration_evidence`; owner: `wi`; evidence: `contract-checkpoint`.

Prerequisites: `wi/WI-11@accepted`.

- The same boundary contract is exercised through actual embedded and remote profiles.
- EXO-11 has usable, pinned test surfaces for both; mock endpoints are not parity evidence.

## EXO-WI-TIME-REVIEW — Schema and semantic-time boundary review

Kind: `semantic_review`; owner: `stack`; evidence: `semantic-review`.

Prerequisites: `exo/EXO-01@accepted`; `wi/WI-01@accepted`.

- Approve the design-level EXO-04 boundary; do not require completed WI runtime or claim compiled integration.
- Any unresolved runtime mapping remains an assumption until the named conformance gate.

## EXO-WI-FACULTY-REVIEW — Remote faculty boundary and disclosure review

Kind: `semantic_review`; owner: `stack`; evidence: `semantic-review`.

Prerequisites: `exo/EXO-01@accepted`; `wi/WI-01@accepted`.

- Approve the design-level EXO-07 boundary; do not require completed WI runtime or claim compiled integration.
- Any unresolved runtime mapping remains an assumption until the named conformance gate.

## EXO-WI-DISCLOSURE-REVIEW — Persona, proof and disclosure semantic review

Kind: `semantic_review`; owner: `stack`; evidence: `semantic-review`.

Prerequisites: `exo/EXO-01@accepted`; `wi/WI-01@accepted`.

- Approve the design-level EXO-09 boundary; do not require completed WI runtime or claim compiled integration.
- Any unresolved runtime mapping remains an assumption until the named conformance gate.

## EXO-ADR-037 — Pinned Kata/containerd instance profile: supported host/VMM/guest assets, actual runtime selection, storage durability, limits, external supervisor and qualification evidence.

Kind: `architecture_decision`; owner: `exo`; evidence: `decision-review`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-01@accepted`.

- Pinned Kata/containerd instance profile: supported host/VMM/guest assets, actual runtime selection, storage durability, limits, external supervisor and qualification evidence.
- Recorded decision approval is separate from runtime qualification.

## EXO-ADR-038 — Consumer binding to WI-ADR-016 / WI-WORKER-EXECUTION-1, exact process-provider controls and limitations, stricter EXO admission, and external-worker resource seam.

Kind: `architecture_decision`; owner: `exo`; evidence: `decision-review`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-01@accepted`; `WI-ADR-016@passed`.

- Consumer binding to WI-ADR-016 / WI-WORKER-EXECUTION-1, exact process-provider controls and limitations, stricter EXO admission, and external-worker resource seam.
- Recorded decision approval is separate from runtime qualification.

## WI-WORKER-G1 — Provider definition and representation

Kind: `profile`; owner: `wi`; evidence: `profile-checkpoint`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `wi/WI-02/domain@verified`; `wi/WI-09/domain@verified`; `wi/WI-10/domain@verified`; `WI-ADR-016@passed`; `WI-ADR-005@passed`; `WI-ADR-006@passed`; `WI-ADR-008@passed`; `WI-ADR-010@passed`.

- WI-ADR-016 and referenced authorization/evidence ADR clauses reviewed; limitations, field mapping and operation capability contract frozen.
- Source-owned evidence cases are bound in acceptance_coverage; owner PR IDs attribute work and are not automatic accepted-parent prerequisites.

## WI-WORKER-G2 — Qualified-profile admission and truthful evidence

Kind: `profile`; owner: `wi`; evidence: `profile-checkpoint`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `WI-WORKER-G1@passed`; `wi/WI-04/domain@verified`; `wi/WI-05/domain@verified`.

- Exact-profile admission, unsupported-control denials and worker/instance evidence separation proven in producer fixtures.
- Source-owned evidence cases are bound in acceptance_coverage; owner PR IDs attribute work and are not automatic accepted-parent prerequisites.

## WI-WORKER-G3 — Real process lifecycle and crash convergence

Kind: `profile`; owner: `wi`; evidence: `profile-checkpoint`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `WI-WORKER-G1@passed`; `WI-WORKER-G2@passed`; `wi/WI-09/process-provider@verified`; `WI-AQ-G1@passed`; `WI-AQ-G2@passed`; `WI-AQ-G3@passed`; `WI-AQ-G4@passed`.

- Reviewed processes supervised via real WI/AQ; idempotent start, process ownership, event durability and termination/recovery proved.
- Source-owned evidence cases are bound in acceptance_coverage; owner PR IDs attribute work and are not automatic accepted-parent prerequisites.

## WI-WORKER-G4 — Embedded provider proof and portable handoff

Kind: `profile`; owner: `wi`; evidence: `profile-checkpoint`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `WI-WORKER-G3@passed`; `wi/WI-09/process-provider@verified`; `wi/WI-10/process-catalog@verified`; `wi/WI-11/embedded-runtime@verified`; `wi/WI-13/worker-conformance@verified`; `wi/WI-14/worker-handoff@verified`; `WI-AQ-G1@passed`; `WI-AQ-G2@passed`; `WI-AQ-G3@passed`; `WI-AQ-G4@passed`.

- WI-owned embedded harness, artifacts and external-provider seam pass without EXO/platform/Kata dependency or inflated assurance claims.
- Source-owned evidence cases are bound in acceptance_coverage; owner PR IDs attribute work and are not automatic accepted-parent prerequisites.

## WI-WORKER-G5 — Bounded external supervisor boundary

Kind: `profile`; owner: `wi`; evidence: `profile-checkpoint`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `WI-WORKER-G1@passed`; `WI-WORKER-G2@passed`; `wi/WI-11/supervisor-boundary@verified`; `wi/WI-13/supervisor-conformance@verified`; `WI-AQ-G1@passed`; `WI-AQ-G2@passed`; `WI-AQ-G3@passed`; `WI-AQ-G4@passed`.

- Authenticated lifecycle adapter and results survive target shutdown; real instance qualification remains EXO-owned.
- Source-owned evidence cases are bound in acceptance_coverage; owner PR IDs attribute work and are not automatic accepted-parent prerequisites.

## EXO-ENV-G1 — Profile and qualification decisions

Kind: `profile`; owner: `exo`; evidence: `profile-checkpoint`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-03/domain@verified`; `exo/EXO-18/instance-design@verified`; `EXO-ADR-037@passed`; `EXO-ADR-038@passed`; `WI-WORKER-G1@passed`.

- EXO-ADR-037 and EXO-ADR-038 approved; manifest obligations and proof limits frozen
- Source-owned evidence cases are bound in acceptance_coverage; owner PR IDs attribute work and are not automatic accepted-parent prerequisites.

## EXO-ENV-G2 — Kata instance realization

Kind: `profile`; owner: `exo`; evidence: `profile-checkpoint`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `EXO-ENV-G1@passed`; `exo/EXO-18/instance-qualification@verified`.

- actual pinned host/VM evidence, controls, persistence bindings and downgrade refusal
- Source-owned evidence cases are bound in acceptance_coverage; owner PR IDs attribute work and are not automatic accepted-parent prerequisites.

## EXO-ENV-G3 — Embedded process-worker lifecycle

Kind: `profile`; owner: `exo`; evidence: `profile-checkpoint`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `WI-EMBEDDED-WORKER-PROOF-1@passed`; `exo/EXO-12/embedded-worker@verified`; `exo/EXO-13/embedded-acceptance@verified`.

- real embedded WI/AQ lifecycle and independent acceptance with declared process-only assurance
- Source-owned evidence cases are bound in acceptance_coverage; owner PR IDs attribute work and are not automatic accepted-parent prerequisites.

## EXO-ENV-G4 — Durable lifecycle and recovery

Kind: `profile`; owner: `exo`; evidence: `profile-checkpoint`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `EXO-ENV-G2@passed`; `WI-WORKER-G5@passed`; `exo/EXO-15/embedded-lifecycle@verified`; `exo/EXO-16/embedded-recovery@verified`.

- single-host operator-controlled lifecycle, compatible rollback, quiesced restore and crash convergence
- Source-owned evidence cases are bound in acceptance_coverage; owner PR IDs attribute work and are not automatic accepted-parent prerequisites.

## EXO-ENV-G5 — Embedded viability and external-worker seam

Kind: `profile`; owner: `exo`; evidence: `profile-checkpoint`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `EXO-ENV-G2@passed`; `EXO-ENV-G3@passed`; `EXO-ENV-G4@passed`; `WI-WORKER-G4@passed`; `exo/EXO-12/embedded-worker@verified`; `exo/EXO-14/embedded-provenance@verified`; `exo/EXO-19/embedded-viability@verified`.

- representative proof workload, portability fixtures, provenance and no unsupported release claims
- Source-owned evidence cases are bound in acceptance_coverage; owner PR IDs attribute work and are not automatic accepted-parent prerequisites.

## WI-EMBEDDED-WORKER-PROOF-1 — WI-owned real embedded process-provider proof

Kind: `partial_milestone`; owner: `wi`; evidence: `profile-checkpoint`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `WI-WORKER-G1@passed`; `WI-WORKER-G2@passed`; `WI-WORKER-G3@passed`; `WI-WORKER-G4@passed`.

- All named checkpoint evidence is reviewed and valid on one compatible bound generation.
- This partial milestone does not accept parent work items, publish a release, or qualify unimplemented platform/external/hostile-code profiles.

## EXO-EMBEDDED-VIABILITY-1 — Actual Kata-hosted embedded Vessel viability

Kind: `partial_milestone`; owner: `exo`; evidence: `profile-checkpoint`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `EXO-ENV-G1@passed`; `EXO-ENV-G2@passed`; `EXO-ENV-G3@passed`; `EXO-ENV-G4@passed`; `EXO-ENV-G5@passed`.

- All named checkpoint evidence is reviewed and valid on one compatible bound generation.
- This partial milestone does not accept parent work items, publish a release, or qualify unimplemented platform/external/hostile-code profiles.

## WI-EMBEDDED-CORE-1 — Verified embedded core, distinct from full WI parent acceptance

Kind: `profile`; owner: `wi`; evidence: `profile-checkpoint`.

Prerequisites: `STACK-PLAN-ACCEPTED@passed`; `wi/WI-02/integration@verified`; `wi/WI-03/integration@verified`; `wi/WI-04/integration@verified`; `wi/WI-05/integration@verified`; `wi/WI-06/integration@verified`; `wi/WI-07/integration@verified`; `wi/WI-08/integration@verified`; `WI-AQ-G1@passed`; `WI-AQ-G2@passed`; `WI-AQ-G3@passed`; `WI-AQ-G4@passed`.

- Real embedded protocol/store/ingress/intent/receipt/executor/Flow/continuation conformance on exact AQ/WI implementation and fixture pins; no mock substitutes.
- Consumer assumption reconciliation covers the actual embedded surfaces. This is a newly scoped evidence barrier, never an alias for EXO-WI-G3 or accepted WI-06/07/08 parents.
- Parent-owned worker and supervisor cases remain mandatory at full parent acceptance; production activation needs ordinary authority and qualified profiles.
