# Concurrency map — implemented AQ baseline / v0.3.0

The current graph has 33 application parents, 69 slices, 95 checkpoints and 335 expanded milestone nodes. Display order is not an extra dependency. AQ is a source-pinned completed upstream dependency, not an active development project in this schedule.

After explicit STACK-PLAN-ACCEPTED, the WI-01 implementation and EXO-01 domain slices may start, while AQ-BASELINE-ACCEPTED becomes eligible for independent review. That review binds actual build/conformance evidence; source presence alone does not pass it. Pure domain slices can fan out without pretending their real integration adapters are ready.

WI-AQ-G1..G4 and EXO-AQ-G1..G4 preserve consumer-specific core, admission, continuation and disposition/coordination evidence. Embedded WI core supports the independent WI process-provider and supervisor paths. WI worker proof does not depend on EXO or Kata qualification; EXO consumes WI proof and adds its own host/lifecycle/acceptance evidence. No provider/consumer cycle is introduced.

EXO-EMBEDDED-VIABILITY-1 remains a scoped target, not full parent acceptance or a published product. WI-AQ-G5, EXO-AQ-G5, EXO-WI-G5, deployment parity and actual publication remain separate. AQ-PUBLISHED is never inferred from AQ source availability, conformance specifications or empty release blockers.

The canonical YAML is authoritative for the reviewed definition; human catalogs and JSON graph/preview are derived. Runtime state lives in a separate authenticated evidence ledger. All 48 additional baseline-case receipts and existing 76 WP/EE mappings are enforced at their declared producers. See IMPORT-SPEC.md for activation, evidence and fail-closed semantics.
