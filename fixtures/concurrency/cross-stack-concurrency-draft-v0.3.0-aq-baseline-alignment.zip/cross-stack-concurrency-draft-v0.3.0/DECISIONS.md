# Draft decisions — v0.3.0

All 18 require explicit map-bound approval; no previous approval is inherited.

## CS-D01 — Ordering versus dependency edges

Use source depends_on edges for active WI/EXO implementation. AQ is a completed source dependency, not a runnable merge lane; its original numbered work/ADR history remains provenance. Do not infer serial WI/EXO edges from display order or critical_path arrays.

## CS-D02 — Explicit early slices, not early parent completion

Permit only enumerated domain and scoped embedded slices to consume explicitly designated partial milestones. Original parent acceptance barriers remain. Non-domain early slices require CS-D12 and an explicit partial_scope; no inherited full-gate waiver.

## CS-D03 — Conservative mixed-item acceptance

Every parent requires all its designated slices, every original accepted predecessor and its original complete exit-gate attestation. A native/embedded proof may unblock another partial slice, never falsely accept a broad parent.

## CS-D04 — Keep the three G5 meanings separate

Keep the G5 meanings separate: WI-AQ-G5 retains full AQ conformance and an exact independently verified RC made available to consumers, without requiring AQ-PUBLISHED. EXO-AQ-G5 additionally requires AQ-PUBLISHED. EXO-WI-G5 retains WI-13 and WI-14. Historical AQ-13/AQ-14 are evidence coverage, not work to rerun.

## CS-D05 — Resolve body/table gate differences conservatively

Preserve the union of full PR-body and Appendix A requirements. EXO-PLAN-6 has already reconciled EXO-15 AQ G5; retain it on the full integration slice. New named embedded slices have source-authorized restricted scope, not weakened full gates.

## CS-D06 — EXO-11 deployment-parity verification

Add a verify-only WI-DEPLOYMENT-PARITY checkpoint based on WI-11 for EXO-11 embedded/daemon parity. Do not require the entire WI G4 bundle just for this check. EXO-11 may develop and merge its gated core adapters earlier, but full acceptance waits for real parity evidence.

## CS-D07 — Avoid receipt/connector and upstream/downstream cycles

Approve connector commit-point semantics (WI-ADR-007 and WI-ADR-010) before finalizing WI-05. Test convergence at the seam without depending on WI-06 completion, since WI-06 depends on WI-05. AQ-13 consumer fixtures do not require completed WI/EXO projects.

## CS-D08 — Human-reviewed import activation and evidence binding

This sidecar imports as an inactive draft. A designated integration owner must approve these choices, resolve project and plan-version bindings, and define verifier/reviewer identities before any scheduling. A source baseline commit is never evidence of current implementation progress.

## CS-D09 — Optional identity is not an optional work item

Keep WI-12 and all source release prerequisites. Optional identity providers mean optional runtime mechanisms; do not silently drop the SPI, neutrality checks, or WI-12 dependency from WI G4.

## CS-D10 — Safe resource defaults

Development branches/worktrees may run concurrently; one atomic merge lane exists per repository. Runtime integration tests use isolated stores and namespaces. Resource limits are deployment configuration, not inferred from PR numbers or primary_areas.

## CS-D11 — New source bindings and execution-profile ownership

Bind the actual supplied completed AQ source and the revised WI r5 / EXO r6 package bytes. EXO consumes the WI-owned process provider; incorporate only the r5 provider alignment actually supplied in prior-map snapshots, not an unprovided r5 archive. No prior approval or runtime evidence is inherited.

## CS-D12 — Enumerated embedded integration slices before full parent completion

Permit only the named embedded slices to use scoped evidence instead of uncompleted broad parents. All full parent dependency lists, original full upstream gates and release semantics remain unchanged. Native profile tests do not prove platform parity or stronger worker isolation.

## CS-D13 — Producer qualification and separate supervisor evidence

WI owns G1–G4 and its proof harness without EXO/Kata/platform prerequisites. Evaluation-only fixtures have separate operator approval and no ordinary admission until independent qualification. WI G5 remains a separate bounded supervisor path.

## CS-D14 — Kata resources are phase-specific, not universal prerequisites

The first Kata image/host work is an EXO-18 partial slice. Native implementation/merge tests can proceed without a Kata host; actual VM qualification, lifecycle and viability verification cannot. Approved resource/fixture access remains separate from graph eligibility.

## CS-D15 — Embedded viability is an evidence milestone, not a release waiver

Keep separate native provider proof, EXO consumer proof, actual instance qualification and full release acceptance. Full original slices remain required. Default planning focus may target embedded viability without expanding platform AQ/WI or DigiCorp.

## CS-D16 — Case coverage, invalidation and evidence reuse

Bind all 40 WP and 36 EE source cases to producing slices and checkpoints. A case pin or evidence change invalidates the affected claims. Existing AQ progress may be re-used only after independent verification against the unchanged source and runtime pins; reported nearly-done status creates no passes.

## CS-D17 — Core verification versus profile-complete parent acceptance

WI-06/07/08 generic core slices can be verified before later worker/supervisor tests owned by their parents. WI-EMBEDDED-CORE-1 supplies explicit bounded conformance for new embedded consumers, not EXO-WI-G3. Full parent acceptance additionally requires every newly assigned source-profile case and its producing-slice evidence. This prevents both a producer-proof cycle and premature parent completion.

## CS-D18 — Completed upstream AQ binding and additional adapter evidence

Remove AQ implementation and frozen ADR tasks from the active graph. Review AQ-BASELINE-ACCEPTED using exact source/build/proof identity without auto-passing consumer gates or publication. Require all 48 source-bound WI/EXO baseline cases in their assigned slice verification receipts. Reject activation if the importer cannot enforce this schema and evidence semantics.
