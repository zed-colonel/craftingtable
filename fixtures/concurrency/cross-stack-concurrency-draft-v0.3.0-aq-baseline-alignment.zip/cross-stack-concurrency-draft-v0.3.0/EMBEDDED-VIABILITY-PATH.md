# Embedded viability path — v0.3.0

These are dependency analyses, not completion claims. AQ implementation work is not on this path; source/build acceptance and consumer evidence remain required. The initial WI producer proof is native and independent of EXO/Kata. EXO adds actual Kata and consumer/lifecycle evidence. Full platform, hostile-worker, external-provider and release claims remain separate.

## WI-EMBEDDED-WORKER-PROOF-1

Milestones in prerequisite closure: 101. Release target: False.

Kata verification slices: None.

Required accepted parents: wi/WI-01, wi/WI-02, wi/WI-03, wi/WI-04, wi/WI-05.

## EXO-EMBEDDED-VIABILITY-1

Milestones in prerequisite closure: 254. Release target: False.

Kata verification slices: exo/EXO-15/embedded-lifecycle, exo/EXO-16/embedded-recovery, exo/EXO-18/instance-qualification, exo/EXO-19/embedded-viability.

Required accepted parents: exo/EXO-01, exo/EXO-02, exo/EXO-03, exo/EXO-04, exo/EXO-05, exo/EXO-06, exo/EXO-07, exo/EXO-08, exo/EXO-09, exo/EXO-10, wi/WI-01, wi/WI-02, wi/WI-03, wi/WI-04, wi/WI-05.

## FULL-STACK-RELEASE

Milestones in prerequisite closure: 335. Release target: True.

Kata verification slices: exo/EXO-15/embedded-lifecycle, exo/EXO-16/embedded-recovery, exo/EXO-18/instance-qualification, exo/EXO-19/embedded-viability.

Required accepted parents: exo/EXO-01, exo/EXO-02, exo/EXO-03, exo/EXO-04, exo/EXO-05, exo/EXO-06, exo/EXO-07, exo/EXO-08, exo/EXO-09, exo/EXO-10, exo/EXO-11, exo/EXO-12, exo/EXO-13, exo/EXO-14, exo/EXO-15, exo/EXO-16, exo/EXO-17, exo/EXO-18, exo/EXO-19, wi/WI-01, wi/WI-02, wi/WI-03, wi/WI-04, wi/WI-05, wi/WI-06, wi/WI-07, wi/WI-08, wi/WI-09, wi/WI-10, wi/WI-11, wi/WI-12, wi/WI-13, wi/WI-14.
