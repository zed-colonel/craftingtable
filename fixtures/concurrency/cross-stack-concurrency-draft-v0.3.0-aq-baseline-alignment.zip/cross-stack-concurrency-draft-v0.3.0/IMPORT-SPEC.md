# Proposed import and scheduling contract · schema 0.3.0

**Document kind:** `cross_stack_concurrency_map`  
**Purpose:** scheduling sidecar bound to implemented AQ source/build identity and immutable WI/EXO planning versions  
**Status:** draft for application design; not tested against the user's importer

## 1. Dispatch and authority

Dispatch on `kind` and `schema_version` before choosing a parser/schema. This is not a generic `pull_requests` work breakdown. Each source package remains authoritative for its original work items, dependencies, complete exit gates and test obligations. The sidecar supplies reviewed partial decomposition, phase prerequisites, resource requirements and case-to-evidence mappings. It is not a fourth project or a runtime provisioning API.

Unknown required semantics, unsupported schema versions, dangling references and cycles reject the complete import. Never ignore an unsupported partial-scope or evidence requirement and proceed with weaker scheduling.

## 2. Retained v0.2 field semantics (also required by v0.3)

| Field or behavior | Retained requirement |
|---|---|
| `source_archives` | Three repository-qualified ZIP bindings replace the singular old combined `source_archive`. |
| `source_files` | Plans, work breakdowns and execution/provider supplements are all bound; JSON references are supported. |
| `previous_definition` | Inert previous-map snapshot and hash; `approval_inherited` is always false. |
| `repositories[].supplement_sources` | Exact supplement set for the selected immutable plan version. |
| `slices[].partial_scope` | `full`, `domain`, `embedded-proof` or `supervisor-proof`; governs reviewed early decomposition. |
| `resources_by_phase` and `resource_profiles` | Separate start/merge/verify resource needs; missing hardware blocks hardware verification, not unrelated native work. |
| `acceptance_coverage` | The 40 WP and 36 EE case records bind source hashes, source owner, checkpoint, producers and hardware requirements. |
| Parent `source_profile_case_ids` / `profile_evidence_slices` | All owner-assigned new cases remain mandatory, including evidence produced elsewhere. |
| `planning_targets` | Producer proof, embedded viability and full stack publication are separate targets. |
| New checkpoint kinds | `profile` and `partial_milestone`; neither implies parent completion or a product release. |

An application with only the 0.1.0 parser must not auto-upgrade field names and activate. Implement the new semantics, revalidate the complete source-bound graph, and obtain version-specific approval.

## 3. Atomic import transaction

1. Parse bounded UTF-8 YAML. Reject duplicate/non-string keys, aliases/anchors, merge keys, unknown tags and excessive nesting/size. For ZIPs, reject path traversal, links, excessive expansion and duplicate member names; do not execute imported code. The supplied validator reads ZIP members without extracting them, but does not replace a production ZIP-ingestion security layer.
2. Validate the draft schema and all semantic constraints. Resolve source snapshots and compare exact source hashes against the three selected immutable application plan versions. A `.source.txt` file is supporting evidence, not a new plan to import.
3. Verify EXO's provider-reference JSON against the three authoritative WI provider files. Matching work-breakdown IDs or bytes alone is insufficient when the plan or supplements changed.
4. Resolve WI/EXO aliases to their application projects and immutable plan versions; resolve AQ to the implemented upstream dependency binding, not a new runnable plan. Bind every namespaced source work ID and canonical complete source-record fingerprint. Do not resolve an implicit “latest.”
5. Resolve all slices, checkpoints, coverage entries, cases, evidence profiles, resource profiles, reviewer roles and target choices. The source coverage owner is not itself an accepted-parent prerequisite.
6. Build the expanded milestone graph and reject unknown nodes or cycles. Compare original parent dependencies, full gate evidence mappings, full release criteria, assigned cases and explicit retirement of completed AQ work. Check that the declared embedded route has no accidental full-platform/consumer cycle.
7. Persist the whole definition and bindings as **inactive** in a single transaction. No new real tasks, fixture runs, grants, completed PRs or checkpoint passes are created during import.
8. Present CS-D01 through CS-D18 to the integration owner. Bind independent reviewer identities, evidence verifiers, resource capacity and the desired planning target. A separately recorded, map-digest-bound `STACK-PLAN-ACCEPTED` attestation activates scheduling.

Idempotent definition identity is `(map_id, revision, content_digest)`. Same ID/revision with different content is a conflict, not an overwrite. Historical definitions remain inspectable. Only one reviewed generation may govern a selected plan set at a time.

Source archive hashes in the supplied map are planning provenance, not a trusted signature. The application must establish where its input packages and review authority came from.

## 4. Persistent application entities

| Entity | Required role |
|---|---|
| Concurrency definition | Immutable source-bound map, schema, revision, digest and reviewed decisions |
| Plan binding | Repository alias to exact project/plan version and all relevant source artifacts |
| Parent binding | Existing work item and its full source-record fingerprint; no duplicate project work |
| Slice | Subordinate scope and phase rules; may map to a physical PR or several reviewable changes |
| Requirement | Typed `(kind, id, state)` all-of edge |
| Case binding | Exact source case, owner attribution, producer slice and checkpoint obligations |
| Checkpoint definition | Required producers, pass criteria, scope, evidence profile and invalidation rules |
| Evidence attestation | Independent identity, exact subjects/pins/cases, immutable artifact digest and results |
| Validity projection | Whether evidence is applicable to the currently active bindings; separate from history |
| Resource allocation | Actual approved host/worktree/test state/merge-lane reservation, with lifetime and limits |

There are 33 active WI/EXO source work items and 69 subordinate slices, not additional top-level projects. Fourteen historical AQ parents are retained only in provenance; no AQ implementation/merge lane is active.

## 5. Phase semantics

A `work_item` requirement always means the **full parent accepted**. A `slice` requirement means exactly `started`, `merged` or `verified` for its declared scope. A `checkpoint` requirement means an applicable independently evidenced pass, not an eligible review.

All prerequisite arrays use all-of semantics. Missing, revoked, stale or incompatible evidence blocks the consuming phase.

### Start

The active map is approved, all `start_requires` are valid, the development assignment is authorized and its start resource profile is allocated. Starting code work does not authorize external fixture execution or production activation.

### Merge

Start requirements still hold. All `merge_requires`, source-applicable pre-merge tests, source-due ADRs, scope/isolation review and exact branch/code bindings are valid. Acquire the repository's single merge lane only after these checks; recheck on the actual proposed merge tree. Never hold the merge lane while awaiting an upstream gate or Kata host.

Early domain work remains behind isolated ports/inactive composition roots. Named embedded integration slices may merge actual bounded implementation only after real scoped upstream conformance; this does not enable ordinary provider use or waive target activation controls. A mock is never a durable production adapter.

### Verify

Merge and its prerequisites remain valid. All `verify_requires`, producing case results and evidence-profile obligations apply to the actual implementation and environment pins. Allocate verification resources only for the test activity. Hardware-dependent cases require actual host-side evidence and cannot be verified with native fixtures.

Before-merge tests stay before merge. Separate deployed-profile verification exists only for the explicitly declared partial scope; it is not permission to defer required source tests arbitrarily.

### Accept a parent

All original parent predecessors are accepted. Every owned slice is verified. All `source_profile_case_ids` have applicable evidence, including their `profile_evidence_slices`. An independent attestation verifies the **entire** original exit gate and all applicable source requirements.

A foreign producing slice can supply evidence for an owner without transferring the responsibility. For example, WI-09/process-provider tests worker start ambiguity owned by WI-06, and WI-13/supervisor-conformance supplies WI-06's later supervisor cases. WI-06 core verification is available earlier; its full parent remains open until those obligations are met.

## 6. Full versus scoped upstream checkpoints

Keep the fifteen original AQ/WI G1–G5 checkpoints distinct. In particular, WI-AQ-G5 retains AQ-13 plus exact RC evidence; EXO-AQ-G5 retains AQ-13 and AQ-14; EXO-WI-G5 retains WI-13 and WI-14. Unrelated gates with similar names are not aliases.

The original EXO-WI-G3 still requires accepted WI-06/07/08. New `WI-EMBEDDED-CORE-1` is separately scoped actual core evidence used only by the explicit embedded route. Its approval does not alter those full parents or gates. Each consumer must reconcile its own applicable mappings and assumptions on exact pins.

Checkpoint `evidence_owners` attributes source work. Do not turn it into `requires parents accepted`, particularly for a checkpoint produced by part of its owning PR. The `requires` array is the actual dependency definition.

## 7. Evidence contracts and qualification bootstrap

For each attestation, bind the active definition digest; source-profile/case versions; candidate and merged code revisions; actual AQ/WI/EXO conformance pins; policy/grant and reviewer identities; fixture/executable/image/configuration digests; and environment/resource evidence as applicable. Evidence from different pins cannot simply be unioned into a pass. Independent review must explicitly establish applicability or rerun the affected work.

A producer declaring a control is not evidence that it is enforced. WI's definition/profile/case hashes are not runtime qualification. A worker receipt is not accepted work. A guest report is not host-side Kata evidence. A simulated external-provider fixture is not a qualified external service.

The unqualified process provider can run source-approved fixture tests using an explicit operator-approved evaluation-only registration. That approval is required **before every relevant execution**, not retrospectively at verification. It retains all source exclusions and mandatory-control requirements. Ordinary admission stays disabled until independent producer qualification and a separate authorized enablement. The map itself grants none of these actions.

The trusted evidence verifier and operator permissions live outside the candidate/worker. The reference Python helpers intentionally do not authenticate evidence, invoke target code, issue credentials or approve deployments.

## 8. Resource eligibility and proof scope

`isolated-development-workspace` requires a unique worktree and test state. `controlled-native-test-host` supports approved non-sensitive native fixtures and real embedded AQ/WI where claimed, with no Kata prerequisite. `kata-instance-test-host` requires a real approved virtualization allocation and the selected instance profile's controls.

Resource profile declarations never assert that a host is available. The application distinguishes dependency-blocked, review/evidence-blocked, authorization-blocked and resource-blocked. Resource availability is not itself qualification evidence. Do not treat resources as interchangeable merely because both can execute a process.

Use separate instance data directories for concurrent integration runs. Review shared protocol/storage mutations and actual host capacity. Reserve multiple required resources atomically in a stable order and release reservations when blocked or finished.

Host runtime-management access remains with an operator-owned supervisor, not an agent work item or delegated worker. The process provider is restricted to reviewed fixtures and non-sensitive inputs; nesting inside the Kata Vessel does not independently isolate workers.

## 9. Focus targets and completion

`planning_targets` separates `WI-EMBEDDED-WORKER-PROOF-1`, `EXO-EMBEDDED-VIABILITY-1` and `FULL-STACK-RELEASE`. The suggested focus is embedded viability; actual selection is a reviewed application binding.

For a chosen target, compute its transitive prerequisite closure and prioritize eligible uncompleted work in that closure. Do not mark unrelated parents complete, delete their requirements, or stop other independently approved work. In particular, finishing the existing AQ release may proceed concurrently under its existing plan.

Producer proof cannot depend on EXO or a Kata host. WI supervisor G5 is separate from basic process proof. Actual EXO instance/recovery/viability claims require real Kata evidence. Full parent/release routes retain their remote/platform and stronger assurance obligations; a later release-scope reduction requires a separate source amendment.

## 10. Invalidation and revision transition

Evidence history is immutable. Its current applicability is a projection over the active bindings. Changed definition, source profile, policy, code, fixture, environment, case or reviewer trust can invalidate affected milestones and their dependents. Preserve historical acceptance records without presenting their old qualification as current.

Do not invalidate unrelated work unnecessarily. For example, loss of a Kata qualification does not invalidate native WI provider conformance; loss of WI profile eligibility invalidates dependent EXO consumption even if the outer VM remains qualified. Quarantine can block new starts while separately authorized inspection, stopping and reconciliation remain possible.

Changing the active map during work does not silently kill a process or authorize replacement. Pause new dispatch and re-evaluate the assignment at phase boundaries; real teardown/cleanup requires its normal owner and grant. Rebase, pin changes and changed test artifacts require renewed applicability review.

No old checkpoint approval automatically transfers into v0.3.0. A reviewer may adopt compatible unchanged evidence through a new binding record. The exact implemented AQ source is supplied, but no current Git commit, runtime conformance pass or publication receipt is inferred; the old AQ work/ADR scheduling graph is retired.

## 11. Reference implementation and limitations

`validate_map.py` validates schema, exact source hashes and references, full parent/gate retention, case coverage, scoped invariants and the expanded dependency graph. `project_validity` and `resource_eligibility` demonstrate synthetic validity/resource separation; they do not implement authentication, independent review or production scheduling.

The validator also contains checks specific to this delivered stack revision (including expected source and case counts). A generic production importer should implement schema/reference semantics generally, with plan-specific invariants supplied through a separately reviewed contract rather than hardcoding these counts for unrelated projects.

Exit codes are 0 for a valid definition, 1 for schema/semantic/source validation failure, and 2 for input/parsing errors. The optional archive-verification mode compares the original ZIPs and their selected members without executing them.

The user application's importer was not run. The draft's successful static tests do not prove target code, sandbox security, process isolation, containerd/Kata deployment, operator authorization or real checkpoint completion.

## 12. Mandatory v0.3.0 implemented-upstream and baseline-case semantics

Only schema 0.3.0 can activate this definition. A v0.1/v0.2 importer must reject activation rather than ignoring these additions. A repository with `role: implemented_upstream` binds source/build/evidence, has no target branch or merge lock, and contributes no runnable parent/slice/ADR nodes. The supplied AQ ZIP has no current Git commit; its historical pre-contract commit must not be promoted to one. `aq_baseline_binding` pins the supplied archive, full source tree and conformance revision 16.

`AQ-BASELINE-ACCEPTED` is an independently reviewed source/build/proof binding, initially unresolved. It replaces pending AQ producer work requirements without declaring any consumer gate or release passed. A new AQ defect/change, should one be found, requires a separate reviewed work item and a new baseline/map binding, not resurrection of all completed AQ tasks.

The fifteen original full consumer checkpoints remain distinct. Historical AQ-NN producer references preserve capability and release evidence coverage only. WI-AQ-G5 requires exact independently verified RC/conformance evidence, not AQ-PUBLISHED. EXO-AQ-G5 additionally requires actual AQ-PUBLISHED. Consumer G1..G4 may review candidate-branch fixtures before gated adapter merge; do not introduce a circular requirement for that already-verified merge.

`baseline_acceptance_coverage` binds 48 additional cases to exact source-record hashes, parent owners, producing slices and capability gates. `slices[].aq_baseline_case_ids` and `work_items[].aq_baseline_case_ids` are mandatory, not advisory tags. Slice verification and parent acceptance require every assigned passing case receipt on the active AQ build/conformance and consumer implementation pins. The 76 existing WP/EE mappings and all original full parent tests remain in force.

A baseline receipt includes `case_id`, `source_record_sha256`, `aq_archive_sha256`, `aq_build_revision`, `conformance_package_revision`, `consumer_revision`, `result: passed`, `result_artifact_sha256`, `fixture_sha256`, `environment_sha256` and `independent_review_reference`. Bind the receipt to the active map generation and the application evidence ledger; authenticate signers, reviewer independence, compatibility and revocation. Require exactly the assigned case set, not empty, duplicate, unknown, stale or planning-only receipts. The reference `validate_baseline_case_receipts` checks completeness and fields only; it does not authenticate evidence or grant a milestone pass.

Changing the accepted AQ source/build or a source case invalidates applicable receipts and dependent projections. Retain old evidence immutably, but re-review any adoption for this new generation. No automatic carry-forward, publication inference, fixture execution, grant or runtime activation occurs on import.
