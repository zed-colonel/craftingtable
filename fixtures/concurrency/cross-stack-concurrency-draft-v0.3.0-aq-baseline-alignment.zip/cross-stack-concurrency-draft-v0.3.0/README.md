# Cross-stack concurrency draft — v0.3.0

**Status: inactive draft; every checkpoint unresolved.** This schedules WorldInterface and Exoskeleton against the supplied implemented ActionQueue baseline. It does not reopen completed AQ work or assert successful runtime integration.

The canonical `cross-stack-concurrency-map.yaml` is governed by schema 0.3.0. Read `REVISION-NOTES.md`, `IMPORT-SPEC.md`, `DECISIONS.md` and `SOURCE-BINDINGS.md` before activation. Use the revised WI r5 and EXO r6 packages as a matched set. The EXO r5 archive referenced by the previous map was not supplied; only its actually embedded provider-alignment snapshots were incorporated.

## Contents
33 application parents; 69 slices; 95 checkpoints; 30 source snapshots; 18 proposed decisions; 76 retained worker/execution case bindings plus 48 additional AQ-baseline case bindings. Original full parent tests, release gates and bounded proof restrictions remain in force.

```sh
python -B validate_map.py --graph-output milestone-graph.json
python -B validate_map.py --source-archives-root /path/to/the/three/archives
python -B -m unittest discover -v
sha256sum -c SHA256SUMS
```

The source-archive directory must contain the exact filenames in `SOURCE-BINDINGS.md`: the original supplied AQ source ZIP and the two revised planning ZIPs. Validation is structural/source-preservation and Python regression evidence, not the user's application importer, AQ Rust tests, actual WI/EXO integration or Kata qualification.

Source presence, prerequisite eligibility and static checks cannot pass AQ-BASELINE-ACCEPTED, consumer G1–G5 or AQ-PUBLISHED. A real importer must support the new completed-upstream role and case-receipt obligations, authenticate evidence and reject unsupported semantics. No old approval automatically transfers.

Prior map, catalogs and tests are retained under `provenance/supplied-v0.2.0/` as inert `.source.txt` files, not runnable plans. The source AQ files are never edited or included as an active implementation queue.
