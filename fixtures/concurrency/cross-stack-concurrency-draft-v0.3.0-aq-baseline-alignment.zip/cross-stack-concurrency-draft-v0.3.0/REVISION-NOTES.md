# v0.3.0 revision notes

The supplied v0.2.0 sidecar was bound to an old AQ planning archive and EXO r5, while the supplied EXO archive was r4. This revision binds the actual completed AQ source, WI r5 alignment package and EXO r6 alignment package. EXO incorporates only the provider-ownership content actually present in the supplied r5 source snapshots; the absent full r5 archive is not represented as verified.

Fourteen AQ parents/slices and seventeen pending AQ ADR checkpoints are retired into inert provenance. One unresolved AQ-BASELINE-ACCEPTED checkpoint replaces AQ producer-work prerequisites. The AQ deferred ADR remains historical. Existing publication and consumer evidence obligations are retained. There are now 33 active parents, 69 slices and 95 checkpoints.

Thirty exact source snapshots include the source lock/amendment/case matrices for both consumers and AQ's source README, release note and conformance-16 manifest. Forty-eight additional AQ adapter cases are assigned to slice verification receipts and parent owners. Eighteen proposed decisions include explicit approval of the completed-upstream migration. Schema 0.3.0 is required; unsupported semantics reject activation.

All source work identities/dependencies and full exit gates for WI/EXO remain. The bounded embedded/provider/Kata staging and 76 existing WP/EE case bindings remain. No prior approval, consumer conformance, host qualification or actual publication is inherited. No ActionQueue source file is modified.
