# Exact source bindings — v0.3.0

These are source/provenance bindings, not runtime or publication evidence. Verify all three archive hashes and all 30 embedded source-file hashes. No implicit latest version or previous-map approval is accepted.

## Archive bindings

| Repository | Exact local filename | Artifact | SHA-256 |
|---|---|---|---|
| aq | `actionqueue-main(1).zip` | source-0.2.0-conformance-16 | `f91f496f22772e8dda044b0cf2cf05cf2eafa9f86d6f0c7e0061b46e3926ffb1` |
| wi | `wi-fabric-2-foundational-package-r5-aq-baseline-alignment.zip` | r5-aq-baseline-alignment | `151dd46ca8c295964de5e82da6d6f01797c663a22b50f01df6ff9fb2db1a5e69` |
| exo | `exo-v3-comprehensive-design-package-r6-aq-baseline-alignment.zip` | r6-aq-baseline-alignment | `5e430bea7723785f70374e0aa377f5c0ab6731ab9c1d52a620b7a3cbfa976a5b` |

## Completed AQ identity

The original supplied AQ source ZIP is unchanged. Its complete source-tree SHA-256 is `a6a8f87272d76e94e69e10d8bcf0992296d1bf8e28ff3d9222374c3b8cdcc34e`, covering 571 files. No current implementation commit is supplied; `97c9dc26c19c697dbfb204ed503e82c5f053394f` is historical pre-contract provenance, not the completed implementation pin. Accept an independently verified build/commit/evidence tuple before real integration; actual publication is separate.

## Embedded source snapshots

| Source ID | Exact archive member | SHA-256 |
|---|---|---|
| aq-plan | `actionqueue-main/docs/planning/aq-cont-1/aq-cont-1-implementation-plan.md` | `542a76d1cfa450a543b898517516ef3bd01521ddbc578c7757b4e5e02e8b9f98` |
| aq-work-breakdown | `actionqueue-main/docs/planning/aq-cont-1/aq-cont-1-work-breakdown.yaml` | `e498242d837ff2acc00d24489842cce04550658c6f84076717bbace05767de5f` |
| wi-plan | `wi-fabric-2-foundational/wi-fabric-2-foundational-implementation-plan.md` | `32564920d4cb1fa43fcecf996ef7897aa38b5c70fe4c04ca89adbedde86e608e` |
| wi-work-breakdown | `wi-fabric-2-foundational/wi-fabric-2-foundational-work-breakdown.yaml` | `39adb49f1ebc0a5b11650315417857286bd3a34cb7bc6f7d0ad6f4a34c1d3ec4` |
| wi-worker-profile-md | `wi-fabric-2-foundational/wi-fabric-2-worker-execution-profile.md` | `9f597cffb7117dc679e9f001c25c7d54f2a6157f6ead563b0c7cbd11f45a04f9` |
| wi-worker-profile | `wi-fabric-2-foundational/wi-fabric-2-worker-execution-profile.yaml` | `6523baf56d14dafa4b199c7493dc030461cc061754c180b4c83006308e633986` |
| wi-worker-cases | `wi-fabric-2-foundational/wi-fabric-2-worker-execution-acceptance-matrix.yaml` | `9c11d92d056b0411ed4af00a8f076182d95c500acd6e360f42a3a0bdd8aec2eb` |
| wi-worker-assumptions | `wi-fabric-2-foundational/wi-fabric-2-worker-boundary-assumption-ledger.yaml` | `65bd7ca0b4fc1c4d116157b9ee05ac575e3da6bba0618dc35284303c5cd92d05` |
| wi-worker-handoff | `wi-fabric-2-foundational/WI-EXO-WORKER-HANDOFF.md` | `6c57c478f7e20cced8525e2fd4730888db82eff825308aa60d573d218f82b374` |
| wi-worker-rebinding | `wi-fabric-2-foundational/WORKER-CONCURRENCY-REBINDING.md` | `1c21f8f0759395f76e14d3bda615d0e15e43fe7a65e0fa419906b47d8385f303` |
| wi-worker-runbook | `wi-fabric-2-foundational/WORKER-PROVIDER-QUALIFICATION.md` | `1e466fd540feb30c51cd676a9e2461fe7861a36fb333e4ee50d601eb0dda8c65` |
| exo-plan | `exo-v3-comprehensive/exo-v3-comprehensive-implementation-plan.md` | `bd92690d91f1af11991de811c12818c62569571ee32ce81ef3462597759eb40e` |
| exo-work-breakdown | `exo-v3-comprehensive/exo-v3-comprehensive-work-breakdown.yaml` | `a8f05709f6d150adf26ce916ac84c555fd0cdfa829790bd18e69228ba9d32a60` |
| exo-execution-profile | `exo-v3-comprehensive/exo-v3-execution-profile.yaml` | `b026ca5cc123907404007846a9f51eaa01e1dcc80c44303c92ea85640243df8a` |
| exo-execution-md | `exo-v3-comprehensive/exo-v3-execution-environment.md` | `815b49979abeef0899809332334327de647eefea426d88b6867fa85bd3a091ef` |
| exo-execution-cases | `exo-v3-comprehensive/exo-v3-execution-environment-acceptance-matrix.yaml` | `7a4bf0021be2bc666d9aca870e794f97fdb93d788446832743508ea47ad65e09` |
| exo-provider-reference | `exo-v3-comprehensive/wi-worker-provider-reference.json` | `44ecf7cb708cc8266fd84b8b2f9b0a5d2a610fc5fbb43a77fa723621bfb54fad` |
| exo-provider-alignment | `exo-v3-comprehensive/WI-PROVIDER-ALIGNMENT.md` | `fa2cca899765033220951e2f6c0ccb2d8355f796556040995bd51138c464a878` |
| exo-execution-rebinding | `exo-v3-comprehensive/EXECUTION-CONCURRENCY-REBINDING.md` | `96bd8e9b7ae1e8d113a95a4a4233fb698a6e724f9b0b0e1fea4369e1fb545745` |
| exo-instance-runbook | `exo-v3-comprehensive/KATA-INSTANCE-QUALIFICATION-RUNBOOK.md` | `3fe4f645caccb1407aacd5c79a0704f971c7939a2a35e43c646e83c89ef0fc2c` |
| aq-readme | `actionqueue-main/README.md` | `3f629de6eedbfd101da6f8f1eaa65d3a1dda4849153da27b136c543e682b6507` |
| aq-conformance | `actionqueue-main/conformance/aq-cont-1/manifest.yaml` | `a13ff040f64dce3acc6988012099acea5e7739162fc1090f0b54376d6e2085c5` |
| aq-release | `actionqueue-main/docs/releases/0.2.0.md` | `ba4de332bd0fb4014a2de8818960e0be7ced21238967d52292e24b1cd79e1977` |
| wi-aq-lock | `wi-fabric-2-foundational/aq-baseline.lock.json` | `1907d0a157628511c2419f84fd6b7820e09c160699505ee986cc46f3bcf78c7a` |
| wi-aq-alignment | `wi-fabric-2-foundational/AQ-BASELINE-ALIGNMENT.md` | `cd013232a0a9cbca2c625d31c3fc75e053f7948d37b8a6de2f08ff5cdc7e4656` |
| wi-aq-cases | `wi-fabric-2-foundational/aq-baseline-integration-acceptance-matrix.yaml` | `3ed55cff70cbc603e6a44591b0f73aabf58b19d81cff28cf95baa08429ad6f4a` |
| exo-aq-lock | `exo-v3-comprehensive/aq-baseline.lock.json` | `1907d0a157628511c2419f84fd6b7820e09c160699505ee986cc46f3bcf78c7a` |
| exo-aq-alignment | `exo-v3-comprehensive/AQ-BASELINE-ALIGNMENT.md` | `cd013232a0a9cbca2c625d31c3fc75e053f7948d37b8a6de2f08ff5cdc7e4656` |
| exo-aq-cases | `exo-v3-comprehensive/aq-baseline-integration-acceptance-matrix.yaml` | `4d3661ece23e58db4af6b42221b46c2b9c1687fff5308490e757d5068c95bb2a` |
| wi-aq-assumptions | `wi-fabric-2-foundational/wi-fabric-2-aq-assumption-ledger-foundational.yaml` | `943d9f263afeee5c56cc6c65a3c6dfca6fca8c871ff070aed2cd0c77f1437415` |

AQ plan/WBS snapshots are retained history only, not runnable work. The EXO r5 archive in the previous map was not supplied; its actually embedded provider-reference snapshots were used and retained as provenance in EXO r6. This revision binds the full supplied-and-revised EXO package rather than assuming the missing archive.
