# Active work-item and slice matrix — v0.3.0

**33 active WI/EXO parents; 69 slices.** AQ implementation/ADR history is retired, not pending. All obligations below are unresolved. Original full exit gates and dependencies remain.

| Parent | Original dependencies | Required slices | Additional baseline cases |
|---|---|---|---|
| `wi/WI-01` | None | `wi/WI-01/implementation` | None |
| `wi/WI-02` | wi/WI-01 | `wi/WI-02/domain`, `wi/WI-02/integration` | AB-WI-001, AB-WI-015, AB-WI-016 |
| `wi/WI-03` | wi/WI-02 | `wi/WI-03/domain`, `wi/WI-03/integration` | AB-WI-006, AB-WI-007, AB-WI-009, AB-WI-022 |
| `wi/WI-04` | wi/WI-02 | `wi/WI-04/domain`, `wi/WI-04/integration` | AB-WI-002, AB-WI-003, AB-WI-004 |
| `wi/WI-05` | wi/WI-02 | `wi/WI-05/domain`, `wi/WI-05/integration` | None |
| `wi/WI-06` | wi/WI-04, wi/WI-05 | `wi/WI-06/domain`, `wi/WI-06/integration` | AB-WI-012, AB-WI-014, AB-WI-020, AB-WI-023 |
| `wi/WI-07` | wi/WI-04, wi/WI-05, wi/WI-06 | `wi/WI-07/domain`, `wi/WI-07/integration` | AB-WI-005, AB-WI-010, AB-WI-013 |
| `wi/WI-08` | wi/WI-07 | `wi/WI-08/integration` | AB-WI-008, AB-WI-011 |
| `wi/WI-09` | wi/WI-06, wi/WI-08 | `wi/WI-09/domain`, `wi/WI-09/integration`, `wi/WI-09/process-provider` | AB-WI-021 |
| `wi/WI-10` | wi/WI-06, wi/WI-09 | `wi/WI-10/domain`, `wi/WI-10/integration`, `wi/WI-10/process-catalog` | None |
| `wi/WI-11` | wi/WI-03, wi/WI-04, wi/WI-05, wi/WI-06, wi/WI-07, wi/WI-08, wi/WI-09, wi/WI-10 | `wi/WI-11/domain`, `wi/WI-11/integration`, `wi/WI-11/embedded-runtime`, `wi/WI-11/supervisor-boundary` | AB-WI-017, AB-WI-018, AB-WI-019 |
| `wi/WI-12` | wi/WI-04, wi/WI-05, wi/WI-11 | `wi/WI-12/domain`, `wi/WI-12/integration` | None |
| `wi/WI-13` | wi/WI-01, wi/WI-02, wi/WI-03, wi/WI-04, wi/WI-05, wi/WI-06, wi/WI-07, wi/WI-08, wi/WI-09, wi/WI-10, wi/WI-11, wi/WI-12 | `wi/WI-13/conformance`, `wi/WI-13/worker-conformance`, `wi/WI-13/supervisor-conformance` | AB-WI-024 |
| `wi/WI-14` | wi/WI-13 | `wi/WI-14/release`, `wi/WI-14/worker-handoff` | None |
| `exo/EXO-01` | None | `exo/EXO-01/domain` | None |
| `exo/EXO-02` | exo/EXO-01 | `exo/EXO-02/domain` | None |
| `exo/EXO-03` | exo/EXO-02 | `exo/EXO-03/domain`, `exo/EXO-03/integration` | None |
| `exo/EXO-04` | exo/EXO-02 | `exo/EXO-04/domain` | None |
| `exo/EXO-05` | exo/EXO-02, exo/EXO-04 | `exo/EXO-05/domain`, `exo/EXO-05/integration` | None |
| `exo/EXO-06` | exo/EXO-03, exo/EXO-04, exo/EXO-05 | `exo/EXO-06/domain`, `exo/EXO-06/integration` | None |
| `exo/EXO-07` | exo/EXO-04, exo/EXO-05, exo/EXO-06 | `exo/EXO-07/domain` | None |
| `exo/EXO-08` | exo/EXO-03, exo/EXO-04, exo/EXO-06, exo/EXO-07 | `exo/EXO-08/domain` | None |
| `exo/EXO-09` | exo/EXO-04, exo/EXO-05, exo/EXO-06, exo/EXO-08 | `exo/EXO-09/domain` | None |
| `exo/EXO-10` | exo/EXO-03, exo/EXO-05, exo/EXO-08, exo/EXO-09 | `exo/EXO-10/domain`, `exo/EXO-10/integration` | None |
| `exo/EXO-11` | exo/EXO-06, exo/EXO-08, exo/EXO-10 | `exo/EXO-11/integration`, `exo/EXO-11/embedded-runtime` | AB-EXO-001, AB-EXO-002, AB-EXO-003, AB-EXO-004, AB-EXO-005, AB-EXO-006, AB-EXO-007, AB-EXO-008, AB-EXO-009, AB-EXO-010, AB-EXO-011, AB-EXO-012, AB-EXO-013, AB-EXO-014, AB-EXO-015, AB-EXO-016, AB-EXO-017, AB-EXO-018 |
| `exo/EXO-12` | exo/EXO-08, exo/EXO-10, exo/EXO-11 | `exo/EXO-12/domain`, `exo/EXO-12/integration`, `exo/EXO-12/embedded-worker` | AB-EXO-021 |
| `exo/EXO-13` | exo/EXO-04, exo/EXO-08, exo/EXO-09, exo/EXO-11, exo/EXO-12 | `exo/EXO-13/domain`, `exo/EXO-13/integration`, `exo/EXO-13/embedded-acceptance` | None |
| `exo/EXO-14` | exo/EXO-04, exo/EXO-07, exo/EXO-09, exo/EXO-13 | `exo/EXO-14/domain`, `exo/EXO-14/integration`, `exo/EXO-14/embedded-provenance` | None |
| `exo/EXO-15` | exo/EXO-10, exo/EXO-11, exo/EXO-12, exo/EXO-13, exo/EXO-14 | `exo/EXO-15/domain`, `exo/EXO-15/integration`, `exo/EXO-15/embedded-lifecycle` | None |
| `exo/EXO-16` | exo/EXO-03, exo/EXO-04, exo/EXO-08, exo/EXO-09, exo/EXO-10, exo/EXO-11, exo/EXO-14, exo/EXO-15 | `exo/EXO-16/domain`, `exo/EXO-16/integration`, `exo/EXO-16/embedded-recovery` | AB-EXO-019, AB-EXO-020, AB-EXO-022, AB-EXO-023 |
| `exo/EXO-17` | exo/EXO-06, exo/EXO-07, exo/EXO-08, exo/EXO-09, exo/EXO-10, exo/EXO-11, exo/EXO-12, exo/EXO-13, exo/EXO-14, exo/EXO-15, exo/EXO-16 | `exo/EXO-17/integration` | AB-EXO-024 |
| `exo/EXO-18` | exo/EXO-11, exo/EXO-13, exo/EXO-15, exo/EXO-16, exo/EXO-17 | `exo/EXO-18/domain`, `exo/EXO-18/integration`, `exo/EXO-18/instance-design`, `exo/EXO-18/instance-qualification` | None |
| `exo/EXO-19` | exo/EXO-18 | `exo/EXO-19/release`, `exo/EXO-19/embedded-viability` | None |

## `wi/WI-01/implementation`

Scope: `full`; evidence: `runtime-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed` | isolated-development-workspace |
| merge | None | isolated-development-workspace |
| verify | None | controlled-native-test-host |

Additional AQ baseline receipts: None.

## `wi/WI-02/domain`

Scope: `domain`; evidence: `domain-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `wi/WI-01@accepted` | isolated-development-workspace |
| merge | `WI-ADR-001@passed`; `WI-ADR-002@passed`; `WI-ADR-003@passed`; `WI-ADR-016@passed` | isolated-development-workspace |
| verify | None | isolated-development-workspace |

Additional AQ baseline receipts: None.

## `wi/WI-02/integration`

Scope: `full`; evidence: `runtime-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `wi/WI-01@accepted`; `wi/WI-02/domain@verified` | isolated-development-workspace |
| merge | `WI-AQ-G1@passed`; `WI-ADR-001@passed`; `WI-ADR-002@passed`; `WI-ADR-003@passed` | isolated-development-workspace |
| verify | None | controlled-native-test-host |

Additional AQ baseline receipts: AB-WI-001, AB-WI-015, AB-WI-016.

## `wi/WI-03/domain`

Scope: `domain`; evidence: `domain-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `wi/WI-02/domain@verified` | isolated-development-workspace |
| merge | `WI-ADR-012@passed`; `WI-ADR-013@passed` | isolated-development-workspace |
| verify | None | isolated-development-workspace |

Additional AQ baseline receipts: None.

## `wi/WI-03/integration`

Scope: `full`; evidence: `runtime-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `wi/WI-02@accepted`; `wi/WI-03/domain@verified` | isolated-development-workspace |
| merge | `WI-AQ-G2@passed`; `WI-AQ-G3@passed`; `WI-ADR-012@passed`; `WI-ADR-013@passed` | isolated-development-workspace |
| verify | None | controlled-native-test-host |

Additional AQ baseline receipts: AB-WI-006, AB-WI-007, AB-WI-009, AB-WI-022.

## `wi/WI-04/domain`

Scope: `domain`; evidence: `domain-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `wi/WI-02/domain@verified` | isolated-development-workspace |
| merge | `WI-ADR-004@passed`; `WI-ADR-005@passed`; `WI-ADR-006@passed`; `WI-ADR-007@passed`; `WI-WORKER-G1@passed` | isolated-development-workspace |
| verify | None | isolated-development-workspace |

Additional AQ baseline receipts: None.

## `wi/WI-04/integration`

Scope: `full`; evidence: `runtime-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `wi/WI-02@accepted`; `wi/WI-04/domain@verified` | isolated-development-workspace |
| merge | `WI-AQ-G2@passed`; `WI-ADR-004@passed`; `WI-ADR-005@passed`; `WI-ADR-006@passed`; `WI-ADR-007@passed` | isolated-development-workspace |
| verify | None | controlled-native-test-host |

Additional AQ baseline receipts: AB-WI-002, AB-WI-003, AB-WI-004.

## `wi/WI-05/domain`

Scope: `domain`; evidence: `domain-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `wi/WI-02/domain@verified` | isolated-development-workspace |
| merge | `WI-ADR-008@passed`; `WI-ADR-009@passed`; `WI-WORKER-G1@passed` | isolated-development-workspace |
| verify | None | isolated-development-workspace |

Additional AQ baseline receipts: None.

## `wi/WI-05/integration`

Scope: `full`; evidence: `runtime-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `wi/WI-02@accepted`; `wi/WI-05/domain@verified` | isolated-development-workspace |
| merge | `WI-AQ-G4@passed`; `WI-ADR-007@passed`; `WI-ADR-010@passed`; `WI-ADR-008@passed`; `WI-ADR-009@passed` | isolated-development-workspace |
| verify | None | controlled-native-test-host |

Additional AQ baseline receipts: None.

## `wi/WI-06/domain`

Scope: `domain`; evidence: `domain-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `wi/WI-04/domain@verified`; `wi/WI-05/domain@verified` | isolated-development-workspace |
| merge | `WI-ADR-010@passed`; `WI-ADR-011@passed` | isolated-development-workspace |
| verify | None | isolated-development-workspace |

Additional AQ baseline receipts: None.

## `wi/WI-06/integration`

Scope: `embedded-proof`; evidence: `embedded-runtime-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `wi/WI-04@accepted`; `wi/WI-05@accepted`; `wi/WI-06/domain@verified` | isolated-development-workspace |
| merge | `WI-AQ-G4@passed`; `WI-ADR-010@passed`; `WI-ADR-011@passed` | isolated-development-workspace |
| verify | None | controlled-native-test-host |

Additional AQ baseline receipts: AB-WI-012, AB-WI-014, AB-WI-020, AB-WI-023.

## `wi/WI-07/domain`

Scope: `domain`; evidence: `domain-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `wi/WI-02/domain@verified` | isolated-development-workspace |
| merge | `WI-ADR-014@passed` | isolated-development-workspace |
| verify | None | isolated-development-workspace |

Additional AQ baseline receipts: None.

## `wi/WI-07/integration`

Scope: `embedded-proof`; evidence: `embedded-runtime-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `wi/WI-04@accepted`; `wi/WI-05@accepted`; `wi/WI-06/integration@verified`; `wi/WI-07/domain@verified` | isolated-development-workspace |
| merge | `WI-AQ-G2@passed`; `WI-AQ-G3@passed`; `WI-AQ-G4@passed`; `WI-ADR-014@passed` | isolated-development-workspace |
| verify | None | controlled-native-test-host |

Additional AQ baseline receipts: AB-WI-005, AB-WI-010, AB-WI-013.

## `wi/WI-08/integration`

Scope: `embedded-proof`; evidence: `embedded-runtime-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `wi/WI-07/integration@verified` | isolated-development-workspace |
| merge | `WI-AQ-G3@passed`; `WI-AQ-G4@passed`; `WI-ADR-015@passed` | isolated-development-workspace |
| verify | None | controlled-native-test-host |

Additional AQ baseline receipts: AB-WI-008, AB-WI-011.

## `wi/WI-09/domain`

Scope: `domain`; evidence: `domain-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `wi/WI-02/domain@verified` | isolated-development-workspace |
| merge | `WI-ADR-016@passed` | isolated-development-workspace |
| verify | None | isolated-development-workspace |

Additional AQ baseline receipts: None.

## `wi/WI-09/integration`

Scope: `full`; evidence: `runtime-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `wi/WI-06@accepted`; `wi/WI-08@accepted`; `wi/WI-09/domain@verified`; `wi/WI-09/process-provider@verified` | isolated-development-workspace |
| merge | `WI-AQ-G3@passed`; `WI-AQ-G4@passed`; `WI-ADR-016@passed` | isolated-development-workspace |
| verify | `WI-EMBEDDED-WORKER-PROOF-1@passed` | controlled-native-test-host |

Additional AQ baseline receipts: None.

## `wi/WI-09/process-provider`

Scope: `embedded-proof`; evidence: `embedded-runtime-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `wi/WI-06/integration@verified`; `wi/WI-08/integration@verified`; `wi/WI-09/domain@verified` | isolated-development-workspace |
| merge | `WI-AQ-G1@passed`; `WI-AQ-G2@passed`; `WI-AQ-G3@passed`; `WI-AQ-G4@passed`; `WI-WORKER-G1@passed`; `WI-WORKER-G2@passed`; `WI-ADR-016@passed`; `WI-ADR-010@passed`; `WI-EMBEDDED-CORE-1@passed` | isolated-development-workspace |
| verify | None | controlled-native-test-host |

Additional AQ baseline receipts: AB-WI-021.

## `wi/WI-10/domain`

Scope: `domain`; evidence: `domain-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `wi/WI-01@accepted` | isolated-development-workspace |
| merge | `WI-ADR-017@passed` | isolated-development-workspace |
| verify | None | isolated-development-workspace |

Additional AQ baseline receipts: None.

## `wi/WI-10/integration`

Scope: `full`; evidence: `runtime-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `wi/WI-06@accepted`; `wi/WI-09@accepted`; `wi/WI-10/domain@verified`; `wi/WI-10/process-catalog@verified` | isolated-development-workspace |
| merge | `WI-ADR-017@passed` | isolated-development-workspace |
| verify | None | controlled-native-test-host |

Additional AQ baseline receipts: None.

## `wi/WI-10/process-catalog`

Scope: `embedded-proof`; evidence: `embedded-runtime-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `wi/WI-10/domain@verified`; `wi/WI-09/process-provider@verified` | isolated-development-workspace |
| merge | `WI-AQ-G1@passed`; `WI-AQ-G2@passed`; `WI-AQ-G3@passed`; `WI-AQ-G4@passed`; `WI-WORKER-G3@passed`; `WI-ADR-017@passed` | isolated-development-workspace |
| verify | None | controlled-native-test-host |

Additional AQ baseline receipts: None.

## `wi/WI-11/domain`

Scope: `domain`; evidence: `domain-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `wi/WI-02/domain@verified` | isolated-development-workspace |
| merge | `WI-ADR-018@passed`; `WI-ADR-004@passed` | isolated-development-workspace |
| verify | None | isolated-development-workspace |

Additional AQ baseline receipts: None.

## `wi/WI-11/embedded-runtime`

Scope: `embedded-proof`; evidence: `embedded-runtime-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `wi/WI-03@accepted`; `wi/WI-04@accepted`; `wi/WI-05@accepted`; `wi/WI-06/integration@verified`; `wi/WI-07/integration@verified`; `wi/WI-08/integration@verified`; `wi/WI-11/domain@verified` | isolated-development-workspace |
| merge | `WI-AQ-G1@passed`; `WI-AQ-G2@passed`; `WI-AQ-G3@passed`; `WI-AQ-G4@passed`; `wi/WI-09/process-provider@verified`; `wi/WI-10/process-catalog@verified`; `WI-ADR-018@passed` | isolated-development-workspace |
| verify | None | controlled-native-test-host |

Additional AQ baseline receipts: AB-WI-019.

## `wi/WI-11/integration`

Scope: `full`; evidence: `runtime-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `wi/WI-03@accepted`; `wi/WI-04@accepted`; `wi/WI-05@accepted`; `wi/WI-06@accepted`; `wi/WI-07@accepted`; `wi/WI-08@accepted`; `wi/WI-09@accepted`; `wi/WI-10@accepted`; `wi/WI-11/domain@verified`; `wi/WI-11/embedded-runtime@verified`; `wi/WI-11/supervisor-boundary@verified` | isolated-development-workspace |
| merge | `WI-AQ-G1@passed`; `WI-AQ-G2@passed`; `WI-AQ-G3@passed`; `WI-AQ-G4@passed`; `WI-ADR-018@passed` | isolated-development-workspace |
| verify | `WI-AQ-G5@passed` | controlled-native-test-host |

Additional AQ baseline receipts: AB-WI-017, AB-WI-018.

## `wi/WI-11/supervisor-boundary`

Scope: `supervisor-proof`; evidence: `supervisor-boundary-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `wi/WI-06/integration@verified`; `wi/WI-08/integration@verified`; `wi/WI-11/domain@verified` | isolated-development-workspace |
| merge | `WI-AQ-G1@passed`; `WI-AQ-G2@passed`; `WI-AQ-G3@passed`; `WI-AQ-G4@passed`; `WI-WORKER-G1@passed`; `WI-WORKER-G2@passed`; `WI-ADR-018@passed`; `WI-ADR-010@passed`; `WI-ADR-016@passed`; `WI-EMBEDDED-CORE-1@passed` | isolated-development-workspace |
| verify | None | controlled-native-test-host |

Additional AQ baseline receipts: None.

## `wi/WI-12/domain`

Scope: `domain`; evidence: `domain-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `wi/WI-02/domain@verified` | isolated-development-workspace |
| merge | `WI-ADR-019@passed`; `WI-ADR-020@passed` | isolated-development-workspace |
| verify | None | isolated-development-workspace |

Additional AQ baseline receipts: None.

## `wi/WI-12/integration`

Scope: `full`; evidence: `runtime-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `wi/WI-04@accepted`; `wi/WI-05@accepted`; `wi/WI-11@accepted`; `wi/WI-12/domain@verified` | isolated-development-workspace |
| merge | `WI-AQ-G1@passed`; `WI-ADR-019@passed`; `WI-ADR-020@passed` | isolated-development-workspace |
| verify | None | controlled-native-test-host |

Additional AQ baseline receipts: None.

## `wi/WI-13/conformance`

Scope: `full`; evidence: `runtime-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `wi/WI-01@accepted`; `wi/WI-02@accepted`; `wi/WI-03@accepted`; `wi/WI-04@accepted`; `wi/WI-05@accepted`; `wi/WI-06@accepted`; `wi/WI-07@accepted`; `wi/WI-08@accepted`; `wi/WI-09@accepted`; `wi/WI-10@accepted`; `wi/WI-11@accepted`; `wi/WI-12@accepted`; `WI-AQ-G5@passed`; `wi/WI-13/worker-conformance@verified`; `wi/WI-13/supervisor-conformance@verified` | isolated-development-workspace |
| merge | `WI-AQ-G5@passed` | isolated-development-workspace |
| verify | `WI-EMBEDDED-WORKER-PROOF-1@passed`; `WI-WORKER-G5@passed` | controlled-native-test-host |

Additional AQ baseline receipts: AB-WI-024.

## `wi/WI-13/supervisor-conformance`

Scope: `supervisor-proof`; evidence: `supervisor-boundary-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `wi/WI-11/supervisor-boundary@verified` | isolated-development-workspace |
| merge | `WI-AQ-G1@passed`; `WI-AQ-G2@passed`; `WI-AQ-G3@passed`; `WI-AQ-G4@passed` | isolated-development-workspace |
| verify | None | controlled-native-test-host |

Additional AQ baseline receipts: None.

## `wi/WI-13/worker-conformance`

Scope: `embedded-proof`; evidence: `embedded-runtime-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `wi/WI-11/embedded-runtime@verified`; `wi/WI-10/process-catalog@verified` | isolated-development-workspace |
| merge | `WI-AQ-G1@passed`; `WI-AQ-G2@passed`; `WI-AQ-G3@passed`; `WI-AQ-G4@passed` | isolated-development-workspace |
| verify | None | controlled-native-test-host |

Additional AQ baseline receipts: None.

## `wi/WI-14/release`

Scope: `full`; evidence: `release-publication`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `wi/WI-13@accepted`; `AQ-PUBLISHED@passed`; `wi/WI-14/worker-handoff@verified` | isolated-development-workspace |
| merge | `AQ-PUBLISHED@passed` | isolated-development-workspace |
| verify | None | controlled-native-test-host |

Additional AQ baseline receipts: None.

## `wi/WI-14/worker-handoff`

Scope: `embedded-proof`; evidence: `embedded-runtime-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `wi/WI-13/worker-conformance@verified` | isolated-development-workspace |
| merge | `WI-AQ-G1@passed`; `WI-AQ-G2@passed`; `WI-AQ-G3@passed`; `WI-AQ-G4@passed` | isolated-development-workspace |
| verify | None | controlled-native-test-host |

Additional AQ baseline receipts: None.

## `exo/EXO-01/domain`

Scope: `domain`; evidence: `domain-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed` | isolated-development-workspace |
| merge | None | isolated-development-workspace |
| verify | None | isolated-development-workspace |

Additional AQ baseline receipts: None.

## `exo/EXO-02/domain`

Scope: `domain`; evidence: `domain-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-01@accepted` | isolated-development-workspace |
| merge | `EXO-ADR-001@passed`; `EXO-ADR-002@passed`; `EXO-ADR-003@passed` | isolated-development-workspace |
| verify | None | isolated-development-workspace |

Additional AQ baseline receipts: None.

## `exo/EXO-03/domain`

Scope: `domain`; evidence: `domain-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-02/domain@verified` | isolated-development-workspace |
| merge | `EXO-ADR-004@passed`; `EXO-ADR-005@passed`; `EXO-ADR-037@passed` | isolated-development-workspace |
| verify | None | isolated-development-workspace |

Additional AQ baseline receipts: None.

## `exo/EXO-03/integration`

Scope: `full`; evidence: `runtime-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-02@accepted`; `exo/EXO-03/domain@verified` | isolated-development-workspace |
| merge | `EXO-AQ-G2@passed`; `EXO-AQ-G3@passed`; `EXO-WI-G1@passed`; `EXO-WI-G2@passed`; `EXO-ADR-004@passed`; `EXO-ADR-005@passed`; `EXO-ADR-037@passed` | isolated-development-workspace |
| verify | None | controlled-native-test-host |

Additional AQ baseline receipts: None.

## `exo/EXO-04/domain`

Scope: `domain`; evidence: `domain-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-02/domain@verified` | isolated-development-workspace |
| merge | `EXO-WI-TIME-REVIEW@passed`; `EXO-ADR-006@passed`; `EXO-ADR-007@passed`; `EXO-ADR-008@passed`; `EXO-ADR-018@passed`; `EXO-ADR-031@passed` | isolated-development-workspace |
| verify | None | isolated-development-workspace |

Additional AQ baseline receipts: None.

## `exo/EXO-05/domain`

Scope: `domain`; evidence: `domain-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-02/domain@verified`; `exo/EXO-04/domain@verified` | isolated-development-workspace |
| merge | `EXO-ADR-008@passed`; `EXO-ADR-009@passed`; `EXO-ADR-010@passed`; `EXO-ADR-011@passed`; `EXO-ADR-012@passed` | isolated-development-workspace |
| verify | None | isolated-development-workspace |

Additional AQ baseline receipts: None.

## `exo/EXO-05/integration`

Scope: `full`; evidence: `runtime-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-02@accepted`; `exo/EXO-04@accepted`; `exo/EXO-05/domain@verified` | isolated-development-workspace |
| merge | `EXO-WI-G1@passed`; `EXO-WI-G2@passed`; `EXO-ADR-008@passed`; `EXO-ADR-009@passed`; `EXO-ADR-010@passed`; `EXO-ADR-011@passed`; `EXO-ADR-012@passed` | isolated-development-workspace |
| verify | None | controlled-native-test-host |

Additional AQ baseline receipts: None.

## `exo/EXO-06/domain`

Scope: `domain`; evidence: `domain-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-03/domain@verified`; `exo/EXO-04/domain@verified`; `exo/EXO-05/domain@verified` | isolated-development-workspace |
| merge | `EXO-ADR-002@passed`; `EXO-ADR-013@passed`; `EXO-ADR-014@passed` | isolated-development-workspace |
| verify | None | isolated-development-workspace |

Additional AQ baseline receipts: None.

## `exo/EXO-06/integration`

Scope: `full`; evidence: `runtime-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-03@accepted`; `exo/EXO-04@accepted`; `exo/EXO-05@accepted`; `exo/EXO-06/domain@verified` | isolated-development-workspace |
| merge | `EXO-AQ-G2@passed`; `EXO-AQ-G3@passed`; `EXO-WI-G1@passed`; `EXO-WI-G2@passed`; `EXO-ADR-002@passed`; `EXO-ADR-013@passed`; `EXO-ADR-014@passed` | isolated-development-workspace |
| verify | None | controlled-native-test-host |

Additional AQ baseline receipts: None.

## `exo/EXO-07/domain`

Scope: `domain`; evidence: `domain-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-04/domain@verified`; `exo/EXO-05/domain@verified`; `exo/EXO-06/domain@verified` | isolated-development-workspace |
| merge | `EXO-WI-FACULTY-REVIEW@passed`; `EXO-ADR-015@passed`; `EXO-ADR-016@passed`; `EXO-ADR-032@passed` | isolated-development-workspace |
| verify | None | isolated-development-workspace |

Additional AQ baseline receipts: None.

## `exo/EXO-08/domain`

Scope: `domain`; evidence: `domain-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-03/domain@verified`; `exo/EXO-04/domain@verified`; `exo/EXO-06/domain@verified`; `exo/EXO-07/domain@verified` | isolated-development-workspace |
| merge | `EXO-ADR-005@passed`; `EXO-ADR-012@passed`; `EXO-ADR-014@passed`; `EXO-ADR-017@passed` | isolated-development-workspace |
| verify | None | isolated-development-workspace |

Additional AQ baseline receipts: None.

## `exo/EXO-09/domain`

Scope: `domain`; evidence: `domain-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-04/domain@verified`; `exo/EXO-05/domain@verified`; `exo/EXO-06/domain@verified`; `exo/EXO-08/domain@verified` | isolated-development-workspace |
| merge | `EXO-WI-DISCLOSURE-REVIEW@passed`; `EXO-ADR-011@passed`; `EXO-ADR-018@passed`; `EXO-ADR-019@passed`; `EXO-ADR-020@passed` | isolated-development-workspace |
| verify | None | isolated-development-workspace |

Additional AQ baseline receipts: None.

## `exo/EXO-10/domain`

Scope: `domain`; evidence: `domain-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-03/domain@verified`; `exo/EXO-05/domain@verified`; `exo/EXO-08/domain@verified`; `exo/EXO-09/domain@verified` | isolated-development-workspace |
| merge | `EXO-ADR-021@passed`; `EXO-ADR-022@passed` | isolated-development-workspace |
| verify | None | isolated-development-workspace |

Additional AQ baseline receipts: None.

## `exo/EXO-10/integration`

Scope: `full`; evidence: `runtime-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-03@accepted`; `exo/EXO-05@accepted`; `exo/EXO-08@accepted`; `exo/EXO-09@accepted`; `exo/EXO-10/domain@verified` | isolated-development-workspace |
| merge | `EXO-WI-G1@passed`; `EXO-WI-G2@passed`; `EXO-ADR-021@passed`; `EXO-ADR-022@passed` | isolated-development-workspace |
| verify | None | controlled-native-test-host |

Additional AQ baseline receipts: None.

## `exo/EXO-11/embedded-runtime`

Scope: `embedded-proof`; evidence: `embedded-runtime-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-06@accepted`; `exo/EXO-08@accepted`; `exo/EXO-10@accepted` | isolated-development-workspace |
| merge | `EXO-AQ-G1@passed`; `EXO-AQ-G2@passed`; `EXO-AQ-G3@passed`; `EXO-AQ-G4@passed`; `EXO-WI-G1@passed`; `EXO-WI-G2@passed`; `WI-EMBEDDED-CORE-1@passed`; `wi/WI-11/embedded-runtime@verified`; `EXO-ADR-020@passed`; `EXO-ADR-021@passed` | isolated-development-workspace |
| verify | None | controlled-native-test-host |

Additional AQ baseline receipts: AB-EXO-001, AB-EXO-002, AB-EXO-003, AB-EXO-004, AB-EXO-005, AB-EXO-006, AB-EXO-007, AB-EXO-008, AB-EXO-009, AB-EXO-010, AB-EXO-011, AB-EXO-012, AB-EXO-013, AB-EXO-015, AB-EXO-016.

## `exo/EXO-11/integration`

Scope: `full`; evidence: `runtime-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-06@accepted`; `exo/EXO-08@accepted`; `exo/EXO-10@accepted`; `exo/EXO-11/embedded-runtime@verified` | isolated-development-workspace |
| merge | `EXO-AQ-G1@passed`; `EXO-AQ-G2@passed`; `EXO-AQ-G3@passed`; `EXO-AQ-G4@passed`; `EXO-WI-G1@passed`; `EXO-WI-G2@passed`; `EXO-WI-G3@passed`; `EXO-ADR-020@passed`; `EXO-ADR-021@passed` | isolated-development-workspace |
| verify | `WI-DEPLOYMENT-PARITY@passed` | controlled-native-test-host |

Additional AQ baseline receipts: AB-EXO-014, AB-EXO-017, AB-EXO-018.

## `exo/EXO-12/domain`

Scope: `domain`; evidence: `domain-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-08/domain@verified`; `exo/EXO-10/domain@verified`; `exo/EXO-11/embedded-runtime@verified` | isolated-development-workspace |
| merge | `EXO-ADR-023@passed`; `EXO-ADR-038@passed` | isolated-development-workspace |
| verify | None | isolated-development-workspace |

Additional AQ baseline receipts: None.

## `exo/EXO-12/embedded-worker`

Scope: `embedded-proof`; evidence: `embedded-runtime-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-11/embedded-runtime@verified`; `exo/EXO-12/domain@verified` | isolated-development-workspace |
| merge | `EXO-AQ-G1@passed`; `EXO-AQ-G2@passed`; `EXO-AQ-G3@passed`; `EXO-AQ-G4@passed`; `EXO-WI-G1@passed`; `EXO-WI-G2@passed`; `WI-EMBEDDED-CORE-1@passed`; `WI-EMBEDDED-WORKER-PROOF-1@passed`; `EXO-ADR-023@passed`; `EXO-ADR-038@passed` | isolated-development-workspace |
| verify | None | controlled-native-test-host |

Additional AQ baseline receipts: AB-EXO-021.

## `exo/EXO-12/integration`

Scope: `full`; evidence: `runtime-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-08@accepted`; `exo/EXO-10@accepted`; `exo/EXO-11@accepted`; `exo/EXO-12/domain@verified`; `exo/EXO-12/embedded-worker@verified` | isolated-development-workspace |
| merge | `EXO-AQ-G2@passed`; `EXO-AQ-G3@passed`; `EXO-AQ-G4@passed`; `EXO-WI-G3@passed`; `EXO-WI-G4@passed`; `EXO-ADR-023@passed`; `EXO-ADR-038@passed` | isolated-development-workspace |
| verify | None | controlled-native-test-host |

Additional AQ baseline receipts: None.

## `exo/EXO-13/domain`

Scope: `domain`; evidence: `domain-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-04/domain@verified`; `exo/EXO-08/domain@verified`; `exo/EXO-09/domain@verified`; `exo/EXO-11/embedded-runtime@verified`; `exo/EXO-12/domain@verified` | isolated-development-workspace |
| merge | `EXO-ADR-018@passed`; `EXO-ADR-024@passed`; `EXO-ADR-031@passed`; `EXO-ADR-033@passed`; `EXO-ADR-034@passed` | isolated-development-workspace |
| verify | None | isolated-development-workspace |

Additional AQ baseline receipts: None.

## `exo/EXO-13/embedded-acceptance`

Scope: `embedded-proof`; evidence: `embedded-runtime-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-12/embedded-worker@verified`; `exo/EXO-13/domain@verified` | isolated-development-workspace |
| merge | `EXO-AQ-G1@passed`; `EXO-AQ-G2@passed`; `EXO-AQ-G3@passed`; `EXO-AQ-G4@passed`; `WI-EMBEDDED-WORKER-PROOF-1@passed`; `EXO-ADR-018@passed`; `EXO-ADR-024@passed`; `EXO-ADR-031@passed`; `EXO-ADR-033@passed`; `EXO-ADR-034@passed` | isolated-development-workspace |
| verify | None | controlled-native-test-host |

Additional AQ baseline receipts: None.

## `exo/EXO-13/integration`

Scope: `full`; evidence: `runtime-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-04@accepted`; `exo/EXO-08@accepted`; `exo/EXO-09@accepted`; `exo/EXO-11@accepted`; `exo/EXO-12@accepted`; `exo/EXO-13/domain@verified`; `exo/EXO-13/embedded-acceptance@verified` | isolated-development-workspace |
| merge | `EXO-AQ-G5@passed`; `EXO-WI-G3@passed`; `EXO-WI-G4@passed`; `EXO-ADR-018@passed`; `EXO-ADR-024@passed`; `EXO-ADR-031@passed`; `EXO-ADR-033@passed`; `EXO-ADR-034@passed` | isolated-development-workspace |
| verify | None | controlled-native-test-host |

Additional AQ baseline receipts: None.

## `exo/EXO-14/domain`

Scope: `domain`; evidence: `domain-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-04/domain@verified`; `exo/EXO-07/domain@verified`; `exo/EXO-09/domain@verified`; `exo/EXO-13/domain@verified` | isolated-development-workspace |
| merge | `EXO-ADR-025@passed`; `EXO-ADR-032@passed` | isolated-development-workspace |
| verify | None | isolated-development-workspace |

Additional AQ baseline receipts: None.

## `exo/EXO-14/embedded-provenance`

Scope: `embedded-proof`; evidence: `embedded-runtime-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-14/domain@verified`; `exo/EXO-13/embedded-acceptance@verified` | isolated-development-workspace |
| merge | `EXO-AQ-G1@passed`; `EXO-AQ-G2@passed`; `EXO-AQ-G3@passed`; `EXO-AQ-G4@passed`; `WI-EMBEDDED-WORKER-PROOF-1@passed`; `EXO-ADR-025@passed`; `EXO-ADR-032@passed` | isolated-development-workspace |
| verify | None | controlled-native-test-host |

Additional AQ baseline receipts: None.

## `exo/EXO-14/integration`

Scope: `full`; evidence: `runtime-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-04@accepted`; `exo/EXO-07@accepted`; `exo/EXO-09@accepted`; `exo/EXO-13@accepted`; `exo/EXO-14/domain@verified`; `exo/EXO-14/embedded-provenance@verified` | isolated-development-workspace |
| merge | `EXO-AQ-G5@passed`; `EXO-WI-G4@passed`; `EXO-ADR-025@passed`; `EXO-ADR-032@passed` | isolated-development-workspace |
| verify | None | controlled-native-test-host |

Additional AQ baseline receipts: None.

## `exo/EXO-15/domain`

Scope: `domain`; evidence: `domain-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-10/domain@verified`; `exo/EXO-11/embedded-runtime@verified`; `exo/EXO-12/domain@verified`; `exo/EXO-13/domain@verified`; `exo/EXO-14/domain@verified` | isolated-development-workspace |
| merge | `EXO-ADR-026@passed`; `EXO-ADR-027@passed`; `EXO-ADR-034@passed`; `EXO-ADR-035@passed`; `EXO-ADR-036@passed`; `EXO-ADR-038@passed` | isolated-development-workspace |
| verify | None | isolated-development-workspace |

Additional AQ baseline receipts: None.

## `exo/EXO-15/embedded-lifecycle`

Scope: `embedded-proof`; evidence: `kata-lifecycle-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-15/domain@verified`; `exo/EXO-14/embedded-provenance@verified`; `exo/EXO-16/domain@verified` | isolated-development-workspace |
| merge | `EXO-AQ-G1@passed`; `EXO-AQ-G2@passed`; `EXO-AQ-G3@passed`; `EXO-AQ-G4@passed`; `EXO-WI-G1@passed`; `EXO-WI-G2@passed`; `WI-EMBEDDED-CORE-1@passed`; `WI-EMBEDDED-WORKER-PROOF-1@passed`; `WI-WORKER-G5@passed`; `EXO-ADR-026@passed`; `EXO-ADR-027@passed`; `EXO-ADR-034@passed`; `EXO-ADR-035@passed`; `EXO-ADR-036@passed`; `EXO-ADR-038@passed` | isolated-development-workspace |
| verify | `EXO-ENV-G2@passed` | kata-instance-test-host |

Additional AQ baseline receipts: None.

## `exo/EXO-15/integration`

Scope: `full`; evidence: `runtime-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-10@accepted`; `exo/EXO-11@accepted`; `exo/EXO-12@accepted`; `exo/EXO-13@accepted`; `exo/EXO-14@accepted`; `exo/EXO-15/domain@verified`; `exo/EXO-15/embedded-lifecycle@verified` | isolated-development-workspace |
| merge | `EXO-AQ-G2@passed`; `EXO-AQ-G3@passed`; `EXO-AQ-G4@passed`; `EXO-AQ-G5@passed`; `EXO-WI-G2@passed`; `EXO-WI-G3@passed`; `EXO-WI-G4@passed`; `EXO-WI-G5@passed`; `EXO-ADR-026@passed`; `EXO-ADR-027@passed`; `EXO-ADR-034@passed`; `EXO-ADR-035@passed`; `EXO-ADR-036@passed`; `EXO-ADR-038@passed` | isolated-development-workspace |
| verify | None | controlled-native-test-host |

Additional AQ baseline receipts: None.

## `exo/EXO-16/domain`

Scope: `domain`; evidence: `domain-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-03/domain@verified`; `exo/EXO-04/domain@verified`; `exo/EXO-08/domain@verified`; `exo/EXO-09/domain@verified`; `exo/EXO-10/domain@verified`; `exo/EXO-11/embedded-runtime@verified`; `exo/EXO-14/domain@verified`; `exo/EXO-15/domain@verified` | isolated-development-workspace |
| merge | `EXO-ADR-028@passed`; `EXO-ADR-036@passed` | isolated-development-workspace |
| verify | None | isolated-development-workspace |

Additional AQ baseline receipts: None.

## `exo/EXO-16/embedded-recovery`

Scope: `embedded-proof`; evidence: `kata-lifecycle-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-16/domain@verified`; `exo/EXO-15/embedded-lifecycle@verified` | isolated-development-workspace |
| merge | `EXO-AQ-G1@passed`; `EXO-AQ-G2@passed`; `EXO-AQ-G3@passed`; `EXO-AQ-G4@passed`; `EXO-WI-G1@passed`; `EXO-WI-G2@passed`; `WI-EMBEDDED-CORE-1@passed`; `WI-EMBEDDED-WORKER-PROOF-1@passed`; `WI-WORKER-G5@passed`; `EXO-ADR-028@passed`; `EXO-ADR-036@passed` | isolated-development-workspace |
| verify | `EXO-ENV-G2@passed` | kata-instance-test-host |

Additional AQ baseline receipts: AB-EXO-019, AB-EXO-020, AB-EXO-022, AB-EXO-023.

## `exo/EXO-16/integration`

Scope: `full`; evidence: `runtime-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-03@accepted`; `exo/EXO-04@accepted`; `exo/EXO-08@accepted`; `exo/EXO-09@accepted`; `exo/EXO-10@accepted`; `exo/EXO-11@accepted`; `exo/EXO-14@accepted`; `exo/EXO-15@accepted`; `exo/EXO-16/domain@verified`; `exo/EXO-16/embedded-recovery@verified` | isolated-development-workspace |
| merge | `EXO-AQ-G5@passed`; `EXO-WI-G4@passed`; `EXO-WI-G5@passed`; `EXO-ADR-028@passed`; `EXO-ADR-036@passed` | isolated-development-workspace |
| verify | None | controlled-native-test-host |

Additional AQ baseline receipts: None.

## `exo/EXO-17/integration`

Scope: `full`; evidence: `runtime-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-06@accepted`; `exo/EXO-07@accepted`; `exo/EXO-08@accepted`; `exo/EXO-09@accepted`; `exo/EXO-10@accepted`; `exo/EXO-11@accepted`; `exo/EXO-12@accepted`; `exo/EXO-13@accepted`; `exo/EXO-14@accepted`; `exo/EXO-15@accepted`; `exo/EXO-16@accepted` | isolated-development-workspace |
| merge | `EXO-AQ-G5@passed`; `EXO-WI-G4@passed`; `EXO-ADR-029@passed` | isolated-development-workspace |
| verify | None | controlled-native-test-host |

Additional AQ baseline receipts: AB-EXO-024.

## `exo/EXO-18/domain`

Scope: `domain`; evidence: `domain-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-11@accepted`; `exo/EXO-13/domain@verified`; `exo/EXO-15/domain@verified`; `exo/EXO-16/domain@verified`; `exo/EXO-17@accepted` | isolated-development-workspace |
| merge | `EXO-ADR-022@passed`; `EXO-ADR-030@passed`; `EXO-ADR-037@passed` | isolated-development-workspace |
| verify | None | isolated-development-workspace |

Additional AQ baseline receipts: None.

## `exo/EXO-18/instance-design`

Scope: `domain`; evidence: `domain-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-02/domain@verified` | isolated-development-workspace |
| merge | `EXO-ADR-022@passed`; `EXO-ADR-030@passed`; `EXO-ADR-037@passed`; `EXO-ADR-038@passed` | isolated-development-workspace |
| verify | None | isolated-development-workspace |

Additional AQ baseline receipts: None.

## `exo/EXO-18/instance-qualification`

Scope: `embedded-proof`; evidence: `kata-instance-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-18/instance-design@verified`; `exo/EXO-03/domain@verified` | isolated-development-workspace |
| merge | `EXO-ENV-G1@passed`; `EXO-ADR-022@passed`; `EXO-ADR-030@passed`; `EXO-ADR-037@passed` | isolated-development-workspace |
| verify | `exo/EXO-11/embedded-runtime@verified` | kata-instance-test-host |

Additional AQ baseline receipts: None.

## `exo/EXO-18/integration`

Scope: `full`; evidence: `runtime-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-11@accepted`; `exo/EXO-13@accepted`; `exo/EXO-15@accepted`; `exo/EXO-16@accepted`; `exo/EXO-17@accepted`; `exo/EXO-18/domain@verified`; `exo/EXO-18/instance-qualification@verified` | isolated-development-workspace |
| merge | `EXO-AQ-G5@passed`; `EXO-WI-G4@passed`; `EXO-WI-G5@passed`; `EXO-ADR-022@passed`; `EXO-ADR-030@passed`; `EXO-ADR-037@passed` | isolated-development-workspace |
| verify | `EXO-ENV-G1@passed`; `EXO-ENV-G2@passed` | controlled-native-test-host |

Additional AQ baseline receipts: None.

## `exo/EXO-19/embedded-viability`

Scope: `embedded-proof`; evidence: `embedded-viability-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `EXO-ENV-G2@passed`; `EXO-ENV-G3@passed`; `EXO-ENV-G4@passed`; `exo/EXO-14/embedded-provenance@verified` | isolated-development-workspace |
| merge | `EXO-AQ-G1@passed`; `EXO-AQ-G2@passed`; `EXO-AQ-G3@passed`; `EXO-AQ-G4@passed`; `EXO-WI-G1@passed`; `EXO-WI-G2@passed`; `WI-EMBEDDED-CORE-1@passed`; `WI-EMBEDDED-WORKER-PROOF-1@passed`; `EXO-ADR-038@passed` | isolated-development-workspace |
| verify | None | kata-instance-test-host |

Additional AQ baseline receipts: None.

## `exo/EXO-19/release`

Scope: `full`; evidence: `runtime-slice`.

| Phase | Prerequisites | Resources |
|---|---|---|
| start | `STACK-PLAN-ACCEPTED@passed`; `exo/EXO-18@accepted`; `EXO-AQ-G5@passed`; `EXO-WI-G5@passed`; `AQ-PUBLISHED@passed`; `WI-PUBLISHED@passed`; `exo/EXO-19/embedded-viability@verified` | isolated-development-workspace |
| merge | `EXO-AQ-G5@passed`; `EXO-WI-G5@passed`; `AQ-PUBLISHED@passed`; `WI-PUBLISHED@passed`; `EXO-ADR-038@passed` | isolated-development-workspace |
| verify | `EXO-EMBEDDED-VIABILITY-1@passed` | controlled-native-test-host |

Additional AQ baseline receipts: None.
