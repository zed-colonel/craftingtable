# Cross-stack concurrency draft · v0.2.0

**Definition:** `cross_stack_concurrency_map` · **schema/revision:** `0.2.0`  
**Map identity:** `EXO-STACK-CONCURRENCY-DRAFT-1`  
**Status:** draft for explicit review and version-bound import; no activation or execution authorized  
**Date:** September 12, 2026

This scheduling sidecar binds the latest supplied **AQ r2**, **WI r4 worker-provider**, and **EXO r5 WI-provider-alignment** planning packages. It replaces the v0.1.0 source binding only after review. It does not edit those packages, add top-level project work items, reopen AQ-CONT-1, or assert implementation progress.

## Start here

| Document | Purpose |
|---|---|
| [CONCURRENCY-MAP.md](CONCURRENCY-MAP.md) | Architectural scheduling overview, parallel lanes, producer/consumer and instance boundaries |
| [EMBEDDED-VIABILITY-PATH.md](EMBEDDED-VIABILITY-PATH.md) | Initial proof route without broader platform/release dependencies |
| [IMPORT-SPEC.md](IMPORT-SPEC.md) | Proposed application contract and schema migration from v0.1.0 |
| [WORK-ITEM-MATRIX.md](WORK-ITEM-MATRIX.md) | All 47 parents and 83 slices, phase prerequisites and evidence |
| [CHECKPOINT-CATALOG.md](CHECKPOINT-CATALOG.md) | All 111 checkpoints, including unchanged full upstream gates |
| [ACCEPTANCE-COVERAGE.md](ACCEPTANCE-COVERAGE.md) | Exact mapping of the 40 WP and 36 EE case specifications |
| [DECISIONS.md](DECISIONS.md) | Seventeen explicit draft decisions requiring map-version approval |
| [REVISION-NOTES.md](REVISION-NOTES.md) | Changes, preserved obligations and rebinding instructions |
| [SOURCE-BINDINGS.md](SOURCE-BINDINGS.md) | Three source ZIP identities and twenty exact source-file bindings |

The authoritative scheduling definition is [cross-stack-concurrency-map.yaml](cross-stack-concurrency-map.yaml), validated against [its JSON Schema](cross-stack-concurrency-map.schema.json). `milestone-graph.json` is a derived inspection artifact, not a separate planning authority.

## What this revision enables

The native WI-owned process-provider proof can proceed without Exoskeleton, a Kata host, platform services, or WI's separate host-supervisor checkpoint. Exoskeleton consumes that evidence and independently proves supervision/acceptance. Instance deployment and lifecycle qualification require actual Kata/containerd evidence. Embedded viability can finish while broad parent work and full platform/release obligations remain open.

The initial provider is `process-managed-proof-1`: reviewed fixture executables and approved non-sensitive inputs only. Its workers are not independently VM-isolated. A Kata Vessel instance is not evidence of an independent worker VM.

## Local verification

Use Python 3.10+ with PyYAML and jsonschema available. No network or repository credentials are required for these static checks.

```sh
python validate_map.py
python -m unittest discover -v
sha256sum -c SHA256SUMS
```

To additionally verify the three original ZIPs against the exact bindings:

```sh
python validate_map.py --source-archives-root /path/to/original-packages
```

The original ZIP filenames are listed in `SOURCE-BINDINGS.md`. The optional command only reads their bytes; it does not execute or extract their contents. All source snapshots are inert `.source.txt` files so they are not mistaken for additional work breakdowns.

**Do not send this sidecar to the generic `document`/`pull_requests` importer.** The application needs the `cross_stack_concurrency_map` 0.2.0 contract, or must retain the draft as supporting material without activating scheduling.

The 95 regression tests exercise definition and synthetic scheduler behavior. No application importer, target Rust code, worker process, Kata VM or production evidence has been exercised by this package.
