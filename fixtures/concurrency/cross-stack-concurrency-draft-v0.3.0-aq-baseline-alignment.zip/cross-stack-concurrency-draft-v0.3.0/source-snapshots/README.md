# Inert source snapshots

These twenty `.source.txt` files preserve exact original bytes selected from the three ZIP packages in `SOURCE-BINDINGS.md`. Their suffix prevents accidental import as duplicate work breakdowns or execution manifests. Parse according to the `format` recorded in the map only when validating the bound sources.

Original source requirements remain authoritative. Source owners and checkpoint criteria are not rewritten in the snapshots. The historical v0.1.0 map is separately held under `provenance/` and is not an active definition for this source set.
