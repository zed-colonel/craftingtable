import copy,unittest
from validate_map import HERE,load_yaml,validate_definition,expanded_graph,checkpoint_node as cp,project_validity,validate_baseline_case_receipts
class CompletedBaselineTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.d=load_yaml(HERE/'cross-stack-concurrency-map.yaml')
 def bad(self,mutate):
  d=copy.deepcopy(self.d);mutate(d);self.assertFalse(validate_definition(d,verify_sources=False)['valid'])
 def test_no_aq_lane(self):self.assertFalse(any(x['repository']=='aq' for x in self.d['work_items']))
 def test_no_aq_adr_queue(self):self.assertFalse(any(x['id'].startswith('AQ-ADR-') for x in self.d['checkpoints']))
 def test_no_commit_invention(self):self.assertIsNone(self.d['aq_baseline_binding']['implementation_commit'])
 def test_archive_tamper_rejected(self):self.bad(lambda d:d['aq_baseline_binding'].update(archive_sha256='0'*64))
 def test_tree_tamper_rejected(self):self.bad(lambda d:d['aq_baseline_binding'].update(source_tree_sha256='0'*64))
 def test_aq_source_not_automatic_pass(self):
  g=expanded_graph(self.d);v=project_validity(g,{cp('STACK-PLAN-ACCEPTED')});self.assertNotIn(cp('AQ-BASELINE-ACCEPTED'),v)
 def test_all_consumer_cases_bound(self):self.assertEqual(len(self.d['baseline_acceptance_coverage']),48)
 def test_case_omission_rejected(self):self.bad(lambda d:d['baseline_acceptance_coverage'].pop())
 def test_slice_case_omission_rejected(self):self.bad(lambda d:next(s for s in d['slices'] if s['aq_baseline_case_ids']).update(aq_baseline_case_ids=[]))
 def test_source_case_fingerprint_tamper(self):
  d=copy.deepcopy(self.d);d['baseline_acceptance_coverage'][0]['source_record_sha256']='0'*64;self.assertFalse(validate_definition(d)['valid'])
 def test_missing_runtime_receipts_rejected(self):
  s=next(s for s in self.d['slices'] if s['aq_baseline_case_ids']);r=validate_baseline_case_receipts(self.d,s['id'],[],'consumer','build');self.assertFalse(r['valid'])
 def test_planning_status_not_receipt(self):
  s=next(s for s in self.d['slices'] if s['aq_baseline_case_ids']);r=validate_baseline_case_receipts(self.d,s['id'],[{'case_id':s['aq_baseline_case_ids'][0],'result':'planned-not-run'}],'consumer','build');self.assertFalse(r['valid'])
 def test_no_publication_from_baseline_claim(self):
  g=expanded_graph(self.d);v=project_validity(g,{cp('STACK-PLAN-ACCEPTED'),cp('AQ-BASELINE-ACCEPTED')});self.assertNotIn(cp('AQ-PUBLISHED'),v);self.assertNotIn(cp('EXO-AQ-G5'),v)
 def test_active_aq_commit_rejected(self):self.bad(lambda d:next(r for r in d['repositories'] if r['id']=='aq').update(source_baseline_commit='9'*40))
if __name__=='__main__':unittest.main()
