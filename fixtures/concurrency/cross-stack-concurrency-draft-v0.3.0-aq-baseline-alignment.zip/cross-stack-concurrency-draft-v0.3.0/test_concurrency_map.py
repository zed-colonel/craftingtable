"""Regression tests for draft structure and synthetic milestone eligibility.

These tests do not execute the three target repositories or authenticate real
checkpoint evidence. Synthetic validity sets test dependency semantics only.
"""
from __future__ import annotations
import copy
import json
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from validate_map import (HERE, InputError, checkpoint_node as cp, expanded_graph,
                         eligible_milestones, invalidation_closure, load_yaml,
                         slice_node as sl, validate_definition, work_node as w)

class DraftTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.definition = load_yaml(HERE/'cross-stack-concurrency-map.yaml')
        cls.graph = expanded_graph(cls.definition)
        cls.all_nodes = set(cls.graph)
        cls.start = cp('STACK-PLAN-ACCEPTED')

    def draft(self): return copy.deepcopy(self.definition)
    def item(self,d,key,identifier): return next(x for x in d[key] if x['id']==identifier)
    def invalid(self,d,fragment=None,sources=False):
        result=validate_definition(d,verify_sources=sources)
        self.assertFalse(result['valid'])
        if fragment:self.assertTrue(any(fragment in x for x in result['errors']),result['errors'])
    def can_advance_without(self,node,*missing):
        valid = self.all_nodes - {node,*missing}
        return node in eligible_milestones(self.graph,valid)

    def test_source_definition_valid(self):
        r=validate_definition(self.definition)
        self.assertTrue(r['valid'],r['errors'])
        self.assertEqual(r['counts']['work_items'],33)
        self.assertEqual(r['counts']['slices'],69)
        self.assertEqual(r['counts']['checkpoints'],95)
    def test_empty_ledger_dispatches_no_work(self):
        ready=eligible_milestones(self.graph,set())
        self.assertEqual(ready,[self.start])
    def test_after_approval_two_roots_and_baseline_review(self):
        ready=eligible_milestones(self.graph,{self.start})
        self.assertEqual(set(ready),{cp('AQ-BASELINE-ACCEPTED'),sl('wi/WI-01/implementation','started'),sl('exo/EXO-01/domain','started')})
    def test_wi_local_fanout_without_aq_gates(self):
        valid={self.start,sl('wi/WI-02/domain')}
        ready=set(eligible_milestones(self.graph,valid))
        for n in [3,4,5,7,11,12]:
            self.assertIn(sl(f'wi/WI-{n:02d}/domain','started'),ready)
    def test_exo_lifecycle_epistemic_fanout(self):
        valid={self.start,sl('exo/EXO-02/domain')}
        ready=eligible_milestones(self.graph,valid)
        self.assertIn(sl('exo/EXO-03/domain','started'),ready)
        self.assertIn(sl('exo/EXO-04/domain','started'),ready)
    def test_exo_integrity_not_blocked_by_lifecycle_runtime(self):
        valid={self.start,sl('exo/EXO-02/domain'),sl('exo/EXO-04/domain')}
        self.assertIn(sl('exo/EXO-05/domain','started'),eligible_milestones(self.graph,valid))
    def test_completed_aq_is_not_runnable(self):
        self.assertFalse(any(n.startswith(('slice:aq/','work_item:aq/')) for n in self.graph))
    def test_baseline_review_does_not_imply_publication(self):
        self.assertFalse(self.can_advance_without(cp('AQ-PUBLISHED'),cp('AQ-BASELINE-ACCEPTED')))
    def test_wi04_real_merge_needs_g2(self):
        self.assertFalse(self.can_advance_without(sl('wi/WI-04/integration','merged'),cp('WI-AQ-G2')))
    def test_ingress_real_merge_needs_g2_and_g3(self):
        for cid in ['WI-AQ-G2','WI-AQ-G3']:
            self.assertFalse(self.can_advance_without(sl('wi/WI-03/integration','merged'),cp(cid)))
    def test_domain_only_never_accepts_mixed_parent(self):
        self.assertFalse(self.can_advance_without(w('exo/EXO-03'),sl('exo/EXO-03/integration')))
    def test_parent_keeps_original_dependencies(self):
        self.assertFalse(self.can_advance_without(w('exo/EXO-08'),w('exo/EXO-03')))
    def test_contract_ready_is_not_contract_pass(self):
        self.assertTrue(self.can_advance_without(cp('WI-AQ-G2')))
        # Eligibility alone did not modify any ledger or provider-consumer gate state.
        valid={self.start,cp('AQ-BASELINE-ACCEPTED')}
        before=set(valid)
        self.assertIn(cp('WI-AQ-G2'),eligible_milestones(self.graph,valid))
        self.assertEqual(valid,before)
        self.assertNotIn(cp('WI-AQ-G2'),valid)
    def test_wi_g5_does_not_require_aq14(self):
        self.assertTrue(self.can_advance_without(cp('WI-AQ-G5'),w('aq/AQ-14'),cp('AQ-PUBLISHED')))
    def test_exo_aq_g5_requires_actual_aq_publication(self):
        self.assertFalse(self.can_advance_without(cp('EXO-AQ-G5'),cp('AQ-PUBLISHED')))
    def test_exo_wi_g5_requires_wi14(self):
        self.assertFalse(self.can_advance_without(cp('EXO-WI-G5'),w('wi/WI-14')))
    def test_wi11_can_merge_before_rc_final_verification(self):
        self.assertTrue(self.can_advance_without(sl('wi/WI-11/integration','merged'),cp('WI-AQ-G5')))
        self.assertFalse(self.can_advance_without(sl('wi/WI-11/integration'),cp('WI-AQ-G5')))
    def test_exo11_parity_is_verify_only(self):
        self.assertTrue(self.can_advance_without(sl('exo/EXO-11/integration','merged'),cp('WI-DEPLOYMENT-PARITY')))
        self.assertFalse(self.can_advance_without(sl('exo/EXO-11/integration'),cp('WI-DEPLOYMENT-PARITY')))
    def test_exo15_keeps_conservative_g5(self):
        self.assertFalse(self.can_advance_without(sl('exo/EXO-15/integration','merged'),cp('EXO-AQ-G5')))
    def test_optional_identity_does_not_delete_wi12(self):
        self.assertFalse(self.can_advance_without(cp('EXO-WI-G4'),w('wi/WI-12')))
    def test_published_release_order(self):
        self.assertFalse(self.can_advance_without(sl('wi/WI-14/release','started'),cp('AQ-PUBLISHED')))
        self.assertFalse(self.can_advance_without(cp('EXO-PUBLISHED'),cp('WI-PUBLISHED')))
    def test_publication_not_inferred_from_exo19(self):
        d=self.item(self.definition,'slices','exo/EXO-19/release')
        self.assertEqual(d['mode'],'release_readiness')
        self.assertEqual(self.item(self.definition,'checkpoints','EXO-PUBLISHED')['status_on_import'],'unresolved')
    def test_invalidation_preserves_unrelated_domain_progress(self):
        affected=invalidation_closure(self.graph,{cp('WI-AQ-G2')})
        self.assertIn(sl('wi/WI-04/integration','merged'),affected)
        self.assertIn(w('wi/WI-04'),affected)
        self.assertIn(cp('EXO-WI-G2'),affected)
        self.assertNotIn(sl('wi/WI-04/domain'),affected)
    def test_unknown_plan_binding_rejected(self):
        d=self.draft(); d['repositories'][0]['source_work_breakdown']='missing-source'; self.invalid(d,'unknown work-breakdown source',sources=True)
    def test_unannotated_early_start_rejected(self):
        d=self.draft(); x=self.item(d,'slices','wi/WI-04/integration')
        x['start_requires']=[r for r in x['start_requires'] if r['kind']!='work_item']; self.invalid(d,'undeclared early-start relaxation')
    def test_integration_cannot_claim_domain_exception(self):
        d=self.draft(); x=self.item(d,'slices','wi/WI-04/integration')
        x['early_start_exception']=True; x['decision_refs']=['CS-D02','CS-D03']; self.invalid(d,'non-domain early start')
    def test_schema_version_unknown_rejected(self):
        d=self.draft(); d['schema_version']='9.0.0'; self.invalid(d,'schema_version')
    def test_unknown_field_rejected(self):
        d=self.draft(); d['silent_auto_pass']=True; self.invalid(d,'Additional properties')
    def test_automatic_activation_rejected(self):
        d=self.draft(); d['automatic_activation']=True; self.invalid(d,'automatic_activation')
    def test_unknown_dependency_rejected(self):
        d=self.draft(); d['slices'][0]['start_requires'].append({'kind':'checkpoint','id':'NOT-A-GATE','state':'passed'}); self.invalid(d,'unknown prerequisite')
    def test_cycle_rejected(self):
        d=self.draft(); d['slices'][0]['start_requires'].append({'kind':'work_item','id':'wi/WI-01','state':'accepted'}); self.invalid(d,'cycle')
    def test_duplicate_id_rejected(self):
        d=self.draft(); d['slices'].append(copy.deepcopy(d['slices'][0])); self.invalid(d,'duplicate ID')
    def test_gate_removed_rejected(self):
        d=self.draft(); x=self.item(d,'slices','exo/EXO-15/integration')
        x['merge_requires']=[r for r in x['merge_requires'] if r['id']!='EXO-AQ-G5']; self.invalid(d,'required checkpoint removed')
    def test_g5_alias_collapse_rejected(self):
        d=self.draft(); x=self.item(d,'checkpoints','EXO-AQ-G5')
        x['requires']=[r for r in x['requires'] if r['id']!='AQ-PUBLISHED']; self.invalid(d,'original producer')
    def test_parent_premature_acceptance_rejected(self):
        d=self.draft(); x=self.item(d,'work_items','exo/EXO-03'); x['acceptance_requires']=[]; self.invalid(d,'acceptance must retain')
    def test_original_scope_mutation_rejected(self):
        d=self.draft(); d['work_items'][0]['source_exit_gate']='Looks good'; self.invalid(d,'original exit_gate changed',sources=True)
    def test_adr_omission_rejected(self):
        d=self.draft(); x=self.item(d,'slices','wi/WI-02/domain'); x['merge_requires']=[r for r in x['merge_requires'] if r['id']!='WI-ADR-001']; self.invalid(d,'missing due ADR',sources=True)
    def test_missing_snapshot_rejected(self):
        d=self.draft(); d['source_files'][0]['snapshot_path']='missing.source.txt'; self.invalid(d,'missing source snapshot',sources=True)
    def test_unsafe_snapshot_path_rejected(self):
        d=self.draft(); d['source_files'][0]['snapshot_path']='../outside.txt'; self.invalid(d,'unsafe source snapshot path',sources=True)
    def test_snapshot_tamper_rejected(self):
        d=self.draft(); d['source_files'][0]['sha256']='0'*64; self.invalid(d,'source hash mismatch',sources=True)
    def test_duplicate_yaml_key_rejected(self):
        with tempfile.TemporaryDirectory() as t:
            p=Path(t)/'x.yaml'; p.write_text('document: one\ndocument: two\n')
            with self.assertRaises(InputError):load_yaml(p)
    def test_yaml_alias_rejected(self):
        with tempfile.TemporaryDirectory() as t:
            p=Path(t)/'x.yaml'; p.write_text('document: &a title\nother: *a\n')
            with self.assertRaises(InputError):load_yaml(p)
    def test_yaml_non_mapping_rejected(self):
        with tempfile.TemporaryDirectory() as t:
            p=Path(t)/'x.yaml'; p.write_text('- value\n')
            with self.assertRaises(InputError):load_yaml(p)
    def test_cli_pass_exit_code_and_json(self):
        p=subprocess.run([sys.executable,str(HERE/'validate_map.py')],capture_output=True,text=True,timeout=20)
        self.assertEqual(p.returncode,0,p.stdout+p.stderr)
        self.assertTrue(json.loads(p.stdout)['valid'])
    def test_cli_parse_error_exit_code(self):
        with tempfile.TemporaryDirectory() as t:
            p=Path(t)/'bad.yaml'; p.write_text('bad: [\n')
            r=subprocess.run([sys.executable,str(HERE/'validate_map.py'),str(p)],capture_output=True,text=True,timeout=20)
            self.assertEqual(r.returncode,2)
            self.assertFalse(json.loads(r.stdout)['valid'])

if __name__=='__main__':unittest.main(verbosity=2)
