"""Version-bound source, partial-proof, resource and scope regression tests.

Every graph/evidence set below is synthetic. No target implementation is run.
"""
from __future__ import annotations
import copy
import json
import tempfile
import unittest
from pathlib import Path

from validate_map import (HERE, InputError, ancestors, checkpoint_node as cp,
 expanded_graph, eligible_milestones, invalidation_closure, load_yaml, project_validity,
 resource_eligibility, slice_node as sl, validate_definition, verify_source_archives,
 work_node as w)

class ExecutionStagingTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.d=load_yaml(HERE/'cross-stack-concurrency-map.yaml')
  cls.g=expanded_graph(cls.d)
  cls.ss={s['id']:s for s in cls.d['slices']}
  cls.cs={c['id']:c for c in cls.d['checkpoints']}
 def bad(self,d,fragment,sources=False):
  result=validate_definition(d,verify_sources=sources)
  self.assertFalse(result['valid'])
  self.assertTrue(any(fragment in x for x in result['errors']),result['errors'])
 def mutate(self):return copy.deepcopy(self.d)
 def item(self,d,key,id):return next(x for x in d[key] if x['id']==id)
 def path(self,id):return ancestors(self.g,cp(id))
 def test_source_counts_and_bindings(self):
  r=validate_definition(self.d)
  self.assertTrue(r['valid'],r['errors'])
  for key,count in [('work_items',33),('slices',69),('checkpoints',95),('architecture_decision_checkpoints',58),('source_profile_acceptance_cases',76),('expanded_milestone_nodes',335)]:self.assertEqual(r['counts'][key],count)
 def test_wi_proof_does_not_depend_on_exo(self):
  self.assertFalse(any(n.startswith(('slice:exo/','work_item:exo/','checkpoint:EXO-')) for n in self.path('WI-EMBEDDED-WORKER-PROOF-1')))
 def test_wi_proof_does_not_depend_on_supervisor(self):
  self.assertNotIn(cp('WI-WORKER-G5'),self.path('WI-EMBEDDED-WORKER-PROOF-1'))
 def test_wi_supervisor_does_not_depend_on_worker_proof(self):
  path=self.path('WI-WORKER-G5')
  for n in ['WI-EMBEDDED-WORKER-PROOF-1','WI-WORKER-G3','WI-WORKER-G4']:self.assertNotIn(cp(n),path)
 def test_wi_proof_requires_real_aq_core(self):
  for gate in range(1,5):self.assertIn(cp(f'WI-AQ-G{gate}'),self.path('WI-EMBEDDED-WORKER-PROOF-1'))
 def test_wi_proof_needs_no_release_candidate(self):
  for n in ['WI-AQ-G5','AQ-PUBLISHED','WI-PUBLISHED']:self.assertNotIn(cp(n),self.path('WI-EMBEDDED-WORKER-PROOF-1'))
 def test_no_wi_hardware_requirement(self):
  for s in self.d['slices']:
   if s['id'].startswith('wi/'):self.assertNotIn('kata-instance-test-host',s['resources_by_phase']['verify'])
 def test_wi_domain_profile_design_can_start_early(self):
  valid={cp('STACK-PLAN-ACCEPTED'),sl('wi/WI-02/domain')}
  self.assertIn(sl('wi/WI-09/domain','started'),eligible_milestones(self.g,valid))
 def test_worker_profile_review_precedes_admission_merge(self):
  self.assertIn(cp('WI-WORKER-G1'),self.g[sl('wi/WI-04/domain','merged')])
  self.assertIn(cp('WI-WORKER-G1'),self.g[sl('wi/WI-05/domain','merged')])
 def test_provider_core_does_not_require_full_owner_completion(self):
  p=self.path('WI-EMBEDDED-CORE-1')
  for n in [6,7,8]:self.assertNotIn(w(f'wi/WI-{n:02d}'),p)
 def test_wi06_acceptance_retains_worker_and_supervisor_cases(self):
  p=self.g[w('wi/WI-06')]
  self.assertIn(sl('wi/WI-09/process-provider'),p)
  self.assertIn(sl('wi/WI-13/supervisor-conformance'),p)
 def test_wi08_acceptance_retains_worker_and_supervisor_cases(self):
  p=self.g[w('wi/WI-08')]
  self.assertIn(sl('wi/WI-09/process-provider'),p)
  self.assertIn(sl('wi/WI-13/supervisor-conformance'),p)
 def test_core_not_alias_for_full_g3(self):
  self.assertIn(w('wi/WI-06'),self.g[cp('EXO-WI-G3')])
  self.assertNotIn(w('wi/WI-06'),self.g[cp('WI-EMBEDDED-CORE-1')])
 def test_consumer_uses_scoped_core_without_losing_full_route(self):
  self.assertIn(cp('WI-EMBEDDED-CORE-1'),self.g[sl('exo/EXO-11/embedded-runtime','merged')])
  self.assertIn(cp('EXO-WI-G3'),self.g[sl('exo/EXO-11/integration','merged')])
 def test_exo_consumer_requires_wi_owned_proof(self):
  self.assertIn(cp('WI-EMBEDDED-WORKER-PROOF-1'),self.path('EXO-ENV-G3'))
  self.assertIn(sl('exo/EXO-13/embedded-acceptance'),self.path('EXO-ENV-G3'))
 def test_exo_lifecycle_requires_separate_supervisor(self):
  self.assertIn(cp('WI-WORKER-G5'),self.path('EXO-ENV-G4'))
  self.assertIn(sl('exo/EXO-15/embedded-lifecycle'),self.path('EXO-ENV-G4'))
 def test_instance_design_is_early(self):
  p=ancestors(self.g,sl('exo/EXO-18/instance-design','started'))
  self.assertNotIn(w('exo/EXO-17'),p)
  self.assertNotIn(cp('WI-DEPLOYMENT-PARITY'),p)
 def test_instance_qualification_does_not_wait_on_its_consumers(self):
  p=self.path('EXO-ENV-G2')
  for n in ['EXO-ENV-G3','EXO-ENV-G4','EXO-ENV-G5','EXO-EMBEDDED-VIABILITY-1']:self.assertNotIn(cp(n),p)
 def test_exo_profile_adr_consumes_wi_adr(self):
  self.assertIn(cp('WI-ADR-016'),self.g[cp('EXO-ADR-038')])
 def test_viability_no_broad_platform_or_publication(self):
  p=self.path('EXO-EMBEDDED-VIABILITY-1')
  for n in ['WI-AQ-G5','EXO-AQ-G5','EXO-WI-G3','EXO-WI-G4','EXO-WI-G5','WI-DEPLOYMENT-PARITY','AQ-PUBLISHED','WI-PUBLISHED','EXO-PUBLISHED']:self.assertNotIn(cp(n),p)
  for n in range(6,15):self.assertNotIn(w(f'wi/WI-{n:02d}'),p)
 def test_viability_does_not_accept_parents(self):
  claims=self.path('EXO-EMBEDDED-VIABILITY-1')|{cp('EXO-EMBEDDED-VIABILITY-1')}
  projected=project_validity(self.g,claims)
  self.assertIn(cp('EXO-EMBEDDED-VIABILITY-1'),projected)
  for parent in ['exo/EXO-11','exo/EXO-12','exo/EXO-19','wi/WI-09','wi/WI-11','wi/WI-14']:self.assertNotIn(w(parent),projected)
  self.assertNotIn(cp('EXO-PUBLISHED'),projected)
 def test_native_host_cannot_verify_kata(self):
  r=resource_eligibility(self.d,sl('exo/EXO-18/instance-qualification'),['isolated-development-workspace','controlled-native-test-host'])
  self.assertFalse(r['resource_eligible']);self.assertEqual(r['missing'],['kata-instance-test-host'])
 def test_kata_slice_can_start_without_hardware(self):
  r=resource_eligibility(self.d,sl('exo/EXO-18/instance-qualification','started'),['isolated-development-workspace'])
  self.assertTrue(r['resource_eligible']);self.assertFalse(r['execution_authority_granted'])
 def test_kata_resource_available_is_not_evidence(self):
  r=resource_eligibility(self.d,sl('exo/EXO-18/instance-qualification'),['kata-instance-test-host'])
  self.assertTrue(r['resource_eligible'])
  self.assertNotIn(sl('exo/EXO-18/instance-qualification'),eligible_milestones(self.g,set()))
 def test_gate_eligibility_never_passes_gate(self):
  claims=self.path('WI-EMBEDDED-WORKER-PROOF-1')
  self.assertNotIn(cp('WI-EMBEDDED-WORKER-PROOF-1'),project_validity(self.g,claims))
 def test_stale_wi_profile_invalidates_consumer_proof(self):
  stale=invalidation_closure(self.g,{cp('WI-WORKER-G1')})
  for n in ['WI-EMBEDDED-WORKER-PROOF-1','EXO-ENV-G3','EXO-EMBEDDED-VIABILITY-1']:self.assertIn(cp(n),stale)
  self.assertNotIn(w('aq/AQ-04'),stale)
 def test_hardware_evidence_revocation_preserves_native_wi(self):
  affected=invalidation_closure(self.g,{cp('EXO-ENV-G2')})
  self.assertIn(cp('EXO-EMBEDDED-VIABILITY-1'),affected)
  self.assertNotIn(cp('WI-EMBEDDED-WORKER-PROOF-1'),affected)
 def test_projection_rejects_orphan_claims(self):
  claims={cp('EXO-EMBEDDED-VIABILITY-1')}
  self.assertEqual(project_validity(self.g,claims),set())
 def test_all_source_case_coverage_preserved(self):
  self.assertEqual(len([c for c in self.d['acceptance_coverage'] if c['id'].startswith('WP-')]),40)
  self.assertEqual(len([c for c in self.d['acceptance_coverage'] if c['id'].startswith('EE-')]),36)
 def test_reference_hash_mismatch_rejected(self):
  d=self.mutate();self.item(d,'source_files','wi-worker-profile')['sha256']='0'*64
  self.bad(d,'provider definition mismatch',True)
 def test_case_digest_mutation_rejected(self):
  d=self.mutate();self.item(d,'acceptance_coverage','WP-019')['source_record_sha256']='f'*64
  self.bad(d,'source case fingerprint',True)
 def test_case_owner_mutation_rejected(self):
  d=self.mutate();self.item(d,'acceptance_coverage','WP-019')['owner_work_item']='wi/WI-09'
  self.bad(d,'source ownership changed',True)
 def test_hardware_case_cannot_become_native(self):
  d=self.mutate();self.item(d,'acceptance_coverage','EE-031')['requires_kata_host']=False
  self.bad(d,'source hardware requirement changed',True)
 def test_hardware_resource_cannot_be_removed(self):
  d=self.mutate();self.item(d,'slices','exo/EXO-18/instance-qualification')['resources_by_phase']['verify']=['controlled-native-test-host']
  self.bad(d,'hardware case lost')
 def test_missing_case_rejected(self):
  d=self.mutate();d['acceptance_coverage']=d['acceptance_coverage'][:-1]
  self.bad(d,'Expected all 40 WP')
 def test_source_profile_prereq_cannot_be_removed(self):
  d=self.mutate();c=self.item(d,'checkpoints','WI-WORKER-G3');c['requires']=[r for r in c['requires'] if r['id']!='WI-AQ-G4']
  self.bad(d,'profile prerequisites weakened',True)
 def test_producer_cannot_depend_on_exo(self):
  d=self.mutate();self.item(d,'checkpoints','WI-WORKER-G3')['requires'].append({'kind':'work_item','id':'exo/EXO-01','state':'accepted'})
  self.bad(d,'forbidden EXO dependency')
 def test_host_g5_cannot_block_worker_proof(self):
  d=self.mutate();self.item(d,'checkpoints','WI-EMBEDDED-WORKER-PROOF-1')['requires'].append({'kind':'checkpoint','id':'WI-WORKER-G5','state':'passed'})
  self.bad(d,'Supervisor G5 blocks')
 def test_broad_gate_cannot_block_embedded_viability(self):
  d=self.mutate();self.item(d,'slices','exo/EXO-19/embedded-viability')['start_requires'].append({'kind':'checkpoint','id':'EXO-WI-G4','state':'passed'})
  self.bad(d,'Embedded viability is blocked')
 def test_case_owner_scope_cannot_be_omitted(self):
  d=self.mutate();w0=self.item(d,'work_items','wi/WI-06');w0['source_profile_case_ids']=[]
  self.bad(d,'owned source case list changed')
 def test_parent_cannot_omit_case_producer_evidence(self):
  d=self.mutate();w0=self.item(d,'work_items','wi/WI-06');w0['acceptance_requires']=[r for r in w0['acceptance_requires'] if r['id']!='wi/WI-13/supervisor-conformance']
  self.bad(d,'acceptance must retain')
 def test_unknown_resource_rejected(self):
  d=self.mutate();self.item(d,'slices','wi/WI-09/process-provider')['resources_by_phase']['verify']=['magic-hardened-host']
  self.bad(d,'unknown resource profile')
 def test_previous_approval_cannot_be_inherited(self):
  d=self.mutate();d['previous_definition']['approval_inherited']=True
  self.bad(d,'approval_inherited')
 def test_missing_decision_blocks_activation(self):
  d=self.mutate();c=self.item(d,'checkpoints','STACK-PLAN-ACCEPTED');c['decision_refs']=c['decision_refs'][:-1]
  self.bad(d,'Activation omits')
 def test_missing_supplement_rejected(self):
  d=self.mutate();r=self.item(d,'repositories','exo');r['supplement_sources']=r['supplement_sources'][:-1]
  self.bad(d,'incomplete supplement source binding')
 def test_missing_archives_not_silent_success(self):
  with tempfile.TemporaryDirectory() as t:
   report=verify_source_archives(self.d,Path(t))
   self.assertFalse(report['valid']);self.assertEqual(len(report['errors']),3)
 def test_excessive_yaml_nesting_rejected(self):
  with tempfile.TemporaryDirectory() as t:
   p=Path(t)/'bad.yaml';p.write_text('document: '+('['*81)+'0'+(']'*81))
   with self.assertRaises(InputError):load_yaml(p)
 def test_missing_activation_checkpoint_is_validation_failure(self):
  d=self.mutate();d['checkpoints']=[c for c in d['checkpoints'] if c['id']!='STACK-PLAN-ACCEPTED'];self.bad(d,'Activation omits')
 def test_missing_source_binding_is_validation_failure(self):
  d=self.mutate();d['source_files']=[c for c in d['source_files'] if c['id']!='aq-plan'];self.bad(d,'Required source snapshot',True)
 def test_unsafe_previous_snapshot_rejected(self):
  d=self.mutate();d['previous_definition']['snapshot_path']='../outside.txt';self.bad(d,'Unsafe previous-definition path',True)

if __name__=='__main__':unittest.main(verbosity=2)
