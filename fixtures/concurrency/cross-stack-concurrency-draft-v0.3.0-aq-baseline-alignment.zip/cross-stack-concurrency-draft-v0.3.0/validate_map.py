#!/usr/bin/env python3
"""Validate the draft definition and its dependency graph, not implementation evidence.

Requires Python 3.10+, PyYAML, and jsonschema. No network requests or code execution
from the imported YAML. This is a reference design validator, not a production
scheduler, credential broker, test runner, or evidence verifier.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import re
import sys
from collections import Counter
from graphlib import CycleError, TopologicalSorter
from pathlib import Path
from typing import Any, Iterable
from functools import lru_cache

import yaml
from jsonschema import Draft202012Validator

HERE = Path(__file__).resolve().parent
MAX_INPUT_BYTES = 5_000_000

class InputError(ValueError):
    pass

class UniqueKeyLoader(yaml.SafeLoader):
    pass

def unique_mapping(loader: UniqueKeyLoader, node: yaml.MappingNode, deep: bool = False) -> dict:
    result: dict = {}
    for key_node, value_node in node.value:
        key = loader.construct_object(key_node, deep=deep)
        if not isinstance(key, str):
            raise InputError('Mapping keys must be strings')
        try:
            if key in result:
                raise InputError(f"Duplicate YAML key: {key!r}")
        except TypeError as exc:
            raise InputError("Mapping keys must be scalar and hashable") from exc
        result[key] = loader.construct_object(value_node, deep=deep)
    return result

UniqueKeyLoader.add_constructor(yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG, unique_mapping)

def load_yaml(path: Path) -> Any:
    data = path.read_bytes()
    if len(data) > MAX_INPUT_BYTES:
        raise InputError(f"Input exceeds {MAX_INPUT_BYTES} bytes")
    text = data.decode('utf-8')
    # Reject aliases/anchors to keep import semantics and resource bounds simple.
    for token in yaml.scan(text):
        if isinstance(token, (yaml.tokens.AnchorToken, yaml.tokens.AliasToken)):
            raise InputError("YAML anchors and aliases are not supported by this draft")
    depth = 0
    for event in yaml.parse(text):
        if isinstance(event, (yaml.events.MappingStartEvent, yaml.events.SequenceStartEvent)):
            depth += 1
            if depth > 80: raise InputError('YAML nesting exceeds 80 levels')
        elif isinstance(event, (yaml.events.MappingEndEvent, yaml.events.SequenceEndEvent)):
            depth -= 1
    value = yaml.load(text, Loader=UniqueKeyLoader)
    if not isinstance(value, dict):
        raise InputError("Top-level YAML must be a mapping")
    return value

def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def record_digest(value: Any) -> str:
    return digest(json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode())

def node_key(kind: str, identifier: str, state: str) -> str:
    return f'{kind}:{identifier}@{state}'

def requirement_key(requirement: dict) -> str:
    return node_key(requirement['kind'], requirement['id'], requirement['state'])

def work_node(identifier: str) -> str:
    return node_key('work_item', identifier, 'accepted')

def slice_node(identifier: str, state: str = 'verified') -> str:
    return node_key('slice', identifier, state)

def checkpoint_node(identifier: str) -> str:
    return node_key('checkpoint', identifier, 'passed')

def expanded_graph(definition: dict) -> dict[str, set[str]]:
    """Return milestone -> predecessor milestones. Edges alone NEVER prove a pass."""
    graph: dict[str, set[str]] = {}
    for item in definition['work_items']:
        graph[work_node(item['id'])] = {requirement_key(r) for r in item['acceptance_requires']}
    for item in definition['slices']:
        started = slice_node(item['id'], 'started')
        merged = slice_node(item['id'], 'merged')
        verified = slice_node(item['id'], 'verified')
        graph[started] = {requirement_key(r) for r in item['start_requires']}
        graph[merged] = {started} | {requirement_key(r) for r in item['merge_requires']}
        graph[verified] = {merged} | {requirement_key(r) for r in item['verify_requires']}
    for item in definition['checkpoints']:
        graph[checkpoint_node(item['id'])] = {requirement_key(r) for r in item['requires']}
    return graph

def eligible_milestones(graph: dict[str, set[str]], valid: Iterable[str]) -> list[str]:
    """Abstract prerequisite eligibility only; caller must first verify evidence.

    `valid` is a synthetic trusted set in the regression tests. A production
    application MUST derive validity from authenticated, version-bound evidence,
    recursively revalidate prerequisites, and enforce resource/review rules.
    """
    valid_set = set(valid)
    return sorted(n for n, deps in graph.items() if n not in valid_set and deps <= valid_set)

def invalidation_closure(graph: dict[str, set[str]], changed: Iterable[str]) -> set[str]:
    """Conservative graph-dependent invalidation; retain historical evidence."""
    result = set(changed)
    while True:
        added = {n for n, deps in graph.items() if deps & result} - result
        if not added:
            return result
        result.update(added)


def ancestors(graph: dict[str, set[str]], node: str) -> set[str]:
    """Transitive prerequisite closure, excluding the target itself."""
    result: set[str] = set()
    pending = list(graph.get(node, ()))
    while pending:
        value = pending.pop()
        if value in result:
            continue
        result.add(value)
        pending.extend(graph.get(value, ()))
    return result


def project_validity(graph: dict[str, set[str]], authenticated_claims: Iterable[str]) -> set[str]:
    """Synthetic reference projection. Does not authenticate, approve or auto-pass evidence.

    Real code must first validate claim signatures, reviewer independence, exact pin
    compatibility, case evidence, revocation and the active map generation.
    """
    supplied = set(authenticated_claims)
    valid: set[str] = set()
    for node in TopologicalSorter(graph).static_order():
        if node in supplied and graph[node] <= valid:
            valid.add(node)
    return valid


def resource_eligibility(definition: dict, milestone: str, available_profiles: Iterable[str]) -> dict:
    """Classify resource availability separately from dependency/evidence validity.

    This helper does not reserve resources or grant permission to execute fixtures.
    Actual allocation, independent fixture approval and atomic leases are external.
    """
    resources: set[str] = set()
    if milestone.startswith('slice:'):
        sid, state = milestone[len('slice:'):].rsplit('@', 1)
        sl = next((s for s in definition['slices'] if s['id'] == sid), None)
        phase = {'started':'start', 'merged':'merge', 'verified':'verify'}.get(state)
        if sl is None or phase is None:
            return {'resource_eligible': False, 'missing': ['unknown milestone']}
        resources = set(sl['resources_by_phase'][phase])
    missing = resources - set(available_profiles)
    return {'resource_eligible': not missing, 'required': sorted(resources), 'missing': sorted(missing), 'execution_authority_granted': False}


def target_analyses(definition: dict, graph: dict[str, set[str]]) -> list[dict]:
    result = []
    slices = {s['id']: s for s in definition['slices']}
    for t in definition['planning_targets']:
        target = checkpoint_node(t['checkpoint'])
        path = ancestors(graph, target) | {target}
        hardware = sorted(sid for sid,s in slices.items() if slice_node(sid) in path and 'kata-instance-test-host' in s['resources_by_phase']['verify'])
        parents = sorted(w['id'] for w in definition['work_items'] if work_node(w['id']) in path)
        result.append({'target': t['id'], 'is_release': t['is_release'], 'prerequisite_milestones_including_target': len(path), 'verified_kata_slices': hardware, 'accepted_parents_in_prerequisite_closure': parents, 'interpretation': 'Dependency closure only, not completed work or runtime evidence.'})
    return result


def validate_profiles_and_slices(d: dict, indexes: dict, require) -> None:
    ws,ss,cs=(indexes[k] for k in ('work_items','slices','checkpoints'))
    graph=expanded_graph(d)
    resources=set(indexes['resource_profiles'])
    sources=indexes['source_files']
    require(len(d['source_archives']) == 3 and {a['repository'] for a in d['source_archives']} == {'aq','wi','exo'}, 'Exactly three source archive bindings required', 'binding')
    require(len(d['source_files']) == 30, 'Expected 30 bound source files', 'binding')
    require(len(d['acceptance_coverage']) == 76, 'Expected all 40 WP and 36 EE source cases', 'case_coverage')
    require(len(d['decisions']) == 18, 'Expected 18 explicit draft decisions', 'binding')
    require(set(cs.get('STACK-PLAN-ACCEPTED',{}).get('decision_refs',[])) == set(indexes['decisions']), 'Activation omits a reviewed decision', 'binding')
    for repository in d['repositories']:
        rid=repository['id']
        supplements={s['id'] for s in d['source_files'] if s['repository']==rid and s['id'] not in (repository['source_plan'],repository['source_work_breakdown'])}
        require(set(repository['supplement_sources']) == supplements, f'{rid}: incomplete supplement source binding', 'binding')
    for x in d['source_files']:
        require(x['id'].startswith(x['repository']+'-'), f"{x['id']}: incorrect owning source repository", 'binding')
    for sid,s in ss.items():
        for phase,rr in s['resources_by_phase'].items():
            require(set(rr) <= resources, f'{sid}/{phase}: unknown resource profile', 'resources')
        require(s['merge_lock']==s['work_item'].split('/')[0]+'-target-branch', f'{sid}: wrong repository merge lock', 'resources')
        if s['partial_scope'] in ('embedded-proof','supervisor-proof'):
            require('CS-D12' in s['decision_refs'], f'{sid}: partial runtime scope requires CS-D12', 'scope')
        if s['mode']=='domain':
            require(s['partial_scope']=='domain', f'{sid}: domain mode/partial_scope mismatch', 'scope')
        if 'kata-instance-test-host' in s['resources_by_phase']['verify']:
            require(sid.startswith('exo/'), f'{sid}: producer/native work acquired a Kata requirement', 'resources')
    # Every new source case is bound, and the producing work is a prerequisite of its own checkpoint.
    for c in d['acceptance_coverage']:
        require(c['source_id'] in sources, f"{c['id']}: unknown case source", 'case_coverage')
        require(c['checkpoint'] in cs, f"{c['id']}: missing case checkpoint", 'case_coverage')
        require(c['owner_work_item'] in ws, f"{c['id']}: unknown source owner", 'case_coverage')
        for sid in c['producing_slices']:
            require(sid in ss, f"{c['id']}: unknown producing slice", 'case_coverage')
            require(slice_node(sid) in ancestors(graph,checkpoint_node(c['checkpoint'])), f"{c['id']}: checkpoint can pass without producer evidence", 'case_coverage')
            if c['requires_kata_host'] and sid in ss:
                require('kata-instance-test-host' in ss[sid]['resources_by_phase']['verify'], f"{c['id']}: hardware case lost its Kata verification resource", 'resources')
    for w in ws.values():
        owned=[c for c in d['acceptance_coverage'] if c['owner_work_item']==w['id']]
        require(w['source_profile_case_ids']==[c['id'] for c in owned], f"{w['id']}: owned source case list changed", 'acceptance')
        expected=list(dict.fromkeys(x for c in owned for x in c['producing_slices']))
        require(w['profile_evidence_slices']==expected, f"{w['id']}: assigned case-producing evidence lost", 'acceptance')
    fixed={
      ('wi/WI-09/process-provider','merge_requires'): ['WI-EMBEDDED-CORE-1','WI-WORKER-G1','WI-WORKER-G2']+[f'WI-AQ-G{i}' for i in range(1,5)],
      ('wi/WI-11/supervisor-boundary','merge_requires'): ['WI-EMBEDDED-CORE-1','WI-WORKER-G1','WI-WORKER-G2']+[f'WI-AQ-G{i}' for i in range(1,5)],
      ('exo/EXO-11/embedded-runtime','merge_requires'): ['WI-EMBEDDED-CORE-1','EXO-WI-G1','EXO-WI-G2']+[f'EXO-AQ-G{i}' for i in range(1,5)],
      ('exo/EXO-12/embedded-worker','merge_requires'): ['WI-EMBEDDED-WORKER-PROOF-1','EXO-ADR-038'],
      ('exo/EXO-15/embedded-lifecycle','merge_requires'): ['WI-WORKER-G5','WI-EMBEDDED-WORKER-PROOF-1'],
      ('exo/EXO-15/embedded-lifecycle','verify_requires'): ['EXO-ENV-G2'],
      ('exo/EXO-16/embedded-recovery','verify_requires'): ['EXO-ENV-G2'],
      ('exo/EXO-19/release','verify_requires'): ['EXO-EMBEDDED-VIABILITY-1']
    }
    for (sid,phase),gates in fixed.items():
        require(sid in ss, f'Missing scoped slice {sid}', 'checkpoint_preservation')
        if sid in ss:
            actual={r['id'] for r in ss[sid][phase] if r['kind']=='checkpoint'}
            require(set(gates)<=actual, f'{sid}/{phase}: required scoped checkpoint removed', 'checkpoint_preservation')
    for target in d['planning_targets']:
        require(target['checkpoint'] in cs, f"{target['id']}: unknown target checkpoint", 'references')
    require(d['scheduling_policy']['suggested_focus_target'] in indexes['planning_targets'], 'Unknown focus target', 'references')
    proof='WI-EMBEDDED-WORKER-PROOF-1'
    viability='EXO-EMBEDDED-VIABILITY-1'
    for target,prefix,n in [(proof,'WI-WORKER-G',4),(viability,'EXO-ENV-G',5)]:
        require(target in cs, f'Missing milestone {target}', 'checkpoint_preservation')
        if target in cs:
            deps={r['id'] for r in cs[target]['requires'] if r['kind']=='checkpoint' and r['id']!='STACK-PLAN-ACCEPTED'}
            require(deps == {prefix+str(i) for i in range(1,n+1)}, f'{target}: source milestone checkpoint set changed', 'checkpoint_preservation')
    producer_path=ancestors(graph,checkpoint_node(proof))
    require(not any(n.startswith(('slice:exo/','work_item:exo/','checkpoint:EXO-')) for n in producer_path), 'WI provider proof has a forbidden EXO dependency', 'staging')
    require(checkpoint_node('WI-WORKER-G5') not in producer_path, 'Supervisor G5 blocks the basic worker proof', 'staging')
    supervisor_path=ancestors(graph,checkpoint_node('WI-WORKER-G5'))
    require(not any(n.startswith(('slice:exo/','work_item:exo/','checkpoint:EXO-')) for n in supervisor_path), 'WI supervisor proof depends on EXO', 'staging')
    require(checkpoint_node(proof) not in supervisor_path and checkpoint_node('WI-WORKER-G3') not in supervisor_path, 'Supervisor proof was made dependent on basic worker proof', 'staging')
    viability_path=ancestors(graph,checkpoint_node(viability))
    forbidden={checkpoint_node(c) for c in ['EXO-AQ-G5','EXO-WI-G3','EXO-WI-G4','EXO-WI-G5','WI-AQ-G5','WI-DEPLOYMENT-PARITY','AQ-PUBLISHED','WI-PUBLISHED','EXO-PUBLISHED']}
    forbidden|={work_node(f'wi/WI-{i:02d}') for i in range(6,15)}
    forbidden|={work_node(f'exo/EXO-{i:02d}') for i in range(11,20)}
    require(not (viability_path & forbidden), 'Embedded viability is blocked on unrequired full/platform/release milestones: '+str(sorted(viability_path & forbidden)), 'staging')
    require(checkpoint_node(proof) in ancestors(graph,checkpoint_node('EXO-ENV-G3')), 'EXO consumer proof lost WI producer proof', 'staging')
    require(checkpoint_node('WI-WORKER-G5') in ancestors(graph,checkpoint_node('EXO-ENV-G4')), 'EXO lifecycle lost distinct supervisor evidence', 'staging')
    for node in producer_path|supervisor_path:
        if node.startswith('slice:') and node.endswith('@verified'):
            sid=node[len('slice:'):-len('@verified')]
            if sid in ss:require('kata-instance-test-host' not in ss[sid]['resources_by_phase']['verify'], f'{sid}: Kata prerequisite leaked into native WI qualification', 'resources')
    # The qualified-instance producer is independent of its later recovery and viability consumers.
    require(checkpoint_node('EXO-ENV-G4') not in ancestors(graph,checkpoint_node('EXO-ENV-G2')), 'Instance qualification depends on its recovery consumer', 'staging')


def validate_bound_sources(d: dict, root: Path, content: dict[str,bytes], require) -> None:
    sf={x['id']:x for x in d['source_files']}
    def read(sid):
        if sid not in content:return None
        try:
            return json.loads(content[sid]) if sf[sid]['format']=='json' else load_yaml(root/sf[sid]['snapshot_path'])
        except (ValueError,InputError,yaml.YAMLError) as exc:
            require(False,f'{sid}: invalid bound source: {exc}','source_preservation');return None
    # Verify the authoritatively owned provider definition across both packages.
    ref=read('exo-provider-reference')
    if ref:
        require(ref['owner_plan_revision']=='WI-PLAN-5' and ref['provider_contract_id']=='WI-WORKER-EXECUTION-1', 'EXO provider ownership binding changed','provider_binding')
        for filename,h in ref['files'].items():
            matches=[x for x in d['source_files'] if x['repository']=='wi' and x['original_path'].endswith('/'+filename)]
            require(len(matches)==1,f'{filename}: WI provider reference is missing/ambiguous','provider_binding')
            if len(matches)==1:
                require(matches[0]['sha256']==h,f'{filename}: EXO-to-WI provider definition mismatch','provider_binding')
    coverage={x['id']:x for x in d['acceptance_coverage']};cs={x['id']:x for x in d['checkpoints']}
    for sid,prefix,count in [('wi-worker-cases','WP-',40),('exo-execution-cases','EE-',36)]:
        matrix=read(sid)
        if not matrix:continue
        cases=matrix['cases']
        require(len(cases)==count,f'{sid}: incorrect source case count','case_coverage')
        require({c['id'] for c in cases}=={c['id'] for c in d['acceptance_coverage'] if c['source_id']==sid},f'{sid}: source case set changed','case_coverage')
        for original in cases:
            if original['id'] not in coverage:continue
            c=coverage[original['id']]
            require(c['source_record_sha256']==record_digest(original),f"{c['id']}: source case fingerprint changed",'case_coverage')
            require(c['checkpoint']==original['checkpoint'],f"{c['id']}: source case checkpoint changed",'case_coverage')
            require(c['owner_work_item']==sid.split('-')[0]+'/'+original['owner_pr'],f"{c['id']}: source ownership changed",'case_coverage')
            require(c['requires_kata_host']==original['requires_kata_host'],f"{c['id']}: source hardware requirement changed",'case_coverage')
    for sid in ['wi-worker-profile','exo-execution-profile']:
        profile=read(sid)
        if not profile:continue
        for pc in profile['checkpoints']:
            cid=pc['id'];require(cid in cs,f'{cid}: missing source checkpoint','checkpoint_preservation')
            if cid not in cs:continue
            c=cs[cid];require(c['pass_criteria'][0]==pc['criterion'],f'{cid}: original profile criterion changed','checkpoint_preservation')
            owner=sid.split('-')[0]
            require(c.get('evidence_owners')==[owner+'/'+v for v in pc['evidence_owners']],f'{cid}: source owner attribution changed','checkpoint_preservation')
            required_cp=set(pc.get('requires_checkpoints',[])+pc.get('required_aq_gates_for_real_integration',[]))
            actual={r['id'] for r in c['requires'] if r['kind']=='checkpoint'}
            require(required_cp <= actual,f'{cid}: profile prerequisites weakened','checkpoint_preservation')
    # Retain the previous draft as provenance, but never inherit its approval.
    prev=d['previous_definition'];pp=(root/prev['snapshot_path']).resolve()
    require(pp.is_relative_to(root), 'Unsafe previous-definition path','source_hashes')
    if not pp.is_relative_to(root):return
    require(pp.is_file(),'Missing previous-definition snapshot','source_hashes')
    if not pp.is_file():return
    require(digest(pp.read_bytes())==prev['sha256'],'Previous-definition hash mismatch','source_hashes')
    old=load_yaml(pp)
    old_files={x['id']:x for x in old['source_files']}
    for sid in ['aq-plan','aq-work-breakdown']:
        require(sid in sf and sf[sid]['sha256']==old_files[sid]['sha256'],f'{sid}: ActionQueue source was changed or omitted','source_preservation')
    ss={x['id']:x for x in d['slices']}
    require(not any(s.startswith('aq/') for s in ss), 'Completed AQ implementation cannot be scheduled', 'source_preservation')
    require(d['aq_baseline_binding']['retired_work_items']==[x['id'] for x in old['work_items'] if x['repository']=='aq'], 'AQ retired-work provenance changed', 'source_preservation')
    require(d['aq_baseline_binding']['retired_adr_checkpoints']==[x['id'] for x in old['checkpoints'] if x['id'].startswith('AQ-ADR-')], 'AQ frozen ADR provenance changed', 'source_preservation')
    # All original full gate sets and actual publication criteria remain at least as strong.
    for old_cp in old['checkpoints']:
        if old_cp['kind'] not in ['contract','publication']:continue
        cid=old_cp['id'];require(cid in cs,f'{cid}: original contract/publication gate missing','checkpoint_preservation')
        if cid in cs:
            before={checkpoint_node('AQ-BASELINE-ACCEPTED') if x['kind']=='work_item' and x['id'].startswith('aq/') else requirement_key(x) for x in old_cp['requires']};after={requirement_key(x) for x in cs[cid]['requires']}
            require(before<=after,f'{cid}: original full/publication prerequisite weakened','checkpoint_preservation')
            require(all(v in cs[cid]['pass_criteria'] for v in old_cp['pass_criteria']),f'{cid}: original full/publication criteria weakened','checkpoint_preservation')
    # Every supplied source line reference is within actual bound content.
    for collection in ['slices','checkpoints','work_items']:
        for item in d[collection]:
            refs=item.get('source_refs',[item['source_test_reference']] if 'source_test_reference' in item else [])
            for ref in refs:
                if 'end_line' in ref and ref['source_id'] in content:
                    n=len(content[ref['source_id']].decode().splitlines())
                    require(ref['end_line']<=n,f"{item['id']}: source reference beyond file",'references')


def verify_source_archives(d: dict, directory: Path) -> dict:
    """Compare supplied local original ZIPs; never extract untrusted archive paths."""
    import zipfile
    errors=[];members=0
    for binding in d['source_archives']:
        path=(directory/binding['filename']).resolve()
        if not path.is_relative_to(directory.resolve()) or not path.is_file():
            errors.append(f"{binding['repository']}: missing or unsafe source archive");continue
        if digest(path.read_bytes()) != binding['sha256']:
            errors.append(f"{binding['repository']}: source archive hash mismatch");continue
        try:
            with zipfile.ZipFile(path) as z:
                if z.testzip() is not None:errors.append(f"{binding['repository']}: source ZIP corruption")
                for sf in d['source_files']:
                    if sf['repository']!=binding['repository']:continue
                    info=z.getinfo(sf['original_path'])
                    if info.file_size>MAX_INPUT_BYTES:
                        errors.append(f"{sf['id']}: source archive member too large");continue
                    if digest(z.read(info))!=sf['sha256']:errors.append(f"{sf['id']}: archive member differs from snapshot")
                    members+=1
        except (OSError,ValueError,KeyError,zipfile.BadZipFile) as exc:errors.append(str(exc))
    return {'valid':not errors,'archives':len(d['source_archives']),'compared_members':members,'errors':errors}


def validate_definition(definition: dict, root: Path = HERE, verify_sources: bool = True) -> dict:
    errors: list[str] = []
    checks = Counter()
    schema = json.loads((HERE / 'cross-stack-concurrency-map.schema.json').read_text())
    Draft202012Validator.check_schema(schema)
    for e in sorted(Draft202012Validator(schema).iter_errors(definition), key=lambda e: str(list(e.path))):
        errors.append(f"schema/{'/'.join(map(str, e.path))}: {e.message}")
    checks['json_schema'] = 1
    if errors:
        return {'valid': False, 'errors': errors, 'checks_by_category': dict(checks)}

    def require(condition: bool, message: str, category: str = 'semantic') -> None:
        checks[category] += 1
        if not condition:
            errors.append(message)

    indexes: dict[str, dict] = {}
    for name in ('work_items','slices','checkpoints','repositories','source_files','decisions','evidence_profiles','resource_locks','resource_profiles','acceptance_coverage','planning_targets'):
        rows = definition[name]
        ids = [r['id'] for r in rows]
        require(len(ids) == len(set(ids)), f'duplicate ID in {name}', 'identifiers')
        indexes[name] = {r['id']: r for r in rows}
    ws, ss, cs = (indexes[k] for k in ('work_items','slices','checkpoints'))
    expected_sources = {r+'-'+suffix for r in ('aq','wi','exo') for suffix in ('plan','work-breakdown')}
    require(expected_sources <= set(indexes['source_files']), 'Required source snapshot identities are incomplete', 'references')
    for r in definition['repositories']:
        require(r['source_plan'] in indexes['source_files'], f"{r['id']}: unknown plan source", 'references')
        require(r['source_work_breakdown'] in indexes['source_files'], f"{r['id']}: unknown work-breakdown source", 'references')
        require((r['id']=='aq' and r['merge_lock'] is None) or r['merge_lock'] in indexes['resource_locks'], f"{r['id']}: unknown repository merge lock", 'references')
        require(r['source_plan'] == r['id']+'-plan' and r['source_work_breakdown'] == r['id']+'-work-breakdown', f"{r['id']}: cross-repository source binding mismatch", 'references')
    require(set(indexes['repositories']) == {'aq','wi','exo'}, 'Exactly the three source repositories are required', 'source_preservation')
    require(len(ws) == 33, 'Expected 33 active WI/EXO source work items', 'source_preservation')
    require(len(ss) == 69, 'This draft revision contains 69 explicitly reviewed slice definitions', 'source_preservation')
    require(len(cs) == 95, 'This draft revision contains 95 checkpoint definitions', 'source_preservation')
    require(definition['terminal_checkpoint'] in cs, 'Unknown terminal checkpoint', 'references')
    for collection in ('checkpoints','slices'):
        for item in definition[collection]:
            require(item['evidence_profile'] in indexes['evidence_profiles'], f"{item['id']}: unknown evidence profile", 'references')
            require(set(item['decision_refs']) <= set(indexes['decisions']), f"{item['id']}: unknown draft decision", 'references')
            for src in item['source_refs']:
                require(src['source_id'] in indexes['source_files'], f"{item['id']}: unknown source {src['source_id']}", 'references')
                if 'start_line' in src and 'end_line' in src:
                    require(src['end_line'] >= src['start_line'], f"{item['id']}: inverted source line range", 'references')
    for item in ws.values():
        rid = item['repository']
        require(item['source_test_reference']['source_id'] == rid+'-plan', f"{item['id']}: incorrect source test reference", 'references')
        require(item['acceptance_evidence_profile'] in indexes['evidence_profiles'], f"{item['id']}: unknown parent evidence profile", 'references')
        require(item['id'] == rid + '/' + item['source_item_id'], f"{item['id']}: identity/repository mismatch", 'identifiers')
        require(set(item['depends_on']) <= set(ws), f"{item['id']}: unknown source dependency", 'references')
        require(set(item['required_slices']) <= set(ss), f"{item['id']}: unknown slice", 'references')
        expected = {work_node(i) for i in item['depends_on']} | {slice_node(i) for i in item['required_slices']} | {slice_node(i) for i in item['profile_evidence_slices']}
        require({requirement_key(r) for r in item['acceptance_requires']} == expected,
                f"{item['id']}: acceptance must retain all original dependencies, required slices and assigned source-profile evidence", 'acceptance')
        for sid in item['required_slices']:
            if sid in ss:
                require(ss[sid]['work_item'] == item['id'], f'{sid}: wrong parent', 'references')
    for item in ss.values():
        require(item['work_item'] in ws, f"{item['id']}: unknown parent", 'references')
        require(item['id'].startswith(item['work_item'] + '/'), f"{item['id']}: non-parent-qualified slice ID", 'identifiers')
        require(item['merge_lock'] in indexes['resource_locks'], f"{item['id']}: unknown merge lock", 'references')
        require(checkpoint_node('STACK-PLAN-ACCEPTED') in {requirement_key(r) for r in item['start_requires']},
                f"{item['id']}: missing activation barrier", 'acceptance')
        if item['work_item'] in ws:
            require(item['id'] in ws[item['work_item']]['required_slices'], f"{item['id']}: orphan slice", 'references')
        if item['early_start_exception']:
            require({'CS-D02','CS-D03'} <= set(item['decision_refs']), f"{item['id']}: early start needs approved slice decisions", 'acceptance')
            require(item['mode'] == 'domain' or (item['partial_scope'] in ('embedded-proof','supervisor-proof') and 'CS-D12' in item['decision_refs']), f"{item['id']}: non-domain early start needs an explicit partial scope and CS-D12", 'acceptance')
        elif item['work_item'] in ws:
            parent_deps = {work_node(i) for i in ws[item['work_item']]['depends_on']}
            actual_start = {requirement_key(r) for r in item['start_requires']}
            require(parent_deps <= actual_start, f"{item['id']}: undeclared early-start relaxation", 'acceptance')
        if item['mode'] == 'domain':
            require(item['evidence_profile'] == 'domain-slice', f"{item['id']}: pure slice must use isolation evidence", 'acceptance')
        if item['id'].startswith('aq/'):
            number = int(item['work_item'].rsplit('-',1)[1])
            if number > 1:
                predecessor = f'aq/AQ-{number-1:02d}'
                require(work_node(predecessor) in {requirement_key(r) for r in item['merge_requires']},
                        f"{item['id']}: AQ ordered-merge discipline removed", 'source_preservation')

    # Original gate producer sets: similarly named checkpoints are deliberately not aliases.
    provider_groups = {
        'WI-AQ-G1':['AQ-02','AQ-03'], 'WI-AQ-G2':['AQ-04'], 'WI-AQ-G3':['AQ-05','AQ-06','AQ-07'], 'WI-AQ-G4':['AQ-08','AQ-09'], 'WI-AQ-G5':['AQ-13'],
        'EXO-AQ-G1':['AQ-02','AQ-03'], 'EXO-AQ-G2':['AQ-04'], 'EXO-AQ-G3':['AQ-05','AQ-06','AQ-07'], 'EXO-AQ-G4':['AQ-08','AQ-09'], 'EXO-AQ-G5':['AQ-13','AQ-14'],
        'EXO-WI-G1':['WI-02'], 'EXO-WI-G2':['WI-03','WI-04','WI-05'], 'EXO-WI-G3':['WI-06','WI-07','WI-08'], 'EXO-WI-G4':['WI-09','WI-10','WI-11','WI-12'], 'EXO-WI-G5':['WI-13','WI-14'],
    }
    for cid, ids in provider_groups.items():
        require(cid in cs, f'Missing original checkpoint {cid}', 'checkpoint_preservation')
        if cid not in cs:
            continue
        expected = {i.split('-')[0].lower()+'/'+i for i in ids}
        actual = {r['id'] for r in cs[cid]['requires'] if r['kind'] == 'work_item'}
        if ids[0].startswith('AQ-'):
            require(not actual and set(cs[cid].get('historical_producer_work_items',[]))==expected and checkpoint_node('AQ-BASELINE-ACCEPTED') in {requirement_key(r) for r in cs[cid]['requires']}, f'{cid}: original producer evidence mapping or completed baseline lost', 'checkpoint_preservation')
        else:
            require(actual == expected, f'{cid}: original producer work-item set changed', 'checkpoint_preservation')
    fixed_stage_checks = {
        ('wi/WI-04/integration','merge_requires'): ['WI-AQ-G2'],
        ('wi/WI-03/integration','merge_requires'): ['WI-AQ-G2','WI-AQ-G3'],
        ('wi/WI-05/integration','merge_requires'): ['WI-AQ-G4','WI-ADR-007','WI-ADR-010'],
        ('wi/WI-07/integration','merge_requires'): ['WI-AQ-G2','WI-AQ-G3','WI-AQ-G4'],
        ('wi/WI-11/integration','verify_requires'): ['WI-AQ-G5'],
        ('wi/WI-14/release','start_requires'): ['AQ-PUBLISHED'],
        ('exo/EXO-11/integration','merge_requires'): [f'EXO-AQ-G{i}' for i in range(1,5)] + [f'EXO-WI-G{i}' for i in range(1,4)],
        ('exo/EXO-11/integration','verify_requires'): ['WI-DEPLOYMENT-PARITY'],
        ('exo/EXO-15/integration','merge_requires'): [f'EXO-AQ-G{i}' for i in range(2,6)] + [f'EXO-WI-G{i}' for i in range(2,6)],
        ('exo/EXO-19/release','start_requires'): ['AQ-PUBLISHED','WI-PUBLISHED'],
    }
    for (sid, stage), gates in fixed_stage_checks.items():
        require(sid in ss, f'Missing governed slice {sid}', 'checkpoint_preservation')
        if sid in ss:
            actual = {r['id'] for r in ss[sid][stage] if r['kind'] == 'checkpoint'}
            require(set(gates) <= actual, f'{sid}/{stage}: required checkpoint removed', 'checkpoint_preservation')
    # Do not turn the publishable EXO-19 exit into a fictitious publication receipt.
    require(ss.get('exo/EXO-19/release',{}).get('mode') == 'release_readiness', 'EXO-19 must remain publication-ready, with actual publication separately evidenced', 'checkpoint_preservation')

    validate_profiles_and_slices(definition, indexes, require)
    validate_completed_baseline(definition, indexes, require)

    graph = expanded_graph(definition)
    all_nodes = set(graph)
    for node, preds in graph.items():
        require(preds <= all_nodes, f'{node}: unknown prerequisite nodes {sorted(preds-all_nodes)}', 'references')
    try:
        order = list(TopologicalSorter(graph).static_order())
        require(len(order) == len(graph), 'Graph includes undeclared implicit nodes', 'graph')
        require(True, 'expanded graph cycle', 'graph')
    except CycleError as exc:
        order = []
        require(False, 'Expanded milestone graph has a cycle: ' + str(exc.args[1]), 'graph')
    if verify_sources:
        root = root.resolve()
        snapshot_content: dict[str, bytes] = {}
        for sf in definition['source_files']:
            p = (root / sf['snapshot_path']).resolve()
            inside = p.is_relative_to(root)
            require(inside, f"{sf['id']}: unsafe source snapshot path", 'source_hashes')
            if not inside:
                continue
            require(p.is_file(), f"{sf['id']}: missing source snapshot", 'source_hashes')
            if not p.is_file():
                continue
            b = p.read_bytes()
            require(digest(b) == sf['sha256'], f"{sf['id']}: source hash mismatch", 'source_hashes')
            snapshot_content[sf['id']] = b
        for repository in definition['repositories']:
            rid = repository['id']; source_id = repository['source_work_breakdown']
            if source_id not in snapshot_content:
                continue
            source_path = root/indexes['source_files'][source_id]['snapshot_path']
            try:
                source = load_yaml(source_path)
            except (InputError,yaml.YAMLError,UnicodeError) as exc:
                require(False, f'{source_id}: invalid source YAML: {exc}', 'source_preservation')
                continue
            source_records = source['pull_requests']
            if rid=='aq':
                require(not any(v['repository']=='aq' for v in ws.values()), 'AQ source history became active work', 'source_preservation')
                continue
            expected_ids = {rid+'/'+x['id'] for x in source_records}
            require({k for k,v in ws.items() if v['repository'] == rid} == expected_ids,
                    f'{rid}: source work-item set changed', 'source_preservation')
            for ordinal, original in enumerate(source_records,1):
                k = rid+'/'+original['id']
                if k not in ws:
                    continue
                target = ws[k]
                require(target['source_record_sha256'] == record_digest(original), f'{k}: source record fingerprint mismatch', 'source_preservation')
                for target_key, source_key in [('title','title'),('risk','risk'),('primary_areas','primary_areas'),('source_exit_gate','exit_gate')]:
                    require(target[target_key] == original[source_key], f'{k}: original {source_key} changed', 'source_preservation')
                require(target['planning_order'] == original.get('sequence',ordinal), f'{k}: source presentation order changed', 'source_preservation')
                require(target['depends_on'] == [rid+'/'+i for i in original['depends_on']], f'{k}: source dependencies changed', 'source_preservation')
        validate_bound_sources(definition, root, snapshot_content, require)
        validate_baseline_sources(definition, snapshot_content, require)
        # ADR queues are parsed from the actual snapshots, with exact due-PR edges.
        for rid in ('wi','exo'):
            sid = rid+'-plan'
            if sid not in snapshot_content:
                continue
            prefix = rid.upper()
            for line in snapshot_content[sid].decode().splitlines():
                if not line.startswith('| `'+prefix+'-ADR-'):
                    continue
                cells = [c.strip() for c in line.strip().strip('|').split('|')]
                aid = re.search(prefix+r'-ADR-\d{3}',cells[0]).group(0)
                due = cells[1] if rid=='aq' else cells[2]
                ids = re.findall(prefix+r'-\d{2}(?!\d)',due)
                if not ids:
                    require(aid in {d['id'] for d in definition['deferred_decisions']}, f'{aid}: post-release decision lost', 'adr_preservation')
                    continue
                require(aid in cs, f'{aid}: required ADR checkpoint missing', 'adr_preservation')
                for raw in ids:
                    parent = rid+'/'+raw
                    for sl in (s for s in definition['slices'] if s['work_item']==parent):
                        keys = {requirement_key(r) for r in sl['merge_requires']}
                        require(checkpoint_node(aid) in keys, f"{sl['id']}: missing due ADR {aid}", 'adr_preservation')
    after_approval = {checkpoint_node('STACK-PLAN-ACCEPTED')}
    initial_starts = [n for n in eligible_milestones(graph, after_approval) if n.startswith('slice:') and n.endswith('@started')]
    expected_starts = {slice_node('wi/WI-01/implementation','started'),slice_node('exo/EXO-01/domain','started')}
    require(set(initial_starts) == expected_starts, 'Initial development front must contain only the two application foundation slices', 'graph')
    return {
        'valid': not errors,
        'validation_scope':'Definition structure, original-plan preservation, references and expanded dependency graph only; no application import or target runtime execution.',
        'counts':{'repositories':len(definition['repositories']),'work_items':len(ws),'slices':len(ss),'checkpoints':len(cs),'architecture_decision_checkpoints':sum(c['kind']=='architecture_decision' for c in cs.values()),'original_cross_stack_checkpoints':15,'source_profile_acceptance_cases':len(definition['acceptance_coverage']),'source_files':len(definition['source_files']),'review_decisions':len(definition['decisions']),'expanded_milestone_nodes':len(graph),'dependency_edges':sum(len(p) for p in graph.values())},
        'checks_by_category':dict(checks),
        'total_static_checks':sum(checks.values()),
        'planning_targets':target_analyses(definition, graph),
        'hypothetical_initial_starts_after_explicit_plan_approval':initial_starts,
        'errors':errors,
        'all_implementation_and_checkpoint_statuses':'unresolved; no progress asserted',
    }


def validate_completed_baseline(d, indexes, require):
    b=d['aq_baseline_binding'];ws=indexes['work_items'];ss=indexes['slices'];cs=indexes['checkpoints']
    require(b['archive_sha256']=='f91f496f22772e8dda044b0cf2cf05cf2eafa9f86d6f0c7e0061b46e3926ffb1' and b['source_tree_sha256']=='a6a8f87272d76e94e69e10d8bcf0992296d1bf8e28ff3d9222374c3b8cdcc34e','Completed AQ exact source pin changed','baseline')
    aq=indexes['repositories']['aq']
    require(aq['role']=='implemented_upstream' and aq['source_baseline_commit'] is None and aq['target_branch'] is None and aq['merge_lock'] is None and aq['runtime_revision_status']=='source-archive-pinned','AQ historical implementation/merge binding is invalid','baseline')
    require(not any(w['repository']=='aq' for w in ws.values()) and not any(s.startswith('aq/') for s in ss),'AQ completed work is runnable','baseline')
    require(not any(c.startswith('AQ-ADR-') for c in cs),'Frozen AQ ADR was reopened','baseline')
    require('AQ-BASELINE-ACCEPTED' in cs,'AQ baseline acceptance checkpoint missing','baseline')
    if 'AQ-BASELINE-ACCEPTED' in cs:
        c=cs['AQ-BASELINE-ACCEPTED']
        require(c['requires']==[{'kind':'checkpoint','id':'STACK-PLAN-ACCEPTED','state':'passed'}] and c['evidence_profile']=='upstream-baseline','Baseline review activation/evidence barrier changed','baseline')
    for c in ['EXO-AQ-G5','AQ-PUBLISHED']:
        require(c in cs and checkpoint_node('AQ-BASELINE-ACCEPTED') in ancestors(expanded_graph(d),checkpoint_node(c)),c+': accepted baseline missing','baseline')
    require('EXO-AQ-G5' in cs and checkpoint_node('AQ-PUBLISHED') in {requirement_key(r) for r in cs['EXO-AQ-G5']['requires']},'EXO G5 original producer publication prerequisite lost','baseline')
    require('WI-AQ-G5' in cs and checkpoint_node('AQ-PUBLISHED') not in ancestors(expanded_graph(d),checkpoint_node('WI-AQ-G5')),'WI G5 incorrectly requires AQ publication','baseline')
    coverage=d['baseline_acceptance_coverage'];ids=[x['id'] for x in coverage]
    require(len(set(ids))==48 and set(ids)=={f'AB-{rid}-{i:03d}' for rid in ['WI','EXO'] for i in range(1,25)},'Missing or duplicate baseline case coverage','baseline_cases')
    for c in coverage:
        require(c['owner_work_item'] in ws and c['producing_slice'] in ss and c['capability_gate'] in cs,c['id']+': unknown owner/slice/gate','baseline_cases')
        if c['producing_slice'] in ss:
            require(ss[c['producing_slice']]['work_item']==c['owner_work_item'],c['id']+': wrong slice owner','baseline_cases')
    for coll,rows,key in [('work_items',ws,'owner_work_item'),('slices',ss,'producing_slice')]:
        for ident,x in rows.items():
            require(x['aq_baseline_case_ids']==[c['id'] for c in coverage if c[key]==ident],ident+': baseline case obligations dropped','baseline_cases')
    archives={x['repository']:x for x in d['source_archives']}
    require(archives.get('aq',{}).get('sha256')==b['archive_sha256'],'AQ source archive and baseline lock differ','baseline')


def validate_baseline_sources(d, content, require):
    b=d['aq_baseline_binding'];cases={c['id']:c for c in d['baseline_acceptance_coverage']}
    for rid in ['wi','exo']:
        sid=rid+'-aq-lock'
        if sid not in content:
            require(False,sid+': missing lock bytes','baseline');continue
        lock=json.loads(content[sid])
        require(all(lock[k]==b[k] for k in ['archive_sha256','source_tree_sha256','source_tree_file_count','conformance_package_revision','implementation_commit']),sid+': exact source lock mismatch','baseline')
        sid=rid+'-aq-cases'
        if sid not in content:
            require(False,sid+': missing case bytes','baseline_cases');continue
        # Safe unique-key loader; aliases were already rejected by ordinary source loading.
        matrix=yaml.load(content[sid],Loader=UniqueKeyLoader)
        require(len(matrix['cases'])==24,sid+': case count changed','baseline_cases')
        for c in matrix['cases']:
            target=cases.get(c['id'])
            require(bool(target),c['id']+': source case absent from map','baseline_cases')
            if target:
                require(target['source_record_sha256']==record_digest(c) and target['owner_work_item']==rid+'/'+c['owner_pr'] and target['capability_gate']==c['capability_gate'],c['id']+': source criterion/owner/gate fingerprint mismatch','baseline_cases')
        wid=rid+'-work-breakdown'
        if wid in content:
            wbd=yaml.load(content[wid],Loader=UniqueKeyLoader);ws={x['id']:x for x in d['work_items']}
            for w in wbd['pull_requests']:
                require(ws.get(rid+'/'+w['id'],{}).get('aq_baseline_case_ids')==w.get('aq_baseline_acceptance_cases',[]),w['id']+': source baseline case assignment lost','baseline_cases')
    if 'aq-conformance' in content:
        manifest=json.loads(content['aq-conformance'])
        require(manifest['package_revision']==16,'AQ conformance source revision differs','baseline')


def validate_baseline_case_receipts(d, slice_id, receipts, consumer_revision, aq_build_revision):
    """Check receipt completeness/pin fields only; does NOT authenticate or pass a milestone.

    A real importer must separately authenticate signers, review independence,
    revocation, active generations and prerequisite validity before accepting results.
    """
    errors=[];s=next((s for s in d['slices'] if s['id']==slice_id),None)
    if s is None:return {'valid':False,'errors':['unknown slice'],'authentication_performed':False}
    required=s['aq_baseline_case_ids'];coverage={c['id']:c for c in d['baseline_acceptance_coverage']}
    if not isinstance(receipts,list):return {'valid':False,'errors':['receipts must be a list'],'authentication_performed':False}
    ids=[r.get('case_id') for r in receipts if isinstance(r,dict)]
    if len(ids)!=len(receipts) or len(ids)!=len(set(ids)) or set(ids)!=set(required):errors.append('exact assigned case receipt set required')
    for r in receipts:
        if not isinstance(r,dict):continue
        c=coverage.get(r.get('case_id'))
        if not c:errors.append('unknown case');continue
        for k,value in {'source_record_sha256':c['source_record_sha256'],'aq_archive_sha256':d['aq_baseline_binding']['archive_sha256'],'conformance_package_revision':16,'consumer_revision':consumer_revision,'aq_build_revision':aq_build_revision,'result':'passed'}.items():
            if r.get(k)!=value:errors.append(c['id']+': stale or missing '+k)
        for k in ['result_artifact_sha256','fixture_sha256','environment_sha256']:
            if not isinstance(r.get(k),str) or not re.fullmatch('[a-f0-9]{64}',r[k]):errors.append(c['id']+': invalid '+k)
        if not r.get('independent_review_reference'):errors.append(c['id']+': independent review missing')
    if not consumer_revision or not aq_build_revision:errors.append('exact implementation/build identities required')
    return {'valid':not errors,'errors':errors,'authentication_performed':False,'milestone_pass_granted':False}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('map',nargs='?',type=Path,default=HERE/'cross-stack-concurrency-map.yaml')
    parser.add_argument('--graph-output',type=Path,help='Write derived milestone/predecessor JSON for inspection')
    parser.add_argument('--source-archives-root', type=Path, help='Additionally verify the three original ZIP hashes and source-file bytes against their archive members')
    args = parser.parse_args()
    try:
        definition = load_yaml(args.map)
        report = validate_definition(definition, args.map.resolve().parent)
        report['map_sha256'] = digest(args.map.read_bytes())
        if args.source_archives_root and report['valid']:
            archive_report = verify_source_archives(definition, args.source_archives_root)
            report['source_archive_verification'] = archive_report
            if not archive_report['valid']:
                report['valid'] = False
                report['errors'].extend(archive_report['errors'])
        if args.graph_output and report['valid']:
            args.graph_output.write_text(json.dumps({k:sorted(v) for k,v in expanded_graph(definition).items()},indent=2)+'\n')
        print(json.dumps(report,indent=2))
        return 0 if report['valid'] else 1
    except (InputError, OSError, UnicodeError, yaml.YAMLError, json.JSONDecodeError, RecursionError) as exc:
        print(json.dumps({'valid':False,'input_error':str(exc)},indent=2))
        return 2

if __name__ == '__main__':
    sys.exit(main())
