# EXO current concurrency rebinding — AQ baseline alignment

Use this package with concurrency v0.3.0. The supplied AQ source is an implemented dependency, not pending AQ development work. Original EXO parents, dependencies, full exit obligations and G1–G5 evidence meanings remain in force. Embedded proof does not waive release or full deployment parity. No previous map approval or runtime qualification is inherited.

## Current core source hashes

| File | Original r3 | Supplied r4 | Current |
|---|---|---|---|
| `exo-v3-comprehensive-work-breakdown.yaml` | `ee757fa9777a8839a60d588e542b20bce28b78124560c9e7e298dd75d782d806` | `c5d89eb130f40441abe2ff6e874749fcc317f00688a0b00a439c08267a9753a3` | `a8f05709f6d150adf26ce916ac84c555fd0cdfa829790bd18e69228ba9d32a60` |
| `exo-v3-comprehensive-implementation-plan.md` | `6ba1adbe279180c72d48204669e61bf7668f72e2401537991dc33d3a3cd264e2` | `fd965532cb8a850dc6959affbd99f9959ab077fd7a4666bfdd3ae6b2d9cdec5f` | `bd92690d91f1af11991de811c12818c62569571ee32ce81ef3462597759eb40e` |

The original rebinding document is retained in `provenance/supplied-r4-files/`. All current provider/execution supplements and AQ baseline cases are independently source-bound by the v0.3.0 map; matching parent IDs alone is insufficient.

The r5 provider-reference correction was incorporated only from the supplied sidecar snapshots; the missing full r5 archive was not verified. Current EXO r6 references the actual revised WI r5 provider bytes.
