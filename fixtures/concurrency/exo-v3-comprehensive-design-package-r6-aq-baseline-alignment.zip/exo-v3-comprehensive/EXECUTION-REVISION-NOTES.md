# Revision provenance — r6-aq-baseline-alignment

Input was the supplied EXO r4 archive. Current plan is EXO-PLAN-6. Exact prior top-level files are retained under `provenance/supplied-r4-files/` with `.source.txt` suffixes, not as duplicate importable plans. Original r3 provenance and constitutional fingerprints are unchanged. The allowed-change rules now explicitly include AQ source binding and 24 additional case assignments. Neither original exit tests nor runtime gate meanings are removed.

All AQ-facing API sketches defer to the source-pinned amendment. No ActionQueue source file is edited. No application runtime, Kata host or actual importer is executed by this package revision.

The supplied concurrency v0.2.0 referenced an EXO r5 archive that was NOT supplied. Its exact embedded snapshots supplied the provider-reference document, profile, plan and ownership amendment now incorporated here. This reconstructs those specific changes only; it does not assert validation or possession of the missing complete r5 ZIP. A new provider alignment validator checks the actual revised WI package.

## Preserved original revision
The previous full revision notes are retained under `provenance/supplied-r4-files/` as inert source text. The bounded worker/execution profiles, original acceptance cases and original full exit obligations remain in force.
