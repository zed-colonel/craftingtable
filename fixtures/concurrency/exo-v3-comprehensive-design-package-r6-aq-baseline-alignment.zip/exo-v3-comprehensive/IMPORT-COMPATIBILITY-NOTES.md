# Import compatibility — r4 Kata instance revision

**Current artifact:** r6-aq-baseline-alignment  
**Current plan/profile:** EXO-PLAN-6 / EXO-V3-COMPREHENSIVE-3  
**Based on:** r3-import-fix, not the invalid pre-correction YAML

## Stable importer-facing structure

This package keeps one `exo-v3-comprehensive-work-breakdown.yaml`, top-level `document` and `pull_requests`, and all nineteen original PR records. Each retains its ID, title, sequence, dependencies, status, primary-area list and risk string. The earlier `work_items` collection alias is not reintroduced.

`exit_gate` remains a nonempty string and continues to match the implementation-plan PR section exactly. For selected PRs this revision appends execution-profile obligations to the original gate; it does not remove the original text. All existing `developmental_diagnostics_scope` entries remain unchanged.

## Intentional changes

The profile advances to `EXO-V3-COMPREHENSIVE-3` and the plan to `EXO-PLAN-6`. The work breakdown adds `execution_environment_profile` and selected `execution_environment_scope` lists, updates its date/change class, and extends selected exit gates. These are real planning amendments, not another field-name-only import fix.

Do not apply the historical r3 claim that all architecture and gate text is unchanged to this release. The exact baseline and explicit revision rules are in `provenance/r3-work-breakdown.json` and `provenance/revision-rules.json`. They are comparison evidence, not a second importable work breakdown.

## Scope and limits of validation

`validate_work_breakdown.py` retains the previously checked requirements: `document`, `pull_requests`, all `primary_areas` and `risk` fields, plus local identity, dependency, sequence and gate safeguards. `validate_package.py` additionally verifies the intended revision, profile, acceptance inventory, source preservation, checkpoint references and planning limits.

The complete application schema and importer have not been supplied or run. Passing these checks addresses the known import contract; it is not a claim of compatibility with any undocumented strict-field policy. Treat this as a new immutable plan version in the application.

The old cross-stack concurrency draft is hash-bound to prior source files. It must be revised and explicitly rebound before governing this version; an unchanged work-item ID does not make changed scope interchangeable.

Historical explanations of the r2-to-r3 corrections and risk assignments are retained at `provenance/r3-IMPORT-COMPATIBILITY-NOTES.md`.

## AQ baseline alignment import contract
The canonical work breakdown now includes `aq_baseline_alignment` and per-owner `aq_baseline_acceptance_cases`. These fields impose additional integration evidence. An importer may parse them additively but MUST reject scheduling activation when it cannot enforce them. The v0.3.0 concurrency schema removes completed AQ implementation nodes; do not fall back to v0.2.0 or reuse approvals. This local validator is not the actual orchestration application importer.
