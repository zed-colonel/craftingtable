# Kata instance qualification — implementation runbook

**Scope:** The first approved-operator Linux host profile for EXO-V3-EXECUTION-1.  
**Status:** Procedure to implement and execute; not a pre-tested deployment script.

## 1. Freeze the qualification inputs

Resolve EXO-ADR-037 and EXO-ADR-038. Record the actual host architecture/kernel, virtualization availability, maintained containerd/Kata versions, selected hypervisor, guest assets, image/configuration digests, AQ/WI revisions, storage path, network policy, limits, application identity, operator identity and backup/rollback locations.

Select a supported version combination rather than copying a moving `main` example. Review the configuration consumed by the exact launch path: direct containerd clients and CRI do not necessarily use the same runtime configuration mechanism. Refer to the primary sources in the target-preference note.

No host is qualified while required entries remain unknown. This package deliberately does not fill unknown versions with `latest`, guess final EXO command flags, or imply that a sample manifest was exercised.

## 2. Build the target image and host launcher

Implement the target-only Vessel image and entrypoint against the selected manifest. Keep build tooling separate where possible; approved proof-worker executables are explicitly installed/selected, not downloaded or constructed arbitrarily at runtime.

The entrypoint must work as the declared non-root identity, handle signals correctly, and support supervised child reaping. Declare every writable path. Host-owned data initialization must not rely on broad recursive permission changes. Do not mount host homes, engine sockets, root devices, or activation credentials into the workload.

Implement a small operator-owned launcher/supervisor outside the guest. It selects Kata explicitly and records actual sandbox/VM identity. It exposes only the assigned lifecycle operations, not arbitrary mounts/flags or a general shell to the Vessel. A startup probe is not authorization for a worker.

## 3. Establish outer instance behavior

Run EE-002 through EE-006, EE-010 and EE-035 on the target host. Verify actual VM selection from host evidence, independent boundary/state for another fixture Vessel, resource/network policy and no silent fallback. Remove Kata or virtualization capability to exercise the refusal path.

Record which controls are host-enforced, guest-enforced or unsupported. Do not confuse VM-wide resource/network limits with protection of the Vessel from co-resident worker processes.

## 4. Establish persistence and external lifecycle behavior

Choose the actual volume/snapshotter/filesystem path and run EE-007/008/025/026/029/034. Verify the Vessel database, WI records, both logical AQ stores and artifact references on restart and abrupt termination. Recreate the runtime with retained stores and confirm that Genesis and accepted history do not change.

Quiesce and capture a consistent backup; validate the manifest and restore with the former writer excluded. Exercise a deliberately incompatible image/schema rollback and require refusal rather than an attempted unsafe downgrade.

For automated lifecycle fixtures, the external supervisor must retain/query results even when the guest initiating the request stops. An operator must also be able to recover the instance without any request from the failed guest. See EE-027.

## 5. Prove the embedded worker path safely

Use reviewed fixtures and permitted non-sensitive inputs. Run the process lifecycle cases through actual embedded WI/AQ, not a direct Exoskeleton subprocess shortcut. Exercise duplicate/ambiguous start, sanitization, run identity, early/late events, cancellation, descendant cleanup, bounded output, explicit supported limits, checkpoint artifacts and rejected exports.

Attempt a request for an independent worker VM and require an unavailable/rejected result. Test a fake external-provider implementation only to prove the absence of local PID/path assumptions; label it simulated.

Do not run arbitrary adversarial binaries or unreviewed generated candidates inside the shared instance to demonstrate security. That is outside the supported proof profile. Malicious messages and artifact fixtures can still exercise structural admission and parsing controls.

## 6. Record a bounded viability result

Complete a reviewed coding fixture and a non-coding fixture, including an invalid completion proposal that must not be accepted, followed by an interrupted/resumed run. Record correctness, verification, relevant timing/resource measurements, recovery, and residual limitations.

The result may establish EXO-EMBEDDED-VIABILITY-1 if all applicable checkpoint evidence is valid. It must not assert implemented platform services, independent hostile-worker isolation, untrusted-host confidentiality or full release completion without their separate evidence.

## 7. Evidence bundle and maintenance

The implementation's evidence bundle must contain:

- the exact qualification manifest and supported-profile statement;
- observed host/runtime/image identities and redacted configuration;
- test revision, results, logs and artifact hashes for each EE case;
- expected denials, unsupported controls, unresolved risks and reviewer decisions;
- backup/restore, compatible rollback, lifecycle and orphan-cleanup evidence;
- measured resource/latency observations without general performance guarantees;
- patch/upgrade ownership and requalification triggers.

Review/retest affected evidence after runtime, hypervisor, kernel, image, storage, network, supervisor or worker-backend changes. Do not import the static package-validation reports as any part of this runtime qualification result.
