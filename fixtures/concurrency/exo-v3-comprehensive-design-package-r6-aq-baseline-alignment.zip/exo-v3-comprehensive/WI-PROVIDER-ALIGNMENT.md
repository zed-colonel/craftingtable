# EXO consumer alignment to the WI-owned worker provider

**Current artifact:** r6-aq-baseline-alignment  
**EXO plan:** EXO-PLAN-6 / EXO-V3-EXECUTION-1  
**WI producer:** WI-PLAN-5 / WI-WORKER-EXECUTION-1 / r5-aq-baseline-alignment

WI owns the process-managed-proof-1 definition, controls, limits and producer qualification. EXO consumes and may tighten it; EXO-ADR-038 does not create a competing provider contract. Unsupported stronger isolation must block admission rather than silently downgrade. Kata instance provenance is not proof of independent process-worker isolation.

`wi-worker-provider-reference.json` binds the three exact authoritative WI definition files. `validate_provider_alignment.py` checks those hashes against retained source snapshots or, with `--wi-root`, the actual companion package. Retained byte-identical snapshots are provenance, not an independent authoritative definition.

WI-WORKER-G1..G4 producer proof remains independent of EXO/Kata completion. WI-WORKER-G5 is a separate supervisor boundary. EXO adds its own worker supervision, independent acceptance, real Kata/volume/lifecycle evidence and portability obligations. Existing full AQ/WI G1..G5 meanings, parent dependencies and release gates remain intact. No new AQ primitive or automatic activation is introduced.

```sh
python -B validate_provider_alignment.py --wi-root ../wi-fabric-2-foundational
```

The full EXO r5 archive named by the old concurrency map was not supplied. The five actually embedded r5 snapshots are retained in `provenance/supplied-r5-sidecar-snapshots/` and were the source of the ownership correction incorporated here. This does not claim validation of the absent full r5 package or any runtime qualification.
