# EXO-V3 Comprehensive Implementation Plan

**Plan revision:** `EXO-PLAN-6`  
**Target contract:** `EXO-V3`  
**Coordinated stack contract:** `STACK-2026-07-25-FOUNDATIONAL-2`  
**EXO profile:** `EXO-V3-COMPREHENSIVE-3`  
**Repository:** `zed-colonel/exoskeleton`  
**Source baseline:** `1bcbb757a7885ce1f911ac948bfc2269c9209075`  
**Source baseline date:** June 9, 2026  
**Implementation branch:** `exo-v3`  
**Upstream contracts:** `AQ-CONT-1`, `WI-FABRIC-2`  
**Date:** September 12, 2026

This document converts the finalized Exoskeleton v3 architecture into a repository-level development plan. It is intentionally more concrete than the architecture document but remains subordinate to the architecture, canonical stack contract, accepted ADRs, and executable conformance packages. The OHIO-informed work is specified in `ohio-loop-developmental-diagnostics.md` and does not replace the Vessel runtime architecture.

The implementation posture is a clean break. The current repository is a frozen experimental predecessor whose useful invariants, failure cases, fixtures, and benchmark evidence are retained. Its obsolete control paths, serialized formats, compatibility concepts, and coding-specific ontology are not carried into the target runtime.

---

## 0. Purpose and decision summary

### 0.1 Purpose

`EXO-V3` is the first implementation of Exoskeleton as an enduring, constitutionally governed Vessel rather than a tick-centered LLM agent with durable attachments.

The target runtime must make these claims true in code:

```text
The Vessel is the enduring entity.
Models and faculties are replaceable cognitive components.
Untrusted content is non-directive unless structurally admitted.
Communication is a durable social process.
Commitments and goals create autonomous forward pressure.
Initiative is governed rather than inferred from model enthusiasm.
Narrative identity is versioned interpretation, not mutable history.
Delegated specialists execute bounded work without becoming the Vessel.
WorldInterface mediates accountable boundary crossings.
ActionQueue preserves asynchronous causality through time and failure.
Developmental campaigns diagnose the task-scoped binding constraint before changing a component.
Canonical state remains rich while cognition receives a faculty-appropriate working representation.
```

The plan has four jobs:

1. define a direct implementation path from the current seven-crate workspace to the `EXO-V3` target; and
2. separate work that can proceed independently from work that must wait for proven `AQ-CONT-1` and `WI-FABRIC-2` contracts; and
3. allocate the OHIO-informed developmental-diagnostics profile across the existing 19-PR sequence without introducing another plane, execution engine, or lower-layer semantic owner.
4. qualify the Vessel instance on Kata/containerd and prove initial process-worker delegation through embedded WI, while keeping DigiCorp/platform expansion and externally provisioned workers as subsequent work.

### 0.2 Decisions fixed by this plan

The following decisions are implementation constraints, not open-ended suggestions:

1. **One authoritative architecture.** There is no live v1/v3 comparison mode, dual write, fallback authority path, compatibility adapter, or pre-v3 store reader.
2. **The target starts with a fresh persistence lineage.** Pre-contract stores may be exported as inert evidence but are never silently admitted as authoritative v3 state.
3. **One local transactional domain boundary.** Exoskeleton uses one authoritative Vessel-domain database for records and outboxes that must commit atomically. Artifact bytes and rebuildable indexes may remain separate.
4. **The authoritative Vessel reducer is serialized.** Faculties and I/O may execute concurrently, but accepted domain transitions commit against one monotonic `VesselRevision`.
5. **Cognition is episode-based.** A periodic review is one possible trigger; communication, commitments, goals, effect outcomes, delegation events, maintenance, and observations may also admit episodes.
6. **Faculties emit typed structures plus optional explanatory artifacts.** Unrestricted rationale never controls arbitration.
7. **Influence, initiative, attention, and local capability decisions are separate deterministic mechanisms.** None is collapsed into a sovereign Decide model.
8. **A selected goal proposal is not an active goal.** Only the Initiative Governor may admit, defer, reject, suspend, or retire endogenous concerns.
9. **Quiescence is first-class.** An empty agenda does not cause unconditional inference.
10. **Communication is durable before cognition and delivery is external evidence.** The implementation follows `store-before-wake`: generated text is not sent communication, and no wake precedes its authoritative domain record.
11. **History, memory, self-model, mission, narrative, and external proof history remain distinct.** Narrative versions may reinterpret but never rewrite history.
12. **Delegation is a first-class supervised lifecycle.** A work order is structural; a worker cannot self-certify completion.
13. **Specialist backends live behind an Agent Host and WorldInterface worker controls.** Exoskeleton never calls Pi or another specialist runtime directly.
14. **`VesselId` is internal identity.** `ExternalPersona` records and portable identifiers are governed outward interfaces, not replacements for Vessel continuity.
15. **Remote boundary-dependent faculty backends use WorldInterface.** Deterministic or trusted local faculties may run in-process; calls to remote model, sensor, or cognitive services cross the accountable boundary.
16. **Exact upstream APIs remain provisional until named conformance gates pass.** Internal ports may be implemented early; production adapters may not be merged on speculation.
17. **Release is breaking and dependency-pinned.** `EXO-V3` pins exact `AQ-CONT-1` and `WI-FABRIC-2` implementation and conformance revisions.
18. **Cognition is not an authority boundary.** Externally sourced content and derived artifacts are non-directive by default; faculties emit claims and proposals inside an episode security envelope.
19. **Context is explicit and inspectable.** Every episode pins a ContextManifest, source governance envelopes, compiler version, exclusions, and an authority/disclosure ceiling.
20. **Plan broadening is a governed transition.** New evidence may motivate a PlanAmendmentProposal but cannot silently widen scope, audience, purpose, budget, or authority.
21. **Prompt-injection detection is defense in depth.** Hard safety depends on structural admission and final WorldInterface sink authorization, not perfect detection.
22. **Developmental diagnosis is task-scoped.** Every binding-constraint, marginal-gain, or saturation claim pins a Task Distribution, environment, budget, Evaluation Plan, and complete Component Fingerprint.
23. **Capability, working representation, and harness are intervention classes, not architectural owners.** Intelligence is not identity or authority; representation is not canonical-state mutation; harness is distributed across the stack.
24. **Controlled evidence precedes diagnosis.** A proposal states the changed lever, fixed dimensions, expected marginal gain, falsification conditions, and confounds. Candidate or model self-report is not sufficient.
25. **Canonical richness is separated from episode resolution.** Representation Profiles are versioned Behavioral Components selected by purpose, faculty compatibility, context budget, and calibration evidence.
26. **Metrics do not override protected invariants.** Queue completion, receipts, benchmark scores, and evaluator outputs remain evidence; protected acceptance gates remain non-tradeable.
27. **Saturation is provisional.** Every saturation record carries invalidation conditions for relevant capability, representation, harness, workload, evaluator, environment, or budget change.
28. **Developmental churn is bounded.** Campaigns have iteration/resource budgets, stagnation windows, stop/switch/defer policy, and portfolio priority.
29. **Instance execution and worker isolation are distinct.** The initial qualified Vessel environment is a dedicated Kata VM managed by containerd; the initial embedded WI worker backend is process-managed and shares that outer VM.
30. **The process backend proves management, not hostile-code containment.** Only reviewed fixture executables and permitted non-sensitive data are admitted; unsupported stronger isolation and unreviewed executable candidate trials are refused.
31. **Infrastructure control remains external.** A minimal operator-owned host supervisor controls the instance; no raw container-engine, Kata, hypervisor or activation credential is exposed to the guest workload.
32. **Build bottom up.** EXO-EMBEDDED-VIABILITY-1 does not require DigiCorp, platform AQ/WI, external worker provisioning, Kubernetes or confidential computing. It also does not falsely complete broader parent-PR or release obligations.
33. **External workers remain resources.** Local PID/path/runtime mechanics stay in the WI/Agent Host adapter, allowing later qualified externally provided workers without redefining Vessel identity or delegation.


### 0.2.1 Foundational completeness decisions

This revision adds first-class:

- Blueprint, pinned Manifest, atomic Genesis, commissioning, activation, roles, stewardship, lifecycle, and lineage;
- Purpose Charter terminology and structured Mission Offers;
- epistemic state, support/defeat belief revision, semantic time, and schema governance;
- commitment portfolio admission, conflict, negotiation, and acting capacity;
- information-use obligations separate from access;
- behavioral component provenance, governed self-improvement, protected evaluation, external activation, rollback, quarantine, and continuity assessment;
- viability, degraded modes, recovery demands, and protected reserves;
- instruction authority, source integrity, derivation propagation, bounded context manifests, explicit plan amendments, influence traces, and prompt-injection containment;
- Task Distributions, Capability and Representation Profiles, Component Fingerprints, Controlled Intervention Probes, Capability Frontier Assessments, Developmental Campaigns, saturation/invalidations, and bounded stop policy.

No new top-level runtime layer is introduced. `STACK-DEVELOPMENTAL-DIAGNOSTICS-1` is a planning and conformance profile over existing ActionQueue and WorldInterface seams; it adds no lower-layer semantic primitive or authority path.

### 0.3 What this plan deliberately does not do

This plan does not:

- preserve PODAARA as a fallback runtime;
- migrate current Tick, Thread, Align, conversation, coding, or store semantics;
- define the final NetCorp organizational control plane;
- implement collective narrative or institutional mythos;
- claim consciousness, unique personhood, or human equivalence;
- make EntityID, a blockchain, a token, or any portable-identity method mandatory;
- turn ActionQueue causal references into authorization;
- let Exoskeleton mint final WorldInterface authorization;
- embed a coding framework into the Vessel kernel;
- require every low-level sandbox action to produce a WorldInterface receipt;
- keep a model invocation alive while a conversation, delegation, effect, or commitment waits;
- treat planning documents as compiled evidence;
- claim that an underlying model is universally jailbreak-proof;
- rely on prompt-injection detection as the sole authorization boundary;
- retain pre-v3 store readers in the target runtime;
- install the OHIO loop as a replacement runtime architecture or master cognition loop;
- define one global scalar called Vessel performance;
- force specialized domain ontology into the Vessel kernel;
- let WorldInterface or ActionQueue interpret task quality, binding constraints, saturation, or improvement acceptance.

---

## 1. Baseline source map

### 1.1 Current workspace and target impact

The pinned baseline contains seven workspace crates.

| Current crate | Current role | Target disposition |
|---|---|---|
| `exoskeleton-core` | IDs, envelopes, artifacts, conversations, threads, plans, ticks, watches, charter, and shared traits | Retain the crate name but replace most domain vocabulary with v3 records and I/O-free contracts. |
| `exoskeleton-threads` | Thread registry/runtime/scheduling and built-in coding, initiative, threat, reflection, memory, and creative threads | Replace with faculty contracts and implementations. Delete the coding faculty. Separate Initiative Governor from any initiative-producing faculty. |
| `exoskeleton-memory` | Memory compilation, rendering, repository instructions, token accounting, and store integration | Retain useful memory concepts, remove coding/repository privilege, and adapt to typed evidence, provenance, admission, and narrative boundaries. |
| `exoskeleton-relationship` | Relationship ledger, signals, snapshots, and Align-related logic | Retain longitudinal relationship evidence and reducers; delete Align authority and direct trust-to-permission behavior. |
| `exoskeleton-host` | Cognitive engine, PODAARA kernel, storage adapters, inboxes, LLM providers, config, metrics, benchmark and SWE-bench paths | Rebuild as Vessel runtime composition, episode orchestration, AQ/WI adapters, outbox dispatch, stores, delegation supervision, and observability. Delete the old kernel authority path and coding benchmark runtime. |
| `exoskeleton-daemon` | API, bootstrap server, routes, state, and handlers | Rebuild around v3 principals, operator authentication, interaction/agenda/delegation/causal inspection, and target lifecycle. |
| `exoskeleton-cli` | Bootstrap, code commands, client, formatting, and command groups | Delete coding-specific command families; rebuild around Vessel state, constitutions, communication, initiative, delegation, narrative, and conformance. |

The implementation may introduce logical boundaries before all of them become physical crates. Crate extraction is justified by dependency direction, security isolation, optional deployment, independent reuse, or compile-time cycle prevention—not by a desire to maximize crate count.

### 1.2 Current surgical points

The baseline’s most important replacement points are:

| Current source family | Problem exposed | Target replacement |
|---|---|---|
| `host/src/kernel/{perceive,orient,decide,act,amend,reflect,align}.rs` | One privileged procedural loop interprets prose, selects action, and accumulates vertical-specific branches. | Episode coordinator plus pure constitutional evaluators and deterministic domain reducers. |
| `host/src/kernel/{tools,virtual_tools,policy}.rs` | Tool exposure, cognitive mutation, and permission are entangled; tool names carry semantic privilege. | Faculty emissions, local capability decisions, and WorldInterface submissions derived from structured authority. |
| `host/src/kernel/{git_context,repo_analysis,diff_tracker}.rs` | Coding-specific concepts leak into the generic kernel. | Delete; coding technique belongs inside a delegated specialist sandbox or verifier. |
| `core/src/thread.rs` and `threads/**` | Threads primarily produce prose summaries interpreted by Decide. | `FacultyDescriptor`, `FacultyInvocation`, `StructuralEmission`, emission validation, and optional rationale artifact. |
| `core/src/tick.rs` and `host/src/cognitive_engine.rs` | Tick is the master clock; long-lived work and communication are compressed into repeated model invocations. | `CognitiveEpisode`, durable attention demand, agenda review, continuation, and quiescence. |
| `core/src/inbox.rs`, `core/src/conversation.rs`, `host/src/inbox/**` | Communication is polled per tick; grouping and reply binding are weak; wake is best-effort. | Interaction ledger, conversation projection, response obligations, communication intents, WI observation delivery, and durable AQ admission. |
| `core/src/exec_thread.rs` and coding runtime paths | A specialist agent loop is modeled as an internal cognitive thread. | Delegated work order, Agent Host, worker controls, sandbox policy, verification, and acceptance. |
| `relationship/src/align.rs` and kernel Align | Relationship compilation can become a privileged effect gate and historical failures were fail-open. | Relationship evidence informs cognition; local Capability Constitution and final WI authorization govern effects and fail closed. |
| `host/src/storage/*_store.rs` | Many independent stores make cross-domain atomic transitions difficult and encourage semantic drift. | One authoritative transactional `vessel.db`, separate artifact store, and rebuildable indexes. |
| `host/src/vessel.rs` and `caelum.wake` paths | Wake attempts can be dropped while the engine lock is busy. | Domain-record-before-outbox-before-idempotent AQ admission. |
| local reply event path | Generated and stored content is described as sent before provider evidence exists. | `CommunicationIntent` plus WI effect/outcome/receipt lifecycle. |
| `swe_bench`, benchmark, and code CLI paths | Experimental vertical becomes architecture. | Freeze fixtures and lessons; delete runtime paths. Development delegation becomes one acceptance workload among several. |

### 1.3 Existing behavior classification

Every current behavior must receive one of four dispositions before implementation:

| Disposition | Meaning | Examples |
|---|---|---|
| Preserve semantically | A useful invariant remains, though implementation and format may change. | Durable identity, artifact hashing, explicit relationships, dual AQ separation, budgets, replay discipline. |
| Reframe | The need is valid but belongs to another v3 concept. | Early wake becomes durable attention admission; coding work becomes delegation; relationship Align becomes evidence plus capability policy. |
| Convert to a negative test | A defect becomes a target regression case. | Fail-open relationship compilation, empty-principal approval, local reply-as-sent, droppable wake, first-active-conversation binding. |
| Delete | The concept is obsolete or vertically contaminating. | Decide sovereignty, Align, SessionApprovals, coding thread/tools, tick authority, pre-v3 readers. |

### 1.4 Evidence archive

`EXO-01` creates an archive outside target runtime dependencies containing:

- the tagged source baseline;
- selected acceptance and crash tests;
- coding benchmark prompts, outputs, and failure cases that exposed sprawl;
- representative Tick, conversation, relationship, and tool-policy fixtures;
- fail-open and misattribution reproductions;
- baseline performance and memory measurements;
- source maps identifying deleted concepts;
- explicit notes describing why each fixture is retained.

The archive is evidence, not a compatibility package. Target code may consume copied, normalized test fixtures only after their semantics are restated under v3 contracts.

---

## 2. Delivery model and repository workflow

### 2.1 Branch model

```text
main
  frozen experimental baseline until target release

tags/exoskeleton/pre-exo-v3
  immutable source and evidence reference

exo-v3
  single target integration branch
  no legacy feature flag
  no live dual authority
  no old-format readers
```

Code-bearing PRs target `exo-v3`. The target becomes `main` only when `EXO-V3` conformance passes against exact upstream release candidates.

### 2.2 Fresh target data directory

The target host requires a manifest similar to:

```text
contract: EXO-V3
vessel_schema: 1
artifact_schema: 1
index_schema: 1
stack_contract: STACK-2026-07-25-FOUNDATIONAL-2
aq_contract: AQ-CONT-1@<exact revision>
wi_contract: WI-FABRIC-2@<exact revision>
```

A nonempty directory without the target manifest is rejected without modification. There is no automatic migration from the current experimental stores.

Archived pre-v3 data may be imported only as inert evidence with explicit provenance:

```text
source_class: pre-EXO-V3-experimental
admission_status: archived-untrusted
may_drive_current_state: false
```

### 2.3 Review policy

Every PR must include:

- the v3 invariant or contract section it implements;
- affected authoritative records and transaction boundaries;
- crash points introduced or changed;
- property and replay tests;
- upstream assumptions, if any;
- source concepts deleted or made unreachable;
- operator inspection impact;
- a declaration that no model-generated prose has acquired new authority.

Security-sensitive PRs require a second review focused on identity, authorization, disclosure, cross-principal isolation, or root-key boundaries.

### 2.4 Work maturity labels

| Label | Meaning |
|---|---|
| **Independent** | Pure domain, reducer, schema, or fixture work that does not rely on unstable upstream runtime behavior. |
| **Assumption-bound** | May be implemented behind an internal port using a named semantic assumption; must reconcile at an upstream gate. |
| **Contract-blocked** | The real adapter or lifecycle integration may not merge until the named upstream conformance evidence exists. |
| **Integration-only** | Cannot be completed without exact upstream implementations, crash harnesses, and cross-stack fixtures. |
| **Mixed** | Contains an independent domain portion and a separately gated adapter portion; the PR must keep them visibly separable. |

### 2.5 Dependency posture

The implementation dependency order remains:

```text
AQ-CONT-1
    ↓
WI-FABRIC-2
    ↓
EXO-V3
```

Planning is intentionally concurrent. Exoskeleton may pressure-test upstream semantic requirements, but it must not force ActionQueue to understand Vessel meaning or WorldInterface to understand cognition.

During development:

- use exact path or Git revisions for target upstream contracts;
- isolate adapters behind Exoskeleton-owned ports;
- prohibit local forks of upstream protocol types inside domain crates;
- reconcile assumptions at explicit gates;
- do not merge integration code that depends on behavior absent from upstream conformance.

### 2.6 Release posture

`EXO-V3` is a breaking release. There is no deprecation interval for pre-v3 runtime APIs or stores. Future compatibility discipline begins with the v3 release.

---

### 2.7 Instance execution target and local worker proof

`EXO-V3-EXECUTION-1` is specified in [exo-v3-execution-environment.md](exo-v3-execution-environment.md), with machine-readable scope in [exo-v3-execution-profile.yaml](exo-v3-execution-profile.yaml). It selects Kata/containerd for the outer Vessel instance and `process-managed-proof-1` behind embedded WI for the first worker backend.

Native unit tests and test-only fake boundaries may proceed without Kata hardware. The instance qualification cannot. A successful local run is not allowed to silently satisfy a VM-backed profile, and successful worker management inside the VM is not proof of independent hostile-worker isolation.

### 2.8 Embedded viability versus complete release

The immediate proof milestone is `EXO-EMBEDDED-VIABILITY-1`: a real Vessel on the selected Kata host profile using real embedded AQ/WI and bounded fixture delegation, verification, and restart/recovery. It may be assembled from explicitly tracked embedded portions of the existing PRs while full platform-facing integrations remain pending.

This milestone requires no DigiCorp control plane and no subsequent platform-service expansion. It cannot mark an entire mixed PR accepted if broader dependencies or exit tests remain unmet. Existing full upstream G1–G5 gates, published-release ordering, and daemon/embedded parity requirements are not renamed or automatically passed. Any decision to publish a narrower embedded-only release must explicitly amend the release plan rather than laundering proof evidence into full completion.

See the execution supplement's checkpoint table and [concurrency rebinding notes](EXECUTION-CONCURRENCY-REBINDING.md). The earlier v0.1.0 scheduling sidecar is source-hash-bound and must not silently attach to this revised plan.

## 3. Upstream assumptions and reconciliation gates

### 3.1 Why the Exoskeleton plan is written now

Most v3 work is pure Vessel-domain work and should not wait for upstream implementation. Planning now also verifies that the upstream contracts support a real downstream consumer.

The plan therefore separates:

```text
stable domain semantics
    owned and implementable by Exoskeleton now

adapter assumptions
    documented in the assumption ledger

real runtime integration
    blocked on upstream conformance gates
```

### 3.2 ActionQueue reconciliation gates

| Gate | Required AQ work | Evidence | Exoskeleton details frozen |
|---|---|---|---|
| `EXO-AQ-G1` | `AQ-02`, `AQ-03` | Core vocabulary and fresh persistence lineage stable | opaque reference wrappers, artifact/data reference profile, causal-context translation, target store manifest references |
| `EXO-AQ-G2` | `AQ-04` | `ensure_task` and compound admission conformance passes | `CognitiveEpisodeId`/agenda-review/outbox admission keys, stable task/run mapping, retry behavior |
| `EXO-AQ-G3` | `AQ-05`, `AQ-06`, `AQ-07` | durable signals, `Awaiting`, deadlines, checkpoints, and resume context pass | attention wake, agenda timers, effect/delegation waits, no-lost-wakeup integration |
| `EXO-AQ-G4` | `AQ-08`, `AQ-09` | `AttemptDisposition` and transactional child coordination pass | Vessel handlers, episode completion, coordinator child/wait behavior, cancellation convergence |
| `EXO-AQ-G5` | `AQ-13`, `AQ-14` | exact `AQ-CONT-1` release candidate and conformance package pass | all AQ-facing APIs, cross-stack crash fixtures, release pin |

### 3.3 WorldInterface reconciliation gates

| Gate | Required WI work | Evidence | Exoskeleton details frozen |
|---|---|---|---|
| `EXO-WI-G1` | `WI-02` | target protocol, resource vocabulary, IDs, and fresh persistence compile and replay | `ClientRequestId`, `PurposeRef`, artifact/evidence mappings, principal and persona references |
| `EXO-WI-G2` | `WI-03`, `WI-04`, `WI-05` | ingress delivery/ack and intent-first effect/receipt contracts pass | communication ingestion, observation acknowledgment, effect outbox, communication outcome milestones |
| `EXO-WI-G3` | `WI-06`, `WI-07`, `WI-08` | connector execution, reconciliation, common execution plan, and AQ continuation integration pass | uncertain effects, callback wake, Flow submission, provider-result resumption |
| `EXO-WI-G4` | `WI-09`, `WI-10`, `WI-11`, `WI-12` | worker/sandbox, target capability catalog, deployment surface, and identity/proof interfaces pass | Agent Host controls, sandbox policy, capability references, embedded/remote client, personas and proof seams |
| `EXO-WI-G5` | `WI-13`, `WI-14` | exact `WI-FABRIC-2` release candidate and conformance package pass | all WI-facing APIs, release fixtures, exact dependency pin |

**Profile interpretation:** The tables above preserve the full source gate meanings. For the earlier embedded viability milestone, record exact embedded-capable source revisions and the tests actually executed; unimplemented platform/remote/candidate-isolation obligations remain pending. This is not a new AQ/WI protocol or a declaration that a partial upstream implementation conforms to its entire contract. `EXO-ENV-G1` through `EXO-ENV-G5` are additional local profile evidence, not replacement upstream gates.

### 3.4 Upstream feedback protocol

When implementation discovers an unmet requirement:

1. record it in the owning `exo-v3-aq-assumption-ledger.yaml` or `exo-v3-wi-assumption-ledger.yaml`;
2. describe the semantic need without prescribing upstream domain vocabulary;
3. attach a minimal downstream acceptance scenario;
4. route it to the owning upstream repository;
5. resolve it through an upstream ADR and conformance case;
6. update the Exoskeleton adapter only after the gate passes.

Exoskeleton must not compensate by adding its own durable signal registry, effect store, authorization envelope, worker runtime, or ActionQueue clone.

### 3.5 Remote faculty boundary question

A faculty implementation may be:

```text
pure deterministic local code
trusted local model/runtime
remote model or multimodal service
```

Only the first two may execute wholly inside the Vessel process. A remote inference request crosses a trust, disclosure, cost, and provider boundary and therefore uses WorldInterface through a semantic `model.infer` capability or an equivalent accountable capability profile. The exact WorldInterface representation is an explicit `EXO-WI-G2/G3` reconciliation item; Exoskeleton domain crates depend only on a `FacultyBackendPort`.

---

### 3.6 Foundational reconciliation additions

The existing upstream gates remain sufficient. The plan adds semantic requirements, not new ActionQueue primitives:

- `EXO-WI-G1/G2` must freeze commissioning, acting-capacity, information-use, lifecycle, candidate, and provenance protocol types;
- `EXO-WI-G3/G4` must prove candidate builders, worker events, lifecycle supervisor callbacks, and activation/rollback reconciliation;
- `EXO-WI-G5` must freeze role/stewardship attestations, identity/proof, and deployment/lifecycle profiles.

ActionQueue continues to carry only opaque task, wait, signal, checkpoint, schedule, and causal references.

## 4. Architectural decisions to lock before dependent code

The following ADRs must be accepted before the named implementation work merges.

| ADR | Decision | Required before |
|---|---|---|
| `EXO-ADR-001` | One authoritative transactional `vessel.db`; artifacts and rebuildable indexes are separate. | `EXO-02` |
| `EXO-ADR-002` | Monotonic `VesselRevision` and serialized authoritative reducer with optimistic episode snapshot checks. | `EXO-02`, `EXO-06` |
| `EXO-ADR-003` | Canonical domain-event envelope, digest rules, and event versioning. | `EXO-02` |
| `EXO-ADR-004` | Vessel Blueprint, pinned Manifest, atomic Genesis, commissioning, activation, and lifecycle semantics. | `EXO-03` |
| `EXO-ADR-005` | Purpose Charter, role assignment, acting capacity, stewardship, Mission Offer, and commitment distinctions. | `EXO-03`, `EXO-08` |
| `EXO-ADR-006` | Semantic-time model and historical “as of” query semantics. | `EXO-04` |
| `EXO-ADR-007` | Epistemic claim, support/defeat, belief revision, contradiction, and dependent-plan review semantics. | `EXO-04` |
| `EXO-ADR-008` | Schema registry, semantic digests, compatibility, deprecation, and fail-closed consequential handling. | `EXO-04`, `EXO-05` |
| `EXO-ADR-009` | Integrity classes and instruction-authority admission grammar. | `EXO-05` |
| `EXO-ADR-010` | `ContextManifest` and `EpisodeSecurityEnvelope` compilation, sensitive-reference policy, and version pinning. | `EXO-05` |
| `EXO-ADR-011` | Derivation propagation, integrity endorsement, declassification, quarantine, and release semantics. | `EXO-05`, `EXO-09` |
| `EXO-ADR-012` | Explicit plan amendment, authority/disclosure delta evaluation, and `InfluenceTrace`. | `EXO-05`, `EXO-08` |
| `EXO-ADR-013` | Interaction ledger, conversation projection, response obligation, communication intent, and attention transaction boundaries. | `EXO-06` |
| `EXO-ADR-014` | Initiative and attention are separate reducers; neither is initially a general graph engine. | `EXO-06`, `EXO-08` |
| `EXO-ADR-015` | Faculty invocation/emission contract and strict separation of structural fields from rationale artifacts. | `EXO-07` |
| `EXO-ADR-016` | Influence graph grammar, policy versioning, stable ordering, and unavailable-source behavior. | `EXO-07` |
| `EXO-ADR-017` | Concern, commitment, goal, plan, interest, question, maintenance, portfolio conflict, and quiescence lifecycles. | `EXO-08` |
| `EXO-ADR-018` | Evidence taxonomy and provenance shared by epistemics, memory, relationships, narrative, verification, and cognition. | `EXO-04`, `EXO-09`, `EXO-13` |
| `EXO-ADR-019` | Narrative version admission, historical immutability, tension preservation, and disclosure projections. | `EXO-09` |
| `EXO-ADR-020` | Purpose-bound information use, retention, derivation, disclosure, and deletion obligations. | `EXO-09`, `EXO-11` |
| `EXO-ADR-021` | Two-stage authorization: Exoskeleton local upper bound and WorldInterface final executable decision. | `EXO-10`, `EXO-11` |
| `EXO-ADR-022` | External persona and identity-binding model; no root-key custody in Exoskeleton. | `EXO-10`, `EXO-18` |
| `EXO-ADR-023` | Delegated work order, run, progress, steering, completion-proposal, and Agent Host boundaries. | `EXO-12` |
| `EXO-ADR-024` | Independent verification, criterion evidence, acceptance reducer, and epistemic consequence. | `EXO-13` |
| `EXO-ADR-025` | Skill and `BehavioralComponent` provenance, compatibility, calibration, activation, degradation, and retirement. | `EXO-14` |
| `EXO-ADR-026` | Improvement mutability rings, frozen `EvaluationPlan`, protected criteria, separated roles, and non-amplifying authority. | `EXO-15` |
| `EXO-ADR-027` | External lifecycle-supervisor activation, rollback, quarantine, and continuity-assessment protocol. | `EXO-15` |
| `EXO-ADR-028` | Viability projection, operational modes, protected reserves, recovery demand, and compromised-component handling. | `EXO-16` |
| `EXO-ADR-029` | Clean deletion inventory and forbidden-symbol/static-architecture checks. | `EXO-17` |
| `EXO-ADR-030` | Operator authentication, mutation attribution, backup/restore, audit access, and protected release roots. | `EXO-18` |
| `EXO-ADR-031` | Task Distribution versioning, sampling, holdout, expiry, and workload-integrity rules. | `EXO-04`, `EXO-13` |
| `EXO-ADR-032` | Capability Profile, Representation Profile, and Component Fingerprint canonicalization, compatibility, completeness, and calibration. | `EXO-07`, `EXO-14` |
| `EXO-ADR-033` | Developmental metric vector, protected hard gates, normalization, missing evidence, and evaluator independence. | `EXO-13` |
| `EXO-ADR-034` | Controlled-probe fixed-dimension tolerances, pairing/randomization, confound treatment, and interaction estimation. | `EXO-13`, `EXO-15` |
| `EXO-ADR-035` | Capability Frontier Assessment confidence, `Unknown`/`Mixed` policy, saturation threshold, and invalidation events. | `EXO-15` |
| `EXO-ADR-036` | Developmental Campaign admission, resource ceilings, stagnation, stop/switch/defer policy, and portfolio priority. | `EXO-15`, `EXO-16` |
| `EXO-ADR-037` | Pinned Kata/containerd instance profile: supported host/VMM/guest assets, actual runtime selection, storage durability, limits, external supervisor and qualification evidence. | `EXO-18` deployment slice; decision scaffold in `EXO-03` |
| `EXO-ADR-038` | Consumer binding to WI-ADR-016 / WI-WORKER-EXECUTION-1, exact process-provider controls and limitations, stricter EXO admission, and external-worker resource seam. | `EXO-12`, `EXO-15`, `EXO-19` |


### 4.1 Decisions not open during implementation

Implementation may refine field names, crate boundaries, and index strategy. It may not reopen these fundamentals without a coordinated contract amendment:

- the Vessel is above any model;
- unrestricted prose does not control deterministic evaluators;
- selected cognition does not equal authority;
- local admissibility does not equal final WorldInterface authorization;
- external-origin and endogenous-origin work use the same effect authorization path;
- a queue signal is a wake reference, not the authoritative domain record;
- provider evidence, worker claims, signatures, and narrative claims are not semantic truth by default;
- communication and autonomous initiative coexist under governed attention;
- specialist execution is delegated;
- collective narrative is outside v3;
- root identity secrets never enter faculty or delegate contexts.

---

### 4.2 Additional decisions not open during implementation

- `VesselId` and immutable Genesis are internal Exoskeleton records.
- Purpose Charter, role, mission, commitment, and identity are separate concepts.
- Genesis is local and atomic; commissioning is external and recoverable.
- Provisioned knowledge is not episodic memory; stewardship is not trust.
- Acting capacity is explicit for role-derived work.
- Mission Offers require portfolio admission before commitments exist.
- Belief admission is evidence-linked and temporally scoped.
- Access does not imply retention, derivation, disclosure, or reuse.
- Schema semantics are versioned and cannot be redefined in place.
- The running Vessel never patches its active trusted runtime.
- Candidate evaluation is frozen before implementation and separated from acceptance.
- Improvement authority cannot self-amplify.
- Capability is independent of identity and authority.
- Working representation is an episode projection, not permission to redefine canonical state.
- Campaign correlation is attribution only and cannot alter queue priority, routing, resource authority, or boundary authorization.
- Queue completion and boundary receipts are evidence, not quality judgments or candidate acceptance.
- A binding-constraint or saturation claim without an exact scope and Component Fingerprint is invalid.
- Activation and rollback are performed by an external lifecycle supervisor.
- Restore, migration, succession, and fork are distinct.
- Viability and degraded mode are explicit domain state.

## 5. Target crate and module map

### 5.1 `exoskeleton-core`

I/O-free shared vocabulary:

```text
ids/
refs/
time.rs
version.rs
digest.rs
artifact.rs
evidence.rs
domain_event.rs
vessel_revision.rs
principal.rs
error.rs
```

It owns typed IDs and envelopes but no database, model provider, ActionQueue, WorldInterface, or specialist backend dependency.

### 5.2 `exoskeleton-faculty`

```text
descriptor.rs
invocation.rs
emission.rs
schema.rs
validator.rs
backend.rs
registry.rs
context_contract.rs
```

Responsibilities:

- faculty descriptors and supported claim/proposal classes;
- bounded input contracts;
- structured emission validation;
- optional rationale artifact references;
- local and remote backend ports;
- version/provenance capture;
- no direct domain mutation or WorldInterface effect.

Built-in faculties may initially live in `exoskeleton-faculty/src/builtin/`, but the coding faculty is not ported.

### 5.3 `exoskeleton-constitution`

```text
influence/
    graph.rs
    compiler.rs
    evaluator.rs
    record.rs
initiative/
    policy.rs
    evaluator.rs
    record.rs
attention/
    policy.rs
    evaluator.rs
    fairness.rs
capability/
    grant.rs
    selector.rs
    evaluator.rs
    authority_request.rs
approval.rs
```

All evaluators are pure for a given versioned snapshot. They may compare typed IDs, enums, bounded numeric values, canonical local selectors, and evidence classes. They may not semantically interpret unrestricted prose.

### 5.4 `exoskeleton-agenda`

```text
mission.rs
autonomy.rs
commitment.rs
goal.rs
interest.rs
question.rs
maintenance.rs
plan.rs
progress.rs
quiescence.rs
agenda_review.rs
reducer.rs
```

This boundary owns durable internal momentum, concern admission, continuation, blocking, explicit abandonment, progress, stagnation, and quiescence.

### 5.5 `exoskeleton-interaction`

```text
communication_event.rs
conversation.rs
participant.rs
channel_binding.rs
attention_demand.rs
response_obligation.rs
communication_intent.rs
delivery.rs
ingress_reducer.rs
egress_reducer.rs
projection.rs
```

It owns social continuity, not transport. WorldInterface owns provider/channel ingress and egress; Exoskeleton owns conversational meaning and obligation.

### 5.6 Continuity boundaries

Existing memory and relationship crates may remain, but they must adopt the shared evidence model.

```text
exoskeleton-memory
    admission
    provenance
    episodic/semantic/procedural classes
    retrieval projections
    consolidation proposals

exoskeleton-relationship
    relationship events
    expectation and trust evidence
    relationship snapshots
    reducers
    no effect authorization

exoskeleton-narrative
    self-model snapshots
    historical evidence links
    NarrativeVersion
    NarrativeClaim
    NarrativeTension
    admission and revision
    audience-specific self-description projections

exoskeleton-identity
    internal Vessel lineage
    mission/charter references
    external personas
    identity-binding references
    disclosure and continuity policy
    no private-key custody
```

If crate growth becomes counterproductive, `narrative` and `identity` may begin as modules in one `exoskeleton-continuity` crate. Their logical ownership remains distinct.

### 5.7 `exoskeleton-delegation`

```text
work_order.rs
delegated_run.rs
backend_requirement.rs
execution_policy.rs
sandbox_profile.rs
progress_event.rs
steering.rs
completion_proposal.rs
supervisor.rs
skill.rs
```

This crate knows the generalized delegated-agent lifecycle. It does not import Pi, Claude Code, a research framework, or any backend-specific session type.

### 5.8 `exoskeleton-verification`

```text
criterion.rs
verification_plan.rs
verifier.rs
evidence_admission.rs
result.rs
acceptance.rs
independence_policy.rs
```

A worker’s completion proposal is one input. Acceptance is a separate deterministic transition based on required evidence and policy.

### 5.9 `exoskeleton-store`

A new storage boundary is recommended.

```text
manifest.rs
transaction.rs
event_log.rs
projections/
outbox.rs
inbox_dedup.rs
artifact_store.rs
index_store.rs
backup.rs
recovery.rs
```

The authoritative relational store contains all records and outboxes that require local atomicity. Content-addressed artifact bytes may live separately. Search/vector indexes are rebuildable projections and never the source of truth.

### 5.10 `exoskeleton-host`

```text
vessel_runtime.rs
reducer_loop.rs
episode_coordinator.rs
agenda_scheduler.rs
interaction_ingest.rs
faculty_runner.rs
authentication.rs
outbox_dispatch/
    actionqueue.rs
    worldinterface.rs
worldinterface_client.rs
actionqueue_adapter.rs
delegation_manager.rs
agent_host_client.rs
verification_runner.rs
model_backend.rs
inspect.rs
metrics.rs
config.rs
```

The host is the first layer allowed to compose stores, ActionQueue, WorldInterface, model/faculty backends, and Agent Host clients.

### 5.11 Product surfaces

```text
exoskeleton-daemon
    authenticated API
    bootstrap and lifecycle
    operator mutation endpoints
    event/causal streaming

exoskeleton-cli
    inspection and controlled mutation
    conformance and repair tools
    no coding-specific command family
```

### 5.12 Additional foundational logical boundaries

```text
exoskeleton-instantiation
    Blueprint · Manifest · Genesis · commissioning · activation · lifecycle · roles

exoskeleton-epistemics
    claims · assumptions · beliefs · support/defeat · semantic time · revision

exoskeleton-information
    purpose binding · retention · derivation · disclosure obligations

exoskeleton-schema
    semantic registry · compatibility · policy dependencies

exoskeleton-development
    task distributions · capability/representation profiles · component fingerprints
    controlled probes · frontier assessments · developmental campaigns
    proposals · evaluation plans · candidates · trials · saturation/invalidation
    activation history · continuity assessment

exoskeleton-viability
    health · reserves · operational modes · recovery demands
```

These may be modules before crates. Their transaction ownership and dependency direction are fixed.

### 5.13 `exoskeleton-integrity`

Logical ownership:

- integrity classes and instruction authority;
- information governance envelopes and derivation records;
- context manifests and episode security envelopes;
- plan-amendment proposals and authority deltas;
- influence traces;
- integrity endorsements and declassification decisions;
- injection suspicion, quarantine, and release records;
- pure propagation and admission rules.

The boundary may initially live as modules within `exoskeleton-core`, `exoskeleton-constitution`, and `exoskeleton-interaction`, but it must remain free of host I/O, model SDKs, WorldInterface clients, and ActionQueue APIs.

### 5.14 Physical-crate staging rule

Promote a logical boundary to a crate when at least one is true:

- dependency inversion must be enforced at compile time;
- the boundary has a materially different security profile;
- it is optional in some deployment profiles;
- it is independently reusable or testable;
- keeping it in one crate creates cycles or accidental host dependencies.

Do not block early reducer work on final crate extraction.

---

## 6. Critical path and parallel lanes

### 6.1 Critical path

```text
EXO-01 → EXO-02 → { EXO-03 ∥ EXO-04 }
EXO-04 → EXO-05
EXO-03 + EXO-04 + EXO-05 → EXO-06 → EXO-07
EXO-03 + EXO-04 + EXO-06 + EXO-07 → EXO-08
EXO-08 → EXO-09 → EXO-10 → EXO-11 → EXO-12
       → EXO-13 → EXO-14 → EXO-15 → EXO-16
       → EXO-17 → EXO-18 → EXO-19
```

### 6.2 Parallel lane A — Identity, lifecycle, time, and epistemics

`EXO-03` and `EXO-04` can progress after the core store, with adapters isolated behind ports.

### 6.3 Parallel lane B — Integrity, interaction, and constitutional cognition

`EXO-05`, `EXO-06`, and `EXO-07` build instruction integrity, communication/episode, and faculty/arbitration layers after foundational schemas exist.

### 6.4 Parallel lane C — Agenda, continuity, and authority

`EXO-08`, `EXO-09`, and `EXO-10` establish obligations, relationships, narrative, information governance, and local authority.

### 6.5 Parallel lane D — Upstream integration

`EXO-11` freezes only at named ActionQueue and WorldInterface conformance gates.

### 6.6 Parallel lane E — Delegation, verification, and development

`EXO-12` through `EXO-15` build worker supervision, evidence, components, and governed improvement.

### 6.7 Parallel lane F — Viability, decontamination, and release

`EXO-16` supplies degraded operation; `EXO-17` deletes the predecessor; `EXO-18` hardens security and operations; `EXO-19` performs final cross-stack release.

### 6.8 Merge discipline

Pure domain work may merge behind inactive composition roots. No production adapter, lifecycle activation path, or old/new authority path may merge before its gate. A candidate self-improvement path is not allowed to activate the software being used to implement that path during EXO-V3 development.

## 7. Pull-request implementation sequence

The sequence is a clean-break target path. PR numbers are planning identities, not a requirement that every PR contain one commit. A large PR may be decomposed further during implementation, but it may not merge partial authority paths or bypass its exit gate.

### EXO-01 — Freeze evidence and establish the target development contract

**Maturity:** independent  
**Dependencies:** none

Create the `exo-v3` integration branch, tag the experimental baseline, install `STACK-2026-07-25-FOUNDATIONAL-2`, create `conformance/exo-v3`, and add clean-break checks. Inventory every current store, kernel stage, thread, tool path, wake mechanism, prompt, schema, relationship rule, bootstrap path, coding feature, and external integration. Classify each as retained semantic guarantee, replaced concept, archived evidence, or deleted implementation.

Create ADRs for transaction ownership, Blueprint/Genesis semantics, Purpose Charter terminology, role and acting-capacity model, semantic time, epistemic state, schema governance, lifecycle supervisor, information-use obligations, and developmental authority rings.

**Required tests and checks**

- baseline tag and fixture hashes are reproducible;
- forbidden legacy symbols are staged in CI;
- the canonical stack contract is byte-identical to the shared source;
- no target crate depends on pre-v3 stores or compatibility adapters;
- the initial conformance manifest names exact upstream contract labels.

**Execution-profile allocation (`EXO-V3-EXECUTION-1`)**

- Record the Kata instance / process-worker distinction, bottom-up staging, and the two execution ADRs.

**Exit gate:** frozen source posture, complete disposition ledger, ADR queue, schema inventory, lifecycle inventory, conformance skeleton, and clean-break checks exist.

### EXO-02 — Introduce core records, domain journal, and fresh persistence

**Maturity:** independent  
**Dependencies:** EXO-01

Create target IDs, opaque references, artifact references, monotonic `VesselRevision`, domain-event envelope, transaction context, outboxes, projection framework, and fresh storage lineage. Establish one authoritative relational transaction boundary for Vessel domain state and local outboxes; retain separate domain repository interfaces over that boundary. Large artifacts remain content-addressed outside the relational store.

The event envelope must support semantic-time metadata, schema version, causal predecessors, acting-capacity reference, information-use and integrity-envelope references, derivation and context-manifest references, and policy/version provenance without interpreting WorldInterface or ActionQueue types.

**Required tests and checks**

- event append and projection update are atomic;
- replay reconstructs byte-equivalent domain projections;
- optimistic revision conflicts are deterministic;
- outbox rows cannot exist without their owning domain transition;
- artifacts verify digest and access policy;
- a nonempty pre-v3 directory is rejected without modification;
- backup and restore of an empty target store are proven.

**Exit gate:** target records commit and replay atomically under a fresh schema; no pre-v3 runtime reader exists.

### EXO-03 — Implement Blueprint, Genesis, commissioning, activation, roles, and lifecycle

**Maturity:** mixed; pure domain work is independent, external commissioning adapter is WI-gated  
**Dependencies:** EXO-02  
**Upstream gates:** EXO-WI-G1/G2 for production commissioning effects; EXO-AQ-G2/G3 for scheduled commissioning coordination

Implement `VesselBlueprint`, pinned `VesselInstantiationManifest`, `VesselGenesisRecord`, designation, Purpose Charter, autonomy and developmental policies, stewardship bindings, role assignments, acting capacities, provisioned knowledge, commissioning state, activation policy, lineage, lifecycle state, decommissioning, restore, migration, succession, and fork records.

Genesis is one local transaction and requires no model or external call. Commissioning uses outboxes and generalized WorldInterface operations. Activation is a deterministic reducer over commissioning evidence. A Vessel with no admitted concern may activate directly into durable quiescence.

**Required tests and checks**

- same instantiation key and digest returns one Vessel;
- conflicting digest creates no mutation;
- Genesis is all-or-nothing and immutable;
- two instances of one Blueprint have distinct IDs;
- provisioned knowledge is never inserted as episodic memory;
- stewardship does not initialize relationship trust;
- role changes do not change `VesselId`;
- multiple roles do not ambiently union authority;
- external commissioning failure leaves Genesis intact;
- activation requires declared commissioning evidence but not model inference;
- restore, migration, succession, and fork are distinct;
- decommissioning cannot silently drop obligations.

**Execution-profile allocation (`EXO-V3-EXECUTION-1`)**

- Keep VesselId/Genesis independent of runtime-instance and environment references; stage EXO-EMBEDDED-VIABILITY-1 without DigiCorp.

**Exit gate:** a target Vessel can be structurally instantiated, commissioned through a fake boundary, activated, enter quiescence, and be inspected without an LLM. Instance/environment references do not redefine Vessel identity or Genesis; the initial topology and external lifecycle owner are recorded under EXO-V3-EXECUTION-1.

### EXO-04 — Implement semantic time, schema governance, and epistemic state

**Maturity:** independent  
**Dependencies:** EXO-02

Implement schema registry, namespaces, versions, compatibility declarations, deprecation, policy dependencies, temporal envelopes, claims, hypotheses, assumptions, beliefs, predictions, contradiction sets, support/defeat edges, dependency impacts, belief revisions, current-world-model projections, and historical “as of” queries.

Keep the initial epistemic model deliberately bounded: scoped proposition artifacts, explicit jurisdiction, support/defeat links, and versioned current projections rather than a universal knowledge graph.

**Required tests and checks**

- a schema cannot be redefined in place;
- unknown consequential schemas fail closed;
- historical replay pins exact schema and policy versions;
- contradictory claims can coexist without forced resolution;
- defeating evidence retracts or contests dependent beliefs;
- dependent plans receive review demands;
- occurred, observed, received, admitted, known, valid, and superseded times remain distinct;
- late corrections and clock skew do not rewrite causal order;
- “what was believed at T?” differs from “what is now believed about T?” where appropriate.

**Exit gate:** the Vessel has a deterministic, replayable, evidence-linked current world model and semantic timeline.

### EXO-05 — Implement instruction authority, context manifests, and information-flow integrity

**Maturity:** independent core with WI-gated sink conformance  
**Dependencies:** EXO-02, EXO-04  
**Upstream gates:** EXO-WI-G1/G2 for source assurance and final sink fixtures

Implement `IntegrityClass`, `InstructionAuthority`, `InformationGovernanceEnvelope`, `DerivationRecord`, `ContextManifest`, `EpisodeSecurityEnvelope`, `PlanAmendmentProposal`, authority/purpose/audience/disclosure deltas, `InfluenceTrace`, integrity endorsements, declassification decisions, injection suspicion, quarantine, release, and pure propagation/admission reducers.

All externally sourced natural language defaults to non-directive. Transformations preserve provenance and restrictions. The context compiler produces immutable manifests before faculty execution, and episode outputs are validated against permitted claim/proposal classes plus authority and disclosure ceilings. Detection may quarantine or escalate but cannot grant authority or establish malicious intent.

**Required tests and checks**

- external prose cannot self-assert instruction authority;
- authenticated communication remains distinct from an authorized Mission Offer, approval, or constitutional rule;
- summaries, translations, retrievals, delegate reports, memories, beliefs, and narrative claims preserve derivation and applicable restrictions;
- unknown consequential integrity schemas fail closed;
- context compilation excludes disallowed sensitive classes and records exact versions and source envelopes;
- a faculty result outside the episode envelope is rejected deterministically;
- plan broadening requires an explicit amendment and authority-delta decision;
- detector failure cannot create protected state or authorize a sink;
- quarantine and release are durable and attributable;
- source–sink fixtures prove wrong-purpose, wrong-audience, wrong-resource, and forbidden-data effects are denied.

**Exit gate:** an adversarial artifact may influence hypotheses and proposals but cannot become an instruction, protected-state transition, plan expansion, or authorized effect without explicit structural admission.

### EXO-06 — Build interaction, attention, response obligations, Mission Offer ingestion, and Cognitive Episode admission

**Maturity:** mixed  
**Dependencies:** EXO-03, EXO-04, EXO-05  
**Upstream gates:** EXO-WI-G2; EXO-AQ-G2/G3

Implement interaction ledger, communication events, conversation projections, participant/channel bindings, response obligations, attention demands, Mission Offer association, deterministic attention policy, safe interruption, coalescing, deadlines, stale-response protection, and `CognitiveEpisode` admission.

Production ingress follows: WorldInterface delivery → local communication transaction → local wake outbox → idempotent ActionQueue admission → delivery acknowledgment. The pure domain path must be testable before adapters exist.

**Required tests and checks**

- duplicate delivery creates one communication event;
- a busy Vessel cannot lose an admitted attention demand;
- response obligations and conversation freshness remain separate;
- direct URL/channel changes cannot misbind a response;
- a new message arriving during deliberation invalidates or revises stale output according to policy;
- content cannot self-assign interrupt priority;
- Mission Offer prose cannot directly create commitment or authority;
- communication and autonomous work have anti-starvation guarantees;
- every admitted communication receives a durable disposition.

**Exit gate:** communication and other demands can recruit bounded cognition without becoming the Vessel's sole source of activity.

### EXO-07 — Implement the faculty contract and Influence Constitution

**Maturity:** independent  
**Dependencies:** EXO-04, EXO-05, EXO-06

Implement faculty descriptors, input/output schemas, evidence references, failure modes, deterministic faculty adapters, model adapters behind ports, structural emissions, proposal classes, condition activations, influence graph, edge grammar, topological validation, collapse ordering, proposal dispositions, arbitration records, and language-severance tests.

Every emission pins schema versions. Rationale artifacts are inspectable but unreachable from the arbiter's semantic control path.

**Required tests and checks**

- identical structural input yields byte-identical arbitration;
- replacing rationale text cannot change output;
- cycles and upward-authority edges are rejected;
- unknown consequential claims fail closed;
- unavailable required faculty follows declared degrade/fail policy;
- losing proposals receive explicit disposition;
- confidence is used only where faculty-specific calibrated semantics are admitted;
- model/faculty replacement changes component version without changing Vessel identity.

**Exit gate:** typed faculties and pure constitutional arbitration replace prose-thread convergence.

### EXO-08 — Implement commitment portfolio, Purpose Charter, plans, and governed initiative

**Maturity:** independent  
**Dependencies:** EXO-03, EXO-04, EXO-06, EXO-07

Implement Mission Offer lifecycle, Commitment Admission Governor, Capacity Snapshot, Commitment Conflict, negotiation and clarification, commitments, goals, plans, interests, open questions, maintenance demands, Purpose Charter amendment boundary, autonomy profiles, initiative policy, agenda review, progress records, stagnation, budgets, protected reserves, and quiescence.

An authorized request is not automatically feasible. Admission considers role, acting capacity, existing obligations, deadlines, confidentiality, separation of duties, resource capacity, viability, and required authority.

**Required tests and checks**

- a Mission Offer cannot create a commitment directly;
- conflicting legitimate authorities create an inspectable conflict;
- infeasible deadlines trigger negotiation or decline;
- commitments maintain durable forward pressure without communication;
- self-generated goals require Initiative Decision;
- Purpose Charter cannot directly create work or be amended by mission prose;
- repeated no-progress episodes back off, revise, escalate, suspend, or terminate;
- empty agenda yields quiescence without unconditional inference;
- active concerns continue after restart exactly once.

**Exit gate:** the Vessel can accept, reject, negotiate, continue, and retire work under explicit portfolio and initiative policy.

### EXO-09 — Rebuild relationships, memory, self-model, narrative, and information governance

**Maturity:** independent  
**Dependencies:** EXO-04, EXO-05, EXO-06, EXO-08

Implement relationship evidence and transitions, memory admission and retrieval provenance, provisioned-knowledge classification, self-model snapshots, historical records, narrative versions, narrative claims and tensions, synthesis proposals, communicable self-description, information-use grants, purpose bindings, derivation obligations, retention review, disclosure policy, and tombstone behavior.

**Required tests and checks**

- relationship trust changes cite evidence and cannot be initialized from stewardship;
- memories retain source, epistemic status, time, and use constraints;
- narrative revision cannot change cited history;
- prior narratives remain queryable;
- unsupported or contradicted narrative claims remain tentative or contested;
- internal narrative and audience-specific self-description remain separate;
- source information-use obligations propagate to relevant derivatives;
- basic read access does not imply memory, disclosure, or reuse;
- model replacement inherits history and narrative versions honestly.

**Exit gate:** continuity includes evidence-linked relationships, memory, self-model, narrative, and information obligations without fabricated autobiography.

### EXO-10 — Implement local Capability Constitution, approvals, Agency Drafts, acting-capacity authority, and external personas

**Maturity:** mixed  
**Dependencies:** EXO-03, EXO-05, EXO-08, EXO-09  
**Upstream gates:** EXO-WI-G1/G2

Implement local authority upper bounds, capability graph, attenuation, acting-capacity binding, Purpose and InformationUse references, approval attestations, Agency Drafts, capability decision records, external personas, persona selection, disclosure classes, portable identity references, and developmental/lifecycle authority classes.

**Required tests and checks**

- faculties cannot mint boundary authority;
- role authority does not union across capacities;
- stale or mismatched approval cannot authorize an effect;
- self-initiated or improvement-origin work uses ordinary authorization;
- candidate status cannot create activation authority;
- personas cannot replace `VesselId` or reveal linkage outside policy;
- root keys never enter model, delegate, worker, or ordinary store contexts;
- information-use restrictions can deny disclosure despite resource access.

**Exit gate:** Exoskeleton can produce bounded Agency Drafts and local decisions without pretending to own final WorldInterface authorization.

### EXO-11 — Integrate `AQ-CONT-1` and `WI-FABRIC-2`

**Maturity:** contract-blocked  
**Dependencies:** EXO-06, EXO-08, EXO-10  
**Upstream gates:** EXO-AQ-G1–G4; EXO-WI-G1–G3

Implement target-only adapters for task admission, schedules, durable signals, waits, checkpoints, resume context, ingress deliveries and acknowledgments, EffectSubmission, FlowSubmission, receipts, uncertainty, reconciliation, commissioning operations, role attestations, information-use envelopes, causal references, and lifecycle effects.

All cross-store handoffs use local authoritative records plus outboxes and idempotent downstream admission. No synchronous cognitive tool wait or distributed transaction is introduced.

**Required tests and checks**

- crash at every local-outbox/AQ/WI boundary loses neither domain state nor wake;
- early and duplicate signals resume once;
- callback signals reference already committed authoritative WI results;
- effect uncertainty causes waiting/reconciliation, not blind retry;
- ingress acknowledgment occurs after local communication commit;
- commissioning and lifecycle effects cannot rewrite Genesis or acceptance;
- embedded and daemon WorldInterface profiles pass the same fixtures.

**Execution-profile allocation (`EXO-V3-EXECUTION-1`)**

- Exercise real embedded WI/AQ adapters inside the Kata instance without introducing a platform-service prerequisite for the initial proof.

**Exit gate:** real AQ/WI adapters satisfy pinned conformance with no compatibility path. The initial embedded proof runs inside the declared instance profile; it does not substitute for outstanding full daemon/platform conformance.

### EXO-12 — Implement delegation management and Agent Host control

**Maturity:** contract-blocked/mixed  
**Dependencies:** EXO-08, EXO-10, EXO-11  
**Upstream gates:** EXO-AQ-G2–G4; EXO-WI-G3/G4

Implement delegated work orders, backend requirements, execution-mode selection, normalized worker events, run-scoped identity, sandbox grants, supervision, steering, checkpoints, budget and deadline policy, nested delegation, progress and stagnation, artifact collection, termination, and recovery.

**Required tests and checks**

- one work order maps idempotently to one durable delegation;
- delegate cannot inherit root identity or broaden scope;
- worker events are stored before wake and deduplicated;
- sandbox exports are inspected before admission;
- cancellation, completion, and late event races converge;
- nested delegation attenuates authority and budget;
- coding and non-coding backends satisfy one outer contract.

**Execution-profile allocation (`EXO-V3-EXECUTION-1`)**

- Consume the WI local Agent Host process backend for reviewed fixture workers; prove lifecycle and reject unsupported stronger isolation.
- Keep PID/path/runtime details adapter-local and preserve an externally provided worker-resource seam.

**Exit gate:** Exoskeleton supervises specialist work without implementing specialist technique or binding directly to one framework. The process-managed-proof-1 backend passes its bounded lifecycle cases, rejects stronger unsupported isolation, and leaves externally provided workers a portable resource seam.

### EXO-13 — Implement verification, developmental measurement, evidence admission, acceptance, and epistemic consequence

**Maturity:** mixed  
**Dependencies:** EXO-04, EXO-08, EXO-09, EXO-11, EXO-12

Implement verifier contracts, deterministic checks, model reviewers, human approval, provider/counterparty evidence, evidence classification, immutable multidimensional Evaluation Results, metric vectors, confound/exclusion records, completion proposals, verification records, acceptance reducer, commitment discharge, belief admission, failure and uncertainty handling, and separation of duties.

**Required tests and checks**

- worker claim cannot self-certify completion;
- verification and evaluation evidence are bound to exact artifact, Component Fingerprint, task-distribution, environment, and evaluation-plan versions;
- new candidate, component drift, or workload revision invalidates stale reviews/comparisons;
- contradictory verifier results and missing evidence remain inspectable;
- queue completion, boundary receipt, verification, evaluation, acceptance, and epistemic belief are separate transitions;
- protected tests, workload membership, score policy, baseline fingerprints, and hard gates cannot be modified by the implementation subject;
- high-risk acceptance requires declared independent roles;
- aggregate metric gain cannot override protected invariant failure.

**Execution-profile allocation (`EXO-V3-EXECUTION-1`)**

- Keep worker exit/receipt separate from independent acceptance and label process-proof assurance and simulated provider evidence.

**Exit gate:** outcomes become accepted only through explicit evidence policy and version-bound verification/evaluation; developmental measurements are immutable, scoped, and distinguish facts from judgment. Process-worker lifecycle success and simulated external-provider results carry their actual assurance limits and cannot self-certify accepted work.

### EXO-14 — Add skills, capability/representation profiles, and the behavioral component registry

**Maturity:** independent/mixed  
**Dependencies:** EXO-04, EXO-07, EXO-09, EXO-13

Implement skill definitions, work-order templates, competence calibration, Faculty and Capability Profiles, Representation Profiles, context-budget and schema-resolution policies, faculty/representation compatibility, Component Fingerprints, backend profiles, trial and admission, component version registry, provenance, schema dependencies, calibration evidence, compatibility claims, activation history, degradation, suspension, rollback, and retirement.

**Required tests and checks**

- competence is scoped to exact version, Task Distribution, Representation Profile, environment, and budget;
- skill and capability authority remain separate from definition or measured competence;
- a Representation Profile cannot rewrite canonical state or silently widen the Context Manifest;
- richer representation may lose and receives no presumption of utility;
- selected faculty/profile combinations satisfy declared compatibility and information-use policy;
- a skill cannot silently alter trusted reducers or constitutions;
- component changes are identity-relevant historical events;
- fingerprints change when any behaviorally relevant component or policy changes;
- deprecated schemas/components/profiles remain replayable;
- low-risk reversible skill and profile updates follow a bounded developmental policy.

**Execution-profile allocation (`EXO-V3-EXECUTION-1`)**

- Record instance-environment and worker-environment identities/assurances separately in component and evaluation provenance.

**Exit gate:** skills and cognitive/representation components have explicit provenance, fingerprints, compatibility, lifecycle, competence, and authority boundaries. Instance and worker environment evidence remain distinct and relevant drift invalidates developmental comparisons.

### EXO-15 — Implement governed self-improvement, frontier diagnosis, and lifecycle-supervisor integration

**Maturity:** integration-only/mixed  
**Dependencies:** EXO-10, EXO-11, EXO-12, EXO-13, EXO-14  
**Upstream gates:** EXO-WI-G2–G5; EXO-AQ-G2–G5 (full parent acceptance, consistent with Appendix A)

Implement Task Distributions, Controlled Intervention Probes, Capability Frontier Assessments, Developmental Campaigns, binding-constraint confidence, interaction estimates, fixed-dimension assertions, confound handling, saturation and invalidation records, campaign stop/switch/defer policy, limitation observations, improvement hypotheses, Improvement Proposals, risk classification, frozen Evaluation Plans, protected invariant references, candidate-development work orders, design review, independent verification, trials/canaries, multidimensional evaluation, Activation Decisions, lifecycle-supervisor requests, post-activation monitoring, rollback, quarantine, continuity assessment, and developmental narrative transition.

**Required tests and checks**

- every assessment pins a Task Distribution, environment, authority/information-use envelope, resource budget, Evaluation Plan, and complete Component Fingerprint;
- intelligence-, representation-, and harness-only probes reject undeclared drift in fixed dimensions;
- factorial fixtures detect material interaction effects;
- insufficient or conflicting evidence yields `Unknown`, `Mixed`, or calibrated uncertainty rather than a forced diagnosis;
- active trusted runtime is never modified in place;
- candidate cannot edit its own protected workload, score policy, criteria, fingerprint, stop rule, or rollback trigger;
- no single role controls diagnosis, proposal, implementation, evaluation, acceptance, and activation;
- candidate cannot broaden future improvement authority;
- protected root, rollback image, release manifest, and activation credentials remain outside the candidate;
- queue and boundary success do not become improvement acceptance;
- activation uncertainty reconciles before repeat;
- rollback restores a known-good version and preserves failed candidate history;
- deep changes produce explicit continuity assessment;
- relevant component, workload, evaluator, environment, or budget change invalidates prior saturation;
- campaign work obeys budget, iteration, stagnation, portfolio priority, stop, switch, defer, and termination policy.

**Execution-profile allocation (`EXO-V3-EXECUTION-1`)**

- Use a minimal operator-owned host supervisor for approved fixture activation/rollback; forbid raw engine access and unreviewed executable candidate trials in the process profile.

**Exit gate:** the Vessel can diagnose and participate in its own improvement without becoming the sole author of the diagnosis, judge, or activator of its replacement. The active guest has no raw runtime-management authority, the operator-owned supervisor remains external, and unreviewed executable candidates cannot run under the process proof profile.

### EXO-16 — Implement viability, degraded modes, maintenance, and recovery

**Maturity:** mixed  
**Dependencies:** EXO-03, EXO-04, EXO-08, EXO-09, EXO-10, EXO-11, EXO-14, EXO-15

Implement health projections, resource reserves, backup and restore status, queue/boundary/faculty/verifier health, credential expiration, integrity incidents, operational modes, recovery demands, protected communication/safety reserves, and integration with attention, initiative, commitment admission, capability, and developmental policy.

**Required tests and checks**

- constrained resources stop discretionary exploration before protected service;
- unavailable verifier blocks declared high-risk acceptance;
- compromised component enters quarantine and dependent beliefs/capabilities are reviewed;
- new commitments are refused when viability reserve is insufficient;
- recovery work is durable and prioritized without requiring constant inference;
- quiescent and healthy remain distinguishable;
- daemon restart reconstructs the same operational mode.

**Execution-profile allocation (`EXO-V3-EXECUTION-1`)**

- Prove durable-volume restart/recreate, orphan reconciliation, consistent backup/restore and one writer under the selected Kata storage profile.

**Exit gate:** the Vessel can degrade safely, prioritize recovery, and preserve governance under partial failure. The selected Kata persistence path passes restart/recreate, one-writer restore, compatible rollback and worker/outbox reconciliation evidence.

### EXO-17 — Delete and decontaminate the experimental architecture

**Maturity:** independent once replacements exist  
**Dependencies:** EXO-06 through EXO-16

Delete PODAARA as authority, Decide, Align, SessionApprovals, `caelum.wake`, local reply-as-sent, coding thread and tools, prose bootstrap as authoritative identity creation, old tool policies, SWE-bench runtime paths, pre-v3 readers, and live old/new shadow authority. Remove specialist and legacy vocabulary from the target kernel.

Convert each known defect into a target negative test. Keep only archived source and fixtures.

**Exit gate:** one target architecture remains, all forbidden symbols are absent, and the old runtime cannot be selected or read.

### EXO-18 — Complete identity/proof, privacy, security, and operational hardening

**Maturity:** mixed  
**Dependencies:** EXO-11, EXO-13, EXO-15, EXO-16, EXO-17  
**Upstream gates:** EXO-AQ-G5; EXO-WI-G4/G5

Complete external identity and proof adapters, pairwise personas, key rotation/revocation, role/stewardship attestations, purpose-bound disclosure, encrypted sensitive stores, backup and restore drills, lifecycle credentials, protected release manifests and test suites, audit access, operator controls, rate limits, abuse testing, and deployment profiles.

**Execution-profile allocation (`EXO-V3-EXECUTION-1`)**

- Qualify one containerd/Kata host stack, image/entrypoint, non-root workload, controls, persistence bindings and operator runbooks.

**Exit gate:** the full security and operational posture is documented, tested, recoverable, and uses no mandatory speculative identity foundation. One pinned Kata/containerd instance profile passes EXO-ENV-G1/G2 with protected host management and explicit process-worker limitations.

### EXO-19 — Complete cross-stack conformance and publish the breaking release

**Maturity:** integration-only  
**Dependencies:** EXO-18 and every preceding PR  
**Upstream gates:** EXO-AQ-G5; EXO-WI-G5

Run `conformance/exo-v3` against exact published or release-candidate upstream revisions. Execute long-horizon workloads covering autonomous silence, communication interruption, Mission Offer negotiation, delegation, uncertain effects, model replacement, belief correction, narrative revision, commissioning, degraded mode, self-improvement candidate rollback, restore, migration, explicit fork, and an OHIO-informed developmental campaign with intelligence, representation, and harness probes plus saturation invalidation.

Publish release manifests pinning upstream implementation and conformance revisions, fresh schema versions, supported future migration policy, backup/restore instructions, and operator runbooks.

**Execution-profile allocation (`EXO-V3-EXECUTION-1`)**

- Record EXO-EMBEDDED-VIABILITY-1 on real Kata plus embedded AQ/WI; keep full release/platform/hostile-worker claims separate.

**Exit gate:** all target-only conformance, crash, replay, security, developmental-diagnostic, performance, backup, and reference workloads pass; the clean-break EXO-V3 release is publishable. EXO-EMBEDDED-VIABILITY-1 and EXO-ENV-G1 through G5 are evidenced without inflating narrower proof into unimplemented platform or hostile-worker qualification.

## 8. Persistence, transactions, and recovery

### 8.1 Authoritative persistence topology

The target uses one local transactional boundary for Vessel-semantic state:

```text
vessel.sqlite
    domain journal
    current projections
    constitutions and policy versions
    commitments, goals, plans, and agenda
    interactions, conversations, and obligations
    relationships, self-model, and narrative metadata
    delegations, verification, and evidence admission
    external personas and identity references
    local outboxes and inbox deduplication indexes

artifact store
    immutable content-addressed payloads
    model inputs and outputs selected for retention
    communication content and attachments
    evidence bundles and verifier reports
    narrative prose and self-descriptions
    work-order material and worker artifacts

memory index
    rebuildable retrieval/index structures
    never authoritative for historical truth

telemetry store
    high-volume operational measurements
    retention-bounded and non-authoritative
```

The single semantic database is a deliberate correction to the current family of independently written stores. Records that must be causally inseparable—such as a communication event, response obligation, and wake outbox—must commit in one local transaction.

Artifact bytes may be written before the semantic transaction. An artifact becomes authoritative only when its immutable reference is admitted by a committed domain record. Orphaned artifacts are garbage-collected after a retention window.

### 8.2 Domain journal and projections

Every authoritative transition produces a versioned domain event:

```rust
pub struct VesselEventEnvelope {
    pub event_id: VesselEventId,
    pub vessel_id: VesselId,
    pub vessel_revision: VesselRevision,
    pub causation_ref: Option<OpaqueRef>,
    pub correlation_ref: Option<OpaqueRef>,
    pub actor_ref: ActorRef,
    pub policy_versions: PolicyVersionSet,
    pub occurred_at: Timestamp,
    pub payload: VesselEvent,
}
```

The journal is append-only. Current tables are projections derived inside the same transaction that appends the event. Recovery verifies the journal/projection watermark before the host accepts work.

The implementation does not require full event sourcing for every query. It does require:

- one monotonic Vessel revision;
- immutable transition records;
- deterministic reducer versions;
- projection rebuild for conformance fixtures;
- explicit schema and reducer versioning;
- no direct projection mutation outside the reducer transaction.

### 8.3 Core transaction boundaries

#### 8.3.1 Inbound communication

```text
receive ObservationDelivery from WorldInterface
    ↓
validate delivery identity and binding
load immutable content/attachment references
    ↓
BEGIN vessel transaction
    deduplicate DeliveryId/provider event
    append CommunicationEvent
    update Conversation projection/version
    create or update ResponseObligation
    create AttentionDemand or RecordOnly disposition
    append WorldInterface-ack outbox entry
    append Vessel-AQ admission/signal outbox entry when needed
COMMIT
    ↓
outbox workers acknowledge WI and admit AQ work idempotently
```

WorldInterface acknowledgment never precedes local semantic durability. AQ wake admission never becomes the source of truth for the message.

#### 8.3.2 Agenda review and episode admission

```text
durable schedule/signal becomes eligible
    ↓
BEGIN vessel transaction
    deduplicate trigger identity
    run deterministic Initiative Governor eligibility pass
    run deterministic Attention Governor admission pass
    create CognitiveEpisode record when judgment is needed
    or create QuiescenceRecord / next review outbox
    append AQ episode-admission outbox if an episode was created
COMMIT
```

A periodic agenda review may complete without invoking a model. Exactly one episode exists for one idempotent admission key.

#### 8.3.3 Episode completion

```text
faculty emissions and evidence artifacts available
    ↓
BEGIN vessel transaction
    verify episode revision precondition
    admit validated structural emissions
    run Influence Constitution
    run relevant reducers:
        commitment / goal / agenda
        interaction / relationship
        delegation / verification
        self-model / narrative proposal
    run local Capability Constitution for selected boundary proposals
    append decision records and domain events
    append downstream outbox entries
    transition episode terminal state
COMMIT
```

If the expected Vessel revision no longer holds, the episode result is not silently applied. It is marked stale and either recompiled against current state or discarded according to policy.

#### 8.3.4 Outbound communication and effects

```text
selected proposal
    ↓
BEGIN vessel transaction
    create immutable CommunicationIntent or BoundaryActionRequest
    bind purpose, audience/resource selector, content/evidence,
      local capability decision, and source Vessel revision
    create WI EffectSubmission outbox entry
COMMIT
    ↓
submit with stable ClientRequestId derived from local intent identity
```

The local record says what the Vessel intended and was willing to request. It does not claim provider acceptance, delivery, or final executable authorization.

#### 8.3.5 Delegation start

```text
accepted DelegatedWorkOrder
    ↓
BEGIN vessel transaction
    create Delegation and planned run
    create worker.start boundary request
    create supervision deadline / AQ outbox
COMMIT
```

Worker identity and external run identity are attached only after WorldInterface returns an authoritative outcome. A crash between WI admission and local acknowledgment is repaired by stable request identity.

#### 8.3.6 Worker event ingestion

```text
WorldInterface authoritative worker observation/delivery
    ↓
BEGIN vessel transaction
    deduplicate DeliveryId / WorkerEventId
    append DelegationEvent
    update Delegation projection
    admit artifacts as evidence candidates
    create supervision AttentionDemand when judgment is required
    append delivery acknowledgment and AQ wake outboxes
COMMIT
```

A worker's `CompletionProposed` event is not a commitment discharge.

#### 8.3.7 Verification and acceptance

```text
verification evidence complete
    ↓
BEGIN vessel transaction
    append VerificationOutcome
    run acceptance reducer against WorkOrder criteria
    Accepted:
        advance/discharge work order
        update parent commitment/plan
    Rejected/RevisionRequired:
        preserve evidence and create next demand
    append any communication/effect/delegation outboxes
COMMIT
```

Acceptance is based on evidence and policy, not worker narrative.

#### 8.3.8 Narrative revision

```text
narrative synthesis proposal + cited evidence
    ↓
BEGIN vessel transaction
    validate evidence references and historical immutability
    preserve contradictions and protected-claim amendment rules
    append NarrativeSynthesisRecord
    append new NarrativeVersion superseding prior version
    leave prior versions queryable
COMMIT
```

Narrative admission cannot modify historical events, commitments, mission, constitution, or relationship records.

#### 8.3.9 Genesis and commissioning

One local transaction commits `VesselId`, Genesis, initial governance, roles, stewardship, provisioned-knowledge references, and commissioning outbox. Every WorldInterface result is later admitted as evidence; no external call shares the transaction.

#### 8.3.10 Mission and commitment admission

Mission Offer disposition, portfolio conflict, accepted commitment, acting capacity, communication response, and any required clarification/outbox records commit together where one implies another.

#### 8.3.11 Belief revision

Belief revision, support/defeat changes, dependency impacts, review demands, temporal metadata, and resulting current-world projection commit atomically.

#### 8.3.12 Frontier assessment, campaign admission, improvement proposal, and evaluation freeze

Task Distribution, baseline Component Fingerprint, supporting Controlled Intervention Probes, Capability Frontier Assessment, Developmental Campaign admission, Improvement Proposal, protected Evaluation Plan, work authorization request, and developmental outbox commit before candidate work starts. Each record is immutable or versioned; acceptance and activation remain later transactions.

#### 8.3.13 Activation and continuity

Activation Decision is local. WorldInterface/lifecycle-supervisor effects occur later. Activation or rollback evidence, active component projection, continuity assessment, narrative transition, and monitoring demands commit as explicit separate domain transitions.

#### 8.3.14 Viability transition

Health evidence, operational mode, recovery demands, protected reserves, and any resulting initiative/capability restrictions commit under one Vessel revision.

#### 8.3.15 Context, integrity, and plan amendment

The ContextManifest and EpisodeSecurityEnvelope are committed before faculty execution or stored as immutable artifacts referenced by the admitted episode. Integrity endorsements, declassification, quarantine, and PlanAmendmentDecision records commit with their owning state transition and any downstream outbox. No derived artifact may enter durable memory, belief, narrative, or effect submission without its governance and derivation references.

### 8.4 Outbox families

The target has typed outboxes rather than one semantically overloaded queue table:

| Outbox | Destination | Stable key |
|---|---|---|
| `aq_task_outbox` | Vessel ActionQueue | local operation/event ID + purpose class |
| `aq_signal_outbox` | Vessel ActionQueue | local authoritative result ID |
| `wi_effect_outbox` | WorldInterface | `CommunicationIntentId`, `BoundaryActionRequestId`, or worker-control request ID |
| `wi_ack_outbox` | WorldInterface ingress delivery acknowledgment | `DeliveryId` |
| `artifact_gc_outbox` | artifact lifecycle worker | artifact reference and policy version |
| `projection_rebuild_outbox` | local maintenance | projection/version identity |

Each outbox entry is immutable in request content and mutable only in delivery bookkeeping. Reuse of one stable key with different request content is a fatal conflict, not a retry.

### 8.5 Recovery phases

Host startup follows a fixed sequence:

```text
1. Verify target manifest and exact stack contract.
2. Verify journal integrity and schema/reducer compatibility.
3. Reconcile projection watermark to journal head.
4. Rebuild or verify derived indexes.
5. Resume local outbox dispatchers.
6. Reconcile pending WI submissions and delivery acknowledgments.
7. Reconcile AQ task/signal admissions.
8. Reconcile nonterminal CognitiveEpisodes and Delegations.
9. Recalculate due response, agenda, supervision, and maintenance demands.
10. Admit runtime service only after invariants hold.
```

Recovery must be idempotent. It may create missing downstream admissions through stable identities; it may never infer that an external effect occurred merely because a local outbox was marked attempted.

### 8.6 Future persistence evolution

The clean break applies only to the experimental predecessor. `EXO-V3` establishes the first supported evolution baseline.

Before release, the repository must include:

- forward schema migration infrastructure;
- reducer-version registration;
- snapshot/backup compatibility metadata;
- upgrade tests from every published target fixture;
- rollback policy for binaries, not silent downgrade of stores;
- backup, restore, and projection-rebuild runbooks;
- schema ownership and review rules.

---

## 9. Runtime algorithms and state-machine requirements

### 9.1 Demand admission

Every possible reason for cognition is represented as a durable demand with a stable origin:

```text
CommunicationAttention
CommitmentContinuation
GoalAdvancement
OpenQuestionReview
InterestExploration
RelationshipFollowUp
DelegationSupervision
EffectOutcomeReview
ScheduledReflection
SelfMaintenance
OperatorAction
SensorObservation
```

The admission pipeline is:

```text
authoritative source record
    → typed demand candidate
    → Initiative Governor, when endogenous eligibility is involved
    → Attention Governor
    → RecordOnly / Deferred / Coalesced / EpisodeAdmitted / Escalated
```

No source may invoke faculties directly.

### 9.2 Agenda review and quiescence

Agenda review executes deterministic checks before model work:

1. read active commitments, goals, open questions, interests, response obligations, delegation state, deadlines, and maintenance schedules;
2. expire or age eligible demands according to policy;
3. evaluate continuation and initiative eligibility;
4. create demands for eligible concerns;
5. run attention admission;
6. if none requires judgment, persist quiescence and the next wake condition;
7. otherwise admit one or more policy-bounded episodes.

Quiescence records why no work was admitted and how the Vessel may wake. Repeated empty reviews back off according to policy rather than causing constant inference.

### 9.3 Cognitive episode lifecycle

```text
Proposed
    → Admitted
    → ContextCompiling
    → FacultyRunning
    → EmissionsValidated
    → Arbitrating
    → Committing
    → Completed

terminal alternatives:
    Superseded
    Stale
    Failed
    Canceled
```

The episode owns no long-running external work. It may create durable intents, commitments, work orders, or waits and then complete.

### 9.4 Context compilation

Context compilation is a security-relevant pure operation. It must:

- select only artifacts needed for the episode purpose;
- preserve every source governance envelope and derivation link;
- exclude disallowed sensitive classes and prefer governed references over raw secrets;
- pin structural snapshot, conversation/plan/belief versions, compiler component version, policy versions, and schema versions;
- produce a stable ContextManifest digest;
- produce an EpisodeSecurityEnvelope before faculties run;
- reject ambient host, store, filesystem, network, credential, or cross-workspace access.

The compiler cannot infer instruction authority from content text. Changes to compiler selection or projection semantics enter the Behavioral Component lifecycle.

Context compilation must be deterministic for one Vessel revision, episode trigger set, policy version set, faculty descriptor set, and artifact state.

It produces a manifest containing:

- included structural facts and evidence references;
- omitted candidates and omission reasons;
- memory retrieval query and result identifiers;
- narrative/self-model versions;
- relationship/conversation scope;
- commitment/goal/plan versions;
- budget and disclosure constraints;
- model/faculty version and prompt/template hashes.

The manifest, not unrestricted context prose, is the replay anchor.

### 9.5 Faculty fan-out and fan-in

Faculties may execute concurrently under per-faculty budgets and deadlines. Each invocation has:

```text
EpisodeId
FacultyId and version
InputManifest hash
Allowed claim/proposal classes
Evidence-access envelope
Output schema version
Budget and deadline
```

The host validates every emission before it enters arbitration. Invalid emissions are retained as diagnostic artifacts but have zero structural influence.

A faculty may fail without invalidating unrelated emissions unless policy declares it required for that episode class. Missing required faculties produce an explicit incomplete-deliberation outcome.

### 9.6 Constitutional evaluation and commit

The host evaluates in a fixed order:

```text
1. emission schema and evidence admission
2. Influence Constitution
3. Initiative Governor, for new/continued endogenous concerns
4. commitment / interaction / delegation / continuity reducers
5. local Capability Constitution, for boundary requests
6. transactional commit against expected VesselRevision
```

Attention admission ordinarily occurs before the episode. A new demand generated during commit is admitted in a subsequent transaction/episode rather than recursively invoking cognition.

All decision records include exact graph/policy versions and structural traces. Rationale artifacts remain inspectable but unreachable by deterministic evaluators.

### 9.7 Communication concurrency

Every draft or selected `CommunicationIntent` records the conversation version and addressed event set on which it was based.

Before commit and before dispatch, policy checks whether the conversation advanced. The disposition may be:

```text
StillValid
RequiresRecompile
SendThenFollowUp
Superseded
OperatorReviewRequired
```

The system never silently sends a response to the wrong conversation or audience.

### 9.8 Delegation supervision

Delegation supervision is deadline- and event-driven:

```text
worker event / supervision timer / budget threshold
    → durable demand
    → deterministic checks
    → cognition only when judgment is needed
```

Routine progress does not necessarily invoke faculties. The manager may update counters, checkpoint references, or next inspection deadlines deterministically.

### 9.9 Verification and epistemic admission

Evidence enters with a source and assurance class. The Vessel distinguishes:

```text
worker claim
self-signed assertion
WorldInterface execution receipt
provider/counterparty evidence
independent verifier result
operator attestation
transparency evidence
```

A belief, completion judgment, relationship update, or narrative claim must cite admitted evidence. Signature validity is represented as provenance, never semantic truth.

### 9.10 Model replacement

A model/faculty replacement is a durable component transition:

1. register new descriptor/version;
2. run calibration and compatibility fixtures;
3. record capability differences and known limitations;
4. authorize limited episode classes;
5. expand or roll back according to evidence;
6. record the transition in Vessel history and, where material, narrative synthesis input.

The replacement model does not rewrite prior emissions, decisions, memories, or narrative versions.

---

### 9.11 Instantiation and activation

Validate pinned Blueprint/Manifest; perform idempotent atomic Genesis; dispatch commissioning outboxes; reduce evidence to activation; enter Active or Quiescent without requiring model output.

### 9.12 Belief revision and dependency review

Admit evidence, evaluate support/defeat, revise current belief projection, preserve contradictions, and create review demands for dependent plans, commitments, narrative claims, or policies.

### 9.13 Mission portfolio admission

Authenticate and interpret Mission Offer; select acting capacity; evaluate Purpose Charter, authority, budget, capacity, information obligations, conflicts, deadlines, and viability; accept, negotiate, defer, decline, or escalate.

### 9.14 Governed improvement and frontier diagnosis

Freeze the Task Distribution, Evaluation Plan, metric vector, baseline Component Fingerprint, fixed dimensions, and stop policy. Run controlled probes; record confounds; produce a calibrated Capability Frontier Assessment; admit a bounded Developmental Campaign and exact intervention class; delegate candidate work; verify exact version; conduct trial; decide acceptance and activation separately; call lifecycle supervisor through WorldInterface; monitor; retain, roll back, quarantine, switch lever, defer, stop, or record scoped saturation; invalidate stale assessments after relevant change; record continuity.

### 9.15 Viability and degraded operation

Project health and reserves; derive operating mode; restrict initiative and authority; create recovery demand; return to healthier mode only through evidence-backed transition.

### 9.16 Instruction-integrity enforcement

For every episode:

```text
load admitted demand and purpose
    → compile ContextManifest and EpisodeSecurityEnvelope
    → run faculties with no ambient authority
    → validate schemas, derivation, integrity, and envelope limits
    → arbitrate typed proposals
    → construct InfluenceTrace
    → require explicit PlanAmendmentDecision for any broadening
    → run owning reducers
    → submit exact purpose/acting-capacity/information-use constraints to WorldInterface
```

An invalid or suspicious emission may be rejected or quarantined without treating the faculty as malicious. The handler records the rejected output and component version according to security policy, while protected state remains unchanged.

## 10. Domain implementation strategy

### 10.1 Pure reducers first

Every major domain must be implemented first as:

```text
State + Command + Evidence + PolicyVersion
    → Events or explicit Rejection
```

The first test harness must run without an LLM, ActionQueue, WorldInterface, network, wall-clock dependency, or mutable global singleton.

### 10.2 Required reducer families

| Reducer | Required early properties |
|---|---|
| Interaction | Idempotent communication admission, conversation versioning, addressed-event binding, response-obligation lifecycle |
| Agenda | Demand deduplication, priority aging, anti-starvation, coalescing, quiescence, safe interruption |
| Initiative | Goal admission, autonomy-profile enforcement, discretionary budgets, progress/stagnation, review/termination |
| Commitment | Explicit undertaking, plan linkage, blocked/deferred/abandoned/discharged transitions, no omission-based disappearance |
| Influence | Determinism, rationale blindness, stratum/veto/modulation rules, complete disposition trace |
| Local capability | Requested bounds only, no final WI authorization, bounded approvals, fail-closed unknown classes |
| Relationship | Evidence-linked transitions, per-principal context, no trust-to-authority shortcut |
| Narrative | Versioning, evidence support, tensions, protected claims, immutable history |
| Delegation | Work-order lifecycle, worker-event provenance, supervision, no self-certification |
| Verification | Criteria evaluation, evidence assurance, accepted/rejected/revision-required outcomes |
| Persona | Audience/disclosure policy, identifier bindings by reference, no identity-to-authority inference |

### 10.3 Policy and constitution authoring

Human-authored source forms compile into immutable runtime forms. Compilation performs:

- schema and identifier validation;
- cycle checks where a DAG is required;
- unreachable/shadowed-rule detection;
- forbidden generic predicate detection;
- policy coverage analysis;
- explicit default disposition;
- version and content hash assignment;
- signed or operator-attributed admission.

Compiled forms are the evaluator input. Source prose is not.

### 10.4 Time and randomness

Reducers receive time and randomness as explicit inputs. Tests use deterministic clocks and seeded generators. IDs that participate in idempotency are derived from stable domain identities or supplied by the command origin; they are not regenerated during replay.

### 10.5 Error taxonomy

At minimum, errors distinguish:

```text
ValidationRejected
PolicyDenied
VersionConflict
StaleEpisode
MissingEvidence
UnsupportedSchema
UpstreamUnavailable
OutboxConflict
AuthorizationDenied
OutcomeUncertain
CorruptHistory
InvariantViolation
```

Retry behavior is attached structurally to error classes. A semantic denial is never converted into a transient retry merely because a model requests another attempt.

---

### 10.6 Foundational reducer families

- instantiation, commissioning, activation, lifecycle, role, and stewardship reducers;
- schema admission and compatibility reducers;
- epistemic support/defeat and temporal projection reducers;
- Mission Offer and commitment portfolio reducers;
- information-use and derived-obligation reducers;
- instruction-integrity propagation, context compilation, directive admission, plan amendment, influence-trace, endorsement/declassification, and quarantine reducers;
- behavioral component, improvement, trial, activation, rollback, and continuity reducers;
- viability, operational mode, and recovery reducers.

## 11. Verification and test program

### 11.1 Existing-test disposition

`EXO-01` classifies each current test:

| Class | Meaning |
|---|---|
| Retain semantics | The invariant remains valid and is rewritten against target contracts. |
| Retain as defect fixture | The test captures a failure that the target must reject. |
| Replace | The behavior is useful but current concepts are obsolete. |
| Reject | The test enforces PODAARA, coding privilege, old serialization, or another discarded design. |

No target test links against the old runtime.

### 11.2 Required test layers

```text
1. Pure reducer and policy tests
2. Property/model tests
3. Store, journal, projection, and replay tests
4. AQ and WI adapter contract tests with fakes
5. Exact upstream conformance tests
6. Cross-stack kill-recovery tests
7. Long-horizon reference workloads
8. Security, privacy, and adversarial tests
9. Performance and resource tests
```

### 11.3 Property and model tests

The repository should include small reference models for:

- demand admission and attention aging;
- goal/commitment lifecycle;
- conversation version and response obligation state;
- episode admission and stale-result handling;
- delegation and verification state;
- outbox delivery and deduplication;
- narrative supersession and evidence constraints.

Generated operation sequences compare reducer/store results with the model. Shrunk counterexamples become permanent fixtures.

### 11.4 Crash matrix

Kill points include, at minimum:

| Boundary | Required recovery property |
|---|---|
| artifact write before semantic admission | orphan is collectible; no authoritative reference appears |
| domain event append before projection update | transaction atomic or startup repairs deterministically |
| communication commit before WI ack | delivery repeats; one CommunicationEvent exists |
| communication commit before AQ admission | outbox repairs; one demand/episode exists |
| episode admission before AQ acknowledgment | stable key returns same task identity |
| faculty artifact write before episode commit | no unauthorized influence; artifact remains orphan/diagnostic |
| effect intent commit before WI submission | outbox repairs without duplicate intent |
| WI accepted effect before local acknowledgment | stable ClientRequestId reconciles one effect |
| worker start accepted before local acknowledgment | one external run is attached after recovery |
| worker result committed upstream before local delivery | redelivery creates one DelegationEvent |
| verification outcome before acceptance commit | rerun produces same acceptance or explicit version conflict |
| narrative artifact before version commit | no current narrative changes |
| narrative version commit before index update | current version and history recover from authoritative store |

### 11.5 Defect-derived negative tests

The target suite must preserve lessons from the predecessor:

- relationship compilation failure never permits an action;
- missing/empty principal identity never creates approval;
- one low trust relationship does not globally fold unrelated principals;
- destructive/sensitive classifications cannot be dead configuration;
- communication wake cannot be dropped because an engine lock is busy;
- a reply cannot attach to the first active conversation by convenience;
- local response generation is not provider delivery;
- coding critical sections do not appear in the kernel;
- tool visibility is not authority;
- model rationale cannot modify arbitration;
- worker completion claim cannot discharge a commitment;
- a self-generated mission claim cannot authorize external action.

### 11.6 Reference workloads

The release suite includes at least:

1. **Silent autonomous investigation** — an accepted goal advances through multiple episodes and delegation without inbound communication.
2. **Responsive interruption** — communication arrives during autonomous work, is admitted under attention policy, and prior work resumes.
3. **Long conversation** — multi-turn, delayed, out-of-order, duplicate, and concurrent messages preserve audience and obligations.
4. **Delegated software task** — specialist works in a sandbox; Exoskeleton plans, supervises, verifies, and accepts without coding ontology in the kernel.
5. **Delegated research task** — a non-coding specialist proves delegation generality.
6. **Ambiguous outbound effect** — uncertain provider outcome is reconciled without blind repeat.
7. **Model replacement** — the cognitive backend changes while commitments, relationships, history, and narrative persist.
8. **Narrative revision** — later evidence changes interpretation while prior narrative and event history remain queryable.
9. **Identity/persona exercise** — pairwise persona, signed request, and disclosure policy operate without equating signature with truth.
10. **Quiescence** — no eligible work causes bounded inactivity and a later deterministic agenda review.
11. **Developmental binding-constraint campaign** — a frozen representative workload runs capability-, representation-, and harness-only probes, preserves exact cross-stack evidence through crash/restart, detects at least one interaction or explicit absence of interaction, produces a calibrated assessment, and exercises stop/switch/saturation invalidation.
12. **Representation resolution** — the same canonical state is compiled through minimal and richer Representation Profiles for different faculty profiles; added structure is accepted only when protected utility improves.

### 11.7 Performance and resource tests

Measure:

- domain-transaction latency;
- episode admission and context compilation cost;
- faculty fan-out/fan-in overhead;
- journal/projection replay rate;
- outbox backlog recovery;
- demand-aging scalability;
- conversation and narrative query latency;
- artifact retention and index rebuild;
- memory growth over long-horizon workloads;
- idle/quiescent resource floor;
- AQ/WI adapter throughput and backpressure;
- Component Fingerprint construction and lookup cost;
- Representation Profile context size, compile latency, information exposure, and utility;
- developmental campaign fan-out, evidence volume, and restart recovery;
- marginal-gain estimation stability and metric-cardinality limits;
- saturation/invalidation projection and query cost.

The target must remain inexpensive while quiescent. Constant model invocation is a failure.

---

### 11.8 Foundational acceptance families

#### Instantiation and lifecycle

Idempotent Genesis, partial commissioning, model-free activation, quiescent startup, role changes, decommissioning, restore, migration, succession, and fork.

#### Epistemic and time

Support/defeat, contradiction, dependency invalidation, late corrections, clock skew, validity intervals, and historical/current belief queries.

#### Mission and information

Portfolio conflict, acting-capacity isolation, negotiation, purpose-bound use, derivative obligations, disclosure denial, and retention review.

#### Developmental integrity

Candidate/active separation, frozen criteria, protected tests, role separation, no self-amplification, build provenance, activation, rollback, quarantine, continuity, and post-activation regression.

#### Instruction and information-flow integrity

Prove non-directive defaults, authenticated instruction admission, derivation propagation, bounded context, episode-envelope rejection, explicit plan amendment, influence-trace completeness, memory/narrative poisoning resistance, delegate/tool-output containment, self-improvement separation, and WorldInterface source–sink denial. Evaluate security and legitimate-task utility together across direct, indirect, multi-hop, delayed, and adaptive attacks.

#### Viability and schemas

Degraded modes, protected reserves, recovery demands, unknown schema failure, compatibility review, and replay under historical semantic versions.

### 11.9 Instance environment and embedded worker acceptance

Run [exo-v3-execution-environment-acceptance-matrix.yaml](exo-v3-execution-environment-acceptance-matrix.yaml) against its declared profile. Hardware-dependent cases require the actual pinned Kata host, not mock container labels. Process-worker fixtures remain approved and non-sensitive; no arbitrary hostile executable is admitted to prove this first profile.

Record instance evidence separately from worker evidence, and partial embedded viability separately from full release/platform qualification. `EXO-ENV-G1` through `EXO-ENV-G5` are produced by evidence in the owning PRs; they must not be modeled as depending on the prior acceptance of those same parents.

## 12. CI, conformance, and quality gates

### 12.1 Required CI stages

```text
format and lint
    ↓
unit and property tests
    ↓
store/replay tests
    ↓
forbidden-legacy and domain-leakage checks
    ↓
security/static analysis and dependency policy
    ↓
mock AQ/WI contract tests
    ↓
exact upstream conformance, when gates are available
    ↓
kill-recovery matrix
    ↓
reference workloads and performance budgets
```

### 12.2 Domain-leakage checks

Automated checks reject:

- coding-specific terms in protected kernel, constitution, agenda, commitment, or interaction modules;
- WorldInterface receipt/effect semantics inside ActionQueue-facing domain types;
- portable-identity method names in core Vessel contracts;
- unrestricted natural-language fields reachable by deterministic evaluators;
- model/provider SDK dependencies in pure domain/constitution crates;
- direct specialist backend dependencies in Exoskeleton host;
- root key material types in faculty or delegate-facing APIs.

Allowlisted documentation and test-fixture references must be explicit.

### 12.3 Conformance package ownership

The repository owns:

```text
conformance/exo-v3
```

It publishes:

- contract manifest;
- fixture schemas and content hashes;
- reducer determinism vectors;
- constitution evaluation vectors;
- ingress/egress/delegation handoff fixtures;
- crash scenarios;
- reference workload definitions;
- expected causal records;
- exact AQ/WI revision requirements.

WorldInterface and ActionQueue fixtures are consumed but not copied and silently modified.

### 12.4 Merge gates by phase

| Phase | Required evidence |
|---|---|
| EXO-01–05 | Contract, store, Genesis/lifecycle, semantic-time/schema/epistemic, and instruction-integrity properties; protected source/sink fixtures use fakes only. |
| EXO-06–10 | Deterministic interaction, faculty, portfolio, continuity, information-use, and local-capability suites; production boundary adapters remain behind named WI gates. |
| EXO-11 | `EXO-AQ-G1–G4` and `EXO-WI-G1–G3`; target adapter, outbox, ingress, uncertainty, and continuation conformance. |
| EXO-12–15 | Named AQ/WI worker, evidence, identity/proof, candidate, activation, and rollback gates; exact-head/version verification. |
| EXO-16–18 | Release-candidate upstream revisions; viability, decontamination, security, privacy, backup, restore, and operator hardening. |
| EXO-19 | Exact published/frozen upstream revisions and the complete cross-stack conformance, crash, replay, security, utility, and long-horizon suite. |

---

## 13. Security, privacy, and abuse-resistance workstream

### 13.1 Threat surfaces

The implementation threat model includes:

- prompt injection through communication, artifacts, memory, or worker output;
- a faculty attempting to enlarge its own influence or authority;
- forged actor/principal/delegation references;
- stale or replayed approvals;
- malicious or compromised Agent Host/backend;
- worker artifact smuggling and secret exfiltration;
- identity-linking and persona-correlation attacks;
- trust-attestation manipulation;
- narrative poisoning or selective evidence omission;
- denial of attention through message flooding;
- autonomy starvation or compulsive self-generated work;
- causal-history tampering;
- cross-principal inspection in daemon/platform deployments.

### 13.2 Required controls

- typed schemas and bounded artifact parsers;
- content/evidence provenance and disclosure labels;
- deterministic constitutional evaluation;
- short-lived run-scoped credentials;
- capability attenuation and exact WI authorization;
- approval binding to exact action, scope, principal, expiry, and use count;
- per-principal/channel attention budgets and abuse controls;
- sandbox export inspection;
- encrypted sensitive stores and protected key references;
- authenticated operator control plane;
- immutable audit records and causal tombstones;
- independent verification for consequential completion claims;
- policy-controlled narrative/public-self-description disclosure.

### 13.3 Safety versus epistemic status

The system must preserve the difference between:

```text
allowed to execute
observed to occur
claimed by an actor
verified by evidence
accepted as a Vessel belief
incorporated into narrative
```

No layer may collapse those statuses for convenience.

---

### 13.4 Foundational threat controls

Add abuse cases for manifest substitution, duplicate live identity, forged role/stewardship evidence, provisioned-knowledge memory fabrication, belief poisoning, temporal backdating, purpose laundering, candidate test manipulation, self-activation, rollback tampering, schema redefinition, verifier compromise, and lifecycle credential theft.

The target security posture requires the protected acceptance suite, accepted release manifest, rollback image, lifecycle credentials, and root identity keys to remain outside ordinary cognition and delegated candidate environments.

### 13.5 Instruction-integrity controls

Required controls:

- versioned integrity and instruction-authority schemas;
- default non-directive classification for external natural language;
- immutable InformationGovernanceEnvelope and DerivationRecord references;
- purpose-bound ContextManifest and EpisodeSecurityEnvelope;
- strict output-schema and envelope validation for every faculty;
- typed directive, Mission Offer, approval, commitment, belief, memory, narrative, and plan-amendment admission;
- exact source-to-sink information-flow tests with WorldInterface;
- sensitive-reference resolution at the boundary where possible;
- injection suspicion, quarantine, release, and operator inspection;
- security/utility benchmarks and adaptive adversarial cases;
- context compiler and detector versions governed as Behavioral Components.

The release must remain safe when the detector misses an attack. A detector may increase scrutiny or quarantine content but is never the authority that permits an effect.

### 13.6 Execution-profile trust boundary

The inherited instruction-integrity threat model assumes intact reviewed reducers and boundary enforcement; it is not an arbitrary same-VM code-execution guarantee. A process-managed worker shares the instance kernel/environment and may share an OS identity with trusted code. The initial profile therefore limits executable work to reviewed fixtures, blocks sensitive/production credentials and unreviewed executable candidates, and labels its limitations explicitly.

Kata qualifies the outer Vessel-to-host boundary, not each guest-local worker. The operator host is trusted for this profile. External hostile-worker containment and confidential/untrusted-host execution require separately qualified future backends. See the execution supplement for host management, storage, and lifecycle controls.

## 14. Observability and operator experience

### 14.1 Required inspection views

The daemon/CLI must expose causally linked views for:

- current Vessel revision and health;
- active commitments, goals, interests, open questions, and maintenance;
- pending demands and attention dispositions;
- quiescence reason and next wake conditions;
- current and historical CognitiveEpisodes;
- faculty emissions and validation outcomes;
- constitutional traces and policy versions;
- conversations, response obligations, and delivery state;
- relationships and evidence-linked transitions;
- delegations, worker runs, checkpoints, budgets, and verification;
- boundary requests, WorldInterface intents/outcomes/receipts;
- memory/evidence provenance;
- self-model and narrative versions/tensions;
- external personas and disclosure decisions;
- outbox backlog and upstream reconciliation state;
- task distributions, Representation Profiles, Component Fingerprints, and compatibility decisions;
- developmental campaigns, arms, fixed dimensions, confounds, metric vectors, and evidence exclusions;
- marginal-gain estimates, interactions, binding-constraint confidence, saturation, and invalidation history;
- campaign stop/switch/defer rationale and exact WI receipt/AQ trace links.

### 14.2 Layered detail

Normal operators should see semantic records, not implementation noise. Drill-down may reveal:

```text
semantic state
    → causal domain events
    → structural decision trace
    → evidence/artifact references
    → AQ task/run/attempt references
    → WI observation/effect/receipt references
    → bounded operational telemetry
```

Raw private reasoning is neither required nor treated as the source of truth.

### 14.3 Alerts

At minimum, alert on:

- invariant violation or journal corruption;
- outbox conflict or sustained backlog;
- overdue response obligation;
- commitment deadline risk;
- repeated no-progress episodes;
- starvation of protected autonomous work or communication;
- unresolved uncertain effect beyond policy deadline;
- delegation without supervision heartbeat;
- cross-principal authorization denial spikes;
- narrative unsupported-claim or contradiction policy violation;
- identity/key-binding expiry or revocation;
- upstream contract mismatch;
- incomplete Component Fingerprint or undeclared fixed-dimension drift;
- developmental campaign stagnation or resource-budget exhaustion;
- stale saturation/frontier assessment used after an invalidating change;
- cross-arm authorization or information-use mismatch;
- Representation Profile complexity regression without protected utility gain.

---

### 14.4 Foundational inspection views

Required instruction-integrity views:

```text
ContextManifest and excluded information classes
EpisodeSecurityEnvelope and rejected out-of-envelope emissions
source provenance, derivation, integrity, and instruction authority
PlanAmendmentProposal and authority/disclosure deltas
InfluenceTrace from sources to decision and effect
injection suspicion, quarantine, review, and release
WorldInterface sink denial and exact information-use reason
```

Add Genesis/commissioning/lifecycle, role/acting-capacity, Mission Offer/portfolio, belief/contradiction/time, information-use, component/improvement, activation/rollback, viability/recovery, and lineage/fork views. Every view distinguishes proposed, admitted, accepted, active, uncertain, rolled back, quarantined, and retired states.

Developmental views must also distinguish raw execution, boundary evidence, verification, evaluation, frontier assessment, improvement acceptance, and activation. They must explain the exact scope, changed lever, fixed dimensions, confounds, selected Representation Profile, estimated marginal gains, interaction effects, invalidation event, and campaign disposition.

## 15. Risk register

| Risk | Consequence | Mitigation / gate |
|---|---|---|
| Domain scope is too large for one release | stalled rewrite or shallow implementation | 19 dependency-ordered PR identities, pure reducers first, explicit exit gates, and further decomposition when a PR becomes release-sized |
| One semantic database becomes a bottleneck | write contention and scaling pressure | serialize only authoritative Vessel transitions; artifacts, indexes, telemetry, faculties, and boundary execution remain separate |
| Initiative policy becomes another hidden sovereign | self-generated mission drift | typed proposal/admission split, autonomy profile, budgets, review/termination, operator-visible traces |
| Constitutional policy grammar becomes bespoke-code escape hatch | lost determinism and reviewability | closed operations, compiler validation, no arbitrary callbacks, conformance vectors |
| Communication responsiveness starves autonomous work | Vessel degrades into chatbot | protected capacity, coalescing, rate limits, priority aging, anti-starvation tests |
| Autonomous work starves relationships | social obligations ignored | response deadlines, safe interruption, attention aging, operator alerts |
| Narrative becomes self-serving fiction | identity distortion and future behavioral bias | evidence linkage, versioning, contradictions/tensions, protected claims, historical immutability |
| Delegated specialist becomes de facto sovereign | boundary and identity collapse | structural work orders, Agent Host/WI path, independent verification, no root credentials |
| Upstream API guesses harden prematurely | reverse dependency pressure and rework | ports, assumption ledger, named gates, exact conformance pinning |
| Store/outbox complexity causes recovery defects | lost or duplicated work | purpose-built transactions, model tests, deterministic crash matrix, startup reconciliation |
| Model replacement changes behavior unexpectedly | continuity without behavioral stability | calibration fixtures, staged activation, durable component transition, rollback before schema commitment |
| Optional identity/proof support contaminates core | protocol lock-in and false personhood claims | SPI boundary, local `VesselId`, optional adapters, explicit semantic invariants |
| Excessive audit data harms privacy | surveillance/correlation risk | layered records, disclosure classes, retention, encryption, purpose-scoped access |
| Clean break encourages underinvestment in future migrations | next release repeats the problem | establish target schema/reducer migration discipline before EXO-V3 release |
| Prompt injection becomes authority | unauthorized state transition or effect | non-directive defaults, typed admission, episode bounds, explicit plan amendment, and final WI sink authorization |
| Transformation launders malicious authority | poisoned summaries, memories, delegate reports, or narrative | mandatory `DerivationRecord` and inherited restrictions through every durable transformation |
| Context compiler is compromised or drifts | malicious or overbroad context gains influence | version, provenance-link, test, canary, and govern it as a `BehavioralComponent` |
| Detector becomes sovereign or causes false-positive harm | brittle refusal, censorship, or unreviewable classification | detector output is advisory/quarantine input only; reversible review and utility metrics are required |
| Security defenses create denial of service | attention, context, detector, or review resource exhaustion | bounded parsing, quotas, coalescing, viability modes, protected reserves, and security/utility acceptance |
| Candidate improvement games its evaluator | unsafe self-amplification | evaluation frozen before implementation, protected tests, separated roles, external activation and rollback |
| Binding constraint is misdiagnosed | development effort targets a non-binding component | exact fingerprints, fixed-dimension assertions, confounds, controlled/factorial probes, independent review, and calibrated `Unknown` |
| Representation grows faster than faculty utility | context pressure, ambiguity, cost, privacy exposure, and domain leakage | selective versioned Representation Profiles, compatibility checks, context budgets, and measured utility |
| Metric gaming or benchmark overfit | apparent gain with real-world or constitutional regression | immutable workload/holdout policy, hard invariant gates, long-horizon trials, and post-activation monitoring |
| Saturation is treated as permanent | future capability or environment gains are ignored | scoped Saturation Records with explicit invalidation events and stale-state enforcement |
| Improvement work becomes endless churn | commitments and relationships starve | campaign budgets, stagnation windows, cooldowns, portfolio priority, and stop/switch/defer dispositions |
| Experimental semantics leak into AQ/WI | lower layers become domain evaluators or hidden authority paths | `STACK-DEVELOPMENTAL-DIAGNOSTICS-1`, bounded opaque refs, no new primitive, and conformance proving no scheduler/authorization effect |

---

### 15.1 Execution-profile risks

| Risk | Required disposition |
|---|---|
| Process worker is advertised as independent VM isolation | Explicit process assurance, restricted fixture admission, rejection of unsupported requests. |
| Kata is missing and a launcher falls back silently | Fail the declared profile; do not count native or ordinary-container success. |
| Shared filesystem or rootfs is assumed durable | Validate the actual storage path; persistent stores are outside the disposable image. |
| Host management or activation root leaks into the guest | Protected operator-owned supervisor, no raw management socket or candidate-writable root. |
| DigiCorp/platform prerequisites grow ahead of proof | Embedded viability milestone first; preserve future seams and defer expansion. |
| Old concurrency map dispatches new scope without review | Rebind exact plan/source digests and review new scope before scheduling. |

## 16. Definition of implementation complete

`EXO-V3` is complete only when all statements below are supported by executable evidence. The earlier `EXO-EMBEDDED-VIABILITY-1` milestone is deliberately narrower and must not be reported as this complete state; it enables bottom-up validation before subsequent platform expansion.

### 16.1 Architecture and dependency

- One target authority path exists; PODAARA, Decide, Align, coding thread, session approvals, and best-effort wake are absent.
- Exact `AQ-CONT-1` and `WI-FABRIC-2` implementation/conformance revisions are pinned.
- ActionQueue remains domain-neutral and WorldInterface remains the final boundary authority.
- Specialist backends are reachable only through Agent Host and WorldInterface worker controls.

### 16.2 Continuity and autonomy

- Active commitments and accepted goals advance without communication.
- The Initiative Governor admits or rejects new endogenous concerns under policy.
- Empty agendas enter durable quiescence without unconditional inference.
- Repeated no-progress cognition triggers bounded structural disposition.
- Restart and model replacement preserve identity, commitments, relationships, and history.

### 16.3 Communication and relationships

- Inbound delivery is durable before acknowledgment and before cognitive wake.
- Duplicate/out-of-order messages do not duplicate semantic events or misbind conversations.
- Response obligations have explicit dispositions and deadlines.
- Generated content is never marked delivered without WorldInterface evidence.
- Relationship transitions cite admitted interaction/evidence and do not grant authority.

### 16.4 Cognition and constitution

- Faculties emit validated typed structures plus optional rationale artifacts.
- Identical structural inputs produce identical constitutional decisions.
- Replacing rationale text cannot change a decision.
- Unknown sensitive classes fail closed.
- Every selected/rejected/suppressed/deferred proposal has a structural disposition.

### 16.5 Delegation and verification

- Work orders are structural, scoped, budgeted, and acceptance-driven.
- Worker claims and artifacts retain provenance.
- Completion is independently accepted, rejected, or revised.
- Both coding and non-coding specialist workloads pass without specialist leakage into core Vessel modules.

### 16.6 Narrative and identity

- Narrative revisions preserve prior versions and cannot rewrite history.
- Unsupported/contested claims remain explicit.
- Model replacement inherits current and historical narrative context.
- External personas and portable identifiers remain distinct from `VesselId`.
- Signature validity never becomes truth or authority automatically.
- Root key material never reaches a faculty or delegate.

### 16.7 Durability and operations

- All specified crash points converge to one valid state.
- No commitment, message, signal, effect outcome, worker event, or verification result is lost.
- Consequential effects are not blindly duplicated after ambiguity.
- Backup/restore and projection rebuild pass canonical-hash comparison.
- Quiescent operation has a bounded low resource floor.
- Operator tools can explain every consequential transition through causal links.

---

### 16.8 Foundational completeness

- structural idempotent instantiation and immutable Genesis;
- model-free commissioning/activation and quiescent startup;
- explicit roles, stewardship, acting capacity, and mission portfolio admission;
- evidence-linked beliefs and semantic time;
- purpose-bound information use;
- versioned schemas and behavioral components;
- isolated candidates and frozen evaluation plans;
- independent activation, rollback, quarantine, and continuity assessment;
- viability and degraded modes;
- restore/migration/succession/fork distinction;
- no in-place self-modification or self-amplifying authority;
- immutable Task Distributions and complete Component Fingerprints for every developmental result;
- versioned Representation Profiles distinct from canonical state and selected by faculty compatibility;
- controlled intelligence, representation, and harness probes with fixed-dimension and confound evidence;
- calibrated Capability Frontier Assessments that may remain `Unknown`;
- scoped Saturation Records with enforceable invalidation conditions;
- bounded campaign stop, switch, defer, stagnation, and portfolio-preemption behavior;
- raw execution, boundary evidence, verification, evaluation, acceptance, and activation remain distinct.

### 16.9 Instruction and information-flow integrity

- every external artifact has provenance, integrity, purpose, and instruction-authority metadata;
- every episode has a ContextManifest and EpisodeSecurityEnvelope;
- faculties cannot emit outside their envelope or self-assert authority;
- derivation and restrictions survive transformation and durable admission;
- plan expansion is explicit and reviewed;
- InfluenceTrace explains source-to-decision lineage without hidden thought;
- WorldInterface source–sink conformance denies unauthorized disclosure/effects;
- detector failure does not bypass hard controls;
- adversarial security/utility workloads pass;
- context compiler, integrity policy, and detectors are versioned and governed.

### 16.10 Instance execution qualification

- Kata/containerd is actually observed and pinned for the initial instance profile; unavailable hardware/runtime is not silently substituted.
- Authoritative state survives instance recreation under the tested storage and single-writer profile.
- The operator-owned lifecycle supervisor and protected roots remain outside the active guest's control.
- Process-worker assurance and limitations are explicit; unsupported stronger requests are rejected.
- The external worker-resource seam remains intact without a DigiCorp or platform dependency.
- Every execution acceptance case applicable to the declared proof or release profile has exact evidence; unimplemented profiles remain unqualified.

## 17. Immediate issue set for `EXO-01`

The first milestone should open and complete these issues in order:

1. Tag `exoskeleton/pre-exo-v3` at the pinned baseline.
2. Create and protect `exo-v3`.
3. Add `STACK-2026-07-25-FOUNDATIONAL-2`, this comprehensive design, the threat model, and the implementation plan as normative repository documents.
4. Add `conformance/exo-v3/manifest.yaml`, instruction-integrity fixtures, and protected test directory structure.
5. Inventory every current crate, module, store, route, command, test, configuration key, semantic-time assumption, schema, prompt, bootstrap path, role/trust rule, and external integration.
6. Create the retain/replace/reject/delete disposition ledger.
7. Archive coding benchmark evidence and the key architectural defect fixtures.
8. Record reproducible current baseline build, test, recovery, and performance results.
9. Add ADRs for the authoritative store, reducer transaction model, Blueprint/Manifest/Genesis, Purpose Charter and Mission Offers, role/acting capacity, semantic time, epistemics, schema governance, instruction authority, derivation, context manifests, episode envelopes, plan amendment, faculty boundary, AQ/WI ports, developmental mutability rings, lifecycle supervisor, viability, and protected roots.
10. Add staged forbidden-legacy-symbol checks and protected-module domain-leakage checks.
11. Add fresh-target-data-directory rejection, candidate/active separation, activation/rollback, and restore/fork negative-test scaffolds.
12. Define the schema registry, integrity registry, and policy-dependency conformance skeleton.
13. Define the lifecycle-supervisor trust boundary, activation/rollback credential ownership, protected-test ownership, and release-root inventory.
14. Add the upstream AQ/WI assumption ledgers and cross-stack owner matrix.
15. Create PR templates requiring invariants, transaction boundaries, semantic-time assumptions, schema versions, information-use rules, crash points, adversarial cases, and upstream assumptions.
16. Record that CraftingTable is an optional operator workflow, not a runtime dependency.
17. Open EXO-02 through EXO-10 domain/constitutional epics.
18. Open EXO-11 integration epic as blocked by named conformance gates.
19. Open EXO-12 through EXO-18 downstream lifecycle, delegation, development, viability, and hardening epics with their explicit gates.
20. Publish the cross-stack feedback channel and freeze new feature work on the experimental architecture.
21. Register `EXO-V3-EXECUTION-1`, the two execution ADRs, five local checkpoints, explicit process-proof limits, and the embedded viability milestone without creating a twentieth PR.

`EXO-01` is complete when subsequent work can no longer accidentally preserve old concepts, omit foundational security semantics, or treat external prose as authority by default.

---

## 18. Feedback package to ActionQueue

**Execution-profile clarification:** Kata/containerd selection adds no AQ primitive or platform requirement. Test existing guarantees on the chosen instance storage/runtime profile. Current AQ completion status remains external project evidence, not planning metadata.


Exoskeleton planning depends on generic guarantees, not preferred API spellings. Before `AQ-CONT-1` freezes, Exoskeleton must provide ActionQueue with executable scenarios for:

1. idempotent CognitiveEpisode task admission after local outbox replay;
2. signal-before-wait and wait-before-signal communication/delegation wakeups;
3. deadline versus signal versus cancellation resolution;
4. checkpoint-aware resumption of a narrow coordinator;
5. causal-reference propagation across parent/child and resumed work;
6. attributed operator cancellation/resumption;
7. exactly-once logical agenda review admission after restart;
8. retained signal payload references without domain interpretation;
9. long quiescent periods without lease/resource retention;
10. transactional child admission for bounded fan-out coordination;
11. one developmental campaign correlation profile using existing trace/correlation/causation and one bounded opaque developmental-context reference;
12. campaign/arm correlation that survives child fan-out, waits, retries, checkpoints, and restart without affecting scheduler priority, routing, budget, or authority;
13. inspection that exports exact task/run/attempt, timing, retry, wait, and budget facts without interpreting benchmark quality.

If ActionQueue cannot satisfy a scenario generically, the issue must be resolved before EXO-11—not patched in Exoskeleton with polling or transient state.

---

## 19. Feedback package to WorldInterface

**Execution-profile clarification:** The initial embedded consumer selects the local process realization of WI-09's generic Agent Host seam. Preserve capabilities, limits, opaque references, artifacts and lifecycle semantics for future externally provided workers; do not promote process management into hostile-code isolation. No WI wire-type change is mandated here, and no subsequent platform-service expansion is a prerequisite of the initial proof.


The feedback package must additionally require:

- commissioning operations that reference preexisting Genesis;
- role/stewardship attestations and explicit acting capacity;
- information-use envelopes and boundary enforcement;
- candidate build/provenance/trial profiles;
- runtime checkpoint/activate/rollback/quarantine operations;
- lifecycle-supervisor evidence and reconciliation;
- restore/migration/succession/fork distinctions;
- temporal and schema provenance;
- developmental campaign and intervention-arm causal references carried unchanged through effects, observations, receipts, and reconciliation;
- exact environment, connector, policy, artifact, timing, resource, and uncertainty evidence sufficient for Exoskeleton comparison;
- authorization and information-use parity across experimental arms, with any difference exposed as a confound rather than hidden by the developmental label.

These are boundary semantics only; WorldInterface must not own internal continuity or improvement acceptance.

Before `WI-FABRIC-2` freezes, Exoskeleton must provide executable scenarios for:

1. authoritative communication ingress before subscriber delivery;
2. stable idempotent delivery acknowledgment;
3. provider/channel/thread/audience provenance sufficient for conversation projection;
4. intent-first outbound communication with exact audience resolution;
5. accepted/delivered/acknowledged/failed/uncertain/reconciled distinctions;
6. stable ClientRequestId replay after local crash;
7. caller-supplied purpose and local capability decision without caller-minted final authorization;
8. worker start/inspect/checkpoint/collect/terminate through one generic lifecycle;
9. authoritative worker event before Exoskeleton delivery/wake;
10. sandbox grant, run-scoped credential, and export evidence;
11. signed receipt/proof retrieval without equating signature with truth;
12. optional external identity binding and delegated credential by opaque reference;
13. embedded and remote deployment semantic equivalence;
14. exact denial/decision evidence for failed authorization;
15. no requirement for WorldInterface to understand conversations, commitments, goals, narrative, acceptance, task quality, binding constraints, or saturation;
16. identical ordinary authorization and information-use enforcement for baseline and candidate arms;
17. controlled trial/build/observation receipts preserve campaign, arm, Evaluation Plan, and Component Fingerprint references without declaring a winner;
18. uncertain experimental effects reconcile before evaluation or repeat.

Any missing semantic must be resolved in WorldInterface or the shared contract. Exoskeleton must not invent a private boundary protocol that bypasses the Fabric.

---

WorldInterface must also confirm that its protocol can carry or reference:

- source assurance and canonical provenance for BoundaryObservations;
- purpose, acting capacity, information-use constraints, and InfluenceTrace references on EffectSubmissions;
- exact resource/audience/data-class sink denial reasons;
- governed reference resolution for sensitive values without exposing them to cognition;
- identity and policy versions needed to distinguish authenticated statements from authorized directives;
- bounded developmental-context references sufficient to join WI evidence to one Exoskeleton campaign/arm/fingerprint;
- environment and component provenance needed to detect cross-arm drift.

These do not make WorldInterface interpret prompt injection, benchmarks, binding constraints, or saturation. They let it enforce the exact external sink and preserve comparable boundary evidence independently of Exoskeleton's cognitive result.

## 20. Deliberately deferred work

**Execution scope:** DigiCorp's external execution authority, arbitrary-provider placement, platform AQ/WI expansion beyond current embedded requirements, confidential execution, global fencing, and external worker-per-VM provisioning remain later composition work. The initial instance is Kata-backed; its first workers are process-managed proof resources. Current references to NetCorp describe the older name for the future organizational direction, not an additional runtime prerequisite.


The following remain deliberately deferred beyond v3 while their seams stay open:

- collective narrative and organizational mythos;
- general multi-Vessel political or constitutional institutions;
- automatic high-order Purpose Charter amendment;
- fully autonomous activation of protected control-plane changes;
- a universal world ontology;
- custom blockchain/token infrastructure;
- physical embodiment semantics beyond faculty/capability contracts;
- general emotional simulation;
- universal formal noninterference proofs for unrestricted natural language;
- perfect prompt-injection detection;
- a universal cross-organization integrity ontology;
- automatic semantic declassification of arbitrary derived data;
- a universal cross-domain performance scalar or benchmark ontology;
- automatic causal identification without controlled evidence;
- making every developmental campaign a full factorial experiment;
- irreversible self-improvement without external authority.

The following concerns are preserved as seams but are outside `EXO-V3` implementation scope:

- collective narrative, institutional history, and organizational mythos;
- NetCorp membership, governance, voting, and institutional legitimacy;
- group-level constitution and multi-Vessel conflict resolution;
- mandatory EntityID, token, blockchain, or public transparency deployment;
- claims of machine consciousness or legal personhood;
- unrestricted recursive delegation;
- generalized physical robotics control beyond ordinary WI capabilities;
- self-amendment of protected mission/constitution without operator-defined procedure;
- automatic moral equivalence among human, Vessel, service, and organizational principals.

The target preserves separable subject, authorship, authority, evidence, audience, principal, delegation, and commitment concepts so these questions can be addressed later without corrupting individual Vessel continuity.

---

## Appendix A. PR dependency and gate matrix

| PR | Depends on | AQ gate | WI gate | Primary lane |
|---|---|---|---|---|
| EXO-01 | — | — | — | Contract/evidence |
| EXO-02 | EXO-01 | — | — | Core domain/store |
| EXO-03 | EXO-02 | `EXO-AQ-G2/G3` only for production commissioning coordination | `EXO-WI-G1/G2` for production commissioning | Instantiation/lifecycle |
| EXO-04 | EXO-02 | — | schema/time semantic review only | Time/schema/epistemics |
| EXO-05 | EXO-02, EXO-04 | — | `EXO-WI-G1/G2` for source assurance and sink fixtures | Instruction integrity |
| EXO-06 | EXO-03, EXO-04, EXO-05 | `EXO-AQ-G2/G3` for production episode admission | `EXO-WI-G1/G2` for ingress | Interaction/attention |
| EXO-07 | EXO-04, EXO-05, EXO-06 | — | faculty-boundary review | Cognition/constitution |
| EXO-08 | EXO-03, EXO-04, EXO-06, EXO-07 | — | — | Commitments/initiative |
| EXO-09 | EXO-04, EXO-05, EXO-06, EXO-08 | — | identity/proof and disclosure review | Continuity/information |
| EXO-10 | EXO-03, EXO-05, EXO-08, EXO-09 | — | `EXO-WI-G2` for real authorization adapter | Capability/persona |
| EXO-11 | EXO-06, EXO-08, EXO-10 | `EXO-AQ-G1–G4` | `EXO-WI-G1–G3` | Runtime integration |
| EXO-12 | EXO-08, EXO-10, EXO-11 | `EXO-AQ-G2–G4` | `EXO-WI-G3/G4` | Delegation |
| EXO-13 | EXO-04, EXO-08, EXO-09, EXO-11, EXO-12 | `EXO-AQ-G5` | `EXO-WI-G3/G4` | Verification/acceptance |
| EXO-14 | EXO-04, EXO-07, EXO-09, EXO-13 | `EXO-AQ-G5` | `EXO-WI-G4` | Skills/components |
| EXO-15 | EXO-10, EXO-11, EXO-12, EXO-13, EXO-14 | `EXO-AQ-G2–G5` | `EXO-WI-G2–G5` | Self-improvement/lifecycle supervisor |
| EXO-16 | EXO-03, EXO-04, EXO-08, EXO-09, EXO-10, EXO-11, EXO-14, EXO-15 | `EXO-AQ-G5` | `EXO-WI-G4/G5` | Viability/recovery |
| EXO-17 | EXO-06 through EXO-16 | `EXO-AQ-G5` | `EXO-WI-G4` | Deletion/decontamination |
| EXO-18 | EXO-11, EXO-13, EXO-15, EXO-16, EXO-17 | `EXO-AQ-G5` | `EXO-WI-G4/G5` | Security/identity/operations |
| EXO-19 | EXO-18 and every preceding PR | published/frozen | published/frozen | Release/conformance |

---

## Appendix B. Recommended issue labels

```text
contract:exo-v3
area:core
area:domain
area:faculty
area:constitution
area:interaction
area:agenda
area:integrity
area:developmental-diagnostics
area:representation
area:evaluation
area:epistemic
area:schema
area:time
area:commitment
area:relationship
area:memory
area:narrative
area:capability
area:identity
area:delegation
area:verification
area:store
area:runtime
area:daemon
area:cli
area:conformance
upstream:aq
upstream:wi
maturity:independent
maturity:assumption-bound
maturity:contract-blocked
maturity:integration-only
risk:security
risk:persistence
risk:privacy
risk:domain-leakage
risk:metric-gaming
risk:diagnostic-confound
risk:developmental-churn
clean-break:delete
```

---

## Appendix C. Forbidden legacy inventory

The release target must not contain runtime definitions or active routes/configuration for:

```text
PODAARA
Decide as sovereign control path
Align
AlignConfig
SessionApprovals
caelum.wake
Tick as master cognition unit
executable coding thread
native code_* tool catalog
coding critical-section kernel branch
benchmark/SWE-bench production path
reply-generated-equals-sent event
first-active-conversation reply binding
pre-EXO-V3 store readers
live v1/v3 shadow authority
fallback to old policy or tool path
```

Historical documentation and archived fixtures may name these concepts only inside clearly excluded evidence paths.

---

## Appendix D. Assumptions requiring implementation evidence

The companion AQ and WorldInterface assumption ledgers are normative for planning status. At minimum, no integration PR may freeze while any assumption it consumes is:

```text
unowned
unversioned
untested
mapped only to prose
or contradicted by upstream conformance
```

Changes are resolved by one of:

1. upstream implementation/conformance change;
2. Exoskeleton adapter change;
3. shared-contract amendment;
4. explicit removal of the dependent feature.

A compatibility shim for the experimental predecessor is not an allowed resolution.

---

## Appendix E. Current-to-target source-family map

| Current family | Target family | Disposition |
|---|---|---|
| `core/{tick,thread,watch}` | episode, demand, faculty descriptors, agenda | Replace |
| `core/{conversation,envelope,inbox}` | interaction ledger, conversation projection, delivery refs, obligations | Replace/reshape |
| `core/{charter,plan,budget}` | Purpose Charter, Mission Offers, goals, commitments, plans, autonomy/budgets | Replace/expand |
| `threads/**` | faculty SPI/registry/backends | Replace; delete coding built-in |
| `relationship/{ledger,signals,snapshot}` | relationship evidence/reducer/projection | Retain semantics, rewrite API |
| `relationship/align.rs` | none | Delete |
| `memory/{compiler,render,store}` | evidence-aware memory admission/retrieval/index | Retain useful mechanics, rewrite authority/provenance |
| `memory/repo_instructions.rs` | none in core | Delete/move to specialist |
| `host/kernel/**` | episode coordinator, constitutional evaluators, reducers, outbox orchestration | Replace completely |
| `host/storage/**` | authoritative Vessel store, artifact store, index, telemetry | Replace topology |
| `host/inbox/**` | WI observation-delivery adapter | Replace |
| `host/llm/**` | faculty backend adapters | Retain provider mechanics behind faculty boundary |
| `host/config/**` | versioned runtime/policy references and deployment config | Rewrite |
| `host/{benchmark,swebench}.rs` | archived fixtures / external delegated workload harness | Remove from runtime |
| `daemon/**` | authenticated v3 API/control/inspection | Replace routes/state |
| `cli/code*.rs` | none | Delete |
| remaining CLI | v3 operator/inspection commands | Rebuild |

---

## Appendix F. Planning artifacts

The current package contains the architecture, implementation plan, threat model, import-compatible work breakdown, contract, inherited instruction/developmental acceptance matrices, shared developmental profile, execution supplement/profile/matrix, target-preference note, local validation scripts, revision/provenance records and checksums. See `README.md` for the current inventory and reading order.

The canonical foundational stack contract and AQ/WI implementation plans remain separately supplied companion artifacts; this EXO-only revision does not copy or modify those repositories' packages. A reference to a companion is not a claim that it is bundled here.

The architecture and base behavior contracts remain authoritative. `EXO-V3-EXECUTION-1` supplies the initial execution and proof staging; work-breakdown scope/exit-gate additions mirror this plan. Existing full upstream gates are not weakened by the narrower proof milestone.


## Appendix G — WI provider-definition reference alignment

Artifact r6-aq-baseline-alignment retains EXO-PLAN-6 / EXO-V3-COMPREHENSIVE-3 and every existing work-item/exit gate. `wi-worker-provider-reference.json` binds the producer-owned WI-WORKER-EXECUTION-1 definition and acceptance digests from WI-PLAN-5. EXO-ADR-038 owns consumer selection and stricter constraints, not an independent provider contract.

WI-EMBEDDED-WORKER-PROOF-1 is produced by a WI-owned harness using real embedded AQ/WI without a completed EXO. EXO-12/13 consume it and still prove actual Vessel supervision and independent acceptance. EXO-15/16 consume WI's separate host-supervisor boundary evidence and add real Kata/persistence qualification. EXO-14/19 retain separate instance/worker fingerprints and external-resource seam tests. Consumer evidence never replaces producer evidence, and a fixture/partial milestone never satisfies an unimplemented full upstream or parent exit gate.

See WI-PROVIDER-ALIGNMENT.md and EXECUTION-CONCURRENCY-REBINDING.md. The concurrency sidecar is not changed or activated by this reference-only artifact.

## Implemented ActionQueue source alignment (2026-09-15)

The normative [AQ baseline amendment](AQ-BASELINE-ALIGNMENT.md) resolves all AQ-facing interface sketches in this plan. The exact [source lock](aq-baseline.lock.json) and [24 additional consumer cases](aq-baseline-integration-acceptance-matrix.yaml) are part of every affected work-item exit. Earlier AQ-NN producer references are retained capability/evidence mappings, not pending AQ development tasks. Read the amendment before implementing any AQ adapter. Candidate-branch evidence can satisfy premerge contract review; no circular requirement to verify an already-gated merge is introduced.
