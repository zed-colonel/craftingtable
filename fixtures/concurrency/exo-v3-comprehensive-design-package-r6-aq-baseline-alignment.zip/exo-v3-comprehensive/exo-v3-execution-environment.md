# EXO-V3 instance execution and worker-provider profile

**Profile:** EXO-V3-EXECUTION-1  
**Parent:** EXO-V3-COMPREHENSIVE-3 / EXO-PLAN-6  
**Date:** September 12, 2026  
**Status:** Normative planning supplement; implementation and runtime qualification pending  
**Companion reference alignment:** `r6-aq-baseline-alignment`; provider definition owned by `WI-WORKER-EXECUTION-1`

## 1. Scope and precedence

This supplement chooses **Kata Containers with containerd for the Vessel instance's initial qualified execution environment**, and **process-managed workers through embedded WorldInterface** for the initial delegation proof. It does not create DigiCorp, platform AQ/WI, a new scheduler, a new Vessel plane, or a new public WI protocol.

It is authoritative for initial execution-profile selection, its assurance limits, and its proof milestone. It supplements rather than replaces the constitutional architecture and existing upstream behavior contracts. Where older text discusses centralized Platform/NetCorp capabilities, those remain future or separately qualified profiles, not hidden dependencies of the initial embedded viability milestone.

The original full parent-PR exit gates and G1–G5 definitions retain their meanings. This revision appends execution-profile obligations; it does not pretend that a narrow proof passes a broader release gate. An operator-visible capability that is not implemented stays unavailable. A legitimate reduction of full-release scope would require a separately reviewed release-plan amendment.

The machine-readable definitions are [the execution profile](exo-v3-execution-profile.yaml) and [the acceptance matrix](exo-v3-execution-environment-acceptance-matrix.yaml). They are planning documents, not deployment manifests and not additional pull-request lists.

## 2. The two boundaries

### 2.1 Instance boundary

The initial outer boundary is one dedicated Kata sandbox/VM for one Vessel runtime instance. The host-side containerd/Kata stack remains controlled by the operator. Exoskeleton runs as a workload inside that boundary; it does not embed containerd or implement a Kata shim.

The initial composition contains the Vessel runtime and stores, Vessel AQ, embedded WI, WI AQ, and a local Agent Host adapter. A dedicated VM is required per independent Vessel, not per internal Rust crate. Native unit tests and controlled non-Kata fixtures remain useful but cannot satisfy the instance qualification.

The operator/host is trusted for this initial profile. Confidential computing, protection against the host administrator, multi-provider tenancy, hardware attestation and arbitrary-host placement are not claimed.

### 2.2 Worker boundary

The first worker backend launches approved worker processes through WI and an Agent Host adapter. These processes normally share the Vessel's outer Kata VM. They have separate process lifecycles and protocol identities, but **do not have independent worker VMs**.

`process-managed-proof-1` means bounded functional process management for reviewed fixtures and non-sensitive data. It does not mean that a compromised worker binary cannot access every resource visible to its OS identity. A process boundary, sanitized environment, or separate working directory is not a substitute for a hostile-code sandbox.

The initial policy prohibits arbitrary unreviewed executable code, production credentials, sensitive production data, and running newly generated executable candidates beside the active Vessel. Structural malicious-content tests remain permitted without executing hostile binaries. Strong-isolation work remains blocked until an appropriate backend is implemented and qualified.

The intended progression is to externally provided worker resources. Physical co-location is a first implementation choice, not work-order semantics or a promised permanent containment model.

## 3. Ownership and minimal external control

| Responsibility | Initial owner | Must not become |
|---|---|---|
| Identity, intent, delegation supervision, continuity, acceptance | Exoskeleton | Host runtime or provider-specific semantics |
| Final authorized boundary requests, worker lifecycle evidence, artifacts | Embedded WI through existing seams | A general cluster orchestrator or specialist evaluator |
| Durable task/wait/signal/checkpoint causality | Two logical AQ domains | A VM scheduler or distributed platform by implication |
| Worker backend mechanics | Local Agent Host adapter behind WI | A direct faculty-to-process escape hatch |
| VM/container lifecycle, launch configuration, protected backups | Operator-owned host supervisor/tooling | Credentials or engine sockets held by the active Vessel |
| Organization-wide placement and execution policy | Future DigiCorp composition | A dependency of the present proof |

The supervisor may be a small single-host service with reviewed operator commands. It needs bounded start/inspect/stop/recreate/approved-replacement operations for the assigned Vessel, authorization for each operation, auditable results, and a recovery path when the guest is dead. It does not need a cloud-provider abstraction or an autonomous fleet manager.

Where EXO-15 tests automated lifecycle transitions, the embedded WI lifecycle adapter calls a narrowly authenticated host-supervisor interface. Stop/restart results must remain queryable outside the dying guest and be imported/reconciled after recovery. The candidate never controls the only acceptance suite, rollback artifact, activation credential, or audit trail. Operator-initiated recovery must not depend on the failed Vessel making a request.

The running workload receives no containerd, Docker, Podman, hypervisor or Kata-agent control socket and no host `/dev/kvm`. A containerd namespace is bookkeeping, not authorization. The public provisioning interface must not accept arbitrary engine flags, mounts, devices or host paths from model output.

## 4. Deployment qualification contract

Before acceptance of the deployed profile, `EXO-ADR-037` must bind one tested combination of host OS/kernel/architecture, hardware virtualization, containerd, Kata, selected hypervisor, guest kernel/image, snapshotter/storage transport, network configuration, and workload image.

Kata's documented containerd integration uses the `io.containerd.kata.v2` runtime identifier. Runtime selection and configuration resolution differ between direct containerd clients and CRI; the implementation must test the path actually used. Do not assume that setting a CRI runtime stanza changes a direct `ctr` invocation. [S2][S4]

No runnable command or production configuration is fabricated by this package: the target EXO CLI, image entrypoint, approved host, and tested version pair do not yet exist as qualified outputs here. Implementation must provide the launcher/runbook and attach actual evidence.

Required profile properties:

- Explicit Kata selection and a refusal to silently fall back to ordinary containers or native processes.
- Host-side evidence identifying the actual runtime, sandbox/VM and image/configuration digests. A guest assertion is not sufficient.
- Non-root application execution with explicit data paths, minimal capabilities, no privileged workload, and no unnecessary devices or host namespaces.
- Explicit instance-level network allowlist, limits, log handling, secret injection, and management access restrictions outside model control.
- A deployment manifest linking enduring Vessel identity, runtime-instance identity, opaque environment reference, approved release, and actual host/runtime provenance.
- One active writer of the Vessel and embedded WI/AQ state. Local locking and host supervision are sufficient for this single-host proof; distributed migration/fencing is not claimed.
- A reproducible cold-start, graceful-stop, force-stop, recreate, backup/restore and compatible-rollback procedure.

Kata configuration and defaults are not evidence of a tested workload policy. Unsupported required limits or storage properties block qualification. Host administration may require privilege; this profile does not make an untested rootless-Kata promise.

## 5. Durable state is not the VM's memory

Maintain one authoritative Vessel database and its outboxes, the required embedded WI stores/outboxes, two logical AQ persistence domains, and immutable artifact storage. Names and physical layouts are implementation choices provided ownership and atomicity remain explicit.

Persist authoritative data on a deliberately configured path outside the disposable workload rootfs. Test the selected Kata mount/snapshotter/filesystem path against the actual store guarantees: locking, atomic replacement, fsync, crash recovery, hash verification, and artifact publication. Shared filesystem convenience must not erase queue/WI/Vessel durability requirements. [S5]

A backup is a quiesced or otherwise correctly coordinated application-state backup, not a casual file copy of live databases and WALs. A restore verifies schema compatibility and evidence, excludes the prior writer, restores the coherent set, reconciles outstanding work, and only then resumes admission. Retain a known-good image and separately protected backup access.

A runtime-instance restart does not rerun Genesis. An image rollback cannot open an incompatible schema merely because the old binary starts. A VM snapshot is not a second authorized Vessel and does not restore expired authority by default.

Long-horizon semantics remain in AQ/WI/Exoskeleton. The host supervisor restarts processes/VMs; it must not implement a competing application retry policy.

## 6. Consumption of the WI-owned local worker profile

`WI-ADR-016` owns the first process provider definition and its qualification. `EXO-ADR-038` binds this consumer to the exact `WI-WORKER-EXECUTION-1` definition in [the provider reference](wi-worker-provider-reference.json). Local execution does not bypass WI final authorization. The requirements below are retained consumer obligations and a summary, not a second independently editable provider definition; EXO may tighten but never weaken the pinned profile. Definition mismatch blocks admission pending review.

The WI-owned adapter must supply the following behavior, which EXO must consume and test without directly spawning or manipulating provider processes:

1. A typed start/control/event protocol with stable work/run references. Local PIDs and paths remain adapter state, not required domain identifiers.
2. Reviewed executable selection and argument construction, sanitized environment, closed sensitive descriptors, a per-run workspace, and explicit artifact paths.
3. Run-scoped credentials only where needed; no deliberate inheritance of Vessel root, host supervisor, deployment or organizational credentials.
4. Bounded stdout/stderr, wall time, process-tree termination and cleanup. Other advertised limits require actual enforcement evidence. Network restrictions are not inferred from a working-directory policy.
5. Durable lifecycle intent and a run registry that can reconcile process creation/exit with records after interruption. PID reuse must not cause adoption or termination of an unrelated process.
6. Authoritative WI events committed before AQ wake, with duplicate/late/reordered delivery handling and bounded cancellation escalation.
7. Scoped artifact export/import, validation and quarantine, followed by Exoskeleton-owned verification and acceptance.
8. Explicit declaration of supported checkpoint, suspend and resume semantics. Application-artifact resume is not process-memory restore; an unsupported operation returns unavailable rather than a pretend success.

A crash between process creation and durable acknowledgement can leave ambiguity. The first backend must reconcile liveness using validated ownership, or conservatively stop/quarantine before replacement; it must not solve the ambiguity with fire-and-forget launch or unconditional duplicate spawn. Only controlled fixture work is admitted while this behavior is proved.

The supplied process assurance limits the execution of code, not the adversarial nature of text inputs. Faculties and verifier fixtures may receive malicious text while structural authority remains enforced. Arbitrary executable candidate trials require a stronger future worker profile; a safe fixture trial does not certify them.

## 7. External workers remain resources, not a new Vessel subsystem

A future provider must be able to realize the same bounded work through an independent VM, another host, or a platform-managed environment without changing what a delegation or commitment means.

Preserve requirements/assurance selection, opaque provider and worker references, asynchronous events, artifact references, run-scoped authority, cancellation, and independent acceptance. Never assume that a local file path is a portable artifact or that a child delegation implies nested containers.

Capability negotiation must distinguish requested controls, advertised controls, enforced controls, and observed evidence. If independent isolation is requested, `process-managed-proof-1` is not eligible. An external backend is a new qualified implementation, not a renamed local adapter. A simulated remote fixture proves only the consumer seam.

WI-PLAN-5 now owns `WI-WORKER-EXECUTION-1` and `WI-EMBEDDED-WORKER-PROOF-1`. A WI-owned test consumer establishes producer proof with real AQ/WI and without an EXO binary. EXO selects the process realization and adds consumer supervision, acceptance and instance qualification. Any field-mapping or protocol gap is resolved under WI-ADR-016 before freeze; this reference alignment invents no wire type or AQ primitive.

## 8. The embedded viability milestone and the broader plan

`EXO-EMBEDDED-VIABILITY-1` is an evidence milestone assembled from the relevant embedded portions of EXO-03, EXO-11, EXO-12, EXO-13, EXO-14, EXO-15, EXO-16, EXO-18 and EXO-19. It is not a twentieth PR.

It demonstrates one reviewed coding fixture and one non-coding fixture through a running Vessel on Kata, real embedded WI/AQ, process-worker supervision, independent acceptance, and restart/recovery. It records costs, latency, limitations and unresolved risks. Lifecycle tests use reviewed fixtures and compatible images rather than arbitrary generated executables.

It does **not** require platform AQ/WI, DigiCorp, external worker provisioning, Kubernetes, a distributed registry, or confidential computing. Pure code and fixtures can be developed without hardware; actual instance qualification requires a suitable host.

The full work-item dependency lists are retained. A parent that contains broader daemon/platform or stronger security obligations remains open until those obligations are proved. An implementation tracker may explicitly decompose the embedded proof work, as the existing plan permits, without labeling the entire parent complete. The earlier hash-bound concurrency draft must be revised/rebound before it schedules this new source version.

This is intentional staging: do enough to learn whether Exoskeleton works before broadening the platform. It is not a weakening of the future claims or a silent release waiver. If the eventual first published release is to support only the embedded profile, approve that release-scope change separately and publish its exact supported profile list.

## 9. Checkpoints and PR allocation

The five `EXO-ENV-G*` checkpoints are local evidence barriers. They do not add upstream dependency edges. Evidence can be produced in an owning PR before that parent is accepted; a checkpoint must never depend on its own parent having already completed the same checkpoint.

| Checkpoint | Evidence owners | What must be established |
|---|---|---|
| EXO-ENV-G1 | EXO-03, EXO-18 | Deployment/worker ADRs, identity distinction, qualification manifest and staging rules. |
| EXO-ENV-G2 | EXO-18 | Actual Kata VM realization, no downgrade, bounded host access and resource/network controls. |
| EXO-ENV-G3 | EXO-12, EXO-13 | Real embedded process lifecycle, limits, duplicate/cancel/recovery semantics and independent acceptance. |
| EXO-ENV-G4 | EXO-15, EXO-16 | Persistence, external lifecycle control, compatible rollback, restore, crash and orphan reconciliation. |
| EXO-ENV-G5 | EXO-12, EXO-14, EXO-19 | External-worker seam, complete environment provenance and embedded viability without inflated claims. |

Initial resource qualification may start alongside domain implementation. The first executable host deployment work and image packaging belong to EXO-18's decomposition; integration into acceptance is completed by EXO-19. Nothing in this profile requires AQ-CONT-1 to be reopened merely because a container runtime was selected.

## 10. Evidence, residual risk, and invalidation

Record instance-environment and worker-environment evidence separately. A hardware-virtualized Vessel can still use a process-only worker. Do not collapse these into a single `sandboxed=true` attribute.

Every qualification result names the exact image, runtime configuration, store profile, supported controls, tested versions, test artifacts, and reviewer. A change in these inputs requires impact review and requalification of affected results. Controlled-development comparisons inherit the same environment distinctions in their Component Fingerprints.

Residual risks include a compromised approved host, vulnerabilities in the runtime/VMM/kernel, weak guest-local worker isolation, inadequate egress enforcement, shared writable state, and lifecycle ambiguity. This first profile deliberately excludes sensitive hostile-code execution rather than claiming those risks have been eliminated.

**This document and its structural validators do not prove sandbox security or runtime correctness.** The acceptance matrix is a work specification; all cases are initially planned. Actual conformance requires running the target code and hardware-dependent tests.

## 11. Sources

Technical references and scope notes are listed in [the target-preference note](kata-containerd-initial-target-and-digicorp.md#sources-and-status): [S1] Kata architecture, [S2] containerd Runtime v2, [S3] installation/maintenance guidance, [S4] direct-client/CRI integration, [S5] storage architecture, and [S6] the separate confidential-execution threat model. Project requirements above are our planning choices, not upstream guarantees.


## 12. Producer-to-consumer evidence handoff

Read [WI-PROVIDER-ALIGNMENT.md](WI-PROVIDER-ALIGNMENT.md) and the exact definition digests in `wi-worker-provider-reference.json`. WI-WORKER-G1–G4 jointly support the producer's embedded process proof; they contribute to, but do not replace, EXO-ENV-G3 and EXO's independent acceptance tests. WI-WORKER-G5 separately supports the bounded host-supervisor adapter; EXO-ENV-G4 still needs actual Kata lifecycle and persistence evidence. The no-shared-path provider fixture contributes to EXO-ENV-G5 but cannot certify a real external provider.

No original parent dependency, full upstream G1–G5 gate or EXO execution acceptance case is removed. Producer evidence is a separately scoped input, not a completed WI-09/WI-11/WI-13/WI-14 parent or full EXO-WI-G4/G5. The next reviewed concurrency map must represent partial evidence explicitly and must not require producer proof to wait for EXO completion.
