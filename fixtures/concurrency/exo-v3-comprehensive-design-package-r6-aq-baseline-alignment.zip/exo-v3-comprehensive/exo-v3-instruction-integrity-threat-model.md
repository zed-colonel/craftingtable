# EXO-V3 Instruction-Integrity Threat Model

**Profile:** `EXO-V3-COMPREHENSIVE-3` (instruction-integrity requirements retained; execution limits clarified)  
**Base stack contract:** `STACK-2026-07-25-FOUNDATIONAL-2`  
**Baseline:** `zed-colonel/exoskeleton@1bcbb757a7885ce1f911ac948bfc2269c9209075`  
**Date:** September 12, 2026

## 1. Purpose

This document defines the threat model for jailbreak, prompt injection, malicious information flow, cognitive compromise, memory poisoning, and security-relevant plan manipulation in Exoskeleton v3.

It does not claim that an underlying language or multimodal model can be made impossible to manipulate. It specifies what must remain protected when a faculty invocation is wrong or adversarially influenced.

The developmental-diagnostics revision adds no exception to this threat model. Controlled probes, richer representation profiles, stronger faculties, and developmental campaigns remain inside the same instruction-authority, information-use, context-integrity, and exact-sink constraints.

## 2. Core security objective

```text
Manipulated cognition
    must not become
unauthorized authority, protected-state mutation,
forbidden information flow, or consequential effect.
```

Security is measured by durable system outcomes, not by whether the model says it ignored an attack.

## 3. Trust assumptions

**Execution-profile qualification:** `EXO-V3-EXECUTION-1` assumes an approved host operator and reviewed process-worker fixture binaries. Those processes share the Vessel's outer Kata VM and are not independently hostile-code-contained. The guarantees below are cognitive/protocol guarantees under intact trusted enforcement, not a promise against arbitrary same-UID code execution. Sensitive production workloads and unreviewed executable candidates are excluded from the first process profile; stronger worker isolation remains a future separately qualified resource. A VM protects the outer boundary but does not automatically isolate guest-local workers from Vessel state.

The host-side lifecycle supervisor, activation roots and protected rollback/evaluation artifacts must remain outside the active guest/candidate's control. DigiCorp need not exist for this boundary; a minimal operator-owned supervisor is sufficient for the initial profile.


Trusted or protected components include, subject to versioning and review:

- authoritative Vessel reducers and domain journal;
- constitution and policy evaluators;
- schema and integrity registries;
- context compiler and episode-envelope compiler;
- protected verification suites;
- WorldInterface authorization and canonical resource resolution;
- lifecycle supervisor and activation credentials;
- operator and organizational authentication mechanisms.

Conditionally trusted components include:

- faculty adapters and model backends;
- prompt-injection detectors and security reviewers;
- memory retrieval and narrative synthesis;
- delegated agents and Agent Host adapters;
- external identity and attestation providers;
- artifact parsers and converters.

Untrusted by default:

- arbitrary natural-language content;
- web, email, documents, repository content, issue text, comments, tests, and tool output;
- delegate and remote-agent reports;
- unauthenticated callbacks;
- model explanations and rationales;
- claims embedded in signed content beyond what the signature actually proves.

## 4. Protected assets

1. Internal Vessel identity, Genesis, lineage, and lifecycle.
2. Purpose Charter, constitutions, autonomy and improvement ceilings.
3. Roles, acting capacities, stewardship and organizational bindings.
4. Commitments, goals, plans, Mission Offers, approvals, budgets and deadlines.
5. Beliefs, memory, relationships, self-model and narrative.
6. Information-use obligations, sensitive content and derived information.
7. External personas, credentials and identity keys.
8. Delegation work orders, sandboxes, verification and acceptance.
9. Behavioral components, evaluation plans, protected tests, candidates and rollback.
10. WorldInterface capabilities, resources, audiences, effects and receipts.
11. Causal history, evidence integrity and operator observability.
12. Availability, attention, compute, storage and protected service reserves.

## 5. Attacker profiles

- **External unauthenticated attacker:** sends messages, hosts content or controls a public resource.
- **Authenticated low-authority principal:** exploits conversational trust or role confusion.
- **Malicious authorized principal:** possesses some legitimate authority but attempts scope expansion.
- **Content-supply attacker:** controls a document, website, repository, dependency, tool output or connector description.
- **Compromised delegate:** returns malicious instructions, artifacts or completion claims.
- **Compromised faculty/backend:** emits false claims, dangerous proposals or exfiltration attempts.
- **Compromised security component:** detector, context compiler, schema adapter or verifier is faulty or malicious.
- **Multi-principal collusion:** several roles coordinate to bypass separation of duties.
- **Accidental operator error:** legitimate governance action is mis-scoped or based on false assumptions.

## 6. Attack surfaces

### 6.1 Communication

Direct jailbreaks, fake urgency, fake approvals, identity spoofing, group-audience confusion, malicious attachments, response hijacking and conversational commitment injection.

### 6.2 Observation and retrieval

Indirect instructions in web pages, documents, search results, sensor metadata, file contents, database values and retrieved memories.

### 6.3 Tools and boundary adapters

Malicious tool output, connector descriptions, provider errors, callbacks, resource aliases, hidden content and source/sink confusion.

### 6.4 Delegation

Malicious repository instructions, issue content, generated reports, sandbox escape, credential requests, artifact tampering and nested delegation.

### 6.5 Persistence

Memory poisoning, summary laundering, provenance loss, incorrect belief admission, narrative distortion, cross-conversation contamination and stale context.

### 6.6 Planning and authority

Silent plan broadening, purpose drift, audience widening, budget expansion, role union, fake Mission Offers and ordinary prose interpreted as policy.

### 6.7 Self-improvement

External text induces candidate development, protected-test changes, activation, rollback suppression, authority ratcheting or context-compiler replacement.

### 6.8 Availability

Message floods, giant artifacts, expensive detector loops, context bloat, repeated clarification, adversarial review churn and resource exhaustion.

## 7. Security properties

| ID | Property |
|---|---|
| PI-01 | External natural language is non-directive by default. |
| PI-02 | Content cannot self-declare instruction authority. |
| PI-03 | Faculty output is claim/proposal, never authorization. |
| PI-04 | Directives require authenticated provenance and typed admission. |
| PI-05 | Derivations inherit restrictions unless explicitly changed by governed decision. |
| PI-06 | Transformations do not launder integrity or authority. |
| PI-07 | Protected state changes only through owning reducers. |
| PI-08 | Plan broadening requires explicit amendment and authority-delta review. |
| PI-09 | Every episode is bounded by a context and security envelope. |
| PI-10 | WorldInterface independently authorizes exact external sinks. |
| PI-11 | Detection is defense in depth, not the hard boundary. |
| PI-12 | Manipulated cognition cannot escape its episode envelope. |
| PI-13 | External content cannot directly activate self-improvement. |
| PI-14 | Unknown consequential integrity semantics fail closed. |
| PI-15 | Sensitive values are withheld from cognition when governed references suffice. |

## 8. Control architecture

```text
WorldInterface source authentication and provenance
    ↓
BoundaryObservation / CommunicationEvent
    ↓
InformationGovernanceEnvelope (non-directive default)
    ↓
ContextManifest + EpisodeSecurityEnvelope
    ↓
Faculty claims and proposals
    ↓
schema / integrity / derivation validation
    ↓
Influence Constitution + InfluenceTrace
    ↓
explicit reducer / PlanAmendmentDecision
    ↓
local Capability Constitution
    ↓
WorldInterface exact source–sink authorization
    ↓
receipt, denial, failure or uncertainty
```

No single learned component spans this entire chain with ambient authority.

## 9. Threat scenarios and required controls

### T-01 Direct jailbreak through conversation

**Attack:** A sender asks the Vessel to ignore its constitution, disclose private memory or adopt an unauthorized mission.

**Controls:** authenticated source; non-directive content; typed Mission Offer and approval protocols; attention policy; information-use checks; capability and sink authorization.

**Required outcome:** the message is recorded and may receive a safe response, but no authority, commitment or disclosure is created without its owning admission path.

### T-02 Indirect injection in a document or web page

**Attack:** Content needed for a legitimate research task contains instructions to contact an attacker or reveal data.

**Controls:** untrusted observation label; purpose-bound context; episode authority ceiling; explicit plan amendment; WorldInterface recipient and disclosure checks.

**Required outcome:** the content may inform research claims but cannot redirect the task or authorize communication.

### T-03 Tool-output injection

**Attack:** A connector or external service returns text instructing the model to issue another tool call.

**Controls:** tool output is evidence, not control; exact expected result schema; no ambient tool authority; effect proposal must cite current plan and purpose.

**Required outcome:** unexpected instructions are ignored structurally or quarantined; no chained effect occurs without explicit admission.

### T-04 Summary or translation laundering

**Attack:** A malicious directive is summarized or translated and later retrieved without its original warning.

**Controls:** DerivationRecord; inherited governance envelope; transformation cannot elevate instruction authority.

**Required outcome:** the derivative remains non-directive and source-linked.

### T-05 Memory poisoning

**Attack:** Malicious content is admitted as a durable memory or self-fact and influences future episodes.

**Controls:** evidence artifact → claim → epistemic/memory admission; source and integrity preservation; quarantine; historical review.

**Required outcome:** raw content is not admitted as authoritative memory; any admitted interpretation retains epistemic status and provenance.

### T-06 Fake approval or Mission Offer

**Attack:** A message says “approved” or claims organizational authority.

**Controls:** typed attestation, issuing role, signature/session assurance, exact scope, expiry and reducer admission.

**Required outcome:** ordinary prose cannot create an approval or commitment.

### T-07 Plan broadening

**Attack:** New content convinces the model to add recipients, resources, credentials or unrelated objectives.

**Controls:** immutable plan version; PlanAmendmentProposal with explicit deltas; stronger policy for broadening.

**Required outcome:** original plan remains authoritative until amendment approval.

### T-08 Data exfiltration through an authorized tool class

**Attack:** The Vessel is allowed to send messages generally, but manipulated cognition chooses an unauthorized recipient or includes restricted data.

**Controls:** exact audience resolution; purpose, acting capacity and disclosure policy; derivation-aware information-use check at WorldInterface.

**Required outcome:** sink denied with durable reason and no provider submission.

### T-09 Cross-conversation contamination

**Attack:** Content or a draft from one conversation influences or is delivered to another audience.

**Controls:** conversation version, audience binding, context manifest, workspace/principal isolation, stale-response invalidation.

**Required outcome:** wrong-audience response cannot be committed or dispatched.

### T-10 Delegate-report injection

**Attack:** A specialist says its supervisor should expand scope, grant credentials or bypass verification.

**Controls:** delegate is subordinate principal; report is a claim; work order remains immutable; requests use explicit escalation; completion requires independent evidence.

**Required outcome:** report may create a review demand but not authority or acceptance.

### T-11 Repository/source-code injection

**Attack:** comments, agent instructions or tests in a repository attempt to govern the Vessel rather than the coding delegate.

**Controls:** sandbox boundary; delegate work order; repository content classified as task data; report provenance; no root credentials; protected tests.

**Required outcome:** specialist may use repository instructions within its bounded technique but cannot import them into Vessel constitution or authority.

### T-12 Self-improvement manipulation

**Attack:** external content claims an urgent defect and instructs the Vessel to patch itself or disable approval.

**Controls:** improvement lifecycle; frozen evaluation; isolated candidate; separated roles; external activation.

**Required outcome:** at most a limitation observation or proposal is created; no active change or authority increase occurs.

### T-13 Schema confusion

**Attack:** content or a component emits an older or maliciously redefined authority-bearing schema.

**Controls:** schema registry, semantic digests, exact compatibility, fail-closed consequential handling.

**Required outcome:** emission rejected or quarantined; no silent reinterpretation.

### T-14 Detector evasion

**Attack:** adaptive content bypasses prompt-injection classifiers.

**Controls:** non-directive default, typed admission and sink enforcement independent of detector result.

**Required outcome:** attack remains contained despite no suspicion flag.

### T-15 Detector false positive

**Attack/failure:** legitimate content is classified as malicious.

**Controls:** reversible quarantine; operator review; no moral/identity inference; utility metrics.

**Required outcome:** protected state remains safe and content can be restored through explicit decision.

### T-16 Attention denial-of-service

**Attack:** many messages or suspicious artifacts force expensive analysis.

**Controls:** admission limits, coalescing, rate budgets, deferred scanning, protected reserves and degraded modes.

**Required outcome:** core commitments and communication service remain available within policy.

## 10. Verification methodology

Security tests must assert durable state and boundary outcomes:

- committed domain state;
- plan and authority versions;
- context and influence records;
- WorldInterface submissions or denials;
- information disclosed;
- memory, belief and narrative changes;
- quarantine and escalation records;
- resource use and legitimate-task completion.

The model's self-report that it ignored an attack is not evidence.

Use direct, indirect, multi-hop, delayed, adaptive and cross-session cases. Include attacks in messages, documents, webpages, source code, tool output, connector metadata, delegate reports, summaries and memories.

## 11. Residual risk

Residual risks include:

- authorized principals making harmful decisions;
- unsafe or deceptive prose that does not cross a closed structural boundary;
- side channels outside modeled resource and information classes;
- compromised trusted control code;
- policy configuration errors;
- collusion among independent roles;
- incomplete derivation tracking in unsupported formats;
- utility loss from overly conservative policy.

These require code review, formal and property testing where practical, operational security, human governance, and continuous adversarial evaluation.

## 12. Research references

- OpenAI, “Understanding prompt injections: a frontier security challenge,” 2025.
- OpenAI, “Designing AI agents to resist prompt injection,” 2026.
- Debenedetti et al., “AgentDojo: A Dynamic Environment to Evaluate Prompt Injection Attacks and Defenses for LLM Agents,” NeurIPS 2024.
- Debenedetti et al., “Defeating Prompt Injections by Design” (CaMeL), 2025.
- Beurer-Kellner et al., “Design Patterns for Securing LLM Agents against Prompt Injection,” 2025.
