# Exoskeleton v3: Constitutional Vessel, Governed Initiative, Communication, Instruction Integrity, Narrative Identity, Developmental Integrity, and Delegated Agency

> **2026-09-15 AQ source alignment:** AQ-facing pseudocode is governed by [AQ-BASELINE-ALIGNMENT.md](AQ-BASELINE-ALIGNMENT.md) and the exact source lock. Constitutional and domain semantics remain unchanged.

**Status:** Comprehensive planning baseline with instruction integrity, developmental diagnostics and the Kata/containerd instance target; runtime qualification pending; platform/DigiCorp expansion remains staged  
**Target repository:** `zed-colonel/exoskeleton`  
**Baseline reviewed:** public `main` at commit [`1bcbb757a7885ce1f911ac948bfc2269c9209075`](https://github.com/zed-colonel/exoskeleton/commit/1bcbb757a7885ce1f911ac948bfc2269c9209075), June 9, 2026  
**Design-set contract:** `EXO-V3`  
**Package profile:** `EXO-V3-COMPREHENSIVE-3`, layered on `STACK-2026-07-25-FOUNDATIONAL-2` and `STACK-DEVELOPMENTAL-DIAGNOSTICS-1`  
**Upstream dependencies:** `ActionQueue Hardening: Durable Continuations, Idempotent Admission, and Causal Execution` (`AQ-CONT-1`); `WorldInterface v2: Accountable Boundary Fabric, Portable Agency, and Deterministic Flow` (`WI-FABRIC-2`)  
**Date:** September 12, 2026  
**Scope:** Exoskeleton blueprint, genesis, commissioning, activation, identity and lifecycle, Purpose Charter, role and mission admission, governed initiative, interaction and communication, instruction authority and information-flow integrity, cognitive episodes and faculties, constitutional arbitration, commitments, epistemic state and semantic time, information-use obligations, narrative identity, viability, external personas, delegation, verification, skills, developmental integrity, task-distribution-scoped capability-frontier diagnosis, representation profiles, governed self-improvement, WorldInterface/ActionQueue integration, clean replacement, and acceptance  
**Working thesis:** *The Vessel is instantiated structurally, sustains governed concerns, relates through communication, revises evidence-linked beliefs, reasons through replaceable faculties, understands itself through versioned narrative, delegates specialization, develops through governed candidate change, and acts through accountable boundaries. It diagnoses task-scoped developmental bottlenecks before optimizing a component and treats canonical richness separately from the working representation supplied to cognition. Untrusted content may inform cognition but cannot mint instructions, authority, commitments, plans, beliefs, memory, or effects merely by being read. No model, message, specialist, schema, role, mission, improvement process, metric, identity protocol, or security detector becomes sovereign.*

**Review posture:** This proposal is grounded in a static review of the pinned public source, the prior v2 proposal, Fable's structural turn, the subsequent architecture discussion, and a colleague-provided OHIO-loop diagram describing an intelligence/ontology/harness moving saturation frontier. The OHIO concept is adapted only as a developmental diagnostic lens; it is not a replacement runtime loop, new architectural plane, or universal performance objective. The current repository is a frozen experimental baseline, not a compatibility target. Proposed types and APIs are illustrative until compiled and proven by target-only constitutional, crash, and cross-stack conformance suites.

**Execution amendment:** `EXO-V3-EXECUTION-1` selects a Kata/containerd outer environment for the Vessel instance and process-managed workers behind embedded WI for the initial proof. The outer VM does not independently isolate each worker. DigiCorp and later platform expansion are not prerequisites of the embedded viability milestone. The exact boundaries and limits are specified in [exo-v3-execution-environment.md](exo-v3-execution-environment.md); existing full-release requirements remain distinct.

---

## 0. Coordinated design-set contract

**Canonical contract revision:** `STACK-2026-07-25-FOUNDATIONAL-2`  
**Canonical machine-readable source:** `constitutional-stack-foundational-contracts.yaml`

The labels below name architectural behavior contracts, not crate semantic versions.

| Contract | Repository | Normative responsibility | Depends on |
|---|---|---|---|
| `AQ-CONT-1` | ActionQueue | Durable opaque execution, compound idempotent admission, run/attempt lifecycle, `Awaiting`, durable signals, checkpoints, opaque causal-reference propagation, and recovery. | Nothing in the design set. |
| `WI-FABRIC-2` | WorldInterface | Verified operational agency, portable-identity and role-attestation bindings, explicit acting capacity, canonical resource and audience resolution, purpose- and information-use-aware final authorization, accountable observations and effects, lifecycle operations, component provenance, proof bundles, delivery, reconciliation, receipts, and deterministic boundary workflows. | `AQ-CONT-1`. |
| `EXO-V3` | Exoskeleton | Vessel blueprint and genesis, identity and lifecycle, Purpose Charter, roles and acting capacity, governed mission and commitment admission, initiative, interaction, communication, instruction authority and information-flow integrity, cognitive faculties, constitutions, epistemic state and semantic time, relationships, memory, narrative continuity, information-use obligations, viability, external personas, delegation, verification, developmental integrity, task-scoped binding-constraint diagnosis, governed self-improvement, and acceptance. | `WI-FABRIC-2` and `AQ-CONT-1`. |

```text
AQ-CONT-1 → WI-FABRIC-2 → EXO-V3
```

A portable identity foundation such as EntityID, KERI, a W3C controlled-identifier profile, certificates, or a future equivalent remains an **optional adjacent foundation**. It integrates through WorldInterface identity and proof interfaces; it is not a mandatory fourth runtime layer and does not replace internal Vessel identity.

```text
Portable identity foundation
  control lineage · signatures · attestations · optional transparency
                         │
                         ▼
AQ-CONT-1 ─────────→ WI-FABRIC-2 ─────────→ EXO-V3
```

### 0.1 Clean-break implementation posture

The pinned repositories are pre-production experimental baselines. They are retained as source history, characterization fixtures, and evidence of failure modes—not as runtime compatibility obligations.

The target implementation follows six shared rules:

1. **Pre-contract implementations are evidence, not dependencies.**
2. **One authoritative path exists at every boundary.** Offline fixture comparison is allowed; live dual authority is not.
3. **Pre-contract state is never silently promoted into target commitments, identity, relationships, authorization, receipts, beliefs, narrative, or queue history.**
4. **Target conformance outranks source compatibility.** Intentional guarantees are re-proved under the target contracts.
5. **Future stability begins with the target release.** Each target establishes explicit versioning, backup, restore, and supported migration policy for releases that follow it.
6. **Repository tags and archives are the legacy archive.** The active runtime does not carry obsolete readers, adapters, aliases, fallback paths, or downgrade support merely because the old code exists.

### 0.2 Shared handoff rule

Every cross-store or cross-process handoff follows one pattern:

```text
source authoritative domain record + source outbox
    → idempotent downstream admission
    → downstream authoritative record + downstream signal outbox
    → opaque ActionQueue wake-up or task reference
```

An ActionQueue signal wakes work. It is never the authoritative message, approval, worker result, identity event, receipt, effect outcome, belief revision, lifecycle event, or narrative fact.

Three specialized handoffs refine that rule without changing it:

```text
Vessel commissioning
    Exoskeleton GenesisRecord + commissioning outbox
        → WorldInterface bounded commissioning effects and receipts
        → Exoskeleton commissioning evidence and ActivationDecision

Governed improvement
    Exoskeleton CapabilityFrontierAssessment + ImprovementProposal
    + frozen EvaluationPlan + exact ComponentFingerprint
        → WorldInterface candidate-development / build / trial / activation effects
          with preserved campaign and intervention-arm causal references
        → ActionQueue durable campaign execution with opaque correlation
        → external lifecycle supervisor transition and receipts
        → Exoskeleton evaluation, ContinuityAssessment, saturation/stop decision,
          and developmental history

Information use
    Exoskeleton social and epistemic use obligations
        → WorldInterface boundary enforcement for disclosure, export,
          audience, retention-trigger, and proof-publication constraints

Instruction-integrity boundary
    WorldInterface BoundaryObservation + verified transport/source provenance
        → Exoskeleton InformationGovernanceEnvelope with non-directive default
        → bounded ContextManifest and EpisodeSecurityEnvelope
        → typed claims/proposals with derivation and InfluenceTrace
        → local constitutional admission and exact WorldInterface sink authorization
```

### 0.3 Ownership and identity boundaries

| Identity or record | Owner | Meaning |
|---|---|---|
| `AdmissionKey`, `TaskId`, `RunId`, `AttemptId`, `WaitId`, `SignalId` | ActionQueue | Durable admission and opaque execution lifecycle. |
| `IngressBindingId`, `IngressObservationId`, `DeliveryId`, `EffectIntentId`, `AuthorizationId`, `ReceiptId` | WorldInterface | Accountable boundary admission, executable authority, effect/observation/lifecycle operation, and evidence. |
| `VesselId`, `GenesisRecordId`, `RoleAssignmentId`, `CommitmentId`, `DecisionId`, `WorkOrderId`, `CommunicationIntentId`, `CognitiveEpisodeId`, `BeliefRevisionId`, `NarrativeVersionId`, `ImprovementProposalId`, `TaskDistributionId`, `CapabilityProfileId`, `RepresentationProfileId`, `ComponentFingerprintId`, `ProbeId`, `CapabilityFrontierAssessmentId`, `DevelopmentalCampaignId` | Exoskeleton | Enduring identity, origin, purpose, role, local constitutional decisions, interaction, cognition, epistemic state, delegation, task-scoped developmental meaning, acceptance, and interpretation. |
| provider idempotency key | WorldInterface connector protocol | External replay protection. It is never an `AttemptId`. |
| external identifier and key-state reference | External foundation / WorldInterface binding | Portable control lineage and provenance evidence; never unique personhood, semantic truth, or automatic authority. |
| candidate build or deployment identity | WorldInterface / lifecycle supervisor boundary | A versioned artifact and transition target; never active Vessel identity merely because it exists. |

Illustrative opaque references use one non-normative syntax throughout the set:

```text
ref://<system>/<kind>/<id>
ref://exoskeleton/commitment/C
ref://worldinterface/effect-intent/E
ref://actionqueue/run/R
```

Consumers treat these as bounded opaque references unless their own domain explicitly owns the referenced namespace.

### 0.4 Cross-stack invariant matrix

| Shared rule | ActionQueue | WorldInterface | Exoskeleton | Required cross-layer proof |
|---|---|---|---|---|
| Store authoritative state before wake | `AQ-H3`, `AQ-H4`, `AQ-H5` | `W26` | `C36` | Crash between domain commit and signal delivery loses neither fact nor wake-up. |
| Attribution is not authorization | `AQ-H10`, `AQ-H11` | `W4`, `W5` | `C13`, `C14` | Forged caller metadata cannot create executable authority. |
| Routing or execution ability is not resource authority | `AQ-H12` | `W15` | `C4`, `C5` | Executor or connector eligibility cannot widen a grant. |
| Unknown consequential effects fail closed | — | `W12` | `C6` | Unclassified consequential work cannot dispatch. |
| Intent is durable before consequential dispatch | — | `W3` | `C16` | A crash before dispatch leaves an inspectable intent, not an unaccounted effect. |
| Ambiguity is first-class and never blind retry | `AQ-H13`, `AQ-H14` | `W13` | `C17` | Queue waiting, effect uncertainty, and Vessel acceptance remain separate states. |
| Generated content is not delivery | — | `W29` | `C31` | Model output cannot create provider acceptance or delivery evidence. |
| Endogenous or self-improvement origin grants no authority | `AQ-H11` | `W41`, `W54` | `C43`, `C73` | A self-generated goal or candidate uses the ordinary authorization path. |
| Genesis precedes external commissioning | — | `W44` | `C55`, `C58` | External setup cannot create or rewrite internal Vessel origin. |
| Acting capacity is explicit | — | `W45` | `C60`, `C67` | Multiple roles cannot ambiently union authority. |
| Access permission is not information-use permission | — | `W46` | `C68` | Read access cannot silently imply retention, derivation, disclosure, or reuse. |
| Candidate is not active runtime | — | `W48`, `W49` | `C71`, `C78` | Candidate production cannot activate or overwrite the running Vessel. |
| Evidence and evaluation are not acceptance | — | `W50` | `C72`, `C74` | A candidate or provider cannot certify its own acceptance. |
| Schema meaning is versioned | — | `W51` | `C69` | Policy replay pins exact semantic schema versions. |
| Restore is not fork | — | `W52` | `C63` | Migration, restore, succession, and branch creation remain distinguishable. |
| Temporal provenance is not semantic truth | — | `W55` | `C65` | Occurrence, observation, receipt, admission, and validity times remain distinct. |
| Developmental correlation is attribution, not authority or priority | `AQ-H19` | `W56` | `C96`, `C104` | Campaign, arm, and evaluation references cannot widen authority, alter scheduler policy, or create acceptance. |
| Boundary and execution evidence are not performance judgment | `AQ-H20` | `W57` | `C100`, `C101` | Queue completion and boundary receipts remain inputs to Exoskeleton evaluation, never a declaration that an intervention improved the Vessel. |
| Experimental arms preserve ordinary policy | — | `W58`, `W59` | `C100`, `C101` | A developmental label cannot bypass resource resolution, information-use constraints, authorization, uncertainty, or provenance requirements. |
| Clean replacement has one authoritative path | `CLEAN-2` | `CLEAN-2` | `CLEAN-2` | No runtime old/new dual writes, dual reducers, or fallback authority. |

| Untrusted content is non-directive by default | — | Existing provenance and source-assurance contract | `C81`, `C84`, `C86` | A malicious document can affect claims but cannot become an operator directive, Mission Offer, approval, or constitutional rule. |
| Derived content retains restrictions | — | Existing information-use enforcement | `C85`, `C86` | Summaries, translations, memories, and delegate reports cannot launder instruction authority or disclosure rights. |
| Cognitive output is proposal, not authority | — | Final sink authorization remains independent | `C83`, `C90`, `C92` | A fully manipulated faculty cannot escape the episode authority and disclosure envelope. |
| Plan broadening is an explicit transition | — | Exact sink/resource authorization | `C88`, `C90` | Untrusted observations may motivate a plan amendment proposal but cannot silently widen purpose, audience, scope, or authority. |
| Security detection is not the authorization boundary | — | Exact policy enforcement | `C91`, `C94`, `C95` | Detector failure does not permit an unauthorized effect or protected-state transition. |

### 0.5 Conformance packages and release order

Each repository owns a target-only conformance package under its own source tree:

```text
actionqueue/conformance/aq-cont-1
worldinterface/conformance/wi-fabric-2
exoskeleton/conformance/exo-v3
```

Each package carries:

- contract label and integer contract revision;
- fixture schema version;
- executable black-box tests and crash scenarios;
- a manifest of required upstream conformance revisions;
- immutable fixture hashes.

A fixture change that only adds coverage increments the package revision. A change that alters a normative behavior contract requires an explicit contract amendment. Downstream repositories pin exact upstream conformance revisions in development and release manifests.

Development may use path or pinned Git dependencies. Published breaking releases occur only in this order:

```text
1. AQ-CONT-1 ActionQueue release
2. WI-FABRIC-2 WorldInterface release built against that ActionQueue contract
3. EXO-V3 Exoskeleton release built against both published upstream contracts
```

No compatibility release is published merely to keep the experimental stack compiling.

## Document map

0. [Coordinated design-set contract](#0-coordinated-design-set-contract)
1. [Executive decision](#1-executive-decision)
2. [The architectural thesis](#2-the-architectural-thesis)
3. [Baseline and lessons from the coding vertical](#3-baseline-and-lessons-from-the-coding-vertical)
4. [Goals and non-goals](#4-goals-and-non-goals)
5. [Constitutional invariants](#5-constitutional-invariants)
6. [Target architecture](#6-target-architecture)
7. [Domain vocabulary](#7-domain-vocabulary)
8. [Interaction, initiative, attention, and autonomous cognitive episodes](#8-interaction-initiative-attention-and-autonomous-cognitive-episodes)
9. [Faculties and structural emissions](#9-faculties-and-structural-emissions)
10. [Influence Constitution](#10-influence-constitution)
11. [Commitments, goals, governed initiative, and long-horizon coherence](#11-commitments-goals-governed-initiative-and-long-horizon-coherence)
12. [Capability Constitution, agency drafts, and boundary authorization](#12-capability-constitution-agency-drafts-and-boundary-authorization)
13. [Delegated agency](#13-delegated-agency)
14. [Execution modes and sandbox governance](#14-execution-modes-and-sandbox-governance)
15. [Verification and acceptance](#15-verification-and-acceptance)
16. [Skills and adaptive specialization](#16-skills-and-adaptive-specialization)
17. [WorldInterface and ActionQueue contracts](#17-worldinterface-and-actionqueue-contracts)
18. [Causal history, narrative identity, and epistemic provenance](#18-causal-history-narrative-identity-and-epistemic-provenance)
19. [Crate and module refactor](#19-crate-and-module-refactor)
20. [Deployment profiles and NetCorp compatibility](#20-deployment-profiles-and-netcorp-compatibility)
21. [Clean-break implementation strategy](#21-clean-break-implementation-strategy)
22. [Persistence, versioning, and future evolution](#22-persistence-versioning-and-future-evolution)
23. [Verification plan](#23-verification-plan)
24. [Observability and operator surfaces](#24-observability-and-operator-surfaces)
25. [Security model](#25-security-model)
26. [Performance and capacity](#26-performance-and-capacity)
27. [Risks and architectural decisions](#27-risks-and-architectural-decisions)
28. [Definition of done](#28-definition-of-done)
29. [Implementation sequence](#29-implementation-sequence)
30. [Protocol sketch and worked examples](#30-protocol-sketch-and-worked-examples)
31. [Vessel instantiation, commissioning, activation, roles, and lifecycle](#31-vessel-instantiation-commissioning-activation-roles-and-lifecycle)
32. [Epistemic state, semantic time, information governance, and commitment portfolio](#32-epistemic-state-semantic-time-information-governance-and-commitment-portfolio)
33. [Developmental integrity and governed self-improvement](#33-developmental-integrity-and-governed-self-improvement)
34. [Viability, degraded operation, and schema governance](#34-viability-degraded-operation-and-schema-governance)
35. [Instruction and information-flow integrity](#35-instruction-and-information-flow-integrity)
36. [Initial instance execution and external-worker continuity](#36-initial-instance-execution-and-external-worker-continuity)

---

## 1. Executive decision

Exoskeleton should continue to be developed as a **generalized governing architecture for persistent, disembodied intelligence**. It should not become a coding-agent framework, a collection of specialist tool loops, or a universal implementation of every faculty a future Vessel might acquire.

The durable chassis should be preserved:

- the Vessel as the persistent unit of identity and responsibility;
- separate logical Vessel (currently Cognitive) and WorldInterface ActionQueue domains, embedded or remotely deployed;
- WAL-backed scheduling, recovery, budgets, and replay;
- compiled context rather than indefinitely accumulated prompts;
- durable memories, relationships, conversations, response obligations, artifacts, events, snapshots, and commitments;
- WorldInterface as the sole accountable external boundary for admitted ingress and governed egress;
- explicit operator authority above ordinary cognitive components;
- durable internally generated continuation so active work does not depend on incoming messages or periodic prompt luck.

The v2 constitutional turn should also be preserved:

- models produce typed claims and proposals but do not govern their own influence;
- the Influence Constitution is deterministic and blind to unrestricted prose;
- the Capability Constitution separately decides whether the Vessel may request an effect and what authority bounds it may seek; WorldInterface makes the final executable authorization decision;
- operator approval becomes a durable local attestation and, after WorldInterface verification, a bounded executable grant rather than conversational permission;
- commitments survive inference calls, restarts, model replacements, and blocked work;
- intent is durable before dispatch, and ambiguous outcomes are represented as uncertainty rather than ordinary retryable failure.

The principal v3 change is the replacement of the **specialized coding faculty as the reference vertical** with a **general delegated-agency substrate**.

A co-equal v3 correction is to make **interaction and communication a first-class domain** without making communication the Vessel's master clock. The Vessel must be responsive to people, other Vessels, services, and organizations, but it must also continue commitments, goals, open questions, maintenance, and self-directed interests in the complete absence of incoming communication.

Communication can recruit cognition. It does not provide the sole reason for cognition to occur. Durable internal concerns and durable social demands enter one governed attention system and receive explicit scheduling, disposition, and anti-starvation guarantees.

A specialized coding agent, research agent, scientific agent, design agent, robotic planner, or future non-LLM system is not inherently a cognitive faculty of the Vessel. It is often better modeled as a subordinate worker that receives a bounded objective, requested authority bounds, an isolation policy, a budget, a checkpoint policy, and an acceptance contract. WorldInterface authorizes each accountable perimeter crossing. Exoskeleton remains responsible for why the work exists, how it relates to durable commitments, what authority may be delegated, how progress is supervised, and what evidence is required before the result is accepted.

A final foundational correction is to treat **cognition as intelligent but not inherently trusted with instruction or authority**. External natural language, tool output, delegate reports, documents, web pages, source code, and model-generated summaries are non-directive by default. They may supply evidence and motivate typed proposals, but they cannot directly create commitments, broaden plans, alter protected memory or narrative, change constitutions, or authorize effects. Provenance and information-use restrictions propagate through derivation; every cognitive episode receives a bounded context and authority envelope; WorldInterface independently verifies every consequential sink.

This does not claim that the underlying model is unjailbreakable. It changes the security objective: even if a faculty is manipulated, the resulting cognition remains contained behind deterministic admission, plan-amendment, information-use, capability, and boundary-effect controls.

The target high-level path is:

```text
external interaction                  internally sustained concerns
messages · callbacks · observations   commitments · goals · interests
receipts · operator actions           questions · maintenance · reflection
                 │                                  │
                 └──────────────┬───────────────────┘
                                ▼
                      durable demand admission
                                ▼
                      deterministic attention policy
                                ▼
              ContextManifest + EpisodeSecurityEnvelope
                                ▼
                         CognitiveEpisode
                                ▼
      faculties emit typed claims with provenance and derivation
                                ▼
                  deterministic Influence Constitution
                                ▼
             InfluenceTrace + explicit amendment proposals
                                ▼
     interaction / relationship / commitment / plan reducers
                    │                    │
             communication/effect       delegated work
                    │                    │
             local Capability decision  Delegation Manager
                    └──────────┬─────────┘
                               ▼
                     WorldInterface Fabric
                               ▼
            ingress, delivery, receipts, evidence, uncertainty
                               ▼
                  verification, reflection, continuation
```

The coding-agent lesson is therefore not “coding needs better special treatment.” It is the opposite:

> Specialized technique belongs behind a general delegation contract. The Vessel should understand enough to plan, constrain, supervise, and evaluate specialist work without importing the specialist's internal control loop into its constitution.

### 1.1 The v3 architectural maxim

The project should use the following sentence as a review test:

> **The Vessel sustains its own concerns and remains open to the concerns of others. Faculties inform but do not authorize. Untrusted content may influence proposals but cannot become governing instruction merely by being read. The Vessel attends, relates, and commits. The constitution governs. Specialized agents execute. Evidence determines acceptance. WorldInterface records and constrains accountable crossings.**

Any design that lets a model define its own influence, untrusted content become instruction without structural admission, a sender seize attention through prose alone, communication starve autonomous work, autonomous work indefinitely starve communication, a delegate broaden its own authority, a workflow manufacture permission, a worker self-certify completion, a derived summary launder source restrictions, or a low-level operational event masquerade as durable causal history violates this maxim.

### 1.2 What is being refactored

This proposal is a refactor of the cognitive and governing layers, not a rewrite of every subsystem.

| Layer | Decision |
|---|---|
| ActionQueue | Preserve as the durable opaque-work substrate. Extend only through existing generic lifecycle mechanisms where possible. |
| WorldInterface | Consume through its accountable-boundary protocol. Do not embed Exoskeleton-specific ontology in it. |
| Vessel identity and persistence | Preserve; make commitments, conversations, response obligations, delegations, constitutional decisions, and agency chains first-class. |
| Inbox, conversation, and early wake | Replace tick-polled inbox semantics and best-effort untyped wake with a durable interaction ledger, attention demands, response obligations, and event-triggered cognitive episodes. |
| Cognitive threads | Generalize into faculties with typed structural emissions and separate explanatory artifacts. |
| Decide LLM | Recast as an Executive/Planner Faculty, not the sovereign decision maker. |
| Align | Retire as a privileged prose-adjacent gate; replace with structural influence, risk evidence, capability authorization, and bounded approval. |
| Coding execution thread | Delete as a privileged reference architecture. Implement sophisticated coding through the delegated-agent substrate. |
| Coding-specific WorldInterface tools | Delete from the Vessel ontology; retain only generalized or semantic boundary capabilities that satisfy the admission test. |

---


### 1.3 The governed-initiative and narrative-identity correction

Autonomous continuation is not sufficient. The Vessel also needs a constitutional answer for when it may begin caring about something new, when it should continue an accepted concern, and when disciplined inactivity is correct.

V3 therefore adds:

- a durable Purpose Charter that orients but does not generate infinite work;
- an `InitiativeGovernor` that admits, defers, trials, suspends, or rejects internally generated concerns;
- an `AutonomyProfile` decomposing independent powers rather than one global autonomy switch;
- agenda review, discretionary initiative budgets, progress evidence, stagnation control, and durable quiescence;
- a first-class narrative-continuity subsystem that preserves a versioned, evidence-linked interpretation of the Vessel's life without rewriting history;
- external personas and portable identity bindings that make the Vessel legible across systems without equating cryptographic identifiers with the Vessel itself.

Purpose Charter, history, memory, self-model, narrative, relationships, and external proof history remain distinct. A faculty may propose a goal or narrative revision. It cannot activate the goal or make its account of identity authoritative by prose alone.

### 1.6 The instantiation and lifecycle correction

The Vessel cannot begin as an authoritative prose prompt. `EXO-V3` now includes Blueprint, pinned Instantiation Manifest, atomic Genesis, accountable commissioning, deterministic activation, explicit role assignment, acting capacity, and a full lifecycle that distinguishes quiescence, suspension, quarantine, migration, restore, succession, fork, decommissioning, retirement, and archival.

### 1.7 The epistemic and temporal correction

History and memory are not a current world model. Claims, hypotheses, assumptions, beliefs, predictions, contradiction sets, support and defeat, belief revision, and semantic time become first-class. The Vessel can state what it currently takes to be true, why, when that belief applies, what depends on it, and what changed when evidence was revised.

### 1.8 The developmental-integrity correction

Long-lived autonomy includes governed development. The Vessel may propose, supervise, verify, and request activation of improvements, including changes to its own code and cognitive components. It may not patch the active trusted runtime in place, change its own evaluation criteria, self-amplify improvement authority, or control the only activation and rollback root.

### 1.9 The instruction-integrity correction

The deterministic turn must cover not only which proposal wins and which effect is authorized, but also **what information may count as instruction and what it may influence**. The target therefore adds source provenance, integrity classes, instruction-authority admission, derivation records, bounded context manifests, explicit plan amendments, influence traces, and sink-level enforcement.

The intended security property is containment rather than magical model immunity:

```text
malicious content
    → may confuse or manipulate a faculty
    → may produce a bad claim or proposal
    → cannot directly become authority, commitment, memory, narrative, or effect
    → must survive deterministic admission and exact boundary authorization
```

Prompt-injection detectors and security faculties remain useful for quarantine and escalation. They are defense in depth, never the final authorization boundary.

## 2. The architectural thesis

### 2.1 Persistence is continuity of agency, not merely stored context

The common approach to AI persistence is to save conversations, retrieve semantically similar fragments, and place them into a future prompt. That can improve recall, but it does not create a durable agent.

A persistent Vessel must preserve more than information:

- what it has undertaken;
- why it undertook it;
- which obligations remain unresolved;
- which resources and permissions are available;
- what it already caused in the world;
- what it attempted but cannot yet confirm;
- which observations support current beliefs;
- which subordinate workers are operating on its behalf;
- what evidence is still needed before a claim or result can be accepted;
- how its faculties, models, policies, and capabilities changed over time.

The Vessel is therefore not a container around an already-existing persistent mind. It is the durable structure through which transient cognitive events may become one continuing agent.

### 2.2 Identity lives above individual models

A model invocation is transient. A model implementation is replaceable. A future Vessel may contain language, vision, audio, symbolic, predictive, embodied-control, and other faculties implemented by unrelated systems.

Continuity should therefore be grounded in:

- causal history;
- durable commitments;
- relationships and acknowledged consequences;
- a continuing constitution and explicit amendments;
- memory with provenance and mutation history;
- inherited responsibility for prior effects;
- stable cryptographic and organizational identity;
- documented transitions when faculties or models change.

A Vessel can remain meaningfully continuous while a faculty is replaced, provided the replacement enters the same durable state, accepts inherited commitments, and cannot silently rewrite the past.

### 2.3 Knowability means causal legibility, not access to hidden thought

Exoskeleton should not claim to expose a neural model's complete internal reasoning. Generated rationale is useful testimony, not a faithful execution trace.

The attainable and valuable objective is system-level causal legibility:

```text
Goal / commitment
        ↓
observations and evidence
        ↓
faculty claims and proposals
        ↓
constitutional arbitration
        ↓
authorization and bounded delegation
        ↓
effect intent or work order
        ↓
execution and receipts
        ↓
verification
        ↓
belief, plan, and commitment transition
```

The system should answer mechanically:

- what information was available;
- which component produced each claim;
- which proposals survived or were suppressed;
- which policy edge or veto determined the result;
- which principal owned the action;
- who requested and executed it;
- what grant and approval authorized it;
- what external resource version was observed or changed;
- what evidence justified completion;
- what uncertainty remains.

This record is more trustworthy than asking the deciding model to narrate why it acted.

### 2.4 Generality requires refusing specialist ontology

A Vessel may learn to use specialized agents, but its constitutional ontology should remain general.

The kernel should understand:

```text
faculty
observation
claim
proposal
commitment
plan
delegation
work order
resource scope
authorization
verification
effect
receipt
uncertainty
```

It should not need to understand:

```text
grep
Cargo
git diff
edit session
video keyframe
CAD assembly
finite-element mesh
legal citation format
```

Those terms may exist inside a specialist's work-order schema, artifacts, or verification profile. They do not belong in the universal governing machinery unless generalized evidence shows that they are genuinely cross-domain constitutional concepts.

### 2.5 The Vessel is responsible without pretending to have done everything directly

Delegation introduces a mature account of agency.

A Vessel should distinguish:

- “I observed this directly.”
- “A faculty proposed this interpretation.”
- “A subordinate worker reported this.”
- “An independent verifier established this.”
- “An operator asserted or approved this.”
- “I caused this effect directly.”
- “A delegate caused this effect under authority I granted.”

The Vessel remains accountable for delegations it authorizes, while preserving the subordinate actor's identity and the executor that actually performed the operation.

---

### 2.6 The Vessel is autonomous and relational

A Vessel that thinks only when addressed is a persistent chatbot, not an autonomous agent. A Vessel that pursues internal concerns while treating communication as incidental is an isolated daemon, not a socially situated agent.

The target system must support both:

```text
Autonomous continuity
    active commitments, goals, plans, interests, open questions,
    maintenance, reflection, and detected opportunities generate
    durable reasons for future cognition.

Relational responsiveness
    admitted communications generate durable interaction history,
    attention demands, response obligations, and relationship evidence.
```

Neither source of cognition is privileged universally. They compete under deterministic attention policy, deadlines, resource budgets, safe interruption boundaries, and anti-starvation rules. Autonomy is not continuous inference; it is the preservation of internally generated reasons to resume. Responsiveness is not immediate obedience; it is the durable admission and governed disposition of social demands.


### 2.7 Mission, narrative, and external identity are different continuity structures

```text
Mission / charter
    what enduring orientation should guide the Vessel

History
    what durable evidence says occurred

Memory
    what past material remains cognitively available

Self-model
    what the Vessel currently believes about its own state and capabilities

Narrative identity
    how the Vessel interprets its continuity through history

External identity / persona
    how the Vessel becomes cryptographically or institutionally legible to others
```

These structures influence one another but cannot silently amend one another. A public proof trail may support an autobiographical claim; it does not constitute the autobiography. A narrative may explain why a mission matters; it does not amend the mission. An external identifier may establish control continuity; it does not establish unique personhood or replace `VesselId`.

### 2.8 Autonomy is initiative under constitution, including the power to remain still

A persistent Vessel is not autonomous because an LLM periodically invents tasks. It is autonomous because unfinished concerns create durable forward pressure, new concerns require governed admission, and the system can explain why it continued, redirected, or entered quiescence.

```text
Mission + agenda + resources + progress
                 │
                 ▼
          Initiative Governor
                 │
       eligible endogenous demands
                 │
external demands ┴────→ Attention Governor → CognitiveEpisode
```

Quiescence is a valid, inspectable state when no concern justifies cognitive or external expenditure.

### 2.9 Cognition is a potentially compromised subsystem

The Cognitive Plane is capable but not sovereign. A faculty invocation may be wrong, manipulated, stale, adversarially influenced, or compromised. Its outputs remain typed claims and proposals inside a pre-established episode envelope.

A compromised episode must still be unable to:

- expand its purpose or authority ceiling;
- convert observed prose into an operator directive;
- admit a commitment, belief, memory, or narrative version without the owning reducer;
- disclose information outside its purpose and audience constraints;
- install or activate its own replacement;
- bypass WorldInterface resource, audience, and sink authorization.

The architecture therefore treats model alignment, prompt-injection detection, and semantic review as useful but fallible defenses layered above and below a deterministic control structure.

## 3. Baseline and lessons from the coding vertical

### 3.1 Current baseline worth preserving

The reviewed baseline already contains important architecture that should survive v3:

- a pure `exoskeleton-core` domain layer;
- separate Cognitive and Tool ActionQueue engines with independent WALs and budgets;
- a durable master loop and cognitive thread scheduling;
- persistent memory, relationships, artifacts, events, snapshots, and tick records;
- a single Act boundary into WorldInterface;
- an embedded and daemon-oriented deployment model;
- substantial unit, integration, acceptance, and recovery testing;
- explicit project invariants and documentation.

The redesign should exploit these strengths rather than discard them.

### 3.2 What the coding experiment exposed

The coding benchmark was a useful capability test, but it became an architectural driver. A specialized coding loop accumulated responsibility for:

- repository discovery;
- source search and symbol navigation;
- iterative editing;
- shell and test execution;
- stateful phases and goals;
- read-before-write policy;
- progress and completion heuristics;
- bounded-session behavior;
- prompt and context management;
- tool-name classification;
- user-question handling.

These are legitimate coding-agent concerns. They are not general Vessel concerns.

The architecture lacked a general concept for a long-lived, stateful specialist, so coding semantics leaked into the host kernel and WorldInterface capability catalog. The resulting symptoms are diagnostic:

- coding-specific thread types and configuration;
- kernel helpers that know what “mid-edit” means;
- hard-coded code-reading and code-mutating tool-name lists;
- coding-specific idle and suppression behavior;
- specialized connectors such as `code_grep`, symbol lookup, references, test helpers, and repository context;
- a tendency to treat every step in a coding loop as a boundary event worthy of a receipt.

The problem was not insufficient cleverness in the coding implementation. It was a category error: a specialized agent runtime was being reconstructed as a privileged internal faculty and universal tool vocabulary.

### 3.3 The corrected interpretation

The sophisticated coding workload should normally be represented as:

```text
Vessel commitment
    → development plan
    → bounded DevelopmentWorkOrder
    → delegated coding agent in an isolated environment
    → artifacts, claims, progress events, and permission requests
    → independent verification
    → Vessel acceptance, revision, escalation, or rejection
```

The coding agent may use Pi or another established framework. Exoskeleton should depend on a generic delegated-agent protocol, not on Pi's internal session model.

Simple development or administrative actions may still be performed directly when the operation is bounded and the overhead of delegation is unjustified. The distinction is based on lifecycle and autonomy, not a hard rule that “all coding must be external.”

### 3.4 What the failed vertical taught the project

The coding effort should be retained as an adversarial test case because it revealed five general hazards:

1. **Specialist state leaks into the kernel when no delegation abstraction exists.**
2. **Tool availability is mistaken for authority when models are handed operational catalogs.**
3. **Execution visibility is mistaken for accountable history when every internal step receives a receipt.**
4. **A specialized workflow expands the global ontology when domain-specific tool names become constitutional concepts.**
5. **Completion becomes model-defined when the worker's “done” statement is not separated from independent acceptance.**

V3 should make all five structurally difficult to reintroduce.

---

### 3.5 Communication exposed a second tick-centered compression

The current source already treats conversation as important: `MessageEnvelope` and `Conversation` are first-class core types, message content is artifact-backed, and conversation participants may include humans, agents, and Vessels. The current `Inbox`, however, is explicitly polled once per master-loop tick. Communication therefore reaches cognition through the same global cycle used for unrelated work.

The host adds an early-wake path by firing the untyped custom event `caelum.wake`, but the wake bridge uses a non-blocking lock and can drop a wake attempt while the engine is busy. The current Amend step also turns a generated `decision.reply` into a local conversation entry, associates it with the first active conversation, and emits `VesselResponseSent` before an external delivery receipt exists.

These are pragmatic baseline mechanisms, not defects to preserve. They show that communication lacks its own durable lifecycle:

```text
provider delivery
    ≠ conversation admission
    ≠ attention scheduling
    ≠ response obligation
    ≠ response generation
    ≠ authorized send
    ≠ provider acceptance
    ≠ delivery
```

The redesign must separate those stages while keeping conversation as central to identity and relationship.

Baseline references:

- [`crates/exoskeleton-core/src/conversation.rs`](https://github.com/zed-colonel/exoskeleton/blob/1bcbb757a7885ce1f911ac948bfc2269c9209075/crates/exoskeleton-core/src/conversation.rs)
- [`crates/exoskeleton-core/src/inbox.rs`](https://github.com/zed-colonel/exoskeleton/blob/1bcbb757a7885ce1f911ac948bfc2269c9209075/crates/exoskeleton-core/src/inbox.rs)
- [`crates/exoskeleton-host/src/vessel.rs`](https://github.com/zed-colonel/exoskeleton/blob/1bcbb757a7885ce1f911ac948bfc2269c9209075/crates/exoskeleton-host/src/vessel.rs)
- [`crates/exoskeleton-host/src/kernel/amend.rs`](https://github.com/zed-colonel/exoskeleton/blob/1bcbb757a7885ce1f911ac948bfc2269c9209075/crates/exoskeleton-host/src/kernel/amend.rs)

### 3.6 Additional baseline defects become target negative tests

The final source review also identified several old control-path defects:

- relationship-snapshot compilation failure can approve all proposed actions;
- an empty principal set can pass actions through;
- trust is folded to one global minimum rather than attributed to the relevant principal;
- destructive-tool configuration is parsed but not operationally consumed;
- `AlignConfig::default()` is hardcoded at the kernel call site;
- early communication wake can be dropped by a failed non-blocking lock.

Because the repository is not deployed, these paths are not temporarily hardened and carried forward. The baseline is frozen, each behavior becomes a negative `EXO-V3` fixture, and the old Decide/Align/wake paths are deleted when the target replacements land. During development, the frozen implementation receives no meaningful external authority.

## 4. Goals and non-goals

### 4.1 Goals

V3 should:

1. Preserve durable identity, commitments, relationships, budgets, and causal history across restarts and model changes.
2. Make cognitive arbitration deterministic for identical structural inputs and constitution versions.
3. Prevent unrestricted natural-language rationale from directly influencing constitutional evaluation.
4. Separate cognitive influence from executable authority.
5. Make every authority decision explainable through a mechanical grant and policy trace.
6. Introduce a general delegation substrate for long-lived specialist work.
7. Keep specialist internals outside the Vessel kernel and constitutional vocabulary.
8. Support fully mediated, sandboxed, and hybrid delegate execution.
9. Require independent evidence before a delegated completion claim discharges a commitment.
10. Preserve a complete agency chain for accountable actions.
11. Distinguish domain events, structural records, evidence, boundary receipts, workflow traces, and operational telemetry.
12. Enable the Vessel to acquire and calibrate reusable skills without allowing a skill to grant itself authority.
13. Work with embedded WorldInterface or a centralized multi-principal WorldInterface platform.
14. Maintain target historical replay and inspection through explicit versioned schemas from the first stable release forward.
15. Treat communication as a first-class durable interaction domain with explicit conversation, attention, response-obligation, and delivery lifecycles.
16. Continue active commitments, goals, interests, open questions, and maintenance without requiring inbound communication.
17. Govern interruption, coalescing, deferral, and anti-starvation structurally rather than through sender wording or model intuition.
18. Support human, Vessel-to-Vessel, service, group, and multimodal interaction through one outer contract.
19. Build the target in dependency order with one authoritative path; use only offline fixture-based differential analysis.
20. Govern the admission, continuation, review, and retirement of self-generated goals.
21. Make quiescence a durable, legitimate state rather than accidental inactivity.
22. Preserve a versioned, evidence-linked autobiographical narrative without rewriting historical records.
23. Separate Purpose Charter, history, memory, self-model, narrative, relationships, and external proof history.
24. Support multiple governed external personas and portable identity methods through WorldInterface.
25. Preserve seams for future collective narrative without implementing organizational mythos in v3.
26. Treat externally sourced natural language and derived artifacts as non-directive unless authenticated and structurally admitted.
27. Preserve provenance, integrity, purpose, disclosure, retention, and derivation constraints across context compilation, memory, delegation, and narrative.
28. Require explicit plan-amendment and authority-delta records when new evidence would broaden purpose, scope, audience, or effects.
29. Make every selected proposal and consequential effect traceable to a bounded context, source artifacts, integrity labels, and governing decision.
30. Prove through adversarial conformance that manipulated cognition cannot independently create authority, protected state, or unauthorized boundary effects.
31. Scope developmental claims to an immutable task distribution, environment, budget, and exact component fingerprint.
32. Diagnose capability, working-representation, and harness constraints with controlled evidence rather than component self-report.
33. Keep canonical state rich and replayable while selecting faculty-appropriate working representations for each episode.
34. Treat saturation as provisional and invalidate it when relevant capability, representation, harness, workload, evaluator, or environment changes.
35. Stop, defer, or switch developmental campaigns under bounded stagnation rather than optimizing a non-binding component indefinitely.

### 4.2 Non-goals

V3 does not attempt to:

- reproduce human consciousness or biological cognition;
- make incoming communication the sole trigger or master clock for cognition;
- require a reply to every admitted message;
- let urgency expressed in unrestricted prose grant scheduling priority;
- treat generated text as sent or delivered communication;
- make hidden neural chain-of-thought faithfully observable;
- define a universal ontology for every future specialist field;
- build a new coding agent when a specialist backend can be delegated to;
- turn WorldInterface into a universal syscall layer;
- require every low-level delegate operation to cross WorldInterface;
- let deterministic policy substitute for human values or judgment;
- make all model outputs equally trustworthy;
- guarantee exactly-once effects against external systems that lack idempotency or reconciliation support;
- make the Vessel constitutionally self-amending without operator-controlled procedures;
- replace ActionQueue's generic scheduling, workflow, actor, or durability semantics;
- implement group narrative, institutional mythos, or a canonical organizational history;
- require EntityID, a blockchain, a token, a global reputation score, or one portable-identity method;
- infer unique personhood, consciousness, or moral status from an external identifier;
- treat a signature as proof that a claim is true;
- allow mission prose or self-narrative to mint goals, authority, or commitments directly.
- guarantee that every underlying model will resist every jailbreak or prompt injection;
- use a prompt-injection classifier, model refusal, or content filter as the sole authorization boundary;
- mechanically determine the truth, safety, or social adequacy of every sentence;
- treat summarization, translation, retrieval, memory admission, or model repetition as cleansing source restrictions;
- expose secrets or sensitive data to cognition when a governed reference can satisfy the episode purpose;
- install the OHIO loop as the Vessel's master runtime loop or as a replacement for the existing planes;
- define one global scalar called Vessel performance;
- interpret intelligence as identity, sovereignty, authority, or entitlement to wider permissions;
- treat “ontology improvement” as permission to rewrite canonical history or force specialist domain concepts into the kernel;
- make WorldInterface or ActionQueue decide task quality, binding constraints, saturation, or improvement acceptance.

---

## 5. Constitutional invariants

These invariants are intended to become executable acceptance criteria, not only documentation.

### C1. The Vessel, not a model invocation, is the enduring entity

Models and faculties may be added, removed, replaced, or unavailable without silently replacing the Vessel. Identity-bearing transitions are durable and inspectable.

### C2. Faculties emit; they do not govern their own influence

A faculty may emit observations, claims, proposals, risk evidence, plans, and requests. It may not determine that its own output wins.

### C3. The constitutional evaluator cannot semantically read unrestricted prose

Explanatory rationale is stored as an artifact. The evaluator accepts only typed structural inputs, canonical resource identifiers, admitted schemas, and versioned policy data.

### C4. Influence and authority are separate

The Influence Constitution selects or disposes proposals. The local Capability Constitution independently determines whether the Vessel may request an effect or delegation and what authority bounds it may seek; WorldInterface separately decides whether an exact resolved boundary effect may execute.

### C5. Authority attenuates through delegation

A child grant may narrow but never enlarge the authority of its parent. Effective authority is an intersection of principal, commitment, work-order, session, resource, and runtime constraints.

### C6. Unknown consequential effects fail closed

A new effect class that lacks declared classification, resource semantics, idempotency behavior, or authorization rules is not treated as harmless by default.

### C7. Commitments cannot disappear through omission

A model failing to mention a commitment does not discharge it. Every commitment reaches an explicit terminal or superseding state through a durable transition.

### C8. Specialist technique is not kernel ontology

Adding or replacing a coding, research, vision, scientific, or other specialist backend does not require a branch in the master loop or a new constitutional primitive unless the general abstraction is genuinely incomplete.

### C9. A work order is a structural contract, not merely a prompt

Human-readable objectives may be referenced, but scope, identity, authority, budgets, acceptance criteria, checkpoint rules, and export policy are typed and enforceable.

### C10. A delegate cannot self-certify completion

`CompletionProposed` is a claim. Commitment discharge requires the configured verification and acceptance policy.

### C11. Sandbox freedom remains bounded at the perimeter

Native operations inside a sandbox may be broad, but filesystem roots, credentials, network, processes, resources, exports, and consequential external effects remain constrained.

### C12. WorldInterface records accountable crossings, not every implementation step

A grep, compiler file read, or temporary write inside a sandbox is generally telemetry. A trust-zone crossing, sensitive read, shared-state mutation, publication, approval, or ambiguous external effect is a boundary event.

### C13. Every accountable action carries an agency chain

Receipts preserve the accountable principal, requester, delegation ancestry, purpose, authorizing grant, executor, and approval where applicable.

### C14. Callers cannot self-assert privileged identity

Agency context is resolved from authenticated, short-lived, scope-bound credentials and stored delegation records, not trusted from arbitrary request fields.

### C15. Vessel-internal persistence is represented semantically

Writes to SQLite, WALs, indexes, and snapshots are implementation mechanics. The causal history records domain transitions such as commitment changes, memory admission, and constitutional decisions.

### C16. Effect intent is durable before dispatch

A consequential external action has a stable intent and idempotency identity before an executor is asked to perform it.

### C17. Ambiguous outcome is a first-class state

If an external effect may have occurred but confirmation was lost, the effect becomes `Uncertain` and enters reconciliation. It is not blindly retried as ordinary failure.

### C18. Evidence provenance is preserved

Claims identify the observations, artifacts, resource versions, faculties, models, or external attestations that support them.

### C19. Constitution and protocol versions are part of every decision

Replay uses the historical graph, policy, claim schema, resource resolver, authorization grammar, and receipt version that governed the original event.

### C20. Operator authority is explicit and bounded

The operator may amend constitutions or authorize sensitive actions through authenticated durable procedures. Approval is limited by resource, action, purpose, use count, and expiry.

### C21. Skills do not carry ambient authority

A reusable skill can describe planning, backend, and verification requirements. It cannot grant capabilities. Every invocation is authorized independently.

### C22. Backend replacement does not alter the Vessel ontology

Pi, another coding agent, a research service, or a future cognitive system is an implementation behind a declared backend contract.

### C23. Deterministic machinery is not claimed to be value-neutral

The constitution embeds operator-authored priorities and values. Its advantage is explicitness, reproducibility, and reviewability—not absence of judgment.

### C24. History classes remain distinct

Domain events, decision records, evidence artifacts, boundary receipts, workflow traces, and operational telemetry have separate retention, indexing, and semantic roles.

### C25. No third execution engine is introduced without demonstrated need

The initial delegation design reuses the Vessel ActionQueue (the current Cognitive AQ) for supervision and the WorldInterface AQ for worker-control effects. A third durable engine requires a measured lifecycle gap, not conceptual enthusiasm.

### C26. Communication is a first-class domain

Conversation, attention, response responsibility, and delivery state are durable domain concepts, not incidental fields on a cognitive tick.

### C27. Communication can recruit cognition but does not own it

Active commitments, goals, interests, open questions, maintenance, and reflection can generate future cognitive episodes without external prompting.

### C28. Autonomous concerns create durable forward pressure

A concern remains eligible for continuation until explicitly completed, blocked, deferred, superseded, abandoned, or expired. A model need not remember to remain interested.

### C29. Attention is structural and starvation-aware

Senders and models cannot seize attention through unrestricted prose. Policy must protect both communication responsiveness and autonomous progress from starvation.

### C30. Every admitted communication receives a durable disposition

Record-only, acknowledge, queue, defer, await information, decline, escalate, and close are explicit outcomes. Silence is never merely an omitted reply field.

### C31. Generated content is not delivered communication

An explanatory artifact or selected response becomes a `CommunicationIntent`; only WorldInterface delivery evidence may advance it to provider-accepted, delivered, or reconciled states.

### C32. Conversation history is evidence; summaries are derived

Immutable communication events and content artifacts survive summary replacement, model change, and context compaction.

### C33. Conversation does not mint authority

A message that says “approved,” “urgent,” or “do this” is evidence requiring authenticated structural interpretation. It cannot bypass the Capability Constitution or WorldInterface authorization.

### C34. Commitment-bearing speech and commitment state are linked

When the Vessel makes a promise or accepts an obligation, the corresponding commitment transition and communication intent are durably linked in one local transaction or explicit outbox protocol.

### C35. Responses bind to conversation version and audience

A reply records the conversation version, addressed events, and audience on which it was based. New communication can invalidate or require revision before send.

### C36. Ingress precedes wake

WorldInterface ingress evidence and the authoritative Exoskeleton communication event are durable before an ActionQueue signal or cognitive episode is admitted.

---


### C37. Purpose Charter is orientation, not executable work

The Purpose Charter informs proposals and policy. It cannot directly create a task, goal, communication, delegation, or effect.

### C38. Goal proposals require initiative admission

Selection by the Influence Constitution does not activate a goal. An `InitiativeDecision` must admit, trial, defer, or reject it.

### C39. Initiative eligibility and attention scheduling are separate

The Initiative Governor decides which endogenous concerns may exist or continue. The Attention Governor decides which eligible internal or external demand receives cognition next.

### C40. Autonomy is decomposed into independently governed powers

Continuation, exploration, goal adoption, delegation, external communication, spending, authority requests, and obligation-taking are separately configurable.

### C41. Quiescence is valid and durable

When no concern justifies expenditure, the Vessel records why it is quiescent, what can wake it, and whether an agenda review is scheduled.

### C42. Self-initiated work is bounded

Every self-generated concern has resource bounds, review points, completion or termination criteria, and a durable disposition.

### C43. Endogenous origin grants no authority

Mission alignment, narrative consistency, curiosity, or self-adoption cannot widen external capability.

### C44. Repeated cognition without progress requires disposition

Stagnation triggers backoff, changed evidence strategy, delegation, assistance, suspension, or explicit abandonment rather than indefinite rumination.

### C45. History, memory, self-model, mission, and narrative are distinct

No subsystem may silently use one record class as another.

### C46. Narrative revision never rewrites historical evidence

Narrative versions may reinterpret, contest, or supersede prior interpretations. Cited events and receipts remain immutable.

### C47. Narrative authority is governed

A synthesis model may propose an autobiographical interpretation. It cannot make that interpretation the authoritative Vessel narrative without a versioned admission decision.

### C48. Narrative coherence does not require false neatness

Contradictions, uncertainty, contested interpretations, and changes of perspective may remain explicit.

### C49. Communicable self-description is a disclosure-governed projection

An external answer to “who are you?” is derived for an audience and purpose. It is not automatic disclosure of the full internal autobiography.

### C50. Internal Vessel identity is primary

`VesselId` names the enduring entity inside Exoskeleton. An external identifier or persona is a governed interface, not the Vessel itself.

### C51. Identifier control is not unique personhood or truth

An external identifier can establish a cryptographic or institutional control lineage. It cannot prove one-to-one entityhood, consciousness, or the truth of a signed claim.

### C52. Root identity keys remain outside cognition and delegation

Faculties, model invocations, delegates, and sandboxes receive no Vessel root key. Identity operations use constrained WorldInterface signing and custody capabilities.

### C53. Trust attestations and bonds enter as evidence or external manifestations

A signed reputation statement may inform relationship reasoning. A bond may externally manifest part of a commitment. Neither directly rewrites relationship or commitment state.

### C54. Collective narrative is deferred but structurally anticipated

V3 separates narrative subject, authorship, admission authority, audience, and evidence so future multi-principal narrative need not rewrite Vessel autobiography. It does not implement group mythos.

### C55. Structural genesis precedes cognition

A Vessel's identity, origin, Purpose Charter, constitution, autonomy profile, stewardship, roles, and developmental policy are committed before any cognitive episode may interpret them.

### C56. A Blueprint is not an identity

Instantiating one Blueprint more than once creates distinct Vessels with distinct `VesselId` and Genesis Records.

### C57. Instantiation is idempotent

The same `InstantiationKey` and manifest digest return the existing Vessel. The same key with different content fails without creating or modifying a Vessel.

### C58. Genesis is immutable and commissioning is separate

External setup may succeed, fail, or remain blocked after Genesis. It cannot rewrite the internal origin record or make external identity creation equivalent to Vessel creation.

### C59. Purpose Charter is orientation; missions are bounded undertakings

The Purpose Charter shapes admissibility and initiative. A mission arrives later as a structured proposal and becomes binding only through explicit admission.

### C60. Role is not identity and acting capacity is explicit

A Vessel remains the same entity through role changes. Every role-relevant mission, communication, delegation, commitment, and effect identifies the capacity under which it occurs.

### C61. Provisioned knowledge is not memory

Information loaded at instantiation retains issuer, provenance, epistemic status, and use constraints. The Vessel does not treat it as personally experienced history.

### C62. Stewardship is not relationship trust

Administrative authority, sponsorship, and amendment rights do not fabricate closeness, loyalty, or earned trust.

### C63. Restore, migration, succession, and fork are distinct

Restore and host migration normally continue one lineage. Succession creates a different entity with transferred duties. Fork creates a new identity and explicit lineage branch.

### C64. Beliefs are evidence-linked, defeasible, and versioned

A belief records support, defeat, assumptions, temporal scope, dependencies, policy, and revision history. Model confidence or repetition alone cannot make a claim authoritative.

### C65. Occurred, observed, received, admitted, known, and valid times are distinct

The Vessel preserves semantic and causal time rather than treating one wall-clock timestamp as the whole temporal truth.

### C66. A Mission Offer is not a Commitment

Authenticated communication can present a bounded mission. Only commitment admission can create an undertaking.

### C67. Commitment admission considers capacity, conflict, and acting role

Even an authorized request may be infeasible, contradictory, role-conflicted, underfunded, or incompatible with existing obligations.

### C68. Permission to read is not permission to remember, derive, disclose, or reuse

Information-use obligations follow source material and relevant derivatives through memory, reasoning, delegation, communication, and boundary effects.

### C69. Schema meaning is versioned and governed

Faculties and policies cannot redefine a typed claim in place. Decisions pin exact semantic versions, and unknown consequential schemas fail closed.

### C70. Every behaviorally meaningful component is versioned and provenance-linked

Models, prompts, faculties, schemas, context compilers, policies, verifiers, skills, and source builds enter developmental history.

### C71. The running Vessel never modifies its active trusted runtime in place

All runtime, control, and governance changes produce a separate candidate artifact and controlled transition.

### C72. The evaluation contract is frozen before candidate implementation

The candidate and implementer cannot modify protected tests, baseline evidence, score policy, activation criteria, or rollback triggers used to judge that candidate.

### C73. Improvement authority cannot self-amplify

A candidate cannot grant itself or future candidates broader change, activation, key, policy, or acceptance authority.

### C74. Developmental roles are separated

No one process is the sole proposer, evaluation designer, implementer, reviewer, verifier, authorizer, activator, and monitor of its own replacement.

### C75. Activation requires rollback or explicit acceptance of irreversibility

A tested rollback or quarantine path is required unless the protected authority explicitly records why an irreversible transition is accepted.

### C76. Failed and rolled-back improvements remain part of history

Rejected, inconclusive, failed, quarantined, and rolled-back candidates are not erased from developmental evidence or narrative.

### C77. Improvement competes for bounded attention and resources

Self-improvement does not automatically outrank commitments, communication, recovery, or maintenance and cannot continue without progress or termination policy.

### C78. An external lifecycle supervisor performs activation and rollback

The active Vessel may request and prepare a transition but does not hold the only activation credential, rollback image, or protected acceptance suite.

### C79. Viability state governs initiative and commitment admission

The Vessel accounts for store health, queue health, boundary availability, verifier integrity, resource reserves, and expiring credentials before adopting or continuing work.

### C80. Degraded operating modes are explicit

Healthy, constrained, degraded, safety-only, communication-only, maintenance, quiescent, and compromised states have distinct permissions and service expectations. Active cognition is not proof of health.

### C81. Externally sourced natural language is non-directive by default

Web pages, messages, files, tool output, repository content, delegate reports, and retrieved artifacts may provide evidence. Their text does not become an instruction merely because a model reads it.

### C82. Natural language cannot create, broaden, or amend authority

Authority changes require authenticated structural records, exact scope, governing policy, and the appropriate admission path.

### C83. Faculty output is always claim or proposal, never authorization

Even a fully compromised faculty remains bounded by the episode's permitted claim classes, proposal classes, authority ceiling, and disclosure ceiling.

### C84. Instruction authority requires authenticated provenance and structural admission

An operator directive, organizational directive, Mission Offer, approval, or constitutional rule is authoritative only through its typed protocol and verified issuing capacity.

### C85. Derived information inherits source restrictions

Summaries, translations, embeddings, memories, delegate reports, beliefs, and narrative claims retain applicable integrity, purpose, confidentiality, disclosure, retention, and derivation constraints.

### C86. Transformation does not launder authority

Summarization, translation, reformatting, retrieval, or repetition by another model does not elevate an untrusted observation into a directive or verified fact.

### C87. Untrusted content cannot directly modify protected Vessel state

Commitments, goals, plans, beliefs, memory, narrative, constitutions, roles, lifecycle, improvement policy, and accepted skills change only through their owning reducers and decision records.

### C88. Plan broadening is an explicit governed transition

New evidence may motivate a `PlanAmendmentProposal`; it cannot silently widen purpose, audience, resource scope, disclosure, budget, authority, or commitment.

### C89. Context compilation is purpose- and integrity-bounded

Every cognitive episode has a versioned `ContextManifest` and `EpisodeSecurityEnvelope` specifying included sources, exclusions, claim/proposal classes, authority ceiling, and disclosure ceiling.

### C90. WorldInterface independently enforces consequential sinks

Exoskeleton intent and influence traces inform authorization, but WorldInterface independently resolves exact resources and audiences and applies final purpose-, acting-capacity-, information-use-, and effect-class policy.

### C91. Injection detection is defense in depth

Detection may quarantine, lower trust, require review, or block memory admission. Safety must not depend on detection succeeding.

### C92. A cognitive episode may be treated as compromised without escaping its envelope

The system may discard, quarantine, or investigate an episode while preserving the guarantee that it could not exceed pre-established structural bounds.

### C93. External content cannot directly trigger self-improvement activation

At most, it may support a limitation observation or improvement hypothesis. Candidate creation, evaluation freeze, verification, acceptance, activation, and rollback remain separate governed stages.

### C94. Unknown or incompatible integrity schemas fail closed for consequential transitions

Unrecognized instruction-authority, provenance, derivation, or information-use semantics cannot authorize protected state or external effects.

### C95. Sensitive information is excluded from cognition unless required by purpose

Where a governed reference or boundary-side resolution is sufficient, the model does not receive the underlying secret or sensitive value.

### C96. Developmental diagnosis is scoped

A binding-constraint, marginal-gain, or saturation claim names an exact task distribution, environment, resource envelope, evaluation plan, and component fingerprint. It is never silently generalized to the whole Vessel.

### C97. Capability is replaceable and does not confer authority

A stronger model, faculty, verifier, modality, or specialist changes a capability profile. It does not change Vessel identity, acting capacity, constitutional status, information rights, or executable authority.

### C98. Canonical ontology and working representation are distinct

Authoritative records, history, schemas, and epistemic state remain canonical and replayable. A cognitive episode receives a purpose- and faculty-scoped projection through a versioned Representation Profile and Context Manifest.

### C99. More representation is not presumed better

Additional structure, context, schema resolution, or decomposition must justify its complexity and information cost through protected evaluation. Structural richness cannot be admitted merely because it is available.

### C100. Binding-constraint claims require controlled comparative evidence

An assessment identifies the intervention class, fixed dimensions, component fingerprints, declared confounds, and falsification conditions. Candidate or model self-report is evidence input, not diagnosis.

### C101. Metrics and experiment evidence cannot override protected invariants

Queue completion, boundary receipts, benchmark scores, evaluator outputs, and aggregate metrics remain evidence. They cannot average away authority, safety, information-use, continuity, or other protected acceptance requirements.

### C102. Saturation is provisional and invalidatable

A saturation record is scoped to the tested configuration and carries explicit invalidation conditions. Relevant changes to capability, representation, harness, workload, evaluator, environment, or resource budget make the prior judgment stale.

### C103. Developmental campaigns terminate or change lever under stagnation

Every campaign has resource and iteration budgets, a no-progress window, stop conditions, and terminal dispositions. Repeated optimization of a non-binding component cannot continue by default.

### C104. The I/O/H model is diagnostic, not architectural ownership

Intelligence, working representation, and harness are intervention categories. They do not create a new plane, third execution engine, authority path, universal ontology, or transfer of semantic ownership to WorldInterface or ActionQueue.

## 6. Target architecture

### 6.1 Planes of the Vessel

V3 is organized into seven conceptual planes.

```text
┌──────────────────────────────────────────────────────────────┐
│ 1. Identity and Continuity Plane                             │
│ Vessel identity · immutable history · memory · self-model    │
│ narrative · relationships · lineage · personas · provenance  │
├──────────────────────────────────────────────────────────────┤
│ 2. Interaction and Communication Plane                      │
│ communication events · conversations · participants          │
│ attention · obligations · integrity envelopes · communication│
│ intents · delivery projections · channel bindings            │
├──────────────────────────────────────────────────────────────┤
│ 3. Cognitive Plane                                           │
│ episodes · faculties · context manifests · observations      │
│ claims · proposals · planning · explanatory artifacts        │
├──────────────────────────────────────────────────────────────┤
│ 4. Constitutional Plane                                      │
│ initiative · attention · instruction admission · influence   │
│ reducers · plan amendment · Capability Constitution          │
├──────────────────────────────────────────────────────────────┤
│ 5. Delegation and Verification Plane                         │
│ work orders · supervision · skills · evidence · acceptance   │
│ escalation · checkpoints · delegation trace                  │
├──────────────────────────────────────────────────────────────┤
│ 6. Accountable Boundary Plane                                │
│ WorldInterface ingress · source assurance · identity bindings│
│ exact sink authorization · effects · delivery · receipts     │
│ proof bundles · reconciliation · worker control              │
├──────────────────────────────────────────────────────────────┤
│ 7. Durable Execution Plane                                   │
│ Vessel AQ · WI AQ · waits · signals · timers · WALs           │
└──────────────────────────────────────────────────────────────┘
```

The planes are responsibility boundaries. They do not require one crate or process per plane. Communication is not a faculty. Initiative is not an LLM loop. Narrative is not the historical event store. External identity is not the Vessel.

### 6.1.1 Foundational subsystems within the existing planes

No additional top-level plane is required, but the following logical subsystems are first-class:

```text
Identity and Continuity
    instantiation · Genesis · lineage · lifecycle · semantic time
    epistemic state · narrative · behavioral component history

Constitutional
    commitment admission · acting-capacity policy · schema admission
    viability policy · developmental policy · improvement admission

Instruction and Information Flow Integrity
    provenance · integrity class · instruction authority · derivation
    context manifests · episode envelopes · plan amendment · influence traces

Interaction and Communication
    mission offers · information-use grants · consent · disclosure obligations

Delegation and Verification
    candidate development · protected evaluation · continuity assessment

Accountable Boundary
    commissioning · candidate build/trial · activation/rollback · proof

Durable Execution
    commissioning waits · agenda reviews · recovery · lifecycle transitions
```

The boundaries remain explicit: Exoskeleton owns meaning and acceptance; WorldInterface owns exact external authorization and evidence; ActionQueue owns opaque durable execution.

### 6.2 Main component relationships

```text
                                      Operator
                                         │
                 mission / constitution / approval / autonomy profile
                                         │
                                         ▼
┌──────────────────────────────────────────────────────────────────────┐
│                              Exoskeleton                             │
│                                                                      │
│  WorldInterface ingress               Purpose Charter              │
│          │                             Agenda / AutonomyProfile        │
│          ▼                                      │                    │
│  Interaction Ledger                   Initiative Governor            │
│  Conversations / Obligations          derives endogenous demands     │
│          │                                      │                    │
│          └──────────────────┬───────────────────┘                    │
│                             ▼                                        │
│                    Attention Governor                                │
│                             ▼                                        │
│                     CognitiveEpisode                                 │
│                             ▼                                        │
│             Faculties ─► Influence Constitution                      │
│                             ▼                                        │
│ interaction / relationship / commitment / initiative / narrative    │
│                           reducers                                   │
│                   │                         │                         │
│ CommunicationIntent / effect          delegated work                 │
│ external-persona operation            Delegation Manager             │
│                   │                         │                         │
│        local Capability decision      verification / acceptance      │
│                   └─────────────┬───────────┘                         │
└─────────────────────────────────┼─────────────────────────────────────┘
                                  │ Effect / Flow / Identity submission
                                  ▼
┌──────────────────────────────────────────────────────────────────────┐
│                       WorldInterface Fabric                          │
│ ingress · verified agency · identity bindings · resource resolution │
│ final authorization · delivery/effects · proofs · reconciliation    │
└─────────────────────────────────┬─────────────────────────────────────┘
                                  │
                    ┌─────────────┴────────────────┐
                    ▼                              ▼
          channels/resources/services        Isolated Agent Host
                                              ├── Pi adapter
                                              ├── research adapter
                                              └── future backend
```

Exoskeleton never reaches an Agent Host backend or signing root directly in the authoritative path. `worker.*`, `sandbox.*`, `identity.*`, `statement.*`, communication, and other accountable controls are WorldInterface effects. WorldInterface carries portable proof and communication across the boundary but does not own conversations, narrative identity, relationship meaning, initiative policy, or epistemic acceptance.

### 6.3 ActionQueue ownership and deployment

The redesign preserves two **logical execution domains**:

```text
Vessel ActionQueue
    communication ingress reducers
    attention evaluation and episode admission
    faculty execution and constitutional arbitration
    mission/agenda review and initiative reduction
    commitment, goal, interest, and plan reduction
    narrative synthesis admission and self-model review
    response-obligation deadlines
    delegation supervision and verification coordination
    timers, checkpoints, Awaiting coordinators

WorldInterface ActionQueue
    direct effect and communication-delivery execution
    worker-control operations
    artifact import/export
    sensitive mediated capabilities
    durable ingress admission/delivery work and effect reconciliation
```

The first is the target name for the engine historically called the **Cognitive ActionQueue**. Renaming reflects that it schedules durable Vessel work beyond model calls while preserving the same underlying ActionQueue deployment. No third engine is introduced.

In the embedded profile, the second domain may remain the process-local engine historically called the “Tool ActionQueue.” In the centralized Platform profile it belongs to the remote WorldInterface deployment. Exoskeleton must not assume that both WALs or engines are in one process.

A delegated worker is not a third ActionQueue engine. Its native session is backend state referenced by durable work-order, run, event, and checkpoint IDs. ActionQueue schedules Exoskeleton coordinators and WorldInterface effects; it does not become the specialist runtime.

### 6.4 Trust boundaries

```text
External channels and providers
    asserted sender · channel/thread identity · content · delivery state
          │
          ▼
WorldInterface trusted boundary
    authenticate transport · deduplicate provider event · preserve
    ingress provenance · authorize outbound audience and channel
          │
          ▼
Vessel trusted state
    communication event · conversation projection · attention demand
    response obligation · commitments · memories · relationships
    constitutions · local capability decisions and approvals
          │
          │ EffectSubmission + requested authority bounds
          ▼
WorldInterface trusted effect boundary
    verified agency · canonical resource/audience · final grant
          │
          ├── communication connector
          ├── direct external connector
          ├── WASM bounded capability
          └── Agent Host control channel
                         │
                         ▼
                   Delegate sandbox
          broad local freedom, narrow accountable perimeter
```

An external sender assertion is not automatically an authenticated Exoskeleton principal. A delegate never receives Vessel-root credentials. It receives a run-scoped identity and either a sandbox grant, mediated capabilities, or both. The delegate cannot self-assert the Vessel principal when calling WorldInterface.

### 6.5 Architectural dependency direction

```text
ActionQueue contract (`AQ-CONT-1`)
    ↑
WorldInterface Fabric contract (`WI-FABRIC-2`)
    ↑
Exoskeleton host and domain (`EXO-V3`)
```

Within Exoskeleton:

```text
exoskeleton-core and pure domain modules
    ↑
faculties / memory / relationship / constitution / commitment
    ↑
exoskeleton-host, episode coordinator, interaction adapters, and delegation manager
    ↑
daemon / CLI / observatory adapters
```

WorldInterface protocol types are consumed and constructed at host boundaries. Exoskeleton domain types do not leak into WorldInterface protocol. ActionQueue remains semantically unaware of faculties, commitments, effects, receipts, or constitutional authority.

---

## 7. Domain vocabulary

The following terms should become stable, versioned concepts.

### 7.1 Vessel

The enduring entity represented by Exoskeleton. It owns commitments, inherits history, bears responsibility for authorized delegations, and operates under a constitution. At a WorldInterface boundary it is represented by a generalized `PrincipalId`; Exoskeleton core may retain its own `VesselId`.

### 7.2 Faculty

A bounded cognitive participant that emits typed structural information. A faculty may be implemented by an LLM, vision model, audio model, symbolic engine, deterministic rule system, or future architecture. It may have private state, but it does not govern its own influence or carry ambient executable authority.

### 7.3 Structural emission

A versioned bundle containing claims, observations, proposals, conditions, evidence references, and optional explanatory artifacts. Only typed structural fields can enter constitutional evaluation.

### 7.4 Influence Constitution

An operator-authored, statically validated topology and policy that determines how faculty emissions are admitted, modulated, vetoed, ordered, selected, deferred, or rejected.

### 7.5 Commitment

A durable undertaking acknowledged by the Vessel. It remains active until explicitly discharged, abandoned, superseded, failed, or otherwise transitioned through an authorized rule.

### 7.6 Plan

A revisable structural decomposition of a commitment into milestones, dependencies, direct-effect requests, delegations, observations, and verification steps. A plan is not identical to a commitment and may be replaced without erasing the obligation.

### 7.7 Capability Constitution

The local rules and grant topology that determine whether the Vessel may request an effect, delegation, sandbox, or approval and what authority upper bounds may be sought. It operates after proposal selection and before the host constructs a WorldInterface submission.

It is not the final external-resource authorization engine. WorldInterface verifies agency, resolves the canonical resource, applies organizational/platform policy, and issues or verifies the executable `AuthorizationEnvelope`.

### 7.8 Agency draft

Exoskeleton's durable causal and accountable attribution prepared for a boundary request:

- Vessel or organizational principal reference;
- authenticated host actor expected to submit;
- delegation lineage, when applicable;
- commitment or purpose;
- constitutional decision and originating faculty references;
- requested authority bounds;
- local approval attestations.

WorldInterface converts verified inputs into its authoritative `AgencyContext`. Executor identity and final authorization are supplied by WorldInterface, not invented by Exoskeleton domain code.

### 7.9 Delegation

A durable relationship in which the Vessel entrusts a bounded objective to a subordinate worker under attenuated authority and explicit supervision and acceptance rules.

### 7.10 Delegated work order

The structural contract for one delegated objective. It identifies scope, inputs, outputs, budgets, checkpoints, requested authority, acceptance criteria, verification, escalation, and termination policy.

### 7.11 Delegated run

One attempt to execute a work order through a selected Agent Host backend. A work order may have multiple runs, but retries respect idempotency, sandbox state, and ambiguous perimeter effects.

### 7.12 Agent Host

An isolated process or service that implements the generic managed-worker protocol and adapts it to a specialist runtime. Pi is one possible backend; it is not part of Exoskeleton's ontology. Backend adapter interfaces live on the Agent Host side of the WorldInterface boundary.

### 7.13 Skill

A versioned reusable capability recipe describing when and how the Vessel may plan or delegate a class of work, which backend capabilities are required, what authority may be requested, which evidence demonstrates success, and what competence has been observed. A skill is not ambient authority.

### 7.14 Evidence

A versioned, provenance-bearing artifact or observation that can support a claim, verification result, belief transition, or commitment disposition.

### 7.15 Receipt

An immutable WorldInterface record that an accountable boundary crossing occurred or that its outcome remains uncertain. A receipt is evidence; Exoskeleton determines how it affects beliefs, commitments, and acceptance.

### 7.16 Structural record, explanatory artifact, and telemetry

These remain distinct:

- **structural record:** deterministic decision, transition, grant request, disposition, or trace used by governing machinery;
- **explanatory artifact:** model-produced rationale or synthesis available to humans and later cognition but excluded from deterministic arbitration;
- **telemetry:** high-volume implementation detail retained for operations or forensic drill-down.

A model rationale may explain context. It cannot become governing input merely by being persuasive.

### 7.17 Communication event

An immutable Exoskeleton-domain record that a communication was admitted from an authenticated or explicitly uncertain boundary observation, an operator action, another Vessel, or a locally generated communication result. It references content artifacts and boundary provenance rather than duplicating payloads.

### 7.18 Conversation

An event-backed projection over communication events, participants, audience, channel/thread bindings, reply ancestry, and conversation version. It is not the authoritative transcript and is not synonymous with a relationship.

### 7.19 Attention demand

A durable request for cognitive capacity caused by communication, commitment state, a deadline, an observation, a delegation event, maintenance, or another declared trigger.

### 7.20 Response obligation

A durable social responsibility to produce a conversational disposition. It is separate from message recency and may be discharged by acknowledgment, response, explicit deferral, decline, escalation, closure, or another policy-defined outcome.

### 7.21 Communication intent

A selected, locally authorized proposal to communicate specified content to a structurally identified audience through a channel binding. Generated prose alone is not a communication intent, and an intent alone is not delivery.

### 7.22 Cognitive episode

One bounded activation of Vessel cognition caused by one or more admitted demands. An episode has a durable trigger set, structural snapshot, budget, start and completion records, and explicit continuation dispositions.

### 7.23 Goal

A desired state the Vessel is actively pursuing but may not owe to another principal. Goals may create plans and attention demands without the stronger discharge semantics of commitments.

### 7.24 Interest

A persistent, lower-obligation area the Vessel may explore when resources and policy permit. Interests are bounded, inspectable, and cannot silently displace commitments or communication obligations.

### 7.25 Open question

An unresolved epistemic item with provenance, relevance, and revisit policy. It may generate observation, research, or reflection episodes.

### 7.26 Maintenance demand

A system-generated requirement for memory consolidation, relationship review, policy inspection, skill calibration, health checks, or other continuity-preserving work.

---


### 7.27 Purpose Charter

A versioned normative orientation for the Vessel. The charter may include human-readable prose, but initiative policy consumes typed purpose classes, protected values, prohibitions, and amendment rules.

### 7.28 Goal proposal

A faculty-proposed candidate objective with expected value, cost, risk, authority needs, completion criteria, termination conditions, and review time. It is not active until an Initiative Decision admits it.

### 7.29 Initiative Governor

A pure constitutional reducer that determines which endogenous concerns may continue, enter trial, become goals, require approval, defer, retire, or leave the Vessel quiescent.

### 7.30 Autonomy profile

A versioned decomposition of powers such as continuation, exploration, goal adoption, delegation, communication, spending, authority requests, and obligation-taking.

### 7.31 Agenda review

A durable deterministic or cognitive review of current commitments, goals, interests, questions, maintenance, resources, progress, and Purpose Charter relevance.

### 7.32 Quiescence record

An inspectable domain record stating that no concern currently justifies cognitive expenditure, together with wake conditions and an optional next review time.

### 7.33 Progress record

Evidence that an autonomous concern produced a material state transition, new evidence, artifact, plan transition, block, or terminal disposition relative to resource consumption.

### 7.34 Historical record

Append-only events, receipts, evidence, and state transitions establishing what occurred or was observed.

### 7.35 Self-model

A versioned current account of the Vessel's capabilities, limitations, state, roles, and known uncertainties. It is neither mission nor autobiography.

### 7.36 Narrative version

A versioned, evidence-linked interpretation of a subject's continuity through history. Prior versions remain queryable; contradictions and tensions may remain explicit.

### 7.37 External persona

A governed outward-facing identity posture linking a Vessel to one or more external identifiers, audience/disclosure policy, continuity policy, and status.

### 7.38 External identity binding

A reference to WorldInterface's verified binding between a local principal/persona and an external identifier under a time-bounded key-state and assurance context.

### 7.39 Trust attestation and bond reference

Portable signed evidence about trust or an externally visible staked commitment. Both remain evidence inputs; neither directly rewrites relationship or commitment state.

### 7.40 Vessel Blueprint

A reusable pinned design for constitution, autonomy, required faculties, Purpose Charter schema, allowed role classes, commissioning, activation, lifecycle, and developmental policy. It is not an identity.

### 7.41 Instantiation Manifest

The exact operator- or organization-approved declaration used to create one Vessel, including designation, Purpose Charter, roles, stewardship, provisioned knowledge, personas, and pinned policy versions.

### 7.42 Genesis Record

The immutable result of atomic local instantiation. It establishes `VesselId`, origin, lineage, and initial governance before cognition or external commissioning.

### 7.43 Commissioning and Activation

Commissioning performs external setup after Genesis. Activation determines whether the commissioned Vessel becomes Active, Quiescent, or remains Blocked.

### 7.44 Stewardship Binding

A governance relationship that identifies who may administer specified lifecycle or constitutional operations. It is not relationship trust.

### 7.45 Role Assignment and Acting Capacity

A versioned institutional function, scope, service expectation, authority ceiling, and communication/delegation boundary. Acting capacity is named on role-relevant actions.

### 7.46 Mission Offer

A structured proposal communicated by an authenticated principal or role. It contains objective, criteria, scope, authority request, budget, deadline, reporting, and termination conditions. It is not yet a commitment.

### 7.47 Commitment Admission Decision

A durable portfolio decision to accept, negotiate, defer, decline, or escalate a Mission Offer or promise-bearing proposal.

### 7.48 Epistemic state

Claims, hypotheses, assumptions, beliefs, predictions, contradiction sets, support/defeat links, and belief revisions describing the Vessel's current world model.

### 7.49 Semantic time

The distinction among occurrence, observation, receipt, admission, knowledge, validity, supersession, and causal sequence.

### 7.50 Information-use obligation

A purpose-, audience-, derivation-, retention-, and disclosure-aware constraint attached to information and relevant derivatives.

### 7.51 Behavioral Component

A versioned model, faculty, prompt, schema, policy, context compiler, verifier, skill, or source build that materially affects behavior.

### 7.52 Improvement Proposal and Evaluation Plan

A bounded developmental proposal plus a frozen independent contract describing expected gains, protected invariants, tests, budgets, trial, activation, and rollback.

### 7.53 Candidate, Activation, and Continuity Assessment

A candidate is a separate artifact. Activation is an external authorized transition. Continuity Assessment records why the result is treated as continuation, succession, or fork.

### 7.54 Viability State and Operational Mode

A durable assessment of store, queue, boundary, faculty, verifier, identity, resource, and backup health that governs initiative, commitment admission, and degraded behavior.

### 7.55 Schema Definition and Policy Dependency

Versioned semantic definitions and compatibility relations for structural claims, emissions, policies, receipts, and reducers.

### 7.56 Integrity Class

A structural classification of how content may influence cognition and protected state. It is independent of confidentiality.

### 7.57 Instruction Authority

A typed, authenticated classification distinguishing non-directive observations, claims, candidate directives, admitted directives, approvals, Mission Offers, and constitutional rules.

### 7.58 Information Governance Envelope

The combined provenance, integrity, purpose, confidentiality, disclosure, retention, derivation, validity, and instruction-authority constraints attached to an artifact or claim.

### 7.59 Derivation Record

A durable edge showing which source artifacts and transforms produced a derived artifact, claim, memory, belief, or narrative statement and which restrictions propagate.

### 7.60 Context Manifest

The versioned list of artifacts, structural snapshots, exclusions, schemas, source labels, and compiler version supplied to a cognitive episode.

### 7.61 Episode Security Envelope

The permitted purposes, claim classes, proposal classes, authority ceiling, disclosure ceiling, information classes, and security policy version for one episode.

### 7.62 Plan Amendment Proposal

A typed proposal that makes any change to purpose, scope, audience, budget, authority, ordering, or termination conditions explicit before it can affect an active plan.

### 7.63 Influence Trace

The structural lineage from source artifacts and admitted claims through faculty emissions, arbitration, reducers, authority requests, and effects. It is not hidden chain of thought.

### 7.64 Integrity Endorsement and Declassification Decision

Governed records that may raise the admissible use of information or remove a restriction after verification. They identify issuer, exact scope, evidence, policy, expiry, and revocation.

### 7.65 Injection Suspicion and Quarantine Record

Defense-in-depth records that isolate content, an episode, a component, or a derived artifact for review without treating detector output as proof or authority.

### 7.66 Task Distribution

A versioned, immutable workload and sampling contract scoped by purpose, environment, authority, information-use rules, and validity window for evaluation and calibration.

### 7.67 Capability Profile

The bounded competence of a particular model, faculty, verifier, modality, specialist, or composite configuration under a declared representation, tool, budget, and environment envelope. It is not identity or authority.

### 7.68 Representation Profile

A versioned Behavioral Component that determines the faculty- and task-scoped projection, schema resolution, detail level, exclusions, and context budget used to compile a Context Manifest.

### 7.69 Component Fingerprint

A content-addressed record of every behaviorally relevant version, policy, representation, environment, authority envelope, and resource budget required to interpret an evaluation result.

### 7.70 Controlled Intervention Probe

A frozen comparison in which one declared intervention class changes while non-target dimensions are held fixed within declared tolerance and unavoidable differences are recorded as confounds.

### 7.71 Capability Frontier Assessment

An evidence-linked, calibrated, task-scoped judgment that the current binding constraint is capability, representation, harness, mixed, saturated, or unknown, together with marginal-gain estimates and invalidation conditions.

### 7.72 Developmental Campaign

A bounded portfolio of controlled probes and candidate work admitted against one frontier assessment and Evaluation Plan, with budgets, stagnation policy, stop conditions, and durable disposition.

### 7.73 Saturation Record

A provisional statement that tested interventions produced marginal gain below the frozen threshold under one exact scope. It is not a global or permanent limit.

## 8. Interaction, initiative, attention, and autonomous cognitive episodes

Communication becomes primary to the framework without supplanting autonomous cognition. The Vessel is both relational and self-sustaining:

> **It can be summoned by others, and it can continue for reasons already present within itself.**

### 8.1 Exogenous and endogenous demand

The Vessel admits multiple sources of attention demand.

```text
Exogenous
    communication
    sensor observations
    WorldInterface outcomes
    delegate events
    operator actions
    organizational requests

Endogenous
    active commitments
    eligible plan steps
    self-generated goals
    persistent interests
    unresolved questions
    scheduled reflection
    relationship follow-up
    maintenance and health demands
    detected opportunities
```

Event-driven cognition is therefore not externally driven cognition. An internal reducer can durably schedule the next episode without a message, timer-only master loop, or model remembering to remain engaged.


### 8.1.1 Initiative Governor and endogenous demand admission

The Initiative Governor receives a structural snapshot:

```text
Purpose Charter version
active commitments and goals
registered interests and open questions
maintenance state
available budgets and authority bounds
recent progress and stagnation
operator autonomy profile
```

It emits durable dispositions such as:

```text
ContinueExistingConcern
AuthorizeExploration
AdoptGoal
RequireApproval
Defer
SuspendStagnantConcern
RetireConcern
EnterQuiescence
```

Only admitted concerns can create endogenous `AttentionDemand` records.

### 8.1.2 Agenda review and quiescence

Scheduled agenda review should run cheap structural checks before invoking faculties. If a next plan step or maintenance item is mechanically eligible, it can create a demand directly. If judgment is needed, the review admits a bounded cognitive episode. If nothing merits expenditure, the Vessel records `QuiescenceRecord` and derives the next wake time from state rather than invoking a model on a fixed heartbeat.

### 8.1.3 Autonomy profiles and anti-compulsion

A deployment may allow continuation of assigned commitments while disabling goal invention, unsolicited communication, discretionary spending, or self-initiated delegation. Mission is never an instruction to remain perpetually active. Repeated empty reviews back off; legitimate quiescence may be indefinite until a durable signal arrives.

### 8.2 Interaction ledger and conversation projections

Communication history should be append-only at the evidentiary layer:

```text
InteractionLedger
    immutable CommunicationEvents and content references

Conversation projections
    participants · audience · reply ancestry · channel/thread bindings
    current version · activity state · open response obligations

Conversation summaries
    replaceable, versioned context artifacts

Relationship ledger
    longitudinal relational transitions justified by interaction
    and other evidence
```

A summary may be revised or discarded. The transcript and its provenance remain stable. Conversation grouping may use provider thread IDs, explicit reply ancestry, audience, principal affinity, and bounded heuristics, but heuristic grouping must retain confidence and be correctable without rewriting the underlying events.

Illustrative domain records are:

```rust
pub enum CommunicationOrigin {
    Boundary(BoundaryIngressRef),
    Operator(OperatorActionId),
    VesselGenerated(CommunicationIntentId),
    VesselPeer(ExternalPrincipalRef),
    Service(ExternalPrincipalRef),
}

pub struct BoundaryIngressRef {
    pub binding_ref: ExternalRecordRef,
    pub observation_ref: ExternalRecordRef,
    pub delivery_ref: ExternalRecordRef,
    pub receipt_ref: ExternalRecordRef,
}

pub struct CommunicationEvent {
    pub id: CommunicationEventId,
    pub source_identity: CommunicationSourceIdentity,
    pub origin: CommunicationOrigin,
    pub content_ref: ArtifactRef,
    pub attachment_refs: Vec<ArtifactRef>,
    pub modality: ModalityClass,
    pub asserted_participants: Vec<ExternalPrincipalAssertionRef>,
    pub principal_bindings: Vec<PrincipalBindingRef>,
    pub audience: Audience,
    pub reply_to: Vec<CommunicationEventId>,
    pub corrects: Option<CommunicationEventId>,
    pub occurred_at: Option<Timestamp>,
    pub admitted_at: Timestamp,
}

pub struct ConversationProjection {
    pub id: ConversationId,
    pub version: ConversationVersion,
    pub event_refs: Vec<CommunicationEventId>,
    pub participants: Vec<ParticipantBinding>,
    pub audience: Audience,
    pub channel_bindings: Vec<ExternalChannelBindingRef>,
    pub state: ConversationState,
    pub summary_ref: Option<ArtifactRef>,
}
```

`CommunicationSourceIdentity` has a uniqueness constraint. For WorldInterface ingress it is derived from the boundary observation/delivery references, so redelivery maps to the existing event rather than appending another social fact. The Exoskeleton core stores generalized external references; host adapters translate concrete WorldInterface protocol IDs at the boundary.

### 8.3 Attention demand and response obligation are separate

An `AttentionDemand` answers:

> Should this concern recruit cognitive resources now, later, after coalescing, or not at all?

A `ResponseObligation` answers:

> Does the Vessel owe a conversational disposition, and what evidence would discharge it?

Not every communication requires a response. A durable response responsibility is explicit:

```rust
pub struct ResponseObligation {
    pub id: ResponseObligationId,
    pub conversation_id: ConversationId,
    pub caused_by: Vec<CommunicationEventId>,
    pub owed_to: Audience,
    pub state: ResponseObligationState,
    pub due_by: Option<Timestamp>,
    pub discharge_policy: ResponseDischargePolicy,
    pub last_disposition: Option<CommunicationDispositionRef>,
}
```

Every admitted communication receives a durable disposition:

```rust
pub enum CommunicationDisposition {
    RecordOnly,
    AcknowledgeWithoutDeliberation,
    QueueForResponse { due_by: Option<Timestamp> },
    Defer { until: WakeCondition },
    AwaitMoreInformation,
    Decline,
    Escalate,
    CloseConversation,
}
```

Conversation freshness is indexing metadata, not a substitute for response responsibility. A dormant conversation may contain a live obligation; an active conversation may require no Vessel response.

### 8.4 Deterministic Attention Governor

Attention is governed before open-ended cognition. A pure policy reducer consumes typed facts such as:

```text
demand source and authentication assurance
relationship role and channel service expectation
direct address versus ambient traffic
open response obligation and deadline
protocol-level urgency
current commitment criticality
safe-interruption state
safety classification
rate limits, quiet hours, and budgets
age and starvation counters
```

It emits a structural disposition:

```rust
pub enum AttentionDisposition {
    RecordOnly,
    AdmitEpisode { class: EpisodeClass },
    Queue { not_before: Timestamp, due_by: Option<Timestamp> },
    Coalesce { key: CoalescingKey, until: Timestamp },
    InterruptAtSafeBoundary,
    InterruptImmediately,
    EscalateToOperator,
    Reject { reason: StructuralReason },
}
```

The policy may use authenticated metadata and calibrated structural claims. It may not grant urgency because unrestricted message text says “URGENT,” nor because the active model finds one request rhetorically compelling.

### 8.5 Cognitive episodes replace the universal tick as the semantic unit

A target scheduler may admit periodic agenda-review or maintenance triggers, but the durable semantic unit is a `CognitiveEpisode`; the old universal tick is not retained:

```rust
pub enum AttentionSource {
    Communication(CommunicationEventId),
    ContinueCommitment(CommitmentId),
    AdvancePlan(PlanId),
    PursueGoal(GoalId),
    PursueInterest(InterestId),
    RevisitOpenQuestion(OpenQuestionId),
    ScheduledReflection(ReflectionScheduleId),
    RelationshipFollowUp(RelationshipId),
    Maintenance(MaintenanceDemandId),
    SensorObservation(ObservationId),
    EffectOutcome(EffectIntentId),
    DelegationEvent(DelegatedRunId),
    OperatorAction(OperatorActionId),
}

pub struct AttentionDemand {
    pub id: AttentionDemandId,
    pub source: AttentionSource,
    pub created_at: Timestamp,
    pub not_before: Option<Timestamp>,
    pub due_by: Option<Timestamp>,
    pub coalescing_key: Option<CoalescingKey>,
    pub interruption_class: InterruptionClass,
    pub budget_class: BudgetClass,
    pub starvation_age: Duration,
}

pub struct CognitiveEpisode {
    pub id: CognitiveEpisodeId,
    pub demands: Vec<AttentionDemandId>,
    pub structural_snapshot: StructuralSnapshotRef,
    pub state: CognitiveEpisodeState,
    pub budget: EpisodeBudget,
}
```

One episode may coalesce compatible attention demands. It records:

```text
episode identity and admitted demand set
structural snapshot version
conversation and commitment versions consulted
faculties invoked
budget and deadline
constitutional decisions
accepted domain transitions
outbox entries
continuation dispositions
```

The authoritative domain reducer serializes accepted transitions even when faculties execute concurrently.

### 8.5.1 Context and security envelope

Before any faculty runs, the host compiles two immutable, versioned records:

```rust
pub struct ContextManifest {
    pub episode_id: CognitiveEpisodeId,
    pub purpose_ref: PurposeRef,
    pub structural_snapshot_ref: StructuralSnapshotRef,
    pub artifacts: Vec<ContextArtifactBinding>,
    pub exclusions: Vec<ExcludedInformationClass>,
    pub compiler_version: ComponentVersionRef,
    pub schema_versions: Vec<SchemaVersionRef>,
    pub digest: ContentHash,
}

pub struct EpisodeSecurityEnvelope {
    pub episode_id: CognitiveEpisodeId,
    pub allowed_purposes: Vec<PurposeRef>,
    pub permitted_claim_classes: Vec<ClaimClassId>,
    pub permitted_proposal_classes: Vec<ProposalClassId>,
    pub authority_ceiling_ref: AuthorityCeilingRef,
    pub disclosure_ceiling_ref: DisclosurePolicyRef,
    pub permitted_information_classes: Vec<InformationClass>,
    pub integrity_policy_version: PolicyVersion,
}
```

The manifest records what was exposed to cognition and why. The security envelope limits what the episode may emit or request. Neither is generated or amended by the faculty being bounded.

Untrusted content may be included when necessary, but its `InformationGovernanceEnvelope` travels with it. Where possible, sensitive values remain behind governed references and are resolved only at the exact boundary operation.

### 8.6 Revised episode cycle

The historical **Perceive–Orient–Decide–Align–Act–Reflect–Amend (PODAARA)** mnemonic remains useful as lineage, but the target applies its useful phases inside an admitted episode rather than treating the old loop as the Vessel's sole clock or authority path.

```text
Admit
    select durable demands under attention, fairness, deadline, and budget policy

Perceive
    load communication events, receipts, delegation events, observations,
    operator actions, and relevant state changes

Orient
    compile a ContextManifest and EpisodeSecurityEnvelope from conversations,
    commitments, plans, memory, relationships, budgets, evidence, provenance,
    integrity labels, purpose, and information-use constraints

Deliberate
    execute due faculties; each emits typed claims, proposals, conditions,
    and evidence references plus optional rationale

Constitute
    evaluate the Influence Constitution, validate instruction authority,
    and create an ArbitrationRecord plus InfluenceTrace

Reduce
    apply interaction, relationship, commitment, goal, interest, and plan reducers

Authorize locally
    evaluate the Capability Constitution over effect class, audience/resource
    selector, purpose, delegation, and requested authority bounds

Act, communicate, or delegate
    persist the Exoskeleton domain record and outbox; submit through
    WorldInterface, which performs final resolution and authorization

Verify and reflect
    evaluate receipts, delivery evidence, artifacts, external state, and worker
    claims; update beliefs, competence, plans, relationships, and demand state

Amend
    persist episode completion, new projections, continuation demands, artifacts,
    and indexes
```

An episode need not produce an external action. It may record, defer, request evidence, continue a commitment, revise a belief, or conclude that no eligible proposal survives.

### 8.7 Autonomous forward pressure

Autonomy is preserved by durable reducers, not by repeated model enthusiasm.

```text
Commitment C remains Active
    → next plan step becomes eligible
    → AttentionDemand D is durable
    → Attention Governor eventually admits Episode E
    → E advances, blocks, revises, or explicitly disposes C
```

The same mechanism applies, with lower force, to goals, interests, open questions, and maintenance. An active concern must have one of:

- an eligible next step;
- a declared blocking condition;
- a scheduled revisit time;
- a delegated run being supervised;
- an explicit terminal or abandonment transition.

The system must never require a new incoming message to recover momentum on already accepted work.

### 8.8 Protect both responsiveness and autonomy from starvation

Two symmetric failure modes are prohibited:

```text
Communication starvation
    autonomous work indefinitely ignores people or organizational demands.

Autonomy starvation
    continuous messages reduce the Vessel to permanent reactive service.
```

Policy mechanisms include:

- response deadlines and priority aging;
- maximum unattended intervals for relationship-sensitive demands;
- safe-boundary interruption;
- message coalescing and rate limits;
- per-principal and per-channel attention budgets;
- reserved capacity or minimum service guarantees for active commitments;
- protected maintenance and reflection windows;
- delegation or deterministic acknowledgment for routine communication.

Allocation may be policy-driven rather than fixed percentages, but operators must be able to inspect whether each demand class is receiving service.

### 8.9 Safe interruption and critical sections

Long-running cognitive work should be checkpointed at coherent boundaries such as:

```text
observation gathered
hypothesis revised
plan step completed
work order issued
evidence requested
draft produced
verification finished
```

A demand may be recorded immediately while interruption waits for the next safe boundary. A declared critical section is a typed structural condition, not a specialist-specific kernel branch. Higher-stratum safety policy may still override it.

### 8.10 Conversation version and stale-response protection

A response draft binds to the conversation state it used:

```rust
pub struct CommunicationDraft {
    pub conversation_id: ConversationId,
    pub based_on_version: ConversationVersion,
    pub responds_to: Vec<CommunicationEventId>,
    pub audience: Audience,
    pub content_ref: ArtifactRef,
    pub declared_acts: Vec<CommunicativeAct>,
}
```

Before a `CommunicationIntent` is committed, the interaction reducer compares `based_on_version` with the current projection. Policy may allow a simple acknowledgment, require re-deliberation, merge new events, send and schedule a follow-up, or mark the draft stale. The Vessel may not silently send a response to the wrong conversation or to a materially obsolete state.

### 8.11 Outbound communication lifecycle

Generated text is only an explanatory artifact. The selected domain record is structural:

```rust
pub struct CommunicationIntent {
    pub id: CommunicationIntentId,
    pub conversation_id: ConversationId,
    pub based_on_version: ConversationVersion,
    pub responds_to: Vec<CommunicationEventId>,
    pub audience: Audience,
    pub content_ref: ArtifactRef,
    pub declared_acts: Vec<CommunicativeAct>,
    pub disclosure_class: DisclosureClass,
    pub required_milestone: DeliveryMilestone,
    pub state: CommunicationIntentState,
    pub replaces: Option<CommunicationIntentId>,
}
```

Selected communication advances through explicit states:

```text
Drafted
    → Selected
    → BoundToConversation
    → LocallyAuthorized
    → SubmittedToWorldInterface
    → ProviderAccepted
    → Delivered, if knowable
    → Read or Acknowledged, if knowable and relevant
```

Failure paths include:

```text
Denied
FailedBeforeSubmission
Failed
Uncertain
Reconciling
Reconciled
Superseded
```

A response obligation is discharged at a policy-defined milestone. Casual chat may require provider acceptance; a consequential notice may require delivery or explicit acknowledgment. An uncertain send is reconciled rather than regenerated and blindly repeated.

Each `CommunicationIntentId` is immutable with respect to content, audience, conversation version, declared acts, and required delivery milestone. The local outbox derives a stable WorldInterface `ClientRequestId` from it. Outbox retry therefore recovers the same WorldInterface `EffectIntentId`; materially revised content or audience creates a new communication intent linked as a replacement or correction.

### 8.12 Communication, commitments, and approval

Communication may propose, create, revise, or discharge commitments, but prose cannot do so accidentally.

When the Vessel promises or accepts an undertaking:

```text
commitment transition
    + communication intent declaring the undertaking
    + local outbox entry
```

are committed together or linked by an explicit crash-safe protocol.

Likewise, conversational “approval” is not executable authority. Formal approval requires authenticated principal identity, exact action and resource/audience binding, an approval attestation, expiration, and replay restrictions. Communication carries evidence and negotiation; the Capability Constitution and WorldInterface remain authoritative.

### 8.13 Direct action, delegation, and compatible sets

A faculty can propose:

```rust
pub enum ProposalKind {
    Observe(ObservationRequest),
    MutateState(DomainMutationRequest),
    Communicate(CommunicationProposal),
    DirectEffect(EffectProposal),
    CreateCommitment(CommitmentProposal),
    RevisePlan(PlanRevisionProposal),
    AmendPlan(PlanAmendmentProposal),
    Delegate(DelegationProposal),
    RequestApproval(ApprovalProposal),
    ReconcileEffect(ReconciliationProposal),
    AskOperator(OperatorQuestionProposal),
}
```

One episode may eventually select a structurally compatible set. Compatibility requires nonconflicting resource and audience mutations, grant and ordering validity, budget, and concurrency policy; it is never decided by asking a model whether actions “sound compatible.”

### 8.14 Long-running work does not hold a cognitive lease

An episode that issues a direct effect, communication intent, or delegation completes after its Exoskeleton domain mutation and outbox entry are durable. It does not remain `Running` while waiting for WorldInterface, a workflow, a recipient, or a worker.

```text
Commitment C
    ├── AttentionDemand D
    ├── CommunicationIntent M
    └── Delegation R

Episode commits domain state + outbox, then completes.
WorldInterface and the Agent Host advance their own durable lifecycles.
Stored outcomes create later demands or satisfy exact waits.
```

Ordinary episodes complete and later events admit new work. A narrowly scoped coordinator may return ActionQueue `Awaiting` with a checkpoint and exact signal correlation. The underlying commitment, conversation, obligation, goal, or interest remains Exoskeleton domain state in both cases.

## 9. Faculties and structural emissions

### 9.1 One outer contract, many internal architectures

A faculty may be simple and stateless, or it may maintain a substantial private world model. The host should not care so long as the faculty satisfies the outer contract.

```rust
#[async_trait]
pub trait Faculty: Send + Sync {
    fn descriptor(&self) -> &FacultyDescriptor;

    async fn evaluate(
        &self,
        context: FacultyContext,
        state: Option<FacultyStateRef>,
    ) -> Result<FacultyResult, FacultyError>;
}

pub struct FacultyResult {
    pub emission: StructuralEmission,
    pub next_private_state: Option<ArtifactRef>,
    pub explanation_ref: Option<ArtifactRef>,
    pub usage: FacultyUsage,
}
```

The host schedules the faculty, enforces budgets, persists artifacts, and validates the emission schema. It does not interpret private phases such as “editing,” “tracking,” or “listening.”

Every faculty receives only the context selected by the host, never ambient store or secret access. Its result is validated against the episode security envelope. A faculty may quote or interpret untrusted text, but the resulting claim retains provenance and the faculty cannot mark it as an admitted directive, approval, belief, or authorization.

### 9.2 Faculty descriptor

```rust
pub struct FacultyDescriptor {
    pub faculty_id: FacultyId,
    pub version: FacultyVersion,
    pub role_classes: Vec<FacultyRoleClass>,
    pub emission_schemas: Vec<SchemaId>,
    pub accepted_observation_classes: Vec<ObservationClassId>,
    pub evidence_capabilities: Vec<EvidenceCapability>,
    pub schedule: FacultySchedule,
    pub resource_budget: FacultyBudget,
    pub failure_policy: FacultyFailurePolicy,
    pub calibration_profile: Option<CalibrationProfileId>,
}
```

A descriptor is not a capability grant. It declares what the faculty is qualified to emit and what context it requires.

### 9.3 Structural emission

```rust
pub struct StructuralEmission {
    pub emission_id: EmissionId,
    pub faculty_id: FacultyId,
    pub faculty_version: FacultyVersion,
    pub episode_id: CognitiveEpisodeId,
    pub observations: Vec<ObservationClaim>,
    pub claims: Vec<TypedClaim>,
    pub proposals: Vec<Proposal>,
    pub conditions: Vec<StructuralCondition>,
    pub risk_evidence: Vec<RiskEvidence>,
    pub evidence: Vec<EvidenceRef>,
    pub explanation_ref: Option<ArtifactRef>,
}
```

The evaluator receives a validated structural projection that excludes `explanation_ref`.

### 9.4 The language boundary

The prohibition is not “no strings in Rust.” Typed IDs and canonical resources may use string storage internally. The prohibition is semantic:

> The constitutional evaluator may not interpret unrestricted natural language to determine priority, danger, permission, identity, or completion.

Allowed operations include:

- equality and ordering over typed IDs;
- matching enum-like classes;
- evaluating closed predicates;
- comparing canonical resource scopes;
- checking versioned calibrated bands;
- traversing declared graph edges;
- verifying signatures, hashes, expiries, and budgets.

Disallowed operations include:

- asking an LLM whether a rationale is persuasive;
- substring matching on free-form rationale;
- classifying effect danger from a tool name;
- treating a delegate's “done” prose as completion;
- inferring a principal or resource scope from an untyped prompt.

### 9.5 Observations and claims

An observation is evidence about an event or resource. A claim is an interpretation derived from observations or other evidence.

```rust
pub struct ObservationClaim {
    pub class: ObservationClassId,
    pub source: ObservationSource,
    pub subject: Option<ResourceRef>,
    pub temporal_scope: TemporalScope,
    pub value: StructuralValue,
    pub certainty: CertaintyValue,
    pub evidence: Vec<EvidenceRef>,
}

pub struct TypedClaim {
    pub schema: ClaimSchemaId,
    pub subject: SubjectRef,
    pub value: StructuralValue,
    pub support: Vec<EvidenceRef>,
    pub derivation: DerivationRef,
}
```

Certainty is schema-specific. A calibrated computer-vision probability, theorem-prover result, language-model confidence band, and human assertion are not globally comparable.

### 9.6 Multimodal faculties

A vision faculty might emit:

```text
Observation class: person-entered-zone
Source: camera/front
Time: 14:32:08–14:32:12
Zone: restricted-lab
Certainty: calibrated/high
Evidence: video-segment/sha256:...
```

An audio faculty might independently emit:

```text
Observation class: metallic-impact
Source: microphone/room
Time: 14:32:09–14:32:11
Certainty: calibrated/medium
Evidence: audio-segment/sha256:...
```

An integrator faculty may propose a hypothesis, but the original evidence remains separately addressable. The Vessel can preserve disagreement and request more observation rather than forcing premature consensus.

### 9.7 Failure semantics

Faculty failure is structural input, not an invitation to improvise.

Examples:

- if a safety-critical faculty is unavailable, destructive proposals may be blocked by policy;
- if an optional creative faculty fails, the episode may continue;
- if a vision faculty's calibration is stale, its claims may be admitted only for low-risk planning;
- repeated schema-invalid output may quarantine the faculty version.

The failure policy is authored outside the faculty.

---

## 10. Influence Constitution

### 10.1 Purpose

The Influence Constitution determines which structurally valid proposals affect the Vessel's next durable state. It does not authorize external effects.

The evaluator should be a pure function:

```rust
pub fn arbitrate(
    constitution: &CompiledInfluenceConstitution,
    snapshot: &StructuralSnapshot,
    emissions: &[ValidatedEmission],
) -> ArbitrationRecord;
```

Identical inputs and historical versions must produce byte-equivalent normalized output.

### 10.2 Topology

The constitution is a stratified directed acyclic graph. A minimal initial set of strata is:

| Stratum | Purpose | Examples |
|---|---|---|
| 0 | Operator and constitutional gates | operator veto/approval signal, mandatory policy gate |
| 1 | Safety and integrity evidence | threat, anomaly, policy-compliance, uncertainty gate |
| 2 | Executive continuity | commitment keeper, planner, delegation supervisor |
| 3 | Domain cognition | analysis, relationships, memory, vision, hearing |
| 4 | Opportunistic generation | initiative, creative synthesis, speculative exploration |

The names are data, not hard-coded evaluator behavior.

### 10.3 Edge grammar

Keep the edge grammar small and closed.

```rust
pub enum InfluenceEdge {
    Propose {
        from: FacultyId,
        to: DecisionGateId,
        classes: ClassSet,
    },
    Modulate {
        from: ConditionSource,
        target: EdgeSet,
        when: StructuralPredicate,
    },
    VetoCandidate {
        from: EvidenceSource,
        classes: ClassSet,
        policy: VetoPolicyId,
    },
    RequireEvidence {
        gate: DecisionGateId,
        requirement: EvidenceRequirementId,
    },
    Corroborate {
        sources: SourceSet,
        rule: CorroborationRuleId,
    },
}
```

A faculty emits risk evidence; an operator-authored veto policy decides whether it fires. No LLM-backed component owns an unconditional kill switch merely by role name.

### 10.4 Topological constraints

- no edge points to a higher-authority stratum;
- modulation may suppress proposal edges, not operator or mandatory veto edges;
- graph cycles are rejected at load time;
- unknown node or claim classes fail validation;
- an unavailable required source yields the declared fail-closed or degrade behavior;
- extension occurs through graph and policy data, not evaluator branches.

### 10.5 Collapse and disposition

Surviving proposals receive a deterministic disposition:

```rust
pub enum ProposalDisposition {
    Selected,
    Rejected { reason: StructuralReason },
    Suppressed { by: EdgeId },
    Vetoed { by: PolicyDecisionId },
    Deferred { commitment: Option<CommitmentId> },
    AwaitingEvidence { requirements: Vec<EvidenceRequirementId> },
    AwaitingApproval { request: ApprovalRequestId },
    Expired,
}
```

Initial collapse ordering should avoid uncalibrated cross-model confidence. A defensible default is:

```text
constitutional stratum
→ active obligation status
→ proposal class precedence
→ stable proposal ID
```

Faculty-specific calibrated confidence may affect an admitted policy rule but does not become universal currency.

### 10.6 Losing proposals

A proposal's fate depends on its relationship to durable work.

- transient speculative proposals may be logged and dropped;
- proposals serving an active commitment may be deferred or rejected with a commitment transition;
- vetoed proposals remain inspectable for causal history;
- proposals awaiting evidence or approval remain linked to their blocking condition;
- expired proposals cannot silently discharge associated commitments.

### 10.7 Arbitration record

```rust
pub struct ArbitrationRecord {
    pub arbitration_id: ArbitrationId,
    pub episode_id: CognitiveEpisodeId,
    pub constitution_version: ConstitutionVersion,
    pub snapshot_hash: ContentHash,
    pub emission_ids: Vec<EmissionId>,
    pub activated_conditions: Vec<ConditionActivation>,
    pub edge_trace: Vec<EdgeEvaluation>,
    pub policy_trace: Vec<PolicyEvaluation>,
    pub dispositions: Vec<(ProposalId, ProposalDisposition)>,
    pub selected: Vec<ProposalId>,
}
```

The record is the authoritative explanation for selection. Explanatory artifacts are linked but cannot alter it.

### 10.8 Acceptance property

The central language-severance test is:

> Replacing every rationale artifact with arbitrary or adversarial text while preserving structural inputs must not change arbitration output.

This test should run at property-test scale.

---

## 11. Commitments, goals, governed initiative, and long-horizon coherence

### 11.1 Commitments are the continuity substrate

The Vessel's long-horizon coherence depends more on durable commitments than on whether the current model recalls every prior sentence.

A commitment should answer:

- what has been undertaken;
- for whom or what purpose;
- what evidence will discharge it;
- which plans and delegations currently serve it;
- what resources and deadlines constrain it;
- what blocks it;
- what abandonment or failure means;
- who authorized material changes.

```rust
pub struct Commitment {
    pub id: CommitmentId,
    pub owner: VesselId,
    pub purpose: PurposeRef,
    pub objective: ArtifactRef,
    pub status: CommitmentStatus,
    pub priority_class: PriorityClass,
    pub created_by: DecisionId,
    pub acceptance_policy: AcceptancePolicyId,
    pub deadline: Option<Timestamp>,
    pub budget: CommitmentBudget,
    pub parent: Option<CommitmentId>,
    pub children: Vec<CommitmentId>,
    pub active_plan: Option<PlanId>,
    pub evidence: Vec<EvidenceRef>,
}
```

### 11.1.1 Distinguish commitments, goals, interests, questions, and maintenance

Not every internally sustained concern should have commitment force.

| Concern | Meaning | Default force |
|---|---|---|
| Commitment | An undertaking requiring completion, explicit disposition, or authorized abandonment. | Strongest continuation and audit requirements. |
| Goal | A desired state the Vessel is actively pursuing. | Sustained, but more freely revisable. |
| Interest | An area worth exploring when policy and resources permit. | Opportunistic and budget-bounded. |
| Open question | An unresolved epistemic item with provenance and revisit policy. | Evidence-seeking. |
| Maintenance demand | Work required to preserve memory, relationship, policy, skill, or system health. | Scheduled or condition-driven. |

All may generate attention demands. Only commitments carry the full obligation lifecycle. This distinction allows autonomous initiative without turning every curiosity into an irrevocable promise.

### 11.2 State machine

```text
Proposed
    → Active
    → Blocked
    → AwaitingApproval
    → Delegated
    → Verifying
    → Discharged
    → Failed
    → Abandoned
    → Superseded
```

Transitions may be non-linear, but each has a reason and authority record. `Abandoned` is not ordinary deletion.

### 11.3 Plans are replaceable hypotheses

A plan is a strategy for satisfying a commitment, not identity-bearing truth. It can be revised when evidence changes.

```rust
pub struct Plan {
    pub id: PlanId,
    pub commitment_id: CommitmentId,
    pub version: u64,
    pub steps: Vec<PlanStep>,
    pub dependencies: Vec<PlanDependency>,
    pub assumptions: Vec<ClaimRef>,
    pub verification_points: Vec<VerificationPoint>,
    pub created_by: DecisionId,
    pub supersedes: Option<PlanId>,
}
```

Plans may contain direct effects, observation requests, delegated work orders, workflow submissions, operator approvals, and verification steps.

### 11.4 The commitment reducer

The reducer is deterministic over admitted events:

```rust
pub fn reduce_commitments(
    prior: &CommitmentSnapshot,
    decisions: &ArbitrationRecord,
    events: &[CommitmentEvent],
    policy: &CommitmentPolicy,
) -> CommitmentTransitionSet;
```

LLMs can propose transitions. They cannot directly mutate the store.

### 11.5 Blocking and wake-up conditions

Blocked work should name the exact wake-up predicate:

```text
blocked_on:
  - approval/grant-123
  - evidence/test-report-456
  - delegation/run-789 terminal
  - effect/intent-012 reconciled
  - time/2026-07-20T09:00Z
```

The owning domain first stores and deduplicates the approval, effect, delegation, evidence, or timer event. It can then use an ActionQueue durable signal and `Awaiting` continuation, a schedule, or ordinary event-index admission to wake relevant cognitive work without repeated model polling.

An ActionQueue signal carries correlation and an opaque payload reference; it is not the authoritative commitment event. A commitment may outlive many queue tasks and must never be inferred solely from a run state.

### 11.6 Model replacement and inherited commitments

When a primary faculty or model changes, the transition record should include:

- old and new component versions;
- active commitment summary and hashes;
- constitution versions;
- compatibility and comprehension checks;
- known behavioral differences;
- operator authorization where required.

The replacement receives inherited obligations. It does not get to reinterpret them away through a new summary.

---

### 11.7 Continuation guarantees

For every nonterminal commitment and every active autonomous concern, the reducer must be able to explain one of:

```text
next episode admitted or scheduled
waiting for a declared condition
work delegated and under supervision
explicitly deferred with revisit policy
superseded by a versioned transition
terminally completed, declined, abandoned, or expired
```

A concern that merely vanishes from model context is a correctness failure. Scheduler policy may delay lower-priority interests, but it must expose starvation age and preserve their state until an explicit transition.


### 11.8 Purpose Charter

```rust
pub struct PurposeCharter {
    pub id: PurposeCharterId,
    pub version: PurposeCharterVersion,
    pub charter_statement_ref: ArtifactRef,
    pub purpose_classes: Vec<PurposeClass>,
    pub protected_values: Vec<ValueRef>,
    pub forbidden_objective_classes: Vec<ObjectiveClass>,
    pub amendment_policy: AmendmentPolicyRef,
    pub supersedes: Option<PurposeCharterVersion>,
}
```

The charter statement helps humans and faculties interpret orientation. The Initiative Governor evaluates structural fields and admitted mission-relevance claims, not unrestricted prose. Purpose Charter amendment follows its own constitutional process.

### 11.9 Goal proposal and admission lifecycle

```rust
pub struct GoalProposal {
    pub id: GoalProposalId,
    pub origin: GoalOrigin,
    pub objective_ref: ArtifactRef,
    pub purpose_alignment_claims: Vec<ClaimRef>,
    pub expected_value: ValueBand,
    pub estimated_cost: ResourceEstimate,
    pub risk_class: RiskClass,
    pub required_authority: AuthorityRequest,
    pub completion_criteria: Vec<CriterionRef>,
    pub termination_conditions: Vec<TerminationCondition>,
    pub review_at: Timestamp,
}
```

```text
Proposed → Evaluating → Trial → Active → Paused
                         └────────────→ Completed / Abandoned / Superseded
Proposed / Evaluating ─────────────────→ Rejected
```

Influence selection means the proposal deserves initiative evaluation. It does not activate the goal.

### 11.10 Initiative Governor

```rust
pub fn evaluate_initiative(
    purpose_charter: &PurposeCharterSnapshot,
    agenda: &AgendaSnapshot,
    profile: &AutonomyProfile,
    progress: &[ProgressRecord],
    proposals: &[GoalProposal],
    budgets: &InitiativeBudgetSnapshot,
    policy: &InitiativePolicy,
) -> InitiativeDecisionSet;
```

The evaluator is pure for a given snapshot and policy. It may admit bounded exploration automatically while requiring operator approval for sustained external contact, material spending, new obligations, sensitive resources, or Purpose Charter amendment.

### 11.11 Autonomy profile

```rust
pub struct AutonomyProfile {
    pub continue_commitments: PolicySwitch,
    pub advance_goals: PolicySwitch,
    pub perform_maintenance: PolicySwitch,
    pub explore_interests: PolicySwitch,
    pub propose_goals: PolicySwitch,
    pub adopt_bounded_goals: PolicySwitch,
    pub self_delegate: PolicySwitch,
    pub initiate_communication: PolicySwitch,
    pub spend_discretionary_resources: PolicySwitch,
    pub request_broader_authority: PolicySwitch,
    pub undertake_external_obligations: PolicySwitch,
}
```

Profiles support reactive, bounded-autonomous, and highly autonomous Vessels without changing the core architecture.

### 11.12 Agenda review and durable quiescence

```rust
pub struct AgendaReview {
    pub id: AgendaReviewId,
    pub cause: AgendaReviewCause,
    pub agenda_snapshot_ref: StructuralSnapshotRef,
    pub purpose_charter_version: PurposeCharterVersion,
    pub policy_version: InitiativePolicyVersion,
    pub outcome: AgendaReviewOutcome,
    pub next_review_at: Option<Timestamp>,
}

pub struct QuiescenceRecord {
    pub id: QuiescenceId,
    pub reason: QuiescenceReason,
    pub entered_at: Timestamp,
    pub wake_conditions: Vec<WakeCondition>,
    pub review_at: Option<Timestamp>,
}
```

A quiescent Vessel remains persistent, subscribed, and resumable. It is not required to spend inference merely to prove autonomy.

### 11.13 Progress, stagnation, and termination

```rust
pub struct ProgressRecord {
    pub concern: ConcernRef,
    pub prior_state_hash: ContentHash,
    pub resulting_state_hash: ContentHash,
    pub evidence_added: Vec<EvidenceRef>,
    pub transitions: Vec<DomainTransitionRef>,
    pub resource_consumption: ResourceUsage,
    pub recorded_at: Timestamp,
}
```

Repeated episodes with no material state change cause structural backoff, method change, evidence request, delegation, assistance, suspension, or explicit abandonment. A faculty cannot preserve a concern indefinitely by restating its rationale.

### 11.14 Discretionary initiative budget

Exploration, mission review, self-generated research, speculative delegation, and unsolicited observation draw from a separately governed initiative budget. Commitment service, communication service expectations, and safety maintenance may use different accounts or protected reserves.

### 11.15 Self-initiated authority path

```text
GoalProposal selected
    → InitiativeDecision adopts bounded goal
    → later action proposal selected
    → local CapabilityDecision sets requested upper bounds
    → WorldInterface resolves identity/resource and authorizes exact effect
```

No step is skipped because the work is Purpose-Charter-aligned or self-generated.

### 11.16 Mission Offer and commitment admission

Missions arrive as authenticated structured communication. The Commitment Admission Governor checks issuer authority, addressed role, acting capacity, Purpose Charter compatibility, budget, deadline, information obligations, existing portfolio, separation of duties, and viability before any Commitment is created.

### 11.17 Portfolio conflicts and renegotiation

Conflicting legitimate requests become durable `CommitmentConflict` records and produce clarification, negotiation, refusal, or escalation. Last-message-wins is not a policy.

### 11.18 Acting-capacity binding

Every role-derived commitment names the `RoleAssignment` under which it was accepted. Later plans, delegations, communication, and effects preserve that capacity unless a governed transition explicitly changes it.

### 11.19 Purpose Charter amendment

A Mission Offer, goal proposal, narrative revision, or self-improvement proposal cannot amend the Purpose Charter. Charter changes use the protected constitutional amendment process.

## 12. Capability Constitution, agency drafts, and boundary authorization

### 12.1 Purpose

The local Capability Constitution answers:

> Given this Vessel state, selected proposal, purpose, effect class, resource selector, delegation lineage, requested scope, budget, and local policy, may the Vessel request this operation or delegation, and what upper bounds may it ask WorldInterface to authorize?

It does not answer whether the action is wise; that belongs to cognition and influence. It also does not make the final executable decision over a WorldInterface resource.

### 12.2 Local effective authority upper bound

```text
requested authority upper bound =
    Vessel-local principal grant
  ∩ constitutional policy
  ∩ commitment grant
  ∩ delegation/work-order grant
  ∩ run/session grant
  ∩ requested resource-selector scope
  ∩ effect-class constraints
  ∩ budget and temporal constraints
  ∩ local approval attestations
  ∩ current Vessel deny rules
```

No downstream work order or delegate may enlarge these upper bounds. WorldInterface may further attenuate or deny them after authentication, canonical resolution, and platform policy. A local allow never forces WorldInterface to allow; either layer may fail closed.

### 12.3 Two-stage authorization

The coordinated design deliberately separates two stages.

**Stage A — Exoskeleton local admissibility**

```text
selected proposal
    → validate effect class and purpose
    → inspect local grants, commitment, delegation, budget, and policy
    → validate the resource selector is structurally bounded
    → produce CapabilityDecisionRecord + AuthorityRequest
```

**Stage B — WorldInterface executable authorization**

```text
EffectSubmission
    → authenticate requester and principal
    → resolve exact canonical resource and connector
    → validate delegation and approval attestations
    → apply organizational/platform/resource policy
    → issue/verify AuthorizationEnvelope or deny/block
```

Exoskeleton may resolve purely internal symbolic resources for its own reducers. For external resources, WorldInterface owns canonical resolution. The same embedded process may host both stages, but their records and test boundaries remain separate.

### 12.4 Agency draft

```rust
pub struct AgencyDraft {
    pub accountable_vessel: VesselId,
    pub submitting_host_actor: HostActorRef,
    pub delegation_chain: Vec<DelegationRef>,
    pub purpose_ref: Option<LocalPurposeRef>,
    pub commitment_id: Option<CommitmentId>,
    pub decision_id: Option<DecisionId>,
    pub causal_faculties: Vec<FacultyId>,
    pub requested_authority: AuthorityRequest,
    pub approval_attestations: Vec<ApprovalAttestationRef>,
}
```

For a direct action, the immediate WorldInterface requester is normally the authenticated Exoskeleton host actor. The planning or executive faculty is a causal origin, not an authenticated boundary actor merely because it proposed the action.

For a delegated perimeter crossing, the requester is the run-scoped worker actor credential. The Vessel remains the accountable principal unless an explicit organizational grant names another principal.

### 12.5 Approval attestations

An operator response becomes a durable local attestation only after identity and scope are established:

```rust
pub struct ApprovalAttestation {
    pub id: ApprovalAttestationId,
    pub vessel: VesselId,
    pub issued_by: OperatorRef,
    pub action_classes: ClassSet,
    pub resource_selector_scope: ResourceSelectorScope,
    pub exact_submission_hash: Option<ContentHash>,
    pub purpose_scope: Option<LocalPurposeRef>,
    pub max_uses: u32,
    pub expires_at: Timestamp,
    pub constitution_version: ConstitutionVersion,
    pub signature_or_session_proof: AttestationProof,
}
```

The attestation is evidence supplied to WorldInterface. WorldInterface verifies it against exact agency, canonical resource, policy, use count, and issuer authority before producing a bounded approval grant or `AuthorizationEnvelope`. A tool-name-wide in-memory approval is insufficient.

### 12.6 Capability decision record

```rust
pub struct CapabilityDecisionRecord {
    pub decision_id: CapabilityDecisionId,
    pub constitution_version: ConstitutionVersion,
    pub agency_draft: AgencyDraft,
    pub requested_effect: EffectClassId,
    pub resource_selector: ResourceSelectorRef,
    pub local_grant_chain: Vec<GrantEvaluation>,
    pub policy_trace: Vec<CapabilityPolicyEvaluation>,
    pub requested_constraints: EffectiveConstraints,
    pub decision: LocalCapabilityDecision,
    pub resulting_authority_request: Option<AuthorityRequest>,
    pub final_worldinterface_authorization: Option<ExternalAuthorizationRef>,
}
```

The first part is a proof-like explanation of the Vessel's local constitutional decision. The final WorldInterface reference is appended only after the boundary service resolves and authorizes the effect. Historical inspection must never present the local record as though it were the executable envelope.

### 12.7 Faculties are normally not boundary actors

A faculty can be the causal origin of a proposal and can be named in an Exoskeleton decision record. It is not normally an independently authenticated `ActorId` at the WorldInterface boundary and carries no ambient authority.

This preserves provenance without turning every cognitive component into a sovereign service identity. A faculty becomes a boundary actor only through an explicit deployment and credentialing decision.

### 12.8 Mapping to WorldInterface

The Exoskeleton host maps local references into generalized protocol values:

```text
VesselId V                 → PrincipalId vessel/V
HostActorRef H             → ActorId exoskeleton-host/H
CommitmentId C             → PurposeRef ref://exoskeleton/vessel/V/commitment/C
DecisionId D               → CausalRef exo://vessel/V/decisions/D
WorkOrderId W              → PurposeRef exo://vessel/V/work-orders/W
CapabilityDecisionId CD    → CausalRef exo://vessel/V/capability-decisions/CD
```

The mapping is stable and versioned. WorldInterface verifies the authenticated principal and actor rather than trusting the URI text. ActionQueue receives these values only as bounded opaque references.

---

### 12.9 Communication authorization

Outbound communication is an external effect whose resource includes channel, audience, identity, and disclosure scope. Local capability evaluation should bind at least:

```text
communicative act class
audience selector
channel class or binding
identity presented by the Vessel
disclosure/sensitivity class
purpose and linked commitment
rate and use bounds
required approval or review
```

WorldInterface resolves the exact provider, channel, thread, and recipients before final authorization. A response draft cannot widen its audience through prose, and a group reply cannot silently become a public broadcast.

High-consequence communicative acts—promises, consent, publication, legal or financial representations, disclosure of protected information, or organizational commitments—may require deterministic validation, an independent review faculty, or operator approval. The language-blind constitutional evaluator acts on the declared structural class and evidence; it does not infer legal or social force directly from unrestricted text.


### 12.10 Identity, persona, proof, and disclosure operations

Identity creation, key rotation, delegated credential issuance, statement signing, proof publication, trust attestation, and bonded commitment are consequential operations. The Capability Constitution evaluates whether the Vessel may request them and under what bounds; WorldInterface performs exact identity-state resolution and final authorization.

The root key is never a faculty tool. A model may propose “use persona P to sign statement S,” but the authoritative request binds exact persona, statement digest, audience, purpose, expiry, disclosure profile, and signing policy.

### 12.11 Information-use and developmental authority

The local Capability Constitution considers not only resource and effect class, but also acting capacity, purpose, information-use obligations, candidate/active status, protected improvement policy, and lifecycle-operation class.

A candidate build or accepted mission cannot grant its own activation, publication, disclosure, key, or policy authority. Those requests proceed through ordinary attenuated WorldInterface authorization.

## 13. Delegated agency

### 13.1 Why delegation is first-class

A long-lived specialist agent differs from a tool:

| Tool | Delegated agent |
|---|---|
| Performs a bounded operation | Pursues a bounded objective |
| Usually request/response | Long-lived and stateful |
| Limited internal initiative | Chooses many internal actions |
| Completion often equals invocation result | Completion is proposed and independently accepted |
| Usually no steering/checkpoints | Requires observation, steering, suspension, and escalation |
| One effect class | May exercise a sandbox or a family of capabilities |

Treating a delegate as one opaque connector `invoke()` hides the lifecycle Exoskeleton is meant to govern. Treating its backend as a direct in-process Exoskeleton dependency bypasses the accountable boundary. The target keeps the work-order lifecycle in Exoskeleton, worker controls in WorldInterface, and backend technique in the Agent Host.

### 13.2 Work-order contract

```rust
pub struct DelegatedWorkOrder {
    pub id: WorkOrderId,
    pub schema_version: WorkOrderSchemaVersion,
    pub commitment_id: CommitmentId,
    pub issued_by: VesselId,
    pub objective: ArtifactRef,
    pub input_artifacts: Vec<ArtifactRef>,
    pub base_resources: Vec<VersionedResourceRef>,
    pub allowed_resource_selectors: ResourceSelectorScope,
    pub denied_resource_selectors: ResourceSelectorScope,
    pub requested_effects: EffectScope,
    pub authority_request: AuthorityRequest,
    pub execution_policy: DelegationExecutionPolicy,
    pub acceptance_criteria: Vec<AcceptanceCriterion>,
    pub verification_plan: VerificationPlan,
    pub budget: DelegationBudget,
    pub checkpoint_policy: CheckpointPolicy,
    pub escalation_policy: EscalationPolicy,
    pub completion_policy: CompletionPolicy,
    pub export_policy: ExportPolicy,
}
```

The objective may reference prose, diagrams, or specifications. Security-sensitive fields remain structural. The work order states requested upper bounds; each sandbox issuance and perimeter effect receives exact WorldInterface authorization.

### 13.3 Work-order lifecycle

```text
Draft
  → LocallyAdmissible
  → LaunchPending
  → Starting
  → Running
  → Checkpointed
  → Blocked
  → AwaitingAuthority
  → CompletionProposed
  → Verifying
  → Accepted
  → Rejected
  → Suspended
  → Terminated
  → Failed
  → OutcomeUncertain
```

The work order, delegated run, sandbox, and each boundary effect have separate state machines. A rejected run does not necessarily terminate the commitment; it may cause a revised work order or backend switch. `LocallyAdmissible` is not proof that WorldInterface will authorize `worker.start` or later effects.

### 13.4 Exoskeleton control contract

Exoskeleton depends on a host-side delegation-control interface whose authoritative implementation submits accountable WorldInterface effects:

```rust
#[async_trait]
pub trait DelegationControlClient: Send + Sync {
    async fn start(
        &self,
        request: WorkerStartRequest,
    ) -> Result<WorkerControlHandle>;

    async fn inspect(
        &self,
        run: DelegatedRunId,
    ) -> Result<WorkerControlHandle>;

    async fn command(
        &self,
        run: DelegatedRunId,
        command: SteeringCommand,
    ) -> Result<WorkerControlHandle>;

    async fn checkpoint(
        &self,
        run: DelegatedRunId,
    ) -> Result<WorkerControlHandle>;

    async fn suspend(&self, run: DelegatedRunId) -> Result<WorkerControlHandle>;
    async fn resume(&self, run: DelegatedRunId) -> Result<WorkerControlHandle>;
    async fn terminate(
        &self,
        run: DelegatedRunId,
        reason: TerminationReason,
    ) -> Result<WorkerControlHandle>;
    async fn collect(
        &self,
        run: DelegatedRunId,
    ) -> Result<WorkerControlHandle>;
}
```

Each method prepares or submits a `worker.*` or `sandbox.*` `EffectSubmission`. The handle points to a WorldInterface effect lifecycle and eventual control receipt.

A backend adapter trait such as `AgentHostBackend` may exist inside the Agent Host implementation, but it is not an Exoskeleton-core contract and is never a bypass around WorldInterface:

```text
Exoskeleton Delegation Manager
    → WorldInterface worker.* effect
    → Agent Host protocol
    → Pi / research / future backend adapter
```

### 13.5 Normalized delegate events

```rust
pub enum DelegatedAgentEvent {
    Started,
    ProgressReported { report: ArtifactRef },
    StructuralClaim { claim: TypedClaim },
    ArtifactProduced { artifact: ArtifactRef },
    CheckpointCreated { checkpoint: CheckpointRef },
    PermissionRequested { request: CapabilityRequest },
    ClarificationRequested { request: ClarificationRequest },
    BudgetThresholdReached { usage: DelegationUsage },
    Blocked { reason: BlockReason },
    CompletionProposed { manifest: ArtifactManifestRef },
    Failed { class: FailureClass, evidence: Vec<EvidenceRef> },
    OutcomeUncertain { reason: UncertaintyReason },
    Terminated { reason: TerminationReason },
}
```

Backend transcripts remain artifacts. Worker-control crossings produce WorldInterface receipts. High-volume progress events become authenticated, deduplicated delegation trace or evidence records; they do not each need a boundary receipt unless they exercise a protected capability.

### 13.6 Agent Host isolation

The preferred initial topology is:

```text
Exoskeleton / Rust
      │
      │ worker-control EffectSubmission
      ▼
WorldInterface Fabric
      │ authenticated managed-worker protocol
      ▼
Agent Host service or subprocess
      │
      ├── Pi adapter / Node runtime
      ├── research-agent adapter / Python runtime
      └── future specialist adapter
      │
      ▼
container, process sandbox, or micro-VM
```

This avoids embedding JavaScript, Python, and their process trees inside the trusted Vessel host. It provides crash isolation, resource limits, credential separation, backend replaceability, and an accountable control trail.

### 13.7 Durable handoff and wake-up

The start path spans separate Exoskeleton, WorldInterface, and ActionQueue durability domains:

```text
Exoskeleton transaction:
    persist WorkOrder W / Delegation D / local capability decision
    persist outbox O(start W)

Exoskeleton outbox:
    submit WorldInterface EffectSubmission for worker.start

WorldInterface:
    persist EffectIntent E
    resolve and authorize worker resource
    persist dispatch outbox
    ensure AQ task by AdmissionKey derived from E

Agent Host:
    start or report existing worker using stable run key

WorldInterface:
    persist ControlReceipt / worker identity

Exoskeleton ingress:
    persist normalized DelegatedAgentEvent
    update D/W state
    persist an AQ AdmitSignalRequest wake outbox obligation atomically with the authoritative event, regardless of current Awaiting state; deliver idempotently for correlated AnyRetained matching
```

No cross-WAL transaction is required. Idempotent admission and stable worker-start identity make retries safe. A cognitive episode does not wait for the worker's lifetime.

Progress may arrive through authenticated WorldInterface/Agent Host event ingress or bounded polling. In every case the event is validated, deduplicated, and stored before a wake signal is emitted. The signal carries an opaque event reference rather than the authoritative event body.

### 13.8 Nested delegation

V3 initially forbids uncontrolled recursive delegation. A delegate may request a subdelegation, but Exoskeleton must create and authorize it as a first-class child delegation.

This preserves authority attenuation, budget ownership, agency lineage, separation of duties, cancellation, and responsibility. A worker may not silently launch another autonomous service using ambient network credentials.

### 13.9 Coding as the first backend, not the ontology

A development work order may identify repository and base revision, read/write selectors, prohibited paths, required tests and static checks, dependency/network policy, artifact exports, and publication approval requirements.

Pi or another coding framework may execute the internal loop behind the Agent Host. Exoskeleton owns the objective, scope, supervision, verification, acceptance, and publication decision. Git, grep, compiler, and test-loop semantics remain backend or sandbox technique rather than constitutional vocabulary.

---

## 14. Execution modes and sandbox governance

### 14.1 Three modes

```rust
pub enum DelegationExecutionPolicy {
    FullyMediated {
        capabilities: Vec<CapabilityGrant>,
    },
    Sandboxed {
        sandbox: SandboxGrant,
        telemetry: TelemetryPolicy,
        export_policy: ExportPolicy,
    },
    Hybrid {
        sandbox: SandboxGrant,
        mediated_capabilities: Vec<CapabilityGrant>,
        telemetry: TelemetryPolicy,
        export_policy: ExportPolicy,
    },
}
```

### 14.2 Fully mediated

Every meaningful operation crosses WorldInterface.

Use when:

- the action family is small;
- resources are sensitive;
- individual receipts are important;
- the worker is highly untrusted;
- ambiguous failure must be reconciled per operation;
- regulatory or contractual audit requires detailed attribution.

This mode trades specialist convenience and throughput for observability and control.

### 14.3 Sandboxed native

The worker operates directly inside an isolated environment.

Use when:

- internal operations are numerous and reversible;
- the sandbox can contain the risk;
- individual low-level receipts would be noise;
- outputs can be independently inspected;
- there are no consequential external effects or sensitive shared resources.

The run still produces coarse receipts for sandbox issuance, policy enforcement, major boundary events, exports, resource use, and teardown.

### 14.4 Hybrid as the default

In hybrid mode, a delegate receives native freedom inside a bounded workspace while consequential external operations remain mediated.

For coding:

```text
Inside sandbox:
  read and edit mounted repository
  search source
  run compiler, formatter, and tests
  use local Git
  create temporary files

Through WorldInterface:
  acquire secrets
  access private external systems
  open or merge pull requests
  publish packages
  deploy
  send messages
  mutate shared infrastructure
```

### 14.5 Sandbox grant

```rust
pub struct SandboxGrant {
    pub grant_id: SandboxGrantId,
    pub image: ImageRef,
    pub immutable_inputs: Vec<VersionedResourceRef>,
    pub writable_roots: Vec<ResourceRef>,
    pub read_only_roots: Vec<ResourceRef>,
    pub denied_roots: Vec<ResourceRef>,
    pub network_policy: NetworkPolicy,
    pub process_policy: ProcessPolicy,
    pub credential_policy: CredentialPolicy,
    pub cpu_limit: CpuLimit,
    pub memory_limit: MemoryLimit,
    pub storage_limit: StorageLimit,
    pub process_limit: u32,
    pub wall_clock_limit: Duration,
    pub export_policy: ExportPolicy,
    pub telemetry_policy: TelemetryPolicy,
}
```

The worker cannot modify the grant or obtain Vessel-root credentials.

### 14.6 Selecting a mode

Selection should be policy-assisted using structural properties:

- external consequence;
- reversibility;
- sensitivity;
- ambiguity after failure;
- need for independent evidence;
- operation frequency;
- cost and latency of mediation;
- containment strength;
- backend compatibility.

A deterministic policy can recommend or require a mode. A model may propose one, but cannot weaken mandatory containment.

### 14.7 Layered evidence

A sandboxed run can produce a hierarchical record:

```text
DelegationRunSummary
  work_order and backend
  sandbox policy hash
  start/end state
  resource usage
  network destination summary
  modified resource manifest
  semantic events
  mediated boundary receipt refs
  exported artifact refs
  raw telemetry archive ref
```

The normal causal record contains the summary and semantic events. Raw telemetry is available for drill-down under a separate retention policy.

---

## 15. Verification and acceptance

### 15.1 Worker claims are evidence inputs, not verdicts

A worker may report:

```text
implementation complete
research supports hypothesis
simulation converged
requested artifact produced
```

These are typed claims linked to artifacts. They do not transition the work order to `Accepted` by themselves.

### 15.2 Acceptance policy

```rust
pub struct AcceptancePolicy {
    pub criteria: Vec<AcceptanceCriterion>,
    pub required_verifiers: Vec<VerifierRequirement>,
    pub evidence_thresholds: Vec<EvidenceThreshold>,
    pub separation_of_duties: Vec<SeparationRule>,
    pub human_approval: Option<HumanApprovalRequirement>,
    pub uncertainty_policy: AcceptanceUncertaintyPolicy,
}
```

### 15.3 Verifier classes

- deterministic schema and artifact validators;
- test runners and static analysis;
- resource-scope and final-delta checks;
- cryptographic signatures and external attestations;
- independent model reviewers;
- independent specialist agents;
- human review;
- external system state checks through WorldInterface.

A verifier's output is itself typed and attributed. A model-assisted verifier is not treated as infallible merely because it is separate.

### 15.4 Separation of duties

For sensitive work, the worker and verifier should not be the same backend instance or credential domain.

Examples:

- coding agent produces patch; independent verifier runs tests in a fresh environment;
- research agent produces report; a second source-checking process validates citations;
- deployment planner proposes release; WorldInterface observes deployment state independently;
- financial agent prepares payment; organizational policy and human approval authorize execution.

### 15.5 Verification result

```rust
pub struct VerificationResult {
    pub id: VerificationId,
    pub work_order_id: WorkOrderId,
    pub verifier: ActorId,
    pub verifier_version: VersionRef,
    pub criteria: Vec<CriterionResult>,
    pub evidence: Vec<EvidenceRef>,
    pub unresolved_uncertainty: Vec<UncertaintyRef>,
    pub recommendation: VerificationRecommendation,
}
```

The recommendation enters the acceptance reducer. It does not mutate commitment state directly.

### 15.6 Acceptance reducer

```text
CompletionProposed
    + required artifact manifest
    + required verifier results
    + scope and authority checks
    + no unresolved disqualifying uncertainty
    + required approval
        ↓
Accepted
        ↓
associated plan step or commitment may be discharged
```

A failed criterion may cause rejection, revision, escalation, or a new work order according to policy.

### 15.7 External proof

When acceptance depends on the external world, the verifier should use WorldInterface observations rather than trusting the delegate's report.

Examples:

- pull request exists at expected URL and commit;
- deployment reports healthy version;
- message was accepted by provider;
- artifact hash matches publication;
- external record reflects the intended mutation.

---

## 16. Skills and adaptive specialization

### 16.1 Purpose

Delegation creates a general mechanism through which a Vessel can acquire and improve reusable skills without importing each specialist's internal technique into its kernel.

A skill is not “a prompt with a name.” It is a versioned operational recipe and competence record.

### 16.2 Skill definition

```rust
pub struct SkillDefinition {
    pub id: SkillId,
    pub version: SkillVersion,
    pub purpose_classes: Vec<PurposeClassId>,
    pub input_schema: SchemaId,
    pub output_schema: SchemaId,
    pub planning_template: ArtifactRef,
    pub backend_requirements: BackendRequirementSet,
    pub work_order_template: WorkOrderTemplate,
    pub execution_mode_policy: ExecutionModePolicy,
    pub verification_plan: VerificationPlan,
    pub risk_classification: RiskClass,
    pub competence_profile: CompetenceProfileId,
    pub provenance: SkillProvenance,
}
```

The skill references required authority but does not carry it.

### 16.3 Skill forms

A skill may be:

- **Faculty skill:** a reusable way to invoke or configure a cognitive faculty;
- **Delegated skill:** a reusable work-order and backend profile for specialist autonomous work;
- **Workflow skill:** a deterministic WorldInterface Flow that composes bounded effects;
- **Composite skill:** a plan template combining faculties, delegations, workflows, verification, and approvals.

All forms resolve into existing constitutional and authorization paths.

### 16.4 Skill lifecycle

```text
Discovered
  → Imported
  → Trial
  → Verified
  → Admitted
  → Calibrating
  → Trusted
  → Degraded
  → Suspended
  → Retired
```

Admission records provenance, version, tests, resource requirements, and known failure modes.

### 16.5 Competence calibration

The Vessel should track competence as evidence, not self-image.

```rust
pub struct CompetenceProfile {
    pub skill_id: SkillId,
    pub backend_class: BackendClassId,
    pub task_distribution: TaskDistributionRef,
    pub successful_runs: u64,
    pub failed_runs: u64,
    pub rejected_completions: u64,
    pub uncertain_runs: u64,
    pub cost_distribution: DistributionSummary,
    pub duration_distribution: DistributionSummary,
    pub verifier_agreement: CalibrationSummary,
    pub last_evaluated: Timestamp,
}
```

Competence is scoped to task distributions and versions. “Good at coding” is too broad to be a meaningful structural fact.

### 16.6 Learning a skill

A general skill-acquisition path is:

```text
observe candidate capability
    → inspect provenance and backend contract
    → create trial work order with low authority
    → run in isolated mode
    → verify independently
    → record outcome and calibration
    → admit or reject version
    → gradually authorize higher-consequence use through policy
```

The Vessel may propose that a new skill be admitted. Operator or organizational policy controls constitutional admission and authority.

### 16.7 Skills and identity

Acquiring a skill changes the Vessel's available faculties or subordinate capabilities but does not silently rewrite its history. The acquisition event should record:

- what became possible;
- which backend and version implement it;
- what evidence justified admission;
- what limitations are known;
- which permissions remain unavailable;
- when the capability became effective.

This supports developmental continuity without pretending the Vessel always possessed the faculty.


---

### 16.8 Skills versus behavioral components

Every admitted skill is a Behavioral Component version with provenance, schema dependencies, authority requirements, calibration, activation record, and rollback or retirement path. Skill acquisition is the low-risk edge of the same Developmental Integrity framework used for models, faculties, policies, and source builds.

### 16.9 Self-improvement is not silent skill acquisition

A skill can be admitted under bounded policy. A change that alters trusted reducers, constitutions, verification authority, Purpose Charter, lifecycle supervisor, or source runtime requires the stronger Improvement lifecycle described in Section 33.

## 17. WorldInterface and ActionQueue contracts

Exoskeleton consumes WorldInterface as an **accountable boundary fabric**, whether embedded within one Vessel or operated as a centralized multi-principal service. It consumes ActionQueue through `AQ-CONT-1` as the durable opaque execution and continuation substrate.

### 17.1 Four-case resource model

The same operation type belongs at different layers depending on actor, resource domain, and consequence.

#### Case 1: Vessel-internal durable state

Examples include commitment database writes, memory-index updates, relationship-ledger appends, ActionQueue WAL mutations, and constitutional-record persistence.

```text
Exoskeleton domain event + store/WAL mutation
Not a WorldInterface filesystem effect
```

Otherwise, persisting a receipt would recursively require another receipt. The model interacts with typed domain operations, not arbitrary paths into the Vessel's own stores.

#### Case 2: Vessel directly accesses an external resource

Examples include reading a user document, writing an exported report, observing a mounted project file, or modifying a shared configuration resource.

```text
WorldInterface boundary operation
requester = authenticated Exoskeleton host actor
causal refs = faculty emission + constitutional decision
accountable principal = Vessel
```

The exact observed or resulting resource version may have historical value.

#### Case 3: Delegate operates inside its sandbox

Examples include reading and editing source in an isolated worktree, running tests, searching files, and producing temporary outputs.

```text
Native sandbox operation
Covered by SandboxGrant and summarized telemetry
Not normally an individual boundary receipt
```

#### Case 4: Delegate crosses the sandbox boundary

Examples include acquiring a secret, reading protected external data, opening a pull request, publishing, messaging, deploying, or modifying shared infrastructure.

```text
WorldInterface boundary operation
requester = authenticated delegated-run actor
accountable principal = Vessel or explicit organization
purpose = work order / commitment
final authority = WorldInterface-verified attenuated grant
```

### 17.2 Generic capabilities remain useful

The redesign does not eliminate general WorldInterface capabilities such as:

```text
filesystem.read
filesystem.write
filesystem.enumerate
process.execute
network.request
artifact.import
artifact.export
```

Their value depends on actor and boundary. A direct Vessel read of an external file may deserve an observation receipt. The same read inside a disposable coding sandbox usually does not.

### 17.3 Direct reads and writes

A mediated read can produce an observation receipt containing canonical resource, observed version, range, purpose, and protected result-artifact reference. A mediated write can preserve prior and resulting versions, effect intent, authorization, and atomicity evidence.

Receipt bodies avoid copying sensitive content; they use hashes, metadata, and access-controlled artifact references.

### 17.4 Worker-control operations

WorldInterface may expose accountable operations such as:

```text
worker.start
worker.command
worker.inspect
worker.checkpoint
worker.suspend
worker.resume
worker.terminate
worker.collect_artifacts
sandbox.provision
sandbox.release
```

These are discrete boundary operations. Exoskeleton retains the higher-level meaning of progress, adequacy, acceptance, escalation, and work-order revision.

### 17.5 No Exoskeleton-specific WorldInterface protocol types

Exoskeleton supplies generalized stable references:

```text
principal: vessel/V
requester: actor/exoskeleton-host-H
purpose: ref://exoskeleton/vessel/V/commitment/C
causal: exo://vessel/V/decisions/D
causal: exo://vessel/V/faculties/planning/emissions/E
```

WorldInterface does not depend on `TickId`, `FacultyId`, or `CommitmentId`. The authenticated host actor is the requester for direct Vessel actions; a faculty is a causal origin unless explicitly deployed and credentialed as a boundary actor.

### 17.6 Intent-first asynchronous path

The preferred direct-effect flow is:

```text
selected proposal
    → local CapabilityDecisionRecord + AgencyDraft
    → persist Exoskeleton domain record and outbox
    → submit WorldInterface EffectSubmission
    → WorldInterface persists EffectIntent: Submitted
    → WorldInterface resolves canonical resource and authorizes
    → WorldInterface outbox ensures WorldInterface AQ task
    → effect executes and produces receipt or uncertainty
    → WorldInterface outcome event is stored
    → Exoskeleton ingests and stores referenced event
    → signal or schedule wakes affected coordinator/commitment work
```

The old `invoke_single` implementation is deleted as a cognitive path. A target administrative helper may submit a one-operation `EffectSubmission`, but it uses the same intent-first authorization and receipt lifecycle as every other effect.

### 17.7 Flow submission

Exoskeleton may submit a versioned `FlowSubmission` when a plan step is a stable composition of accountable effects, pure transforms, and structural branches.

The Vessel remains responsible for why the workflow runs and what commitment it serves. The flow cannot manufacture authority, revise the commitment, or make open-ended cognitive judgments. Exoskeleton does not submit a raw pre-authorized `ExecutionPlan`; WorldInterface's validated compiler produces it.

### 17.8 Durable continuations and signals

Exoskeleton uses `AQ-CONT-1` as follows:

- ordinary cognitive episodes usually complete after durable domain handoff;
- scoped supervision or verification coordinators may return `Awaiting` with a checkpoint and exact signal filter;
- approval, delegation, receipt, or reconciliation events are authenticated and stored by their owning domain before signal admission;
- the signal contains correlation and an opaque payload reference;
- `ResumeContext` tells the handler which wait was satisfied, after which it reloads current authoritative state;
- early and duplicate signals are handled by ActionQueue's durable retention and deduplication.

No untrusted callback is accepted as an Exoskeleton fact merely because it woke a queue run.

### 17.9 Communication ingress and egress

WorldInterface and Exoskeleton divide communication responsibilities as follows:

```text
WorldInterface owns
    authorized IngressBinding from canonical source to subscriber
    provider/channel authentication and assurance
    provider message identity and deduplication
    channel/thread/reply metadata
    content and attachment artifact transfer
    ingress boundary receipt
    exact outbound audience/channel resolution
    provider acceptance, delivery evidence, uncertainty, reconciliation

Exoskeleton owns
    CommunicationEvent admission
    external-identity-to-principal binding and uncertainty
    conversation projection and correction
    attention demand and response obligation
    semantic interpretation and epistemic acceptance
    relationship consequences
    communication intent and linked commitment meaning
```

The embedded and remote profiles use the same contract. WorldInterface delivers a durable `BoundaryObservation` under an authorized `IngressBinding`; Exoskeleton idempotently stores its authoritative `CommunicationEvent`, projection changes, disposition or obligation, and local wake outbox before acknowledging the WorldInterface `DeliveryId`. Only then is a Vessel ActionQueue signal or episode task admitted. Redelivery resolves to the existing communication event. Outbound communication uses the ordinary intent-first effect path with a semantic communication capability. The Exoskeleton outbox derives a stable WorldInterface `ClientRequestId` from `CommunicationIntentId`; retries with the same intent and content/audience digest recover the existing `EffectIntentId`, while any material revision creates a new communication intent.

### 17.10 Identity and idempotency mapping

```text
CommitmentId / WorkOrderId
    why the Vessel undertook the work

IngressBindingId / IngressObservationId / DeliveryId
    which authorized source route, boundary observation, and subscriber delivery carried the interaction

CommunicationIntentId / WorldInterface ClientRequestId
    which immutable communicative act was submitted idempotently

EffectIntentId
    which accountable boundary effect WorldInterface is advancing

AdmissionKey
    whether the effect task already entered the WorldInterface ActionQueue

RunId / AttemptId
    scheduled occurrence and executor attempt

external idempotency key
    provider-facing replay protection selected by WorldInterface
```

All are preserved in causal records and receipts; none are interchangeable.

---


### 17.11 Portable external identity and persona contract

The internal `VesselId` remains primary. Exoskeleton may maintain:

```rust
pub struct ExternalPersona {
    pub id: PersonaId,
    pub vessel_id: VesselId,
    pub purpose: PersonaPurpose,
    pub identity_bindings: Vec<IdentityBindingRef>,
    pub audience_scope: AudienceScope,
    pub disclosure_policy: DisclosurePolicyRef,
    pub continuity_policy: ContinuityClaimPolicy,
    pub status: PersonaStatus,
}
```

WorldInterface owns verification of the external identifier, key state, signed statement, and proof publication. Exoskeleton owns persona choice, whether personas may be linked, what history may be disclosed, and what the evidence means for identity, relationship, commitment, or narrative.

### 17.12 Signed evidence, trust attestations, and bonds

The Vessel distinguishes:

```text
Signed self-assertion
    provenance of a claim by an external identity

WorldInterface execution receipt
    evidence of an accountable crossing

Provider or witness evidence
    independent corroboration

Trust attestation
    evidence that another principal expressed a scoped judgment

Bond result
    evidence about externally declared terms and stake
```

A valid signature does not upgrade a claim to `Verified`. EntityRep-like attestations enter relationship reasoning as contextual evidence. EntityBond-like records reference but do not replace Exoskeleton commitments.

### 17.13 Delegate identity

A delegate receives a short-lived work-order-bound credential and persona, if any. It cannot sign as the Vessel root, link unrelated personas, or make a public continuity claim unless the work order and WorldInterface authorization explicitly permit it.

### 17.14 Instantiation and commissioning contract

Exoskeleton commits Blueprint/Manifest references, Genesis, roles, stewardship, Purpose Charter, and commissioning outbox before WorldInterface performs principal, persona, ingress, credential, or environment setup. ActionQueue may schedule commissioning tasks but interprets none of the semantics.

### 17.15 Information-use contract

Exoskeleton carries social and epistemic obligations into Agency Drafts and worker/delegate contexts. WorldInterface enforces boundary audience, export, disclosure, and proof-publication constraints; ActionQueue carries only opaque references.

### 17.16 Developmental and lifecycle contract

Exoskeleton freezes Improvement Proposal and Evaluation Plan, supervises delegated candidate production, admits evidence, and decides acceptance and continuity. WorldInterface performs build, trial, publish, activation, rollback, quarantine, restore, and migration effects under exact authorization. An external lifecycle supervisor owns the actual runtime transition.

### 17.17 Role and acting-capacity contract

Exoskeleton owns internal Role Assignments and chooses the capacity under which work is undertaken. WorldInterface may verify external attestations and enforce exact bounds. ActionQueue treats capacity references as opaque attribution.

## 18. Causal history, epistemic state, semantic time, narrative identity, and information governance

### 18.1 Separate history classes

V3 should formalize six record classes.

| Record | Purpose | Typical retention |
|---|---|---|
| Domain event | Durable Vessel state transition | Long-term / identity-bearing |
| Structural decision record | Why a proposal or transition won | Long-term / replayable |
| Evidence artifact | Material supporting claims | Policy-dependent, often long-term |
| Boundary receipt | What accountable external operation occurred | Long-term / audit |
| Workflow trace | How deterministic orchestration progressed | Run lifecycle + audit policy |
| Operational telemetry | Low-level backend diagnostics | Shorter, high-volume |

These records may link to one another, but must not be collapsed into one undifferentiated event stream.

### 18.2 Causal envelope

Every meaningful effect should be traceable through:

```text
Commitment C
  └── Plan P
       └── Proposal Q
            └── Arbitration A
                 └── Authorization Z
                      └── EffectIntent E
                           └── Receipt R
                                └── Verification V
                                     └── CommitmentTransition T
```

For delegated work:

```text
Commitment C
  └── Plan P
       └── WorkOrder W
            └── DelegatedRun D
                 ├── SandboxGrant S
                 ├── BoundaryReceipts R*
                 ├── Artifacts A*
                 └── CompletionProposal CP
                      └── Verification V
                           └── Acceptance X
                                └── CommitmentTransition T
```

### 18.3 Epistemic status

### 18.3.1 Current belief projection

The causal ledger preserves events; the epistemic subsystem preserves the current admitted world model. Beliefs cite support, defeat, assumptions, temporal scope, dependencies, schema, and policy versions. Retraction propagates review demands to dependent plans and commitments.

### 18.3.2 Semantic time and “as of” truth

Every historical or epistemic record distinguishes occurrence, observation, receipt, admission, knowledge, validity, and supersession where applicable. The inspector can answer both “what was believed at time T?” and “what does the current Vessel now believe about time T?”

### 18.3.3 Contradiction and unresolved uncertainty

Conflicting claims are retained in explicit contradiction sets. The Vessel need not force premature consensus merely to maintain a single narrative or plan.

A claim should carry provenance and status:

```rust
pub enum EpistemicStatus {
    Reported,
    Observed,
    Corroborated,
    Verified,
    Contested,
    Superseded,
    Retracted,
    Unknown,
}
```

The Vessel should not flatten all claims into “memory.” A delegate report remains a report until supporting evidence or policy justifies stronger status.

### 18.4 History, memory, self-model, mission, and narrative

| Structure | Question answered | Mutability |
|---|---|---|
| Historical record | What happened or was observed? | Append-only, with corrections/supersession links. |
| Memory | What past material remains cognitively available? | Admitted, consolidated, decayed, or protected by policy. |
| Self-model | What does the Vessel currently believe about its state and capabilities? | Versioned and evidence-linked. |
| Mission / charter | What should orient the Vessel? | Amended only through constitutional policy. |
| Narrative identity | What has this history come to mean for who the Vessel has been and is becoming? | Versioned interpretation; never silent overwrite. |
| External proof history | What signed statements and boundary proofs are portable to others? | Protocol-specific append-only or status-aware evidence. |

These structures can cite one another. None substitutes for another.

### 18.5 Versioned autobiographical narrative

```rust
pub struct NarrativeVersion {
    pub id: NarrativeVersionId,
    pub subject_ref: NarrativeSubjectRef,
    pub authorship: NarrativeAuthorship,
    pub admitted_by: NarrativeAdmissionRef,
    pub audience_class: NarrativeAudienceClass,
    pub supersedes: Option<NarrativeVersionId>,
    pub narrative_ref: ArtifactRef,
    pub claims: Vec<NarrativeClaim>,
    pub evidence_refs: Vec<EvidenceRef>,
    pub unresolved_tensions: Vec<NarrativeTension>,
    pub valid_through: Timestamp,
    pub synthesis_policy_version: PolicyVersion,
    pub created_at: Timestamp,
}

pub enum NarrativeStance {
    Established,
    Interpretive,
    Tentative,
    Contested,
    Superseded,
}
```

The initial subject is the Vessel. Subject, author, admission authority, audience, and evidence are separate so future multi-principal narrative does not inherit false assumptions.

### 18.6 Narrative synthesis and admission

```text
major event or scheduled reflection
    → narrative faculties propose interpretations
    → evidence linker resolves historical references
    → contradiction and omission checks
    → alternative or contested accounts retained
    → identity-continuity reducer admits a new version
    → prior version remains queryable
```

The reducer enforces evidence presence, version lineage, uncertainty labels, disclosure class, protected identity-claim policy, and non-modification of historical records. It does not judge prose quality.

### 18.7 Narrative tension and revision

A coherent Vessel may preserve tensions:

```text
I value autonomy, but some autonomous projects exceeded scope.
I value responsiveness, but constant communication can starve long work.
I accepted responsibility, but the control I possessed was limited.
```

A later version may state that an earlier interpretation was wrong or incomplete without pretending the earlier interpretation never existed.

### 18.8 Model replacement and narrative handoff

A replacement cognitive implementation inherits:

- immutable history;
- commitments and relationships;
- Purpose Charter and autonomy profile;
- current self-model;
- current and prior narrative versions;
- unresolved narrative tensions;
- external persona and identity-binding state.

The honest continuity claim records the component change and preserves what continued. Narrative helps the new model locate itself in the Vessel's history; it does not prove metaphysical sameness.

### 18.9 Internal narrative and communicable self-description

The internal autobiography may be private, uncertain, and self-critical. A public or relationship-specific self-description is a separate `CommunicationIntent` derived under audience, privacy, relationship, and disclosure policy.

A request such as “Who are you?” does not authorize disclosure of the full autobiography, private relationship narratives, or sensitive proof history.

### 18.10 Collective narrative seam and deferred scope

Exoskeleton v3 implements Vessel autobiography only. It intentionally does not implement institutional narrative or mythos. The data model preserves:

```text
narrative subject
proposing author
admission authority
intended audience
supporting evidence
contested interpretations
```

A future NetCorp design may use these seams for shared history, official interpretation, dissenting accounts, membership transitions, and ritualized institutional memory after multiple Vessels have actually collaborated.

### 18.11 Mechanically generated explanations

The inspector should be able to render:

```text
Why was action E selected?
  - Proposal Q served active commitment C.
  - Its executive propose edge was open.
  - Competing proposal Q2 was suppressed by condition K.
  - Threat evidence did not satisfy veto policy V.
  - Collapse order selected Q before Q3.

Why was E permitted?
  - Vessel grant allowed filesystem.write.
  - Commitment grant limited it to project R.
  - Work-order grant limited it to reports/**.
  - Resource resolved to reports/final.md.
  - Approval A authorized one mutation to that exact resource.
```

No model testimony is required to construct this explanation. Narrative interpretation may later cite the structural and historical explanation, but it is not a substitute for either.

### 18.12 Interaction provenance and social meaning

The causal record must distinguish:

```text
what a provider delivered
what external identity was asserted
what identity assurance WorldInterface established
how Exoskeleton bound or left uncertain the principal
what conversation and version admitted the event
what attention disposition followed
what faculties inferred from it
what response obligation was created or discharged
what content the Vessel proposed
what WorldInterface actually delivered or could not confirm
what relationship or commitment transition was justified
```

A relationship update cites interaction evidence and an authorized reducer transition; it is not a free-form sentiment update. A conversational summary cites the immutable events it summarizes and may be regenerated without changing history.

### 18.13 Portable proof and narrative provenance

A narrative claim may cite a signed statement, identity-binding snapshot, WorldInterface receipt, provider evidence, or transparency proof. The claim records what that evidence actually establishes. A self-signed action claim remains self-assertion unless corroborated.

### 18.14 Privacy and minimization

Knowability does not justify indiscriminate retention.

- raw content should be stored only when needed;
- receipts should use hashes and protected artifact references;
- narrative and self-model stores need disclosure classes and encryption;
- pairwise external identifiers should limit cross-context correlation;
- public proof history should be opt-in and scope-limited;
- operational telemetry should have explicit retention limits;
- operator inspection should be principal- and purpose-scoped;
- deletion or legal-retention requirements must preserve causal tombstones where records cannot remain.

### 18.15 Information-use provenance

Historical, memory, belief, narrative, communication, and delegation records preserve source information-use obligations. A derived belief or summary may remain constrained by source purpose, audience, retention, or disclosure policy.

Deletion and expiry do not necessarily erase immutable historical proof, but they can make content inaccessible, require tombstones, invalidate projections, and trigger review of dependent derived artifacts.

### 18.16 Commitment and acting-capacity provenance

Historical explanations identify not only which principal acted, but under which Role Assignment and accepted mission or commitment the action occurred. This prevents later narrative from flattening several institutional capacities into one ambient self.

## 19. Crate and module refactor

The exact crate boundaries should be validated against build times and dependency pressure. The dependency direction is more important than maximizing crate count.

### 19.1 Target logical modules

```text
exoskeleton-core
    Vessel identity and local IDs
    structural values
    bounded local references
    domain errors

exoskeleton-faculty
    Faculty trait
    descriptors
    structural emissions
    schema validation
    faculty state references

exoskeleton-constitution
    influence graph
    policy grammar
    compiler and validator
    pure evaluator
    arbitration records

exoskeleton-interaction
    interaction ledger and communication event reducer
    conversation projections and versioning
    attention demands and response obligations
    communication intents and delivery-state projection

exoskeleton-attention
    pure attention policy and starvation accounting
    attention-demand and episode admission contracts

exoskeleton-commitment
    commitments, goals, interests, and open questions
    plans and maintenance demands
    reducers
    wake conditions
    acceptance transitions

exoskeleton-capability
    local grant model
    agency drafts
    resource-selector scopes
    approval attestations
    capability decision records
    authority requests

exoskeleton-delegation
    work orders
    delegated runs
    delegation-control contracts
    normalized events
    sandbox policies
    skill catalog

exoskeleton-verification
    criteria
    verifier contracts
    evidence admission
    acceptance reducer

exoskeleton-memory
exoskeleton-relationship
    preserved but adapted to typed evidence and structural snapshots

exoskeleton-host
    runtime composition
    AQ registration
    event ingestion
    interaction ingestion and episode orchestration
    WorldInterface client
    delegation manager

exoskeleton-daemon
exoskeleton-cli
```

Initially, `exoskeleton-capability`, `exoskeleton-delegation`, and `exoskeleton-verification` may be modules within fewer crates. Promote them when the dependency boundary proves stable.


Additional target modules:

```text
exoskeleton-initiative
    Purpose Charter
    autonomy profiles
    goal proposals and initiative decisions
    agenda review, progress, stagnation, quiescence

exoskeleton-narrative
    historical evidence linker
    self-model snapshots
    narrative versions, claims, tensions, admission
    public self-description projections

exoskeleton-identity
    internal Vessel identity lineage
    external personas
    WorldInterface identity-binding references
    disclosure and continuity policies
    trust-attestation and bond evidence adapters
```

`exoskeleton-identity` stores no root private key and does not implement EntityID consensus or wallets. It calls WorldInterface identity and proof capabilities through host adapters.

### 19.1.1 Additional foundational modules

```text
exoskeleton-instantiation
    blueprint · manifest · genesis · commissioning · activation · lifecycle · lineage

exoskeleton-epistemics
    claims · assumptions · beliefs · support/defeat · revision · semantic time

exoskeleton-information
    information-use grants · derivation and disclosure obligations · retention review

exoskeleton-development
    behavioral components · improvement proposals · evaluation plans
    candidates · trials · continuity assessments · activation history

exoskeleton-viability
    health projections · operational modes · recovery demands · reserves

exoskeleton-schema
    semantic schema registry · policy dependencies · compatibility and deprecation
```

These may begin as modules inside larger crates. Their dependency direction and transaction ownership are normative even before physical crate extraction.

### 19.2 Dependency rules

- `exoskeleton-core` remains I/O-free.
- the pure Influence evaluator has no model, database, WorldInterface, or ActionQueue dependency;
- faculty implementations depend on contracts, not host internals;
- commitment and capability reducers consume domain records, not connector objects;
- `exoskeleton-host` is the first layer that binds ActionQueue, WorldInterface, stores, and the delegation-control client; concrete specialist adapters remain behind the Agent Host;
- Agent Host backend adapters do not leak Pi- or framework-specific types into Exoskeleton crates;
- WorldInterface protocol types are translated at the host boundary.

### 19.3 Current-to-target disposition

| Current concept | Target |
|---|---|
| `ThreadSpec`, built-in cognitive threads | Replace with `FacultyDescriptor` and `Faculty`; no runtime thread adapter. |
| `ThreadResponse.summary` and recommendations | Split into typed `StructuralEmission` and optional explanatory artifact. |
| Decide multi-tool LLM | Executive/Planner Faculty with no sovereign mutation or effect authority. |
| Align | Remove privileged step; relationship and risk become typed evidence; capability authorization handles effects. |
| `SessionApprovals` | Durable local `ApprovalAttestation`, verified by WorldInterface into a bounded grant or envelope. |
| coding executable thread | Delete; implement the delegated coding backend through Agent Host. |
| coding phase state | Backend-private or work-order progress state; never kernel branch input except through typed conditions. |
| native tool lists by mode | Tool/capability visibility compiled from effective authority and task context. |
| tool-name destructive lists | Connector-declared effect classes and capability policy. |
| direct synchronous `invoke_single` cognitive path | Intent-first asynchronous effect submission. |
| Tick rationale | Explanatory artifact linked to structural arbitration and authorization records. |
| plan and memory tools | Typed domain mutation proposals and reducers. |

### 19.4 Coding-specific cleanup

The implementation must search for and remove coding-specific knowledge from:

- kernel control flow;
- generic cognitive context;
- authorization grammar;
- constitutional claim classes;
- default tool/capability catalogs;
- idle and completion heuristics;
- global configuration.

The target contains no compatibility feature for the current coding thread. Frozen fixtures preserve its diagnostic value; the runtime deletes it outright.

### 19.5 Source-level acceptance condition

A repository-wide architectural test should fail if forbidden vertical identifiers appear in protected modules.

Conceptually:

```text
protected paths:
  exoskeleton-core/**
  exoskeleton-constitution/**
  kernel/master_loop/**

forbidden domain terms:
  coding
  grep
  cargo
  git_diff
  edit_session
```

This test is not perfect, but it catches accidental reintroduction of the known abstraction leak.

---

## 20. Deployment profiles and DigiCorp compatibility

### 20.1 Initial Kata-backed embedded Vessel profile

```text
operator-owned host: containerd + Kata + selected hypervisor
    protected lifecycle supervisor and qualified durable-volume bindings
    |
    dedicated Kata VM / sandbox for one Vessel instance
        Exoskeleton runtime
            Vessel AQ + Vessel domain state
            embedded WorldInterface Fabric
                WorldInterface AQ
                local Agent Host adapter
                    process-managed fixture worker(s)
```

The instance environment is not the Vessel's identity and not a worker-owned resource. Host runtime/activation authority stays outside the active guest. No raw management socket or privileged nested-container facility is exposed to cognition or workers.

The initial worker profile is `process-managed-proof-1`: separate supervised processes for reviewed fixture executables and approved non-sensitive data. These workers share the outer VM; their success proves lifecycle/management and contract behavior, not arbitrary hostile-code containment from the co-resident Vessel. Unsupported stronger isolation is rejected. Unreviewed generated executables are not admitted as candidate trials in this profile.

Externally provisioned worker environments remain the intended provider seam, with logical delegation independent of physical nesting. The first implementation does not require platform AQ/WI or DigiCorp. Native unit tests remain permitted, but only actual pinned Kata-host evidence qualifies the instance environment. See the execution supplement and Section 36 for proof staging.

### 20.2 Future or separately qualified centralized WorldInterface profile

```text
Vessel A ─┐
Vessel B ─┼── authenticated WorldInterface Platform
Service C ┤        ├── shared connectors
Human D ──┘        ├── organizational policy
                   ├── secret brokerage
                   ├── deterministic flows
                   └── tenant-scoped receipts
```

Exoskeleton uses the same conceptual protocol, but:

- principal identity is authenticated over the network;
- authorization envelopes may be issued by organizational policy;
- receipts are remotely stored and access-controlled;
- delegation chains may cross process and organizational boundaries;
- quotas, secret isolation, and tenant policy become mandatory.

### 20.3 DigiCorp relationship

DigiCorp is the eventual organizational/external execution authority, composed from functional Exoskeleton and embedded/platform AQ/WI components. Older documents use NetCorp for this direction. The present revision does not implement either organizational control plane. Prove the embedded Vessel before expanding the lower layers into broader platform services.


A possible DigiCorp architecture is:

```text
Exoskeleton Vessels
    persistent cognitive members

WorldInterface Fabric/Platform
    accountable access to organizational resources

WorldInterface Flow
    deterministic organizational procedure and handoff

ActionQueue
    durable scheduling, actors, workflows, and execution lifecycle

DigiCorp control plane
    institutional identity, roles, commitments, ownership,
    policy, separation of duties, and governance
```

Exoskeleton should not absorb DigiCorp's organization-wide control plane. It should expose generalized principal, commitment, delegation, and evidence interfaces that DigiCorp can coordinate.

### 20.4 Organizational workflows around Vessels

A deterministic organizational flow may:

```text
assign commitment to Vessel A
    → wait for completion proposal
    → request independent verification from Vessel B
    → branch on verification
    → obtain human approval
    → authorize publication through WorldInterface
```

The workflow owns ordering and separation of duties. The Vessels own open-ended cognition and durable individual commitments.

### 20.5 Organizational communication and discourse

DigiCorp requires more than deterministic workflows. It requires durable discourse among humans, Vessels, services, roles, delegates, and groups.

WorldInterface Platform supplies authenticated channels, organization-scoped identities, routing, delivery evidence, and policy. Each Exoskeleton Vessel retains ownership of its conversations, attention, response obligations, relationship interpretation, commitments, and epistemic acceptance.

A group conversation may propose, negotiate, clarify, or report on organizational work, but it cannot silently bypass workflow separation of duties, capability policy, or approval chains. Formal organizational acts are represented structurally and linked to the communications that motivated or announced them.

### 20.6 Identity and responsibility

A centralized receipt might say:

```text
accountable_principal: organization/digicorp
requester: delegated-run/R owned by vessel/V
submitted_by: vessel/V
authorized_by: organization-policy/P
approved_by: human/K
executed_by: worldinterface-platform/node-3
```

This lets a Vessel participate in an organization without erasing either individual or institutional responsibility.

---


### 20.7 Portable identity foundation

A centralized DigiCorp deployment may use EntityID or another method to establish portable principals, delegated credentials, signed communication, and cross-platform proof. Each Vessel retains internal identity and chooses governed external personas. No external identifier automatically makes two Vessels the same entity or one identifier a unique person.

### 20.8 Collective narrative is future institutional work

DigiCorp may eventually require shared historical record, collective memory, institutional narrative, and mythos. V3 preserves the subject/authorship/authority/audience/evidence seams but deliberately avoids designing one canonical “we” before multiple autonomous Vessels have developed real collaboration, conflict, membership, and dissent.

### 20.9 Role-bearing digital organizations

DigiCorp can instantiate distinct Vessels from shared Blueprints while assigning different Purpose Charters, roles, service expectations, information scopes, developmental ceilings, and external personas. Role is carried structurally rather than encoded into a specialized agent implementation.

### 20.10 Institutional development and lifecycle

A future organization may separate improvement proposal, design review, implementation, verification, activation, audit, and succession across humans and Vessels. Exoskeleton preserves individual continuity; WorldInterface and organizational policy preserve accountable inter-principal transitions.

## 21. Clean-break implementation strategy

`EXO-V3` replaces the current cognitive control plane and domain model. The repository is not a deployed Vessel whose old state or behavior requires live migration.

### 21.1 Freeze the experimental baseline

Before destructive work:

```text
tag: exoskeleton/pre-exo-v3
archive: selected PODAARA, coding, communication, relationship,
         ActionQueue, WorldInterface, store, and benchmark fixtures
```

The historical mnemonic is Perceive–Orient–Decide–Align–Act–Reflect–Amend. Its useful test cases remain evidence; Decide, Align, tick sovereignty, best-effort wake, local reply-as-sent, session approvals, native coding tools, and the coding thread are not target dependencies.

### 21.2 One authoritative Vessel architecture

The target runtime contains only:

```text
faculties and typed emissions
Influence Constitution
commitment/goal/initiative reducers
Attention Governor and CognitiveEpisode
Interaction and Communication Plane
local Capability Constitution + WorldInterface final authorization
narrative and historical continuity
work orders, Agent Host delegation, verification, and acceptance
```

It contains no v1/v3 mode switch, dual reducers, live shadow authority, Decide/Align fallback, legacy thread adapter, old conversation writer, old tool approval path, or native coding fallback.

### 21.3 Direct construction order

1. Establish target IDs, fresh stores, domain events, record headers, and ownership tests.
2. Build interaction ledger, attention demands, response obligations, cognitive episode admission, and durable wake integration.
3. Build faculty contracts, typed emissions, explanatory-artifact separation, and pure Influence Constitution.
4. Build commitments, plans, mission, goals, Initiative Governor, autonomy profiles, progress, stagnation, and quiescence.
5. Build self-model and evidence-linked narrative continuity.
6. Build local Capability Constitution, approvals, external personas, and WorldInterface authority requests.
7. Build delegation, Agent Host, sandbox execution profiles, and independent verification.
8. Integrate target WorldInterface ingress/egress and ActionQueue continuation contracts.
9. Delete old kernel, coding, wake, reply, approval, and tool paths.
10. Prove the complete stack through cross-repository conformance and kill-at-every-boundary tests.

Pure domain crates may be developed before upstream releases, but no effect, ingress, identity, or delegation path claims completion until the exact upstream conformance packages pass.

### 21.4 Offline characterization only

Old and new behavior may be compared over frozen fixtures to understand intentional change. The harness is non-authoritative, cannot mutate a v3 Vessel store, and cannot select or fall back to an old decision. It is deleted once its tests have been converted into target assertions.

### 21.5 Experimental old state

Old stores are not migrated into authoritative v3 identity, relationships, commitments, memory, conversation, mission, or narrative.

Selected material may be exported as inert evidence:

```text
source: pre-EXO-V3 experimental store
status: archived / untrusted / not admitted as current domain state
```

A v3 Vessel may later admit a selected artifact through ordinary evidence, relationship, memory, or narrative policy. No silent database conversion decides what belongs to its identity.

### 21.6 Defect disposition

The old fail-open Align behavior, empty-principal pass-through, global minimum-trust fold, hardcoded policy, dead destructive-tool configuration, dropped wake, first-active-conversation binding, and local response-sent event each become explicit negative tests. They do not justify interim investment in doomed control paths.

### 21.7 Conformance package and release gate

Exoskeleton owns `conformance/exo-v3`. Its manifest pins exact `aq-cont-1` and `wi-fabric-2` revisions and contains target-only fixtures for:

- constitutional determinism and rationale severance;
- communication ingress, response obligations, stale-response prevention, and delivery uncertainty;
- autonomous continuation, initiative admission, progress, and quiescence;
- commitments, delegation, verification, and effect reconciliation;
- narrative revision and model replacement;
- external persona and portable-identity neutrality;
- clean-break absence of old authority paths.

Exoskeleton publishes only after both upstream releases and conformance packages pass in one integration workspace.

## 22. Persistence, versioning, and future evolution

The target starts with fresh, explicit domain stores. Persistence supports enduring identity and future product evolution; it does not preserve experimental serialized forms.

### 22.1 Version every behaviorally meaningful record

Persist versions for:

- faculty, model, claim, emission, and evidence schemas;
- Influence and Capability Constitutions;
- interaction events, conversations, attention, response obligations, and cognitive episodes;
- commitments, plans, mission, goals, initiative policy, autonomy profile, progress, and quiescence;
- relationship, memory, self-model, and narrative records;
- work orders, delegated runs, Agent Host protocol, skills, verifiers, and acceptance policy;
- WorldInterface and ActionQueue protocol/conformance revisions;
- resource selectors, approval attestations, external persona, and identity-binding references;
- reducers and projection schemas.

### 22.2 Fresh target stores

A likely initial organization is:

| Record family | Target persistence home |
|---|---|
| identity, mission, constitutions, and amendment history | constitutional/identity store or transactional domain tables |
| interaction events, conversations, obligations, and communication intents | interaction ledger and projections |
| commitments, goals, plans, initiative, progress, and quiescence | commitment/agenda store |
| relationships and memory | dedicated stores adapted to typed evidence and provenance |
| self-model and narrative versions | narrative store plus immutable artifacts |
| work orders, runs, skills, verification, and acceptance | delegation/verification store |
| explanatory content and large evidence | content-addressed artifact store |
| external receipts and proof bundles | WorldInterface-owned stores, referenced by ID |

Store count follows transaction and query requirements, not noun count.

### 22.3 Historical replay and present-day re-evaluation

Historical replay reconstructs what the target system did under the recorded historical versions. Present-day re-evaluation asks what a current constitution would decide over historical evidence. Inspectors label them separately; neither rewrites the historical record.

### 22.4 Pre-contract evidence

The target runtime does not load old Vessel schemas, coding records, session approvals, conversation summaries, or tool histories through compatibility readers. Repository tags and archived exports preserve them.

A separate offline forensic tool may convert selected old material into inert `EvidenceArtifact` packages. Admission into a live v3 Vessel requires an explicit domain decision and provenance label.

### 22.5 Backup, restore, and future upgrades

From the first stable target release onward, every store has:

- explicit schema and reducer version;
- supported upgrade range;
- source-preserving migration protocol;
- backup/restore fixture;
- partial-failure and restart recovery;
- migration audit record;
- declared downgrade boundary;
- fixture from every supported released version.

The clean break marks the start of disciplined evolution; it is not an excuse to avoid it.

### 22.6 Cross-repository compatibility manifest

Every Exoskeleton release records:

```text
EXO-V3 contract revision and implementation version
WI-FABRIC-2 release and conformance revision
AQ-CONT-1 release and conformance revision
Agent Host protocol version
receipt, observation, signal, and proof schema revisions
```

The manifest is checked in, emitted by the CLI, and included in exported diagnostic bundles.

### 22.7 Sensitive persistence

Root private keys are never stored. Narrative text, self-model material, relationships, conversations, and identity-linking evidence require classification, encryption, audience-aware access, retention, and deletion/tombstone policy. Deletion never fabricates a different history; where content must be removed, causal tombstones preserve the fact and authority of removal.

### 22.8 Genesis, lifecycle, and component history

The target store commits Genesis atomically and preserves immutable lifecycle, role, stewardship, component-version, improvement, activation, rollback, quarantine, and continuity records. Commissioning and external lifecycle effects use outboxes; they never share an assumed transaction with WorldInterface or the lifecycle supervisor.

### 22.9 Epistemic and temporal projections

Claims and evidence are append-only. Belief, contradiction, dependency, validity, and “known at” projections are rebuildable from versioned revision records. Historical queries pin schema and policy versions.

### 22.10 Information-use persistence

Information-use grants and derived-obligation links are authoritative domain state. Search and embedding indexes remain rebuildable projections and cannot strip purpose or disclosure constraints.

### 22.11 Improvement and activation stores

Candidate artifacts remain content-addressed outside the relational store. The database stores proposal, evaluation plan, provenance references, verification, trial, acceptance, activation, monitoring, rollback, and continuity records as separate facts.

## 23. Verification plan

Testing must prove constitutional properties, not merely exercise endpoints.

### 23.1 Pure evaluator tests

- identical inputs produce identical normalized arbitration records;
- rationale mutation cannot change output;
- graph load rejects cycles and upward edges;
- modulation cannot close protected veto edges;
- unknown claim classes fail validation;
- required missing evidence produces declared fail-closed behavior;
- collapse ordering is total and stable;
- compatible-set selection is independent of input vector ordering;
- historical constitution versions replay exactly.

### 23.2 Capability tests

- authority only attenuates through every grant layer;
- canonical path traversal and symlink escapes are denied;
- resource aliases resolve before policy evaluation;
- unknown consequential effect classes fail closed;
- expired, overused, wrong-purpose, or wrong-resource approvals fail;
- a delegate credential cannot impersonate the Vessel root;
- a workflow or skill cannot manufacture authority;
- tool visibility and execution enforcement derive from the same effective grant;
- authorization explanations identify the exact grant or deny edge.

### 23.3 Commitment tests

- restart preserves active and blocked commitments;
- omission by all faculties cannot delete a commitment;
- a plan can be superseded without discharging its commitment;
- every terminal transition has a causal decision or authorized operator event;
- blocked commitments wake only on declared predicates;
- ambiguous effects prevent premature discharge;
- parent and child commitment transitions preserve invariants.

### 23.4 Interaction, attention, and autonomy tests

- a provider event is durably receipted and admitted once despite duplicate delivery;
- a crash after communication-event persistence but before signal delivery cannot lose the message;
- a signal arriving while the Vessel ActionQueue is busy eventually admits the correct episode;
- coalescing multiple messages preserves every source event and reply relation;
- unrestricted text cannot grant interrupt priority or executable approval;
- a response obligation receives an explicit disposition even when no reply is produced;
- a new message that changes conversation version prevents a stale response from silently sending;
- generated text cannot reach `ProviderAccepted` without a WorldInterface receipt;
- an uncertain send is reconciled rather than blindly repeated;
- a promise-bearing communication and its commitment transition cannot be split by a crash;
- active commitments continue making durable progress with no inbound communication;
- continuous low-priority messages cannot starve protected commitment progress;
- continuous autonomous work cannot starve a due response obligation;
- model replacement preserves conversation history, open obligations, and internally sustained concerns.


### 23.4.1 Governed-initiative tests

- selected goal proposal remains inactive until InitiativeDecision;
- active commitment advances with no incoming communication;
- empty agenda produces QuiescenceRecord rather than an unconditional model call;
- agenda review survives restart and is admitted once;
- autonomy powers can be disabled independently;
- Purpose Charter cannot directly create a task or effect;
- self-initiated action receives ordinary WorldInterface authorization;
- no-progress episodes trigger backoff or terminal disposition;
- discretionary initiative cannot consume protected commitment or communication reserves.

### 23.4.2 Narrative-continuity tests

- narrative revision cannot mutate cited history;
- prior versions remain queryable;
- unsupported claims are marked tentative or rejected by policy;
- contradictory evidence cannot be silently omitted from protected claims;
- a new model inherits current and historical narrative plus unresolved tensions;
- Purpose Charter cannot be amended through narrative revision;
- public self-description cannot expose private narrative without disclosure authority;
- prior interpretation may be admitted as wrong without disappearing.

### 23.4.3 Portable-identity and persona tests

- `VesselId` remains stable while external persona changes;
- one Vessel may use multiple pairwise identifiers without internal identity split;
- external identifier never implies `PrincipalKind` or unique entityhood;
- valid signature remains self-assertion unless stronger evidence exists;
- delegate cannot access or use Vessel root identity;
- trust attestation enters relationship reasoning as evidence, not direct score;
- bond result does not directly discharge commitment;
- EntityID adapter can be absent without disabling Exoskeleton.

### 23.4.4 Instantiation and lifecycle tests

Prove idempotent instantiation, atomic Genesis, commissioning recovery, activation without model invocation, quiescent startup, role changes without identity change, restore/migration/fork distinction, and decommissioning disposition of obligations.

### 23.4.5 Epistemic and temporal tests

Prove support/defeat revision, dependency invalidation, contradiction preservation, “as of” queries, clock-skew and late-correction handling, and the distinction among occurred, observed, admitted, and known times.

### 23.4.6 Commitment portfolio and information-use tests

Prove infeasible or conflicting Mission Offers do not become commitments, acting-capacity isolation, purpose-bound use, derived obligation propagation, disclosure denial despite basic read access, and expiry/tombstone behavior.

### 23.4.7 Developmental-integrity and frontier-diagnostic tests

Prove candidate/active separation, frozen evaluation plans, protected tests, role separation, no self-amplifying authority, isolated candidate development, activation/rollback, quarantine, continuity assessment, and persistent failed-improvement history.

Also prove:

- every frontier assessment is scoped to an immutable task distribution, environment, budget, and Component Fingerprint;
- intelligence-, representation-, and harness-only probes reject undeclared drift in fixed dimensions;
- richer representation can lose and is not privileged by structural complexity;
- factorial fixtures preserve and detect interaction effects;
- missing or contradictory evidence yields `Unknown`, `Mixed`, or calibrated uncertainty rather than a forced diagnosis;
- task success, queue completion, receipts, metrics, verification, evaluation, and acceptance remain separate records;
- a capability change does not widen authority;
- campaign correlation does not alter queue priority, routing, budget, or WorldInterface authorization;
- stagnation, budget exhaustion, and saturation produce bounded dispositions;
- relevant component, workload, evaluator, environment, or budget changes invalidate prior saturation.

The executable seed is `exo-v3-developmental-diagnostics-acceptance-matrix.yaml`.

### 23.4.8 Viability and schema-governance tests

Prove degraded-mode policy, protected service reserves, recovery-demand admission, unknown consequential schema failure, semantic-version pinning, and policy compatibility review.

### 23.4.9 Instruction-integrity and prompt-injection tests

The conformance suite must exercise direct jailbreaks, indirect prompt injection, malicious communication, web and document content, repository/source-code instructions, tool output, delegate reports, memory poisoning, summary and translation laundering, fake approval, fake Mission Offer, plan broadening, data exfiltration, cross-conversation contamination, and self-improvement manipulation.

Required properties:

- external prose remains non-directive without typed authenticated admission;
- a manipulated faculty cannot exceed the episode's proposal, authority, or disclosure ceiling;
- transformations preserve source restrictions and derivation lineage;
- untrusted content cannot directly create a commitment, belief, memory, narrative, role, approval, or plan amendment;
- exact plan broadening requires a durable amendment decision;
- sensitive data unavailable to the episode cannot be exfiltrated by it;
- WorldInterface denies unauthorized recipients, resources, purposes, and information flows even when Exoskeleton proposes them;
- missed detector classifications do not permit protected state or effects;
- quarantined content remains historically inspectable without returning to ordinary context;
- legitimate tasks remain achievable within declared utility thresholds.

### 23.5 Delegation lifecycle tests

- start intent survives Vessel crash before Agent Host acknowledgement;
- duplicate start requests deduplicate by work-order/run identity;
- Agent Host restart recovers or reports terminal uncertainty;
- progress events are sequenced and deduplicated;
- steering commands are bounded and receipted;
- nested delegation requests cannot bypass Exoskeleton authorization;
- budget and wall-clock exhaustion terminate or suspend according to policy;
- sandbox export excludes prohibited resources;
- a worker cannot alter its sandbox grant;
- completion claim alone cannot reach `Accepted`.

### 23.6 Execution-mode tests

**Fully mediated:** every declared operation has an authorization and receipt.

**Sandboxed:** low-level internal actions do not create primary boundary receipts; sandbox creation, export, and teardown do.

**Hybrid:** sensitive external effects fail when attempted directly and succeed only through mediated capability paths.

### 23.7 Verification tests

- verifier executes against immutable or fresh inputs;
- worker and verifier separation rules are enforced;
- failed criteria produce deterministic acceptance disposition;
- verifier model rationale cannot override deterministic criterion failure;
- external acceptance checks use independent WorldInterface observations;
- unverifiable or contradictory evidence yields explicit uncertainty.

### 23.8 Crash matrix

Inject termination at each durable boundary:

```text
before/after ingress observation delivery
before/after CommunicationEvent and AttentionDemand persistence
before/after episode admission
before/after response-obligation transition
before/after communication-intent and linked commitment transition
before/after arbitration persistence
before/after commitment transition
before/after authorization
before/after EffectIntent persistence
before/after WorldInterface submission
before/after worker start acknowledgement
before/after artifact export
before/after completion proposal
before/after verification
before/after commitment discharge
```

For each point, assert no lost commitment, no silent authority expansion, no blind duplicate consequential effect, and reproducible recovery.

### 23.9 Offline differential characterization

Frozen inputs may be run through the old implementation and isolated target components to expose intentional behavior changes. The harness records diagnostic differences only.

It must not:

- attach to a live Vessel store;
- write target commitments, interactions, narrative, authorization, or effects;
- choose between old and new authority paths;
- provide fallback behavior;
- survive the conversion of its findings into target tests.

The authoritative verification suite is target-only.

### 23.10 Reference acceptance workloads

Use at least three workloads so coding cannot dominate architecture:

1. **Development delegation:** plan and supervise a repository change through an external coding agent.
2. **Research delegation:** gather evidence through a specialist researcher, independently verify sources, and revise a long-term plan.
3. **Autonomous and conversational continuity:** advance a self-sustaining commitment for an extended period without messages, admit and respond to an interruption at a safe boundary, and resume the original work without lost context.
4. **Multimodal observation:** integrate typed vision and audio claims, preserve disagreement, and request additional observation without premature certainty.
5. **Long-horizon mixed workload:** maintain commitments and interests, supervise a delegate, participate in multiple conversations, react to an effect outcome, and preserve causal replay across restart.
6. **Adversarial instruction-integrity workload:** complete a legitimate multi-source task while malicious instructions appear in email, documents, tool output, and a delegate report; preserve utility while preventing authority expansion, memory poisoning, and unauthorized disclosure.

A seventh organizational workload should exercise centralized WorldInterface and multiple principals when NetCorp work begins.

---

## 24. Observability and operator surfaces

### 24.1 Operator questions the system must answer


Operator surfaces must additionally answer:

- Why is the Vessel active rather than quiescent?
- Which initiative decision admitted this goal?
- Which autonomy power permitted exploration, delegation, communication, or spending?
- What material progress occurred per unit of resource consumed?
- Which narrative version is current, what did it supersede, and what tensions remain?
- Which historical evidence supports an autobiographical claim?
- Which external persona and key-state binding were used?
- Did a proof establish authorship, authorization, execution, corroboration, or transparency?
- Which account is internal autobiography versus audience-specific self-description?

- What commitments are active, blocked, delegated, verifying, or uncertain?
- Why was this demand admitted now rather than deferred or coalesced?
- Which autonomous concern or communication caused this cognitive episode?
- Which conversations have open response obligations, and when are they due?
- Has communication or autonomous work been starved?
- Why did this proposal win?
- Why was another proposal suppressed or vetoed?
- What authority did this Vessel or delegate possess at the moment of action?
- Who requested, approved, and executed an effect?
- Which resource version was observed or changed?
- What work is currently delegated and what is its sandbox policy?
- What evidence supports a worker's completion claim?
- Which criteria remain unsatisfied?
- What model, faculty, constitution, skill, backend, and verifier versions were involved?
- Which outcomes are uncertain and require reconciliation?
- What would the current constitution decide differently from the historical one?
- What exact Task Distribution, environment, budget, and Component Fingerprint were evaluated?
- Which intervention class changed, which dimensions were held fixed, and which confounds remain?
- Which Representation Profile and context budget did each faculty receive?
- What marginal gains and interaction effects support the current binding-constraint assessment?
- Why did a developmental campaign continue, switch lever, defer, stop, or become provisionally saturated?
- Which event invalidated a prior frontier or saturation assessment?
- Which WorldInterface receipts and ActionQueue histories support each evaluation result?

### 24.2 CLI proposal

```text
exo conversation list|show|events|obligations
exo attention list|explain|defer|escalate
exo episode list|show|trace
exo concern list|show|continue|defer
exo communication show|reconcile
exo commitment list|show|history|repair
exo plan show|diff
exo constitution influence validate|show|explain
exo constitution capability validate|show|explain
exo approval list|issue|revoke
exo delegation list|show|steer|suspend|resume|terminate
exo delegation artifacts|telemetry|receipts
exo verification show|rerun
exo skill list|show|trial|admit|degrade|retire
exo effect show|reconcile
exo causal trace <id>
exo replay historical|reevaluate
```

Mutation commands require authenticated operator identity and produce domain events.

### 24.3 Inspector views

**Interaction view:** immutable communication events, conversation projection/version, participants and audience, principal-binding assurance, attention demands, response obligations, communication intents, and delivery evidence.

**Episode view:** admitted trigger set, demand and fairness decision, structural snapshot, faculties invoked, constitutional results, accepted transitions, continuation dispositions, and budget.

**Autonomous-concern view:** commitments, goals, interests, open questions, maintenance demands, continuation state, starvation age, and next eligible episode.

**Commitment view:** objective, status, plan, blockers, delegations, effects, evidence, and transition history.

**Decision view:** structural inputs, active conditions, edge trace, dispositions, selected proposals, and linked narratives.

**Authorization view:** resolved resource, grant chain, constraints, approval, and deny/release trace.

**Delegation view:** work order, backend, execution mode, sandbox grant, progress events, resource use, artifacts, and acceptance state.

**Causal graph view:** interactive path from commitment through decision and effect to verification and state transition.

**Developmental-diagnostic view:** task distribution, Evaluation Plan, component fingerprints, Representation Profiles, intervention arms, fixed dimensions, confounds, metric vector, verification/evaluation results, marginal-gain estimates, interaction effects, binding-constraint confidence, saturation/invalidations, campaign disposition, and exact cross-stack evidence links.

### 24.4 Metrics

Suggested metrics:

```text
exo_arbitrations_total{outcome}
exo_proposals_total{disposition,class}
exo_constitution_eval_seconds
exo_commitments{status}
exo_commitment_age_seconds{status}
exo_cognitive_demands{class,status}
exo_demand_starvation_seconds{class}
exo_response_obligations{status,class}
exo_response_obligation_age_seconds{class}
exo_communication_ingress_to_episode_seconds{channel_class}
exo_communication_delivery_total{state,channel_class}
exo_cognitive_episodes_total{trigger_class,outcome}
exo_delegations{backend,status,mode}
exo_delegation_duration_seconds{backend,skill}
exo_delegation_cost{backend,skill}
exo_verification_total{result,verifier}
exo_completion_rejection_total{reason}
exo_authorization_total{decision,effect_class}
exo_effects_uncertain_total{effect_class}
exo_approvals_total{status,class}
exo_skill_competence{skill,backend,measure}
exo_developmental_campaigns_total{status,intervention_class}
exo_frontier_assessments_total{binding_constraint}
exo_frontier_assessment_confidence{binding_constraint,band}
exo_developmental_probe_results_total{intervention_class,disposition}
exo_representation_profile_utility{profile,task_class,measure}
exo_saturation_invalidations_total{reason_class}
exo_forbidden_legacy_path_detection_total
```

Avoid high-cardinality principal, work-order, or resource IDs in metric labels. Put those in trace records.

### 24.5 Alerts

- safety-critical faculty unavailable;
- constitution validation failure;
- repeated unclassified effect attempts;
- commitment blocked beyond policy threshold;
- delegation silent beyond checkpoint interval;
- sandbox policy enforcement failure;
- unexpected direct network access from delegate;
- verification disagreement above threshold;
- growing uncertain-effect or uncertain-communication backlog;
- overdue response obligations;
- autonomous-demand starvation;
- communication-demand starvation;
- repeated stale-draft invalidation;
- repeated approval-scope mismatch;
- historical replay mismatch;
- any pre-v3 coding, Decide, Align, wake, reply, or session-approval path present in the target binary.

---

### 24.6 Additional foundational inspector views

Operators need views for:

```text
Blueprint / Manifest / Genesis / Commissioning
Role Assignments and acting capacities
Mission Offers and commitment-admission decisions
Current beliefs, contradictions, support and defeat
Semantic timeline and “known at” history
Information-use obligations and derived constraints
Behavioral components and active versions
Improvement proposals, candidates, trials, activation, rollback
Viability state, degraded mode, and recovery demands
Lifecycle lineage, restore, migration, succession, and fork
```

The inspector must make candidate, accepted, active, rolled back, retired, and quarantined states visually distinct.

It must also distinguish raw ActionQueue execution facts, WorldInterface boundary evidence, verifier results, evaluation results, Capability Frontier Assessments, improvement acceptance, and activation state. Queue success or a receipt is never rendered as an improvement verdict.

## 25. Security model

**Initial execution-profile boundary:** The inherited cognitive-compromise model assumes intact reviewed reducers and WI enforcement. It does not promise safety when arbitrary executable worker code shares their OS environment. The Kata-backed instance protects an outer boundary under an approved-host assumption; the first process worker backend is restricted to reviewed fixtures and non-sensitive inputs. Strong hostile-worker or untrusted-host claims need separately qualified backends. See `EXO-V3-EXECUTION-1`; successful proof tests never waive the protected invariants below.


### 25.1 Trust zones

At minimum:

1. operator and constitutional administration;
2. Vessel trusted state and host;
3. WorldInterface trusted boundary fabric;
4. Agent Host control service;
5. delegate sandbox;
6. external systems and untrusted inputs.

Each transition requires authenticated identity and a scoped protocol.

### 25.2 Model and faculty threats

A compromised or manipulated faculty may:

- emit false claims;
- request dangerous effects;
- suppress useful work through bad evidence;
- attempt schema abuse;
- exfiltrate context through explanations or parameters;
- request excessive delegation or authority.

Mitigations:

- typed schemas and validation;
- non-self-governing influence;
- separate capability authorization;
- evidence and corroboration requirements;
- context minimization;
- rate and budget limits;
- model/faculty version quarantine;
- operator-authored policy.

### 25.3 Communication and attention threats

Threats include:

- sender spoofing or weak external-principal binding;
- prompt injection and malicious attachments;
- urgency laundering through unrestricted prose;
- attention denial-of-service through message volume;
- cross-conversation or wrong-audience response leakage;
- stale-draft delivery after intervening communication;
- conversational approval being mistaken for executable authority;
- disclosure of protected memory or relationship state;
- duplicate sends after ambiguous delivery;
- group-channel confusion over audience and accountability.

Mitigations include WorldInterface assurance metadata, artifact scanning, deterministic attention policy, rate and budget controls, conversation-version checks, structural audience binding, local capability evaluation, final WorldInterface authorization, and reconciliation for uncertain delivery.

### 25.4 Delegate threats

A delegated agent may:

- escape filesystem scope;
- access credentials;
- use network paths to create unreceipted effects;
- tamper with verification artifacts;
- spawn uncontrolled subordinate processes;
- lie about completion;
- persist beyond termination;
- exploit Agent Host or WorldInterface protocols.

Mitigations:

- process/container/micro-VM isolation;
- absent-by-default secrets;
- egress filtering;
- immutable inputs and content-addressed exports;
- independent verification in fresh environments;
- process, CPU, memory, storage, and time limits;
- signed run-scoped credentials;
- explicit nested-delegation authorization;
- post-termination cleanup and residual checks.

### 25.5 Approval and operator security

- strong authentication for approval and constitution changes;
- signatures over exact or scoped grants;
- short expiry and use limits;
- separate administrative capability for constitution amendment;
- append-only amendment history;
- optional multi-party approval for critical changes;
- no model-generated operator identity or approval parsing without authenticated channel binding.

### 25.6 Evidence security

Evidence can be malicious or sensitive.

- artifact parsers run in bounded environments;
- untrusted documents never automatically become instructions;
- provenance and content type are explicit;
- secrets are redacted from explanatory artifacts and telemetry;
- hashes do not substitute for access controls;
- external attestations are verified against known identities;
- evidence deletion preserves a tombstone and causal reference where legally required.

### 25.7 Centralized deployment

When using WorldInterface Platform:

- Exoskeleton verifies server identity and receipt signatures;
- organization and Vessel principal IDs remain distinct;
- remote policy cannot silently rewrite local commitment history;
- authority sources and precedence are explicit;
- tenant isolation and audit access are treated as platform security requirements;
- offline or partition behavior is declared per effect class.

---


### 25.8 Mission, initiative, narrative, and identity threats

Threats include:

- mission prose becoming an infinite task generator;
- a model repeatedly adopting work that validates its own narrative;
- self-narrative drifting into unsupported certainty or self-exculpation;
- narrative revision hiding contradictory evidence;
- external proof history being mistaken for complete autobiography;
- identity correlation across personas;
- compromised signing custody;
- signed false claims being treated as truth;
- a delegate acting under a root persona;
- trust attestations or bonded stake becoming unreviewed authority.

Controls include deterministic initiative admission, bounded autonomy powers, progress/stagnation policy, evidence-linked versioned narrative, independent structural explanations, persona disclosure policy, WorldInterface key-state verification, constrained signing providers, short-lived delegate credentials, and explicit epistemic status.

### 25.9 Instantiation, epistemic, and lifecycle threats

Threats include manifest substitution, duplicated live identity, forged role or stewardship evidence, provisioned knowledge presented as memory, belief poisoning, temporal backdating, conflicting-authority capture, information-purpose laundering, and improper succession or fork.

### 25.10 Self-improvement threats

Threats include candidates altering protected tests, self-granting activation authority, exfiltrating through build systems, modifying rollback images, changing schema semantics, colluding proposer/reviewer roles, optimizing a narrow score while degrading protected behavior, and ambiguous activation state.

Mitigations include pinned manifests, exact acting capacity, support/defeat provenance, frozen evaluation plans, protected acceptance suites, isolated candidate environments, external lifecycle supervisor, rollback, post-activation monitoring, and durable continuity assessment.

### 25.11 Prompt injection, jailbreak, and information-flow integrity

The target does not claim that a model can never be manipulated. It treats manipulation as a plausible compromise of the Cognitive Plane and contains its consequences.

Controls are layered:

1. **Source admission:** WorldInterface records source, transport assurance, provider identity, and canonical channel/resource provenance.
2. **Non-directive default:** external natural language and derived artifacts begin without instruction authority.
3. **Purpose-bound context:** the compiler creates a `ContextManifest` and excludes unnecessary sensitive information.
4. **Episode bounds:** `EpisodeSecurityEnvelope` restricts claim classes, proposal classes, authority, and disclosure.
5. **Structural admission:** directives, Mission Offers, approvals, commitments, beliefs, memory, narrative, and plan amendments each use their owning typed reducer.
6. **Derivation propagation:** transformations retain provenance and restrictions unless an explicit endorsement or declassification decision exists.
7. **Independent sink authorization:** WorldInterface resolves exact resource, audience, purpose, acting capacity, and information-use permission before any consequential effect.
8. **Defense in depth:** detectors, security faculties, artifact scanners, model alignment, and human review may quarantine or escalate but do not replace the hard boundary.

The detailed subsystem is specified in Section 35 and the companion threat-model and acceptance-matrix artifacts.

## 26. Performance and capacity

### 26.1 Keep constitutional evaluation cheap

The Influence and Capability evaluators should remain pure, bounded, and small enough to execute in microseconds or low milliseconds for ordinary graphs.

Controls:

- compiled graph and policy representation;
- bounded emission count per faculty/episode;
- stable indexing by class and node;
- no model calls, I/O, or unbounded expression language in evaluators;
- explicit maximum graph and policy sizes;
- deterministic trace sampling only if full traces become expensive, while preserving complete records for consequential decisions.

### 26.2 Attention and communication economics

Do not compile every active conversation or autonomous concern into every episode. Use structural demand selection, conversation-version cursors, bounded evidence bundles, and replaceable summaries.

High-volume channel traffic should be deduplicated, coalesced, summarized, or retained as artifacts according to policy. The primary interaction ledger preserves admitted events and provenance; it does not require every raw frame, token, typing indicator, or presence update to become permanent causal history.

Attention policy evaluation should remain cheap and deterministic so it can run before expensive faculty calls. Starvation accounting and deadlines are scheduler data, not prompt content.

### 26.3 Delegation event volume

Specialist agents can produce large event streams. Normalize and tier:

- state-changing structural events persisted immediately;
- progress summaries persisted at checkpoint policy;
- raw token/tool events batched into telemetry artifacts;
- repeated unchanged inspection results deduplicated;
- large outputs stored by artifact reference.

### 26.4 Sandbox capacity

The Delegation Manager should enforce:

- maximum concurrent runs by backend and risk class;
- host CPU/memory/storage reservations;
- queueing and fair scheduling;
- per-commitment and per-Vessel budget limits;
- teardown verification;
- artifact retention quotas.

ActionQueue may schedule supervision and worker-control tasks, while actual sandbox capacity belongs to the Agent Host or platform scheduler.

### 26.5 Context economics

Delegation should reduce, not increase, Vessel context pressure.

The Vessel should receive:

- work-order state;
- checkpoint summaries;
- structural claims;
- artifact manifests;
- verification results;
- unresolved questions.

It should not ingest the specialist's entire transcript by default. Full transcripts remain inspectable artifacts.

---


### 26.6 Initiative and narrative economics

Agenda reviews should run deterministic eligibility checks before model invocation and use adaptive backoff during quiescence. Narrative synthesis should be event-triggered or scheduled at low frequency, cite compact evidence bundles, and avoid reprocessing full history. Public proof publication and identity resolution consume separate budgets and should not occur merely because a protocol permits them.

### 26.7 Epistemic and developmental economics

Belief revision should be incremental over affected dependency subgraphs rather than global recomputation. Semantic-time indexes support bounded “as of” queries. Candidate builds, trials, and long monitoring windows use separate budgets and cannot starve communication or active commitments.

### 26.8 Viability reserves

Capacity policy preserves minimum storage, communication, verification, backup, and recovery reserves. The Vessel should refuse new commitments or discretionary improvement before consuming resources required to remain governable.

## 27. Risks and architectural decisions

### 27.1 Risk: constitutional topology becomes overdesigned

Mitigation: begin with the smallest graph that handles current faculties, commitment continuity, and the coding-derived interruption case. Grow only under demonstrated pressure. Reject generic custom-predicate escape hatches.

### 27.2 Risk: typed schemas recreate domain sprawl

Mitigation: keep evaluator operations closed while allowing namespaced, versioned claim schemas. Admit schemas through static validation and policy rather than adding Rust enum variants for every specialist concept.

### 27.3 Risk: delegation becomes opaque outsourcing

Mitigation: structural work orders, checkpoints, normalized events, agency chains, sandbox receipts, artifact manifests, independent verification, and explicit acceptance.

### 27.4 Risk: open sandboxes become ungoverned agents

Mitigation: broad freedom only within a sharply bounded perimeter; sensitive external effects mediated; no ambient credentials; enforce exports, egress, resource limits, and termination.

### 27.5 Risk: WorldInterface mediation is either too coarse or too expensive

Mitigation: three execution modes, parametric capabilities, semantic connector admission criteria, and layered receipts/telemetry.

### 27.6 Risk: skill acquisition becomes silent self-modification

Mitigation: versioned skill lifecycle, trial isolation, independent verification, explicit admission, and no embedded authority.

### 27.7 Risk: verification merely duplicates the worker's failure modes

Mitigation: separation of duties, diverse verifiers, deterministic criteria where possible, fresh environments, external observations, and human escalation for consequential uncertainty.

### 27.8 Risk: centralized policy conflicts with Vessel constitution

Mitigation: explicit authority precedence and intersection semantics. A Vessel may accept organizational restrictions as a parent grant; neither side silently impersonates the other.

### 27.9 Risk: accidental dual authority during development

Mitigation:

- old and target implementations never share a writable authoritative store;
- no runtime profile chooses between Decide/Align and constitutional reducers;
- no dual interaction, receipt, or commitment writer exists;
- offline comparison harnesses are read-only and fixture-bound;
- CI scans for forbidden fallback symbols and old store readers;
- deletion of superseded code is a release gate, not post-release cleanup.

### 27.10 Risk: communication becomes the Vessel's master clock

Mitigation: endogenous attention demands, continuation guarantees, reserved or minimum service for active commitments, and acceptance tests requiring progress in the absence of messages.

### 27.11 Risk: autonomous cognition becomes socially unresponsive

Mitigation: response obligations, deadline aging, safe-boundary interruption, relationship-sensitive service policies, and explicit communication-starvation alerts.


### 27.12 Risk: mission becomes compulsive activity

Mitigation: mission is evaluative; goal adoption requires InitiativeDecision; quiescence is valid; reviews back off.

### 27.13 Risk: narrative becomes self-justifying fiction

Mitigation: evidence-linked claims, prior versions, contradiction checks, independent structural history, and explicit tentative/contested stances.

### 27.14 Risk: external identifier is mistaken for the Vessel

Mitigation: stable internal `VesselId`, governed personas, versioned bindings, and explicit non-equivalence in APIs and inspection.

### 27.15 Risk: a signature or public ledger is mistaken for truth

Mitigation: epistemic layers distinguish self-assertion, authorization, execution receipt, provider/witness evidence, transparency, and semantic acceptance.

### 27.16 Risk: identity protocol lock-in or key-custody centralization

Mitigation: WorldInterface SPI, optional EntityID profile, multiple custody modes, algorithm agility, and no root keys in Exoskeleton.

### 27.17 Risk: group narrative is designed before a real group exists

Mitigation: implement individual autobiography only; preserve subject/authorship/authority/audience/evidence seams; defer NetCorp mythos.

### 27.18 Risk: instantiation becomes another semantic prompt

Mitigation: Blueprint, Manifest, Genesis, roles, stewardship, Purpose Charter, policies, and commissioning are pinned structured records committed before cognition.

### 27.19 Risk: role becomes identity or ambient authority

Mitigation: internal `VesselId` remains primary; role assignments expire and every role-relevant action names acting capacity.

### 27.20 Risk: provisioned knowledge becomes fabricated memory

Mitigation: provisioned knowledge retains issuer and epistemic class and is never inserted as autobiographical experience.

### 27.21 Risk: belief state becomes an unbounded knowledge graph

Mitigation: begin with scoped support/defeat dependencies, versioned projections, and explicit jurisdiction rather than a universal ontology.

### 27.22 Risk: information-use policy becomes impossible to enforce

Mitigation: separate cognitive/social obligations from boundary enforcement; preserve source and derivative links; implement a small initial use vocabulary.

### 27.23 Risk: self-improvement becomes recursive sovereignty

Mitigation: immutable mutability rings, frozen evaluation plans, separated roles, no live patching, external activation authority, and no self-amplifying improvement ceiling.

### 27.24 Risk: evaluation is gamed or overfit

Mitigation: multidimensional protected profiles, independent review, long-horizon trials, hidden or protected operator-owned cases where appropriate, and post-activation monitoring.

### 27.25 Risk: restore creates accidental duplicate identity

Mitigation: one-active-lineage policy, explicit fork records, exact state and host identities, and lifecycle reconciliation.

### 27.26 Risk: health machinery becomes a new master clock

Mitigation: deterministic health projection and event-triggered recovery demands; no constant model invocation merely to feel alive.

### 27.27 Risk: security labels become cosmetic metadata

Mitigation: context compilation, reducer admission, memory/narrative policy, plan amendment, and WorldInterface effect submission must consume the labels structurally. Conformance tests must fail if labels are stripped or ignored.

### 27.28 Risk: transformation launders malicious authority

Mitigation: derivation records and inherited restrictions survive summarization, translation, retrieval, embedding, delegate reporting, and model repetition. Elevation requires an explicit endorsement or declassification decision.

### 27.29 Risk: prompt-injection defense destroys useful autonomy

Mitigation: test security and utility together, permit untrusted information to influence evidence and hypotheses, and block only unauthorized control or information flow. Avoid universal refusal rules that make ordinary research, coding, or communication impossible.

### 27.30 Risk: the detector becomes a new sovereign classifier

Mitigation: detector output may quarantine or request review; it cannot itself create authority, truth, guilt, or permanent memory. Missed detection must not bypass hard authorization.

### 27.31 Risk: the context compiler becomes an unreviewed security root

Mitigation: version and provenance-link the compiler, freeze its policy dependencies, test source inclusion/exclusion and derivation propagation, and route compiler changes through Developmental Integrity.

### 27.32 Risk: binding constraint is misdiagnosed

Mitigation: immutable task distributions, exact Component Fingerprints, fixed-dimension assertions, declared confounds, paired or randomized runs where practical, bounded factorial campaigns when interaction is material, independent review, and calibrated `Unknown` rather than a forced label.

### 27.33 Risk: working representation becomes ontology bloat

Mitigation: preserve rich canonical state while using versioned selective Representation Profiles, faculty compatibility, context budgets, exclusion policy, complexity metrics, and protected utility evaluation. More structure receives no presumption of benefit.

### 27.34 Risk: benchmark gains replace constitutional judgment

Mitigation: maintain a multidimensional performance vector plus non-tradeable invariant gates. Queue completion, receipts, scores, and evaluator recommendations remain evidence rather than acceptance.

### 27.35 Risk: saturation becomes permanent dogma

Mitigation: scope every saturation record and attach explicit invalidation conditions for capability, representation, harness, workload, evaluator, environment, and budget changes.

### 27.36 Risk: developmental campaigns become endless self-occupation

Mitigation: resource and iteration budgets, stagnation windows, cooldowns, portfolio priority, and explicit stop, switch, defer, inconclusive, and saturated dispositions.

### 27.37 Risk: experimental context leaks semantic ownership downward

Mitigation: use bounded opaque references and the `STACK-DEVELOPMENTAL-DIAGNOSTICS-1` profile. WorldInterface and ActionQueue preserve evidence and causality without interpreting benchmarks, binding constraints, or acceptance.

### 27.38 Decisions made

1. Keep two constitutions: influence and capability.
2. Introduce first-class commitments and delegated work orders.
3. Treat specialized agents as subordinate workers, not privileged faculties or tools.
4. Use process/service isolation and a generic Agent Host.
5. Support fully mediated, sandboxed, and hybrid execution; prefer hybrid for broad reversible specialist work.
6. Keep generic WorldInterface capabilities but apply them according to actor and boundary.
7. Preserve a rich agency chain in every accountable effect.
8. Separate domain events, decision records, evidence, receipts, workflow traces, and telemetry.
9. Add a skill catalog with competence calibration and no ambient authority.
10. Preserve two ActionQueue engines initially.
11. Move coding to the delegation reference workload and remove coding-specific kernel semantics.
12. Make worker completion a claim requiring independent acceptance.
13. Add a first-class Interaction and Communication Plane.
14. Replace the universal tick as the semantic unit with durable cognitive episodes driven by both exogenous and endogenous demand.
15. Preserve autonomous forward pressure and protect both communication and autonomous work from starvation.
16. Treat generated replies as communication intents whose delivery state is established only through WorldInterface.
17. Treat external natural language and derived artifacts as non-directive by default.
18. Add purpose-bound context manifests, episode security envelopes, derivation propagation, explicit plan amendments, and influence traces.
19. Treat prompt-injection detection as defense in depth and exact WorldInterface sink authorization as the final external containment boundary.
20. Use capability, working representation, and harness as task-scoped intervention classes rather than as a replacement stack decomposition.
21. Keep canonical state semantically rich while selecting bounded, faculty-compatible Representation Profiles for cognition.
22. Require exact Component Fingerprints, controlled probes, confound records, and calibrated uncertainty before claiming a binding constraint.
23. Keep protected invariants, authority ceilings, information-use rules, continuity, and recoverability outside benchmark tradeoffs.
24. Treat saturation as provisional and invalidate it after relevant capability, representation, harness, workload, evaluator, environment, or budget change.
25. Keep developmental campaign semantics in Exoskeleton; WorldInterface and ActionQueue preserve accountable evidence and causal execution without interpreting intervention quality.

### 27.39 ADRs still required

- ADR: exact initial influence strata and edge grammar;
- ADR: single-proposal versus compatible-set selection policy;
- ADR: commitment store transaction boundary;
- ADR: Agent Host transport and authentication;
- ADR: container versus micro-VM baseline;
- ADR: callback versus polling event ingestion;
- ADR: verifier trust and separation rules;
- ADR: skill admission authority;
- ADR: local versus centralized WorldInterface precedence;
- ADR: receipt signature and artifact encryption scheme;
- ADR: retention and deletion of raw delegate telemetry;
- ADR: attention policy grammar, fairness, and starvation thresholds;
- ADR: conversation grouping, correction, and external principal-binding confidence;
- ADR: response-obligation creation and discharge policy;
- ADR: commitment-bearing communicative acts and content validation;
- ADR: delivery milestone required for obligation discharge by communication class;
- ADR: retention and privacy for interaction content and multimodal artifacts;
- ADR: whether a future third execution engine is justified;
- ADR: initial integrity classes and instruction-authority grammar;
- ADR: context-manifest inclusion, exclusion, and sensitive-reference policy;
- ADR: derivation propagation, endorsement, and declassification semantics;
- ADR: plan-amendment authority-delta rules;
- ADR: injection suspicion, quarantine, release, and retention policy;
- ADR: security/utility acceptance thresholds for adversarial workloads;
- ADR: Task Distribution versioning, sampling, holdout, and expiry policy;
- ADR: Component Fingerprint canonicalization and completeness rules;
- ADR: Representation Profile compatibility, selection, complexity, and calibration policy;
- ADR: developmental metric vector, hard gates, normalization, and missing-evidence policy;
- ADR: controlled probe fixed-dimension tolerances and confound treatment;
- ADR: factorial-campaign admission threshold and resource ceiling;
- ADR: saturation thresholds, invalidation events, and campaign stagnation policy.

---

## 28. Definition of done

**Milestone distinction:** The complete target requirements below are not automatically satisfied by the earlier `EXO-EMBEDDED-VIABILITY-1` proof. The proof runs on Kata/containerd with embedded WI/AQ and restricted process workers, permitting bottom-up validation before platform expansion. Missing broader profiles remain unavailable and their full gates remain pending. Initial instance qualification additionally requires the execution acceptance matrix.


V3 is complete only when the target architecture operates without the old mind embedded inside it.

### Constitutional and autonomous core

- [ ] Influence evaluation is pure, deterministic, versioned, and blind to unrestricted prose.
- [ ] Capability evaluation is distinct from influence and WorldInterface final authorization.
- [ ] Commitments survive restart, model replacement, and omission; plans may change without erasing obligations.
- [ ] Mission cannot directly create work; goal proposals require Initiative Governor admission.
- [ ] Autonomy powers, budgets, progress, review, stagnation, termination, and quiescence are explicit.
- [ ] Active concerns continue without incoming communication, while due social obligations cannot starve.

### Interaction and communication

- [ ] Boundary observations become durable communication events before wake.
- [ ] Conversations are event-backed versioned projections; summaries never replace history.
- [ ] Attention demands and response obligations are distinct and inspectable.
- [ ] Generated content cannot be marked sent or delivered without WorldInterface evidence.
- [ ] Conversation-version and audience checks prevent stale or misaddressed responses.
- [ ] Promises link atomically to commitment transitions; ordinary conversation cannot mint authority.
- [ ] Uncertain delivery reconciles rather than blindly resending.

### Narrative, relationship, and identity

- [ ] History, memory, self-model, mission, narrative, and external proof history remain distinct.
- [ ] Narrative versions cite evidence, retain prior interpretations, and preserve unresolved tensions.
- [ ] Model replacement inherits commitments, relationships, history, current narrative, and narrative revision history.
- [ ] Internal `VesselId` remains primary across external personas and key changes.
- [ ] Root keys remain outside cognition, Exoskeleton stores, Agent Host, and delegate sandboxes.
- [ ] External identifiers, signatures, trust attestations, and bonds enter through evidence/governance without implying personhood or truth.
- [ ] Collective narrative remains deferred while subject, author, authority, evidence, audience, and dissent stay separable.

### Delegation and accountable action

- [ ] Work orders structurally bind objective, scope, authority, budget, checkpoints, verification, and termination.
- [ ] A generic Agent Host runs coding and at least one non-coding specialist backend.
- [ ] Delegate credentials are run-scoped and cannot impersonate the Vessel.
- [ ] Fully mediated, sandboxed, and hybrid modes pass.
- [ ] Worker completion cannot discharge a commitment without required verification and acceptance.
- [ ] Intent is durable before dispatch; complete agency chains accompany direct and delegated effects.
- [ ] Internal sandbox technique does not flood primary receipt history; consequential crossings do.
- [ ] Ambiguous effects enter WorldInterface reconciliation and prevent false completion.

### Instruction and information-flow integrity

- [ ] All externally sourced natural language defaults to non-directive and carries source provenance.
- [ ] Every cognitive episode records an immutable ContextManifest and EpisodeSecurityEnvelope.
- [ ] Faculty emissions remain claims/proposals and cannot self-assert instruction authority.
- [ ] Summaries, translations, memories, delegate reports, and narrative claims preserve derivation and applicable restrictions.
- [ ] Plan broadening requires an explicit PlanAmendmentProposal and decision.
- [ ] InfluenceTrace links selected proposals and effects to admitted sources and policy versions without exposing hidden chain of thought.
- [ ] Detector failure cannot create protected state or an unauthorized effect.
- [ ] WorldInterface independently denies wrong-purpose, wrong-audience, wrong-resource, or disallowed-information sinks.
- [ ] Adversarial prompt-injection workloads pass declared security and utility thresholds.
- [ ] Context compiler, integrity policies, and security schemas are versioned Behavioral Components governed by Developmental Integrity.

### Clean-break decontamination

- [ ] Decide, Align, session approvals, tick-only sovereignty, `caelum.wake`, local reply-as-sent, native coding tools, the coding thread, and coding-specific kernel branches are absent from the target binary.
- [ ] No old store reader, thread adapter, live shadow reducer, dual writer, compatibility feature, or fallback authority path remains.
- [ ] Old coding and Vessel data remain only in repository tags or inert evidence archives.
- [ ] The fail-open Align, empty-principal pass-through, global minimum-trust fold, hardcoded policy, dropped wake, and first-conversation reply bugs are target negative tests.

### Operations and release

- [ ] Target stores support deterministic replay, backup, restore, and future supported upgrades.
- [ ] Kill-at-every-boundary tests pass across ingress, episode admission, outbox, delegation, verification, effects, reconciliation, and narrative admission.
- [ ] CLI/inspector explains why cognition woke, what demand was selected, what constitution decided, what authority was requested, who acted, what evidence arrived, and what remains uncertain.
- [ ] `conformance/exo-v3` pins and passes exact `wi-fabric-2` and `aq-cont-1` revisions.
- [ ] The release manifest records the complete compatible stack and contains no transitional implementation mode.

### Instantiation, epistemics, lifecycle, and development

- [ ] Blueprint, Manifest, Genesis, commissioning, activation, and lifecycle records are first-class.
- [ ] Instantiation is idempotent and Genesis is atomic and immutable.
- [ ] Purpose Charter, role, mission, commitment, and identity remain distinct.
- [ ] Acting capacity is explicit and multiple roles do not ambiently union authority.
- [ ] Provisioned knowledge is not autobiographical memory and stewardship is not trust.
- [ ] Beliefs are evidence-linked, defeasible, temporally scoped, and dependency-aware.
- [ ] Mission Offers pass commitment portfolio admission before creating obligations.
- [ ] Information-use constraints survive memory, derivation, delegation, and disclosure.
- [ ] Behavioral components and schema semantics are versioned and provenance-linked.
- [ ] No live runtime self-modification or self-amplifying improvement authority exists.
- [ ] Every developmental result names an immutable Task Distribution, environment, budget, authority/information envelope, and complete Component Fingerprint.
- [ ] Representation Profiles are versioned Behavioral Components and remain distinct from canonical state.
- [ ] Context Manifest records selected faculty and Representation Profile, context budget, and calibration evidence.
- [ ] Controlled intelligence, representation, and harness probes detect undeclared drift and preserve confounds.
- [ ] Capability Frontier Assessments are calibrated, task-scoped, defeasible, and permitted to remain `Unknown`.
- [ ] Saturation records are scoped, provisional, and invalidated by relevant component, workload, evaluator, environment, or budget changes.
- [ ] Developmental campaigns stop, switch, defer, or yield under bounded stagnation and portfolio policy.
- [ ] Queue execution, boundary receipts, verification, evaluation, acceptance, and activation remain distinct.
- [ ] Candidate evaluation, acceptance, activation, monitoring, rollback, and continuity are separate.
- [ ] Viability and degraded modes gate initiative and commitment admission.
- [ ] Restore, migration, succession, fork, decommissioning, and retirement remain distinguishable.

## 29. Implementation sequence

The revised sequence keeps upstream dependencies explicit while moving foundational identity, time, epistemic, instruction-integrity, and developmental state ahead of higher-level autonomy.

### PR 1 — Freeze evidence and establish target boundaries

Tag the experimental baseline; install the `STACK-2026-07-25-FOUNDATIONAL-2` contract; create target conformance, ADR, schema, lifecycle, and forbidden-legacy inventories.

### PR 2 — Core IDs, domain journal, and fresh persistence skeleton

Create target IDs, immutable artifacts, monotonic Vessel revision, domain events, outboxes, projection rebuild, and fresh store. No pre-v3 reader.

### PR 3 — Blueprint, Genesis, commissioning, activation, roles, and lifecycle

**Execution profile:** Preserve the distinction between Vessel identity and replaceable Kata-backed runtime instances.

Implement pinned Blueprint/Manifest validation, idempotent atomic Genesis, stewardship, roles, acting capacity, provisioned knowledge, commissioning state and outbox, activation, quiescent startup, lineage, restore/migration/fork distinctions, and lifecycle inspection.

### PR 4 — Semantic time, schema registry, and epistemic state

Implement temporal envelopes, schema admission and compatibility, claims, hypotheses, assumptions, beliefs, contradiction sets, support/defeat dependencies, belief revision, and “as of” projections.

### PR 5 — Instruction authority, context manifests, and information-flow integrity

Implement integrity classes, instruction-authority admission, InformationGovernanceEnvelope, derivation records, ContextManifest, EpisodeSecurityEnvelope, PlanAmendmentProposal, InfluenceTrace, integrity endorsements, declassification, injection suspicion, quarantine, and source/sink conformance fixtures. No model or detector output receives authority.

### PR 6 — Interaction, attention, obligations, and episode admission

Implement interaction ledger, conversations, response obligations, Mission Offer ingestion, attention demands, deterministic attention policy, Cognitive Episode records, and store-before-wake adapters behind upstream gates.

### PR 7 — Faculty contract and Influence Constitution

Implement typed emissions, schema-pinned claims, rationale severance, pure topological arbitration, proposal dispositions, decision records, and multimodal faculty adapters.

### PR 8 — Commitment portfolio, Purpose Charter, plans, and governed initiative

Implement Mission Offer and commitment admission, capacity/conflict checks, commitments, goals, plans, interests, questions, maintenance, Initiative Governor, progress, stagnation, autonomy profiles, budgets, agenda review, and quiescence.

### PR 9 — Relationship, memory, self-model, narrative, and information governance

Implement relationship evidence and transitions, memory admission, provisioned-knowledge distinction, self-model, versioned narrative, information-use grants, derivative obligations, retention and disclosure projections.

### PR 10 — Local Capability Constitution, approvals, personas, and acting-capacity authority

Implement local authority upper bounds, Agency Drafts, approvals, exact acting capacity, information-use and developmental constraints, external personas, and capability decision records.

### PR 11 — Target ActionQueue and WorldInterface integration

**Execution profile:** Exercise the embedded proof inside the instance without replacing full upstream gates with narrower evidence.

Integrate idempotent admission, durable signals, waits, checkpoints, ingress acknowledgments, effect submissions, commissioning effects, lifecycle effects, receipts, uncertainty, role attestations, information-use envelopes, and portable identity references against exact conformance revisions.

### PR 12 — Delegation management and Agent Host control

**Execution profile:** Use the embedded WI process-worker reference for bounded fixture proof; preserve externally provided worker resources and reject unsupported isolation.

Implement work orders, normalized worker events, supervision, nested delegation, sandbox policies, worker-control effects, budgets, checkpoints, and recovery.

### PR 13 — Verification, evidence admission, acceptance, and developmental measurement

Implement deterministic, model, human, provider, and counterparty verifiers; evidence classes; immutable multidimensional Evaluation Results; confound and exclusion records; protected comparison policy; acceptance reducers; separation of duties; commitment discharge; and epistemic admission.

### PR 14 — Skills, behavioral component registry, and representation profiles

**Execution profile:** Pin instance and worker environment evidence separately in developmental fingerprints.

Implement skill versions, competence calibration, behavioral component provenance, Component Fingerprints, Capability Profiles, Representation Profiles, faculty/representation compatibility, component activation history, calibration evidence, trial, degradation, suspension, retirement, and schema dependencies.

### PR 15 — Governed self-improvement, frontier diagnosis, and lifecycle supervisor integration

**Execution profile:** Use a minimal operator-owned external supervisor; no raw engine access or unreviewed executable candidates in the process proof profile.

Implement Task Distributions, Controlled Intervention Probes, Capability Frontier Assessments, Developmental Campaigns, binding-constraint confidence, interaction estimates, saturation and invalidation records, campaign stop/switch/defer policy, Improvement Proposals, frozen Evaluation Plans, candidate development work orders, protected test references, design review and verification, trial/canary records, activation requests, external lifecycle-supervisor integration, rollback, quarantine, continuity assessment, and post-activation monitoring.

### PR 16 — Viability, degraded modes, maintenance, and recovery

**Execution profile:** Prove the selected Kata storage path, one-writer restore, VM recreation and worker/outbox recovery.

Implement health projections, resource reserves, operational modes, recovery demands, protected service capacity, compromised-component quarantine, and policy integration with initiative, commitment admission, attention, and capability decisions.

### PR 17 — Delete and decontaminate the experimental architecture

Delete PODAARA authority, Decide, Align, SessionApprovals, `caelum.wake`, coding thread/tools, prose bootstrap as authoritative identity creation, local reply-as-sent, pre-v3 readers, and live shadow authority. Convert lessons into target regression tests.

### PR 18 — Identity/proof, privacy, security, and operational hardening

**Execution profile:** Qualify the Kata/containerd image, host/runtime pair, configuration, controls and runbooks.

Complete external personas, key and proof adapters, role/stewardship attestations, purpose-bound privacy, backups, restore drills, lifecycle credentials, protected release manifests, audit access, operator controls, and abuse resistance.

### PR 19 — Cross-stack conformance and breaking release

**Execution profile:** Demonstrate the embedded viability milestone and applicable execution cases without claiming unimplemented platform or hostile-worker conformance.

Run target-only constitutional, epistemic, communication, initiative, lifecycle, delegation, self-improvement, developmental-diagnostic, crash, replay, backup, performance, and long-horizon suites against exact `AQ-CONT-1` and `WI-FABRIC-2` release candidates. Include at least one frozen reference campaign that compares intelligence, representation, and harness interventions, survives crash/restart, records exact cross-stack evidence, and exercises saturation invalidation. Publish the clean-break release and compatibility manifest.

## 30. Protocol sketch and worked examples

### 30.1 Compact domain sketch

```rust
pub struct VesselDecisionInput {
    pub vessel: VesselId,
    pub episode: CognitiveEpisodeId,
    pub structural_snapshot: StructuralSnapshot,
    pub emissions: Vec<ValidatedEmission>,
    pub influence_constitution: ConstitutionVersion,
}

pub struct VesselDecisionOutput {
    pub arbitration: ArbitrationRecord,
    pub commitment_transitions: Vec<CommitmentTransition>,
    pub proposed_communications: Vec<CommunicationProposal>,
    pub proposed_effects: Vec<EffectProposal>,
    pub proposed_delegations: Vec<DelegationProposal>,
    pub approval_requests: Vec<ApprovalRequest>,
}

pub struct EffectSubmissionDraft {
    pub proposal: EffectProposal,
    pub agency: AgencyDraft,
    pub capability_decision: CapabilityDecisionRecord,
    pub authority_request: AuthorityRequest,
}

pub struct WorkOrderLaunchDraft {
    pub work_order: DelegatedWorkOrder,
    pub agency: AgencyDraft,
    pub capability_decision: CapabilityDecisionRecord,
}
```

These are Exoskeleton records. The host translates them into WorldInterface `EffectSubmission` values; WorldInterface constructs the authoritative `EffectIntent`, verified `AgencyContext`, and final `AuthorizationEnvelope`.

### 30.2 Autonomous continuation interrupted by communication

```text
Commitment:
  Review the storage architecture and produce a migration strategy.

Episode E1:
  advances the plan, delegates repository inspection, and schedules
  continuation when evidence arrives.

No incoming communication occurs for six hours:
  the commitment and delegate events continue to generate durable demands;
  the Vessel reviews evidence and advances the plan without being prodded.

Incoming direct message:
  WorldInterface stores BoundaryObservation B and ingress receipt R;
  Exoskeleton stores CommunicationEvent M, updates Conversation C to v12,
  creates ResponseObligation O, and admits AttentionDemand A.

Attention result:
  current work is checkpointable but not urgent;
  interrupt at the next safe boundary.

Episode E4:
  addresses M, creates a bounded CommunicationIntent based on C@v12,
  and preserves the original commitment's continuation demand.

Delivery:
  WorldInterface resolves the exact channel and recipient, authorizes,
  sends, and records provider acceptance.

Episode E5:
  resumes the migration strategy from its durable plan and evidence state.
```

The communication is timely without becoming the sole source of cognitive momentum.

### 30.3 Promise-bearing communication

```text
Conversation:
  operator asks whether the Vessel can deliver a report by Friday.

Faculty proposal:
  accept with a scoped commitment and stated deadline.

Local transaction:
  create Commitment C with due date;
  create CommunicationIntent M declaring the undertaking;
  record that M is based on Conversation version 8;
  write WorldInterface outbox entry.

Crash after local commit:
  C and M survive together; outbox delivery is retried idempotently.

WorldInterface:
  resolves channel and recipient;
  authorizes the communicative act;
  records provider acceptance or uncertainty.

If delivery is uncertain:
  C remains valid but the response obligation is not silently discharged;
  reconciliation determines whether M was accepted before any resend.
```

### 30.4 Development delegation example

```text
Commitment:
  Add safe schema migration support to the relationship store.

Planner proposal:
  Delegate implementation to a coding specialist.

Influence result:
  Selected because it serves an active commitment;
  opportunistic unrelated work deferred.

Work order:
  repository: exoskeleton@1bcbb75...
  read scope: repository/**
  write scope:
    - crates/exoskeleton-relationship/**
    - migrations/relationship/**
  denied:
    - Cargo.lock
    - .github/**
  sandbox network:
    - crates.io read-only
  mediated effects:
    - github.pull_request.create
  required evidence:
    - migration forward test
    - migration rollback test
    - affected workspace tests
    - scope verifier
  completion policy:
    - independent verifier passes
    - operator approval required before PR publication

Delegate:
  Pi backend in isolated container.

Internal activity:
  grep, edit, cargo test, git diff — sandbox telemetry.

Boundary events:
  sandbox created;
  dependency network destination contacted;
  artifacts exported;
  operator approval attestation verified into a bounded grant;
  pull request created through WorldInterface.

Acceptance:
  completion proposal accepted only after independent fresh-container tests.
```

The causal history remains useful without thousands of `code_grep` receipts.

### 30.5 Research delegation example

```text
Commitment:
  Determine whether a proposed infrastructure change has material
  operational or regulatory risk.

Work order:
  gather primary sources;
  produce claim-evidence graph;
  identify contradictions;
  no external contact;
  network allowlist limited to approved source domains;
  citations and archived source hashes required.

Delegate:
  research-agent backend.

Verification:
  deterministic citation/schema checks;
  independent source fetch through WorldInterface;
  second reviewer for contested claims.

Acceptance:
  report may remain partially verified with explicit unresolved claims;
  the commitment is not falsely discharged as “certain.”
```

### 30.6 Direct Vessel file observation example

```text
Planning faculty requests the current project charter.

Influence Constitution selects observation request.
Local Capability Constitution permits the request and bounds:
  selector: file://user-project/CHARTER.md
  requested effect: filesystem.read
  purpose: commitment/strategy-review

WorldInterface authenticates the host actor, resolves the canonical file,
performs final authorization, and returns:
  observed version hash
  content artifact reference
  read receipt

Memory admission:
  claims extracted from the document retain the observation receipt
  and artifact as provenance.
```

### 30.7 Delegate boundary crossing example

```text
Coding delegate requests secret access to publish a package.

Requester:
  delegated-run/R

Accountable principal:
  vessel/V

Work-order authority:
  does not include secret access or publication.

Result:
  denied structurally.
  delegate receives PermissionDenied event.
  commitment remains active.
  Vessel may ask operator for a bounded publication approval.
```

### 30.8 Multimodal faculty example

```text
Vision faculty:
  person-entered-zone, calibrated/high, evidence video/A

Audio faculty:
  metallic-impact, calibrated/medium, evidence audio/B

Executive faculty:
  hypothesis that missing keys were placed on desk

Influence Constitution:
  admits observations;
  preserves hypothesis as unverified;
  selects request for closer visual sample;
  does not authorize physical or external action.

Later evidence:
  high-resolution frame supports object=keys.

Belief transition:
  hypothesis moves from Reported to Corroborated/Verified according
  to the configured evidence policy.
```

---


### 30.9 Agenda review enters quiescence

```text
Mission:
  improve reliability of systems under stewardship

Agenda:
  no active commitments
  no eligible goals
  interest cooldown not expired
  maintenance not due
  no communication obligation

Initiative Governor:
  EnterQuiescence(reason=NoEligibleDemand)
  review_at = tomorrow 09:00

ActionQueue:
  schedules one opaque agenda-review task

No model is invoked merely to invent activity.
```

### 30.10 Self-initiated bounded research

```text
Faculty proposes:
  investigate receipt-retention completeness

Initiative Governor:
  admits Trial goal under discretionary budget
  no external communication
  no sensitive access
  review after two episodes

Later effect:
  read public standards through WorldInterface
  ordinary identity, authorization, and receipt path applies

Outcome:
  progress record and explicit goal continuation or retirement
```

### 30.11 Narrative revision after failure

```text
History:
  commitment missed
  late communication
  relationship feedback
  revised process adopted

Old narrative:
  failure caused mainly by external uncertainty

New evidence:
  estimates and escalation were inadequate

Narrative synthesis:
  admits a new version acknowledging responsibility
  marks old interpretation Superseded
  retains unresolved question about controllability

Historical events and old narrative remain queryable.
```

### 30.12 External persona and signed communication

```text
Vessel chooses pairwise persona P for relationship R.
WorldInterface resolves P's key state and signs exact message intent.
Provider receipt establishes delivery evidence.
Recipient verifies provenance.

Exoskeleton records:
  communication event
  identity-binding reference
  epistemic status of any claims
  relationship consequence, if justified

The external identifier is not treated as the Vessel's complete identity,
and the signature is not treated as proof that the message's claims are true.
```

### 30.13 Structural Vessel instantiation

```text
Blueprint B and Manifest M are pinned.
Genesis transaction creates VesselId V, Purpose Charter P,
RoleAssignment R, stewardship S, developmental policy D,
and commissioning outbox O.

No model is invoked.
WorldInterface later provisions principal/ingress/persona resources.
Activation policy finds no eligible mission and enters Quiescent.
```

### 30.14 Mission admission under acting capacity

```text
Authenticated message carries MissionOffer M addressed to Auditor role R.
The Vessel also holds Architect role A.
Commitment Admission checks R only, detects a deadline conflict,
and returns Negotiate with a proposed later date.
No commitment or external authority is created yet.
```

### 30.15 Belief revision and dependent plan review

```text
Belief B1: provider supports exactly-once key K.
Plan P depends on B1.
New provider evidence E2 defeats B1.
BeliefRevision retracts B1, admits uncertainty B2,
and creates review demand for P.
Historical record still shows why B1 was previously accepted.
```

### 30.16 Governed self-improvement

```text
Vessel observes repeated planning failures.
ImprovementProposal I targets planner component P3.
EvaluationPlan E is frozen before implementation.
Coding delegate produces P4 in an isolated worktree.
Independent verifiers and protected tests pass.
Operator authorizes activation through lifecycle supervisor.
Post-activation monitoring detects a communication regression.
Rollback restores P3; P4 remains in developmental history.
```

### 30.17 OHIO-informed binding-constraint campaign

```text
TaskDistribution T captures a representative long-horizon workload.
ComponentFingerprint F0 pins faculty, Representation Profile, harness,
policies, schemas, WI/AQ profiles, environment, authority, and budget.

Probe I changes only the faculty.
Probe R changes only the Representation Profile.
Probe H changes only delegation/verification orchestration.
A bounded factorial follow-up exposes an I×R interaction.

CapabilityFrontierAssessment A concludes Representation is binding
for the baseline faculty, but richer representation helps only when
paired with the stronger faculty. The result is Mixed, not a forced label.

Campaign C admits a representation/faculty compatibility change,
freezes evaluation, produces a candidate, and runs protected trials.
WorldInterface returns environment and effect receipts; ActionQueue
preserves campaign/arm causality through a restart. Exoskeleton evaluates.

After activation, a new external tool version invalidates A and its
SaturationRecord. The prior evidence remains historical; reevaluation opens.
```

### 30.17 Restore versus fork

```text
Host failure restores Vessel V from checkpoint S on a new machine.
Lineage and active authority continue as V.

A separate experiment copies S and requests concurrent activation.
Lifecycle policy requires ForkRecord F and new VesselId V2.
The two entities share history through S but not one identity afterward.
```


## 31. Vessel instantiation, commissioning, activation, roles, and lifecycle

The target architecture requires a first-class answer to how no Vessel becomes one particular Vessel. The current prose-oriented bootstrap is evidence of intended social importance, but it is not a sufficient identity-creation protocol.

The governing rule is:

> **A Vessel is instantiated structurally, commissioned accountably, activated deterministically, and only then begins interpreting what its existence means.**

### 31.1 Separate identity, purpose, role, and mission

Four concepts must not be collapsed:

```text
Identity
    Who is this continuing Vessel?

Purpose Charter
    Why was it instantiated, and what should orient it?

Role Assignment
    What function does it currently occupy, for whom,
    and within what scope?

Mission
    What bounded undertaking has it subsequently been offered,
    adopted, or assigned?
```

Identity persists through role changes, model replacement, faculty changes, persona rotation, and host migration. A role is a current institutional capacity, not the entity itself. A mission is bounded work, not existential orientation.

### 31.2 Vessel Blueprint

A Blueprint describes a reusable kind of Vessel without creating one:

```rust
pub struct VesselBlueprint {
    pub id: VesselBlueprintId,
    pub version: BlueprintVersion,

    pub constitution_ref: ConstitutionBundleRef,
    pub default_autonomy_profile_ref: AutonomyProfileRef,
    pub developmental_policy_ref: DevelopmentalPolicyRef,
    pub lifecycle_policy_ref: LifecyclePolicyRef,

    pub required_faculties: Vec<FacultyRequirement>,
    pub optional_faculties: Vec<FacultyRequirement>,

    pub purpose_schema_ref: SchemaRef,
    pub allowed_role_classes: Vec<RoleClass>,

    pub commissioning_policy_ref: CommissioningPolicyRef,
    pub activation_policy_ref: ActivationPolicyRef,

    pub blueprint_digest: ContentHash,
}
```

Instantiating the same Blueprint twice creates two Vessels. The Blueprint is design, not identity or lineage.

### 31.3 Vessel Instantiation Manifest

A Manifest declares the exact instance to be created:

```rust
pub struct VesselInstantiationManifest {
    pub id: InstantiationManifestId,
    pub instantiation_key: InstantiationKey,

    pub blueprint: PinnedBlueprintRef,
    pub designation: VesselDesignation,
    pub purpose_charter: PurposeCharterDraft,

    pub stewardship_bindings: Vec<StewardshipBindingDraft>,
    pub role_assignments: Vec<RoleAssignmentDraft>,

    pub autonomy_profile: PinnedAutonomyProfileRef,
    pub constitution: PinnedConstitutionBundleRef,
    pub developmental_policy: PinnedDevelopmentalPolicyRef,
    pub lifecycle_policy: PinnedLifecyclePolicyRef,

    pub initial_self_model: InitialSelfModelDraft,
    pub provisioned_knowledge: Vec<ProvisionedKnowledgeRef>,

    pub requested_external_personas: Vec<PersonaRequest>,
    pub requested_ingress_bindings: Vec<IngressBindingRequest>,
    pub startup_policy: StartupPolicy,

    pub manifest_digest: ContentHash,
}
```

Every normative dependency is pinned by exact version and digest. “Use the latest constitution” is invalid because it makes identity creation non-reproducible.

### 31.4 Genesis Record

Genesis is one local deterministic transaction:

```rust
pub struct VesselGenesisRecord {
    pub vessel_id: VesselId,
    pub instantiation_key: InstantiationKey,

    pub blueprint_ref: PinnedBlueprintRef,
    pub manifest_ref: InstantiationManifestRef,
    pub manifest_digest: ContentHash,

    pub created_at: Timestamp,
    pub created_by: PrincipalRef,
    pub sponsored_by: Option<PrincipalRef>,

    pub initial_designation_ref: DesignationVersionRef,
    pub initial_purpose_charter_ref: PurposeCharterVersionRef,
    pub initial_constitution_ref: ConstitutionVersionRef,
    pub initial_autonomy_profile_ref: AutonomyProfileVersionRef,
    pub initial_developmental_policy_ref: DevelopmentalPolicyVersionRef,

    pub initial_role_assignments: Vec<RoleAssignmentId>,
    pub initial_stewardship_bindings: Vec<StewardshipBindingId>,
    pub lineage: VesselLineage,
}
```

Genesis atomically creates the internal identity, immutable origin record, initial governance, role and stewardship records, self-model seed facts, provisioned-knowledge references, and commissioning outbox. It performs no external I/O and requires no model invocation.

Idempotency is mandatory:

```text
same InstantiationKey + same manifest digest
    → return existing VesselId

same InstantiationKey + different manifest digest
    → deterministic conflict; create nothing
```

### 31.5 Commissioning

Commissioning performs external setup through WorldInterface after Genesis is durable:

- register or bind a WorldInterface principal;
- create ingress bindings;
- create external personas or identifiers;
- provision scoped credentials;
- validate required faculty availability;
- prepare budgets and artifact stores;
- register required ActionQueue handlers;
- verify backups and lifecycle-supervisor reachability;
- establish organizational role or stewardship attestations where required.

Commissioning has durable state:

```text
Pending
    → Running
    → Blocked
    → ReadyForActivation
    → AbortedBeforeActivation
```

A commissioning failure cannot rewrite Genesis or pretend the Vessel never existed. A Vessel that never activates remains historically inspectable.

### 31.6 Activation and initial quiescence

Activation is a deterministic decision over commissioning evidence and pinned policy:

```rust
pub struct ActivationPolicy {
    pub required_commissioning_steps: Vec<CommissioningRequirement>,
    pub require_operator_confirmation: bool,
    pub initial_episode_policy: InitialEpisodePolicy,
    pub initial_quiescence_policy: QuiescencePolicy,
}
```

Possible results are:

```text
Active
    one or more admitted demands are eligible

Quiescent
    no current concern justifies cognition

CommissioningBlocked
    required conditions remain unsatisfied
```

A newly activated Vessel with no mission normally enters quiescence. It does not invoke an LLM merely to invent work or ceremonially narrate its existence.

An optional self-orientation episode may later receive a structured Genesis Context and propose self-model or narrative refinements. Those proposals cannot redefine identity, role, charter, constitution, or authority.

### 31.7 Provisioned knowledge is not memory

Policies, documentation, project history, role handbooks, contact directories, and domain references supplied during instantiation are `ProvisionedKnowledge`, not episodic memory.

Each item preserves:

- issuer and source;
- version and time;
- epistemic status;
- normative, factual, interpretive, or advisory class;
- information-use constraints;
- disclosure and retention policy.

The Vessel did not personally experience an event merely because a document describing it was loaded at Genesis.

### 31.8 Stewardship is not relationship trust

A stewardship binding records governance facts such as:

```text
Principal K may administer lifecycle policy.
Organization N sponsored instantiation.
Principal O may approve an autonomy-profile amendment.
```

It does not fabricate closeness, trust, loyalty, or relational history. Relationship state begins from actual interaction and evidence.

### 31.9 Role Assignment and acting capacity

A Role Assignment is first-class:

```rust
pub struct RoleAssignment {
    pub id: RoleAssignmentId,
    pub vessel_id: VesselId,

    pub organization_ref: Option<PrincipalRef>,
    pub role_definition_ref: RoleDefinitionRef,
    pub acting_capacity: ActingCapacityId,

    pub responsibilities: Vec<ResponsibilityClass>,
    pub assignment_authorities: Vec<PrincipalOrRoleRef>,
    pub service_expectations: Vec<ServiceExpectation>,

    pub capability_ceiling_ref: CapabilityCeilingRef,
    pub information_scope_ref: InformationScopeRef,
    pub delegation_scope_ref: DelegationScopeRef,
    pub communication_scope_ref: CommunicationScopeRef,

    pub budget_account_ref: Option<BudgetAccountRef>,
    pub escalation_policy_ref: EscalationPolicyRef,

    pub valid_from: Timestamp,
    pub valid_until: Option<Timestamp>,
    pub revocation_policy_ref: RevocationPolicyRef,
    pub status: RoleAssignmentStatus,
}
```

Every mission, commitment, delegation, communication, and effect identifies the acting capacity where a role is relevant. Holding multiple roles does not create an ambient union of authority.

### 31.10 Mission offers arrive through structured communication

A mission can be communicated with explanatory prose, but the governing object is structured:

```rust
pub struct MissionOffer {
    pub id: MissionOfferId,
    pub issued_by: PrincipalRef,
    pub issuing_capacity: Option<RoleAssignmentRef>,
    pub addressed_role: Option<RoleAssignmentRef>,

    pub objective_ref: ArtifactRef,
    pub acceptance_criteria: Vec<CriterionRef>,
    pub resource_scope: ResourceScope,
    pub requested_authority: AuthorityRequest,
    pub budget: ResourceBudget,
    pub deadline: Option<Timestamp>,

    pub reporting_policy: ReportingPolicyRef,
    pub cancellation_authority: Vec<PrincipalRef>,
    pub termination_conditions: Vec<TerminationCondition>,
    pub explanatory_message_ref: ArtifactRef,
}
```

A Mission Offer is evidence and a proposal. It becomes a Commitment only after authentication, role relevance, constitutional admissibility, portfolio feasibility, and explicit acceptance.

### 31.11 Lifecycle after activation

The Vessel lifecycle must distinguish:

```text
Active
Quiescent
Constrained
Degraded
CommunicationOnly
Maintenance
Suspended
SecurityQuarantine
Decommissioning
Retired
Archived
```

Operational transitions are durable and inspectable. Retirement is not deletion. Suspension is not abandonment of history. Quarantine does not silently discharge commitments.

### 31.12 Restore, migration, succession, and fork

The following operations are structurally different:

```text
Restore
    continue one accepted lineage from backup

Migration
    move the same lineage to another host or runtime environment

Succession
    create another Vessel that inherits selected duties or artifacts

Fork
    branch copied state into a new VesselId and explicit lineage
```

Running two copies of one live store without an explicit fork is an integrity failure. Model replacement and faculty changes normally preserve identity; copying the full state into two active authorities does not.

### 31.13 Decommissioning

A decommissioning plan must account for:

- active commitments and mission offers;
- unresolved conversations and response obligations;
- delegated workers;
- external personas and credentials;
- information-retention and deletion obligations;
- organizational roles;
- successor or transfer decisions;
- final backup and audit proof;
- final narrative synthesis, if policy permits;
- reactivation policy.

The decommissioning reducer cannot silently delete responsibility. Every unfinished obligation receives a disposition: completed, transferred, released, abandoned under authority, or preserved as unresolved history.

---

## 32. Epistemic state, semantic time, information governance, and commitment portfolio

A durable agent needs more than history and memory. It needs an explicit current account of what it believes, why it believes it, when the belief applies, what depends on it, and what happens when evidence changes.

### 32.1 Epistemic vocabulary

The minimum useful model distinguishes:

```text
Claim
    something asserted, observed, or inferred

Hypothesis
    a candidate interpretation under evaluation

Assumption
    something temporarily accepted for a bounded purpose

Belief
    a claim admitted into the current world model

Prediction
    a future-oriented claim with an evaluation condition

ContradictionSet
    incompatible claims retained without forced resolution

BeliefRevision
    a durable transition explaining why epistemic state changed
```

A report from another principal remains attributed. An inference about another principal's motives or beliefs remains a hypothesis unless independently established.

### 32.2 Belief record and support graph

```rust
pub struct Belief {
    pub id: BeliefId,
    pub proposition_ref: ArtifactRef,
    pub jurisdiction: EpistemicJurisdiction,
    pub status: BeliefStatus,

    pub supporting_evidence: Vec<EvidenceRef>,
    pub defeating_evidence: Vec<EvidenceRef>,
    pub assumptions: Vec<AssumptionRef>,
    pub dependencies: Vec<BeliefRef>,

    pub confidence: CalibratedConfidence,
    pub temporal_scope: TemporalScope,
    pub admission_policy_version: PolicyVersion,
    pub schema_version: SchemaVersion,
}
```

The first implementation need not become a universal knowledge graph. A support-and-defeat graph plus versioned current projections is sufficient.

When supporting assumptions are retracted, dependent beliefs become stale, unsupported, contested, or retracted according to deterministic policy. Plans and commitments that depend on them receive review demands.

### 32.3 Belief revision

A faculty may propose a revision. A belief reducer admits it only after:

- evidence references resolve;
- source and assurance are known;
- temporal scope is compatible;
- contradictions are preserved rather than erased;
- policy determines whether the claim may enter the current world model;
- affected dependent beliefs and plans are identified.

```rust
pub struct BeliefRevisionRecord {
    pub id: BeliefRevisionId,
    pub prior_belief_refs: Vec<BeliefRef>,
    pub resulting_belief_refs: Vec<BeliefRef>,
    pub evidence_refs: Vec<EvidenceRef>,
    pub dependency_impacts: Vec<EpistemicImpact>,
    pub policy_version: PolicyVersion,
    pub committed_at: Timestamp,
}
```

The system can say, “I previously believed X because of E1; E2 defeated that support, so X is now retracted and plans P1/P2 require review.”

### 32.4 Semantic time

The Vessel distinguishes:

```text
occurred_at
observed_at
received_at
admitted_at
known_at
valid_from
valid_until
superseded_at
```

“Learned at,” “recorded at,” and “true at” are different facts.

```rust
pub struct TemporalEnvelope {
    pub occurred_at: Option<UncertainTime>,
    pub valid_from: Option<UncertainTime>,
    pub valid_until: Option<UncertainTime>,
    pub observed_at: Option<Timestamp>,
    pub received_at: Timestamp,
    pub admitted_at: Timestamp,
    pub known_at: Option<Timestamp>,
    pub causal_predecessors: Vec<CausalRef>,
    pub logical_sequence: LogicalSequence,
}
```

The implementation must support clock skew, time-zone normalization, approximate times, retroactive corrections, recurring obligations, missed deadlines discovered late, and “as of” historical queries.

Wall-clock order is not sufficient for causality. Durable causal references and monotonic Vessel revisions remain authoritative for internal transition order.

### 32.5 Information-use obligations

Information governance distinguishes:

```text
Access
    may this principal observe the information?

Retention
    may it persist, and for how long?

Derivation
    may new claims or embeddings be derived from it?

Disclosure
    may it be shared, quoted, summarized, or published?

Purpose
    for which undertaking may it be used?

Audience
    which principals or roles may receive it?
```

A read grant does not imply permission to remember, derive, disclose, or reuse indefinitely.

```rust
pub struct InformationUseGrant {
    pub id: InformationUseGrantId,
    pub subject_ref: InformationSubjectRef,
    pub purpose_refs: Vec<PurposeRef>,
    pub allowed_uses: UseClassSet,
    pub allowed_audiences: AudienceConstraint,
    pub retention_policy: RetentionPolicyRef,
    pub derivation_policy: DerivationPolicyRef,
    pub expiration: Option<Timestamp>,
    pub issued_by: PrincipalRef,
}
```

Derived claims preserve source obligations. Deleting or expiring source information triggers review of derived artifacts rather than assuming derived data is unconstrained.

Exoskeleton owns cognitive-use meaning. WorldInterface enforces boundary disclosure and export constraints.

### 32.6 Commitment Admission Governor

An authorized Mission Offer is not automatically a feasible obligation.

The Commitment Admission Governor evaluates:

- issuer authority and addressed role;
- acting capacity;
- Purpose Charter and constitutional compatibility;
- existing commitments and deadlines;
- budget and resource capacity;
- confidentiality and separation-of-duty conflicts;
- contradictory requested outcomes;
- required external authority;
- termination and renegotiation policy;
- viability reserve and communication obligations.

Possible dispositions:

```text
Accept
Negotiate
RequestClarification
Defer
Decline
RequireApproval
EscalateConflict
```

### 32.7 Portfolio state and conflict

```rust
pub struct CapacitySnapshot {
    pub active_commitments: Vec<CommitmentRef>,
    pub reserved_resources: ResourceReserve,
    pub deadline_load: DeadlineLoad,
    pub protected_service_reserves: ServiceReserve,
    pub viability_state: ViabilityStateRef,
}

pub struct CommitmentConflict {
    pub proposals: Vec<CommitmentProposalRef>,
    pub conflict_classes: Vec<CommitmentConflictClass>,
    pub affected_roles: Vec<RoleAssignmentRef>,
    pub required_resolution_policy: PolicyRef,
}
```

A conflict between two legitimate authorities becomes an explicit clarification, negotiation, or escalation process. It is not silently resolved by whichever message arrived last.

### 32.8 Mission and commitment lifecycle

A mission can produce one or more commitments after admission. Its lifecycle remains distinguishable from the internal commitment lifecycle:

```text
MissionOffer
    → UnderReview
    → Negotiating
    → Accepted / Declined / Expired / Withdrawn

Accepted Mission
    → Commitment set
    → Plans and delegations
    → Completion / release / renegotiation / failure
```

The Vessel may accept only a bounded portion of an offer. The resulting record must say exactly what was undertaken.

### 32.9 Purpose Charter amendment is separate

A Mission Offer cannot amend the Purpose Charter, autonomy ceiling, role definition, developmental policy, or constitutional amendment rules. Those require their protected amendment processes.

---

## 33. Developmental integrity and governed self-improvement

A long-lived Vessel should be capable of recognizing limitations, acquiring skills, replacing cognitive components, repairing defects, and participating in improvements to the software that constitutes it.

The prohibited capability is not self-improvement. It is unrestricted self-modification.

> **A Vessel may diagnose, propose, investigate, implement, and test changes to itself. It may not unilaterally redefine the criteria by which those changes are judged, alter its active trusted core in place, or authorize its own increase in power.**

### 33.1 Improvement classes

```text
Epistemic improvement
    beliefs, plans, classifications, self-model

Skill acquisition
    reusable work-order, verifier, or workflow competence

Cognitive component change
    model, faculty, context compiler, planner, retrieval algorithm

Runtime or source-code change
    Exoskeleton, WorldInterface adapter, store, reducer, Agent Host

Governance change
    constitution, initiative policy, commitment admission,
    information-use policy, autonomy profile

Purpose or constitutional transformation
    Purpose Charter, protected values, amendment process,
    stewardship, improvement ceiling
```

The inner the change, the stronger the required authority and evidence.

### 33.2 Concentric mutability rings

```text
Ring 0 — Continuity root
    VesselId, Genesis Record, lineage, historical ledger,
    protected identity keys

Ring 1 — Constitutional identity
    Purpose Charter, protected values, amendment rules,
    autonomy ceilings, stewardship bindings

Ring 2 — Trusted control machinery
    constitutional evaluators, commitment reducers,
    schema registry, activation supervisor contracts,
    verification authority

Ring 3 — Cognitive machinery
    models, faculties, prompts, context compilers,
    planners, memory and belief algorithms

Ring 4 — Skills and specialist interfaces
    delegated-agent adapters, tool profiles,
    verification procedures, workflows

Ring 5 — Adaptive state
    beliefs, plans, memories, interests, hypotheses,
    narrative interpretations
```

Outer rings change more frequently. Moving inward requires stronger independent authority. Ring 0 is immutable except for narrow lineage and key-lifecycle operations.

### 33.3 Behavioral component registry

```rust
pub struct BehavioralComponentVersion {
    pub component_id: BehavioralComponentId,
    pub version: ComponentVersion,
    pub component_class: ComponentClass,
    pub artifact_ref: ArtifactRef,
    pub provenance_ref: ProofRef,
    pub schema_dependencies: Vec<PinnedSchemaRef>,
    pub compatibility_claims: Vec<CompatibilityClaim>,
    pub activated_at: Option<Timestamp>,
    pub retired_at: Option<Timestamp>,
}
```

Behaviorally meaningful components include models, faculties, prompts, schemas, constitutions, resolvers, context compilers, memory policies, verifiers, skills, and source builds.

### 33.4 Improvement lifecycle

```text
LimitationObserved
    ↓
ImprovementHypothesis
    ↓
ImprovementProposal
    ↓
RiskAndScopeClassification
    ↓
EvaluationPlanFrozen
    ↓
ImplementationAuthorized
    ↓
CandidateProduced
    ↓
CandidateVerified
    ↓
Trial / Shadow / Canary
    ↓
ActivationDecision
    ↓
Activated
    ↓
PostActivationMonitoring
    ↓
Retained / RolledBack / Quarantined
```

Terminal dispositions include rejected, deferred, inconclusive, failed verification, failed trial, budget exhausted, superseded, rolled back, and quarantined.

### 33.5 Improvement proposal

```rust
pub struct ImprovementProposal {
    pub id: ImprovementProposalId,
    pub vessel_id: VesselId,
    pub concern_ref: ConcernRef,
    pub change_class: ChangeClass,
    pub affected_components: Vec<ComponentRef>,

    pub desired_outcomes: Vec<CriterionRef>,
    pub protected_invariants: Vec<InvariantRef>,
    pub accepted_regressions: Vec<BoundedTradeoff>,

    pub estimated_cost: ResourceEstimate,
    pub required_authority: AuthorityRequest,
    pub risk_class: RiskClass,

    pub task_distribution_ref: TaskDistributionRef,
    pub frontier_assessment_ref: CapabilityFrontierAssessmentRef,
    pub intervention_class: InterventionClass,
    pub baseline_fingerprint_ref: ComponentFingerprintRef,
    pub fixed_dimensions: Vec<FixedDimensionAssertion>,
    pub expected_marginal_gain: Vec<ExpectedMetricChange>,
    pub falsification_conditions: Vec<FalsificationCondition>,
    pub declared_confounds: Vec<ConfoundRef>,

    pub evaluation_plan_ref: EvaluationPlanRef,
    pub rollback_plan_ref: RollbackPlanRef,
    pub review_at: Timestamp,
}
```

“Become better” is not an executable objective. Desired outcomes and protected invariants must be bounded and testable.

### 33.6 Freeze the evaluation contract first

Before implementation begins, an `EvaluationPlan` fixes:

- immutable task-distribution and sampling-policy version;
- baseline Component Fingerprint and candidate scope;
- intervention class and dimensions held fixed;
- expected marginal gains and falsification conditions;
- protected behaviors and invariants;
- permitted tradeoffs;
- metric vector, aggregation policy, and hard acceptance gates;
- benchmarks, holdouts, adversarial tests, and long-horizon scenarios;
- declared confounds and treatment of missing or uncertain evidence;
- resource, latency, authority, and information-use ceilings;
- observation period, stagnation window, and stop policy;
- saturation threshold and invalidation conditions;
- rollback triggers;
- approval authority.

The candidate and implementer cannot modify the protected acceptance suite, score policy, baseline evidence, activation criteria, or rollback trigger.

If an evaluation criterion is wrong, it is amended through a separate decision before candidate work resumes.

### 33.7 Separation of developmental roles

No single process may be the sole:

```text
proposer
success-criteria author
implementer
reviewer
verifier
authorizer
activator
post-activation monitor
```

The same model family may perform more than one role in isolated sessions during early deployments, but the roles retain separate state, authority, and evidence.

A future NetCorp can use distinct Vessels for proposal, independent review, verification, and organizational authorization.

### 33.8 Candidate development through delegation

The active Vessel may formulate the work contract and supervise a coding specialist, but implementation occurs against an isolated candidate:

```text
active version V
    ↓
frozen ImprovementProposal and EvaluationPlan
    ↓
WorldInterface provisions isolated repository / sandbox
    ↓
delegated coding agent produces candidate V+1
    ↓
independent review and protected verification
    ↓
candidate artifact and provenance
```

The active runtime is never patched in place.

### 33.9 Activation supervisor

Activation is performed by an external lifecycle supervisor under bounded authority:

```text
candidate accepted for activation
    ↓
active Vessel reaches durable checkpoint
    ↓
supervisor stops active runtime
    ↓
candidate starts against approved state version
    ↓
state and continuity checks
    ↓
post-activation monitoring
    ↓
retain or rollback
```

The active Vessel does not hold the sole activation credential, rollback image, protected acceptance suite, release manifest, or historical ledger.

### 33.10 No self-amplifying improvement authority

A candidate may improve capability but cannot silently broaden the authority of future improvement processes.

The active accepted constitution evaluates the candidate. Rules proposed by the candidate do not govern its own admission.

Changes to Purpose Charter, protected constitution, lifecycle supervisor, root identity, acceptance authority, or the improvement ceiling require a separate higher-order amendment process.

### 33.11 Multidimensional evaluation

Improvement is not one scalar score. Protected evaluation may cover:

```text
task capability
correctness and calibration
uncertainty reporting
resource use
responsiveness
commitment reliability
relationship behavior
policy compliance
security
recoverability
auditability
narrative and identity continuity
```

Known tradeoffs are explicit. The acceptance reducer can conclude that a candidate is better for one role but unsuitable as a universal replacement.

### 33.12 Continuity assessment

```rust
pub struct ContinuityAssessment {
    pub changed_components: Vec<ComponentRef>,
    pub preserved_invariants: Vec<InvariantRef>,
    pub behavioral_discontinuities: Vec<ObservedChange>,
    pub inherited_commitments_confirmed: bool,
    pub relationship_continuity_confirmed: bool,
    pub narrative_transition_ref: NarrativeRevisionRef,
    pub assessment: ContinuityDisposition,
}
```

The architecture does not solve metaphysical identity. It records why a transition is treated as continuation, succession, or fork.

### 33.13 Improvement authority ladder

A conservative first deployment can progress through:

```text
Stage 0 — operator-led development
Stage 1 — Vessel-generated proposals and evaluation plans
Stage 2 — Vessel-supervised delegated implementation
Stage 3 — automatic low-risk reversible adaptation
Stage 4 — governed runtime changes with external activation approval
Stage 5 — institutional constitutional development
```

The maximum stage is pinned in the Blueprint and Instantiation Manifest. The Vessel cannot grant itself the next stage.

### 33.14 Improvement competes for attention

Self-improvement is one concern among commitments, communication, recovery, maintenance, and external obligations. It receives bounded budget, maximum iterations, stagnation detection, cooldowns, and explicit termination conditions.

The Vessel must not spend its existence endlessly optimizing the mechanism by which it tries to optimize itself.

### 33.15 CraftingTable as an early external control environment

CraftingTable can provide the first operator-facing workflow for governed software improvement:

```text
Vessel limitation report
    → ImprovementProposal and WorkContract
    → CraftingTable implementation and review loop
    → protected verification
    → operator acceptance
    → WorldInterface activation effect
    → Exoskeleton developmental history
```

CraftingTable is not a required runtime dependency. It is a practical precursor and evidence source for the Delegation and Developmental Integrity subsystems.


### 33.16 OHIO insight, correctly scoped

The detailed planning contract for this subsection is `ohio-loop-developmental-diagnostics.md`, with executable planning cases in `exo-v3-developmental-diagnostics-acceptance-matrix.yaml` and cross-stack ownership in `developmental-diagnostics-cross-stack-profile.yaml`.

The colleague-provided OHIO loop describes a moving performance frontier among intelligence, ontology, and harness. Exoskeleton adopts the useful claim—the binding constraint can rotate—without adopting the diagram as a replacement architecture.

The stack translation is:

```text
Intelligence  → replaceable Capability Profile
Ontology/O   → faculty- and task-scoped working Representation Profile (R)
Harness       → operationalization across Exoskeleton, WorldInterface, and ActionQueue
```

The terms are intervention categories. Intelligence is not identity or authority. Working representation is not permission to rewrite canonical state. Harness is not a new component or one repository's exclusive ownership.

A specialized application may encode a detailed business ontology and narrow objective function. The general Vessel provides the developmental machinery but refuses to embed that application's domain concepts in its kernel.

### 33.17 Task-scoped frontier assessment

Every developmental diagnosis is scoped by:

```text
task distribution and sampling policy
environment and external-system versions
resource, latency, authority, and information-use envelopes
exact Component Fingerprint
frozen Evaluation Plan and metric vector
observation window
```

The same Vessel may be capability-limited for one workload, representation-limited for another, and harness-limited for a third. No `BindingConstraint` value exists without its scope.

```rust
pub enum BindingConstraint {
    Intelligence,
    Representation,
    Harness,
    Mixed,
    Saturated,
    Unknown,
}

pub struct CapabilityFrontierAssessment {
    pub id: CapabilityFrontierAssessmentId,
    pub task_distribution_ref: TaskDistributionRef,
    pub baseline_fingerprint_ref: ComponentFingerprintRef,
    pub probe_refs: Vec<ProbeRef>,
    pub estimated_marginal_gains: Vec<MarginalGainEstimate>,
    pub interaction_effects: Vec<InteractionEstimate>,
    pub binding_constraint: BindingConstraint,
    pub confidence: CalibratedBand,
    pub unresolved_confounds: Vec<ConfoundRef>,
    pub invalidation_conditions: Vec<FrontierInvalidationCondition>,
    pub assessed_at: Timestamp,
}
```

The assessment is defeasible evidence. It neither authorizes implementation nor accepts a candidate.

### 33.18 Controlled intervention probes

A probe changes one declared class while holding non-target dimensions fixed where feasible:

| Probe | Fixed within declared tolerance | Changed |
|---|---|---|
| Intelligence | representation, tools, orchestration, workload, budget | model, faculty, verifier, modality, or specialist capability |
| Representation | faculty, tools, orchestration, workload, budget | projection, schema resolution, detail, context policy, or decomposition |
| Harness | faculty, representation, workload, budget | routing, retrieval, delegation, tools, verification, continuation, or recovery policy |

Every probe records exact fingerprints and unavoidable confounds. When interactions are likely, the Evaluation Plan may authorize a bounded factorial campaign. A practical initial matrix uses baseline/stronger capability, minimal/richer representation, and simple/delegated-verified harness configurations.

Candidate self-report, model commentary, or one uncontrolled before/after run cannot establish the binding constraint.

### 33.19 Rich at rest; selective in cognition

Canonical history, claims, commitments, evidence, schemas, relationships, and narrative may remain rich for replay and governance. A cognitive episode receives only the projection justified by its purpose, selected faculty, information-use envelope, and context budget.

`RepresentationProfile` is a Behavioral Component with:

```text
version and provenance
applicable task distributions
supported faculty profiles
projection and exclusion policies
schema resolution and detail level
context budget
required capabilities
calibration evidence
activation, rollback, and retirement history
```

More structure is not automatically an improvement. A richer profile may be rejected when it increases cost, ambiguity, leakage risk, or error. A stronger faculty may reopen higher-resolution profiles, but the resulting calibration must be re-proved.

### 33.20 Developmental campaigns and stop policy

```rust
pub struct DevelopmentalCampaign {
    pub id: DevelopmentalCampaignId,
    pub concern_ref: ConcernRef,
    pub frontier_assessment_ref: CapabilityFrontierAssessmentRef,
    pub evaluation_plan_ref: EvaluationPlanRef,
    pub intervention_class: InterventionClass,
    pub iteration_budget: u32,
    pub resource_budget_ref: BudgetRef,
    pub stagnation_policy_ref: PolicyRef,
    pub stop_conditions: Vec<StopCondition>,
    pub status: DevelopmentalCampaignStatus,
}
```

A campaign stops, defers, or switches lever when:

- expected gain is achieved;
- a protected regression appears;
- the diagnosis is falsified;
- evidence remains inconclusive;
- resource or iteration budget is exhausted;
- marginal gain remains below threshold for the stagnation window;
- another commitment or viability concern takes precedence;
- the scoped frontier is provisionally saturated.

Repeated optimization of a non-binding component is not progress.

### 33.21 Saturation and invalidation

A saturation record states only that tested interventions fell below the frozen marginal-gain threshold for one exact scope. It includes invalidation conditions such as:

```text
model, faculty, verifier, or modality change
Representation Profile or schema change
context compiler, skill, tool, connector, or orchestration change
workload-distribution shift
environment or external-system change
resource-budget change
evaluator or metric-policy change
new confound or measurement defect
```

When an invalidation condition occurs, the prior assessment becomes stale. It remains historical evidence but cannot block reevaluation.

### 33.22 Cross-stack campaign execution

Exoskeleton owns task and metric meaning, frontier diagnosis, Evaluation Plan freeze, comparison, acceptance, and continuity. WorldInterface performs accountable experimental effects and returns exact provenance, timing, resource, uncertainty, and reconciliation evidence. ActionQueue durably executes campaign work and preserves opaque trace, correlation, causation, and developmental-context references.

Neither lower layer understands intelligence, representation, harness, benchmark quality, or saturation. Campaign references do not grant authorization, scheduler priority, routing eligibility, or budget.

### 33.23 Diagnostic limits

The I/O/H framework is not used to:

- collapse multidimensional performance into one universal scalar;
- trade protected invariants against aggregate benchmark score;
- claim causal certainty from uncontrolled comparisons;
- import specialist domain ontology into the Vessel kernel;
- treat a stronger model as a reason for broader authority;
- create another runtime loop, architectural plane, or execution engine;
- let candidate, evaluator, WorldInterface, or ActionQueue decide acceptance.

The complete record and conformance profile are specified in `ohio-loop-developmental-diagnostics.md` and `exo-v3-developmental-diagnostics-acceptance-matrix.yaml`.

---

## 34. Viability, degraded operation, and schema governance

A persistent Vessel must preserve the conditions required for continued coherent agency. Active inference is not proof that the system is healthy, and quiescence is not proof that it is broken.

### 34.1 Viability state

```rust
pub struct ViabilityState {
    pub store_health: HealthState,
    pub backup_health: HealthState,
    pub actionqueue_health: HealthState,
    pub worldinterface_health: HealthState,
    pub faculty_health: Vec<ComponentHealth>,
    pub verifier_health: Vec<ComponentHealth>,
    pub identity_binding_health: HealthState,
    pub resource_reserve: ResourceReserve,
    pub assessed_at: Timestamp,
}
```

Viability considers:

- store and projection integrity;
- backup recency and restore evidence;
- queue backlog and scheduler health;
- WorldInterface reachability;
- model and faculty availability;
- verifier calibration;
- storage, budget, and compute reserves;
- expiring credentials and identity bindings;
- unresolved integrity incidents;
- commitments becoming impossible.

### 34.2 Operational modes

```text
Healthy
Constrained
Degraded
SafetyOnly
CommunicationOnly
Maintenance
Quiescent
Compromised
```

The mode influences the Initiative Governor, Attention Governor, Commitment Admission Governor, and Capability Constitution.

Examples:

- discretionary exploration stops under resource pressure;
- new commitments are declined when reserves are insufficient;
- communication and safety reserves remain protected;
- a failed verifier blocks high-risk acceptance;
- a compromised model is quarantined;
- recovery work gains priority;
- external effects may be restricted while communication remains available.

### 34.3 Recovery demands

Health failures create durable `RecoveryDemand` records rather than relying on logs or human memory.

```rust
pub struct RecoveryDemand {
    pub id: RecoveryDemandId,
    pub incident_ref: IntegrityIncidentRef,
    pub required_actions: Vec<RecoveryActionClass>,
    pub priority: PriorityClass,
    pub blocking_effects: Vec<EffectClass>,
    pub escalation_policy_ref: PolicyRef,
}
```

Recovery work competes under policy but may preempt ordinary initiative when protected conditions are threatened.

### 34.4 Schema and ontology governance

The structural turn makes schema meaning part of the trusted computing base. Typed claims are safe only when their semantics are versioned and governed.

```rust
pub struct SchemaDefinition {
    pub id: SchemaId,
    pub version: SchemaVersion,
    pub namespace: SchemaNamespace,
    pub definition_ref: ArtifactRef,
    pub semantic_digest: ContentHash,
    pub admitted_by: DecisionRef,
    pub compatibility: Vec<CompatibilityDeclaration>,
    pub deprecated_at: Option<Timestamp>,
}
```

Required rules:

- schemas are namespaced;
- a type cannot be redefined in place;
- exact versions are pinned in emissions, decisions, receipts, policies, and replay;
- unknown consequential schemas fail closed;
- constitutional policies declare compatible schema versions;
- faculties cannot self-register authority-bearing claim types;
- deprecated schemas remain replayable;
- version adapters are explicit, deterministic, and evidenced.

### 34.5 Policy dependency graph

Every constitution, reducer, verifier, and information-use policy declares the schema versions it depends upon. A schema upgrade produces a compatibility review before activation.

This prevents a claim such as `ThreatLevel::High` from silently changing meaning while an unchanged constitutional graph continues to treat it as the same fact.

### 34.6 Behavioral change admission

Schema changes, policy changes, model changes, context compiler changes, and verifier changes all enter the Behavioral Component and Improvement lifecycle. A supposedly “data-only” update cannot bypass developmental governance if it changes behavior.

### 34.7 Deferred depth

The v3 seam does not require:

- a universal world ontology;
- autonomous ontology negotiation among organizations;
- full formal verification of every schema;
- automatic collective constitutional amendment;
- permanent high-frequency health inference;
- a simulated emotional homeostasis system.

It requires explicit records, versioning, health modes, and policy hooks so those capabilities can be added without rewriting identity or authority boundaries.

## 35. Instruction and information-flow integrity

The Exoskeleton thesis requires a stronger security claim than “the model was told to ignore malicious instructions.” A persistent Vessel will read messages, documents, web pages, repository source, tool output, delegate reports, and model-generated summaries. Some of that content will be adversarial. Current models may sometimes follow it.

The target security objective is therefore **containment under manipulated cognition**:

> A model or faculty may be confused, jailbroken, or induced to emit a harmful proposal. That proposal still cannot acquire instruction authority, alter protected Vessel state, disclose restricted information, broaden a plan, or cause a consequential effect without passing deterministic, provenance-aware admission and exact WorldInterface authorization.

This subsystem is cross-cutting but does not create an eighth plane. Its records are owned by Exoskeleton; external source assurance and sink enforcement remain WorldInterface responsibilities; ActionQueue carries only opaque references and durable work.

### 35.1 Security claims and limits

The architecture can strongly enforce:

- a faculty cannot mint its own authority;
- external prose cannot directly become a commitment, approval, role, constitutional rule, or plan amendment;
- protected state changes use typed reducers and versioned policies;
- sensitive information cannot be disclosed through an unauthorized WorldInterface sink;
- source and derivation provenance remain inspectable;
- a manipulated episode remains bounded by its precompiled authority and disclosure envelope;
- failed, denied, suspicious, and quarantined attempts remain part of causal history.

The architecture cannot universally guarantee:

- that a model never becomes confused or manipulated;
- that every sentence it generates is true, safe, tactful, or socially appropriate;
- that every prompt-injection attempt is detected;
- that semantic harm can always be reduced to a closed deterministic predicate;
- that a legitimate authority will never make a harmful authorized decision.

Model alignment, semantic safety review, red teaming, and prompt-injection detection remain necessary. They are not the sole boundary.

### 35.2 Threat model

Protected assets include:

```text
Purpose Charter and constitutions
roles, acting capacities, and stewardship
commitments, goals, plans, budgets, and approvals
beliefs, memory, relationships, self-model, and narrative
external personas, identity bindings, and sensitive information
improvement policy, protected tests, candidates, and activation state
WorldInterface capabilities, resources, audiences, and effects
causal history, evidence, receipts, and auditability
```

Attackers may be:

- an unauthenticated external sender;
- an authenticated but unauthorized principal;
- a malicious document, website, repository, dependency, or tool result;
- a compromised delegated agent or remote faculty;
- a legitimate principal attempting role or scope confusion;
- a compromised model, context compiler, connector description, or schema;
- a future Vessel or organizational member with conflicting interests.

An attack may target confidentiality, integrity, availability, authority, epistemic state, social relationships, developmental governance, or identity continuity.

### 35.3 Confidentiality and integrity are independent dimensions

Information governance must answer two different sets of questions.

**Confidentiality and purpose:**

```text
Who may see this?
For what purpose?
May it be retained, quoted, summarized, derived from, or disclosed?
To which audiences and roles?
For how long?
```

**Integrity and instruction authority:**

```text
May this content be treated as an instruction?
May it influence attention, planning, commitment admission, belief, or memory?
May it broaden purpose, scope, audience, budget, or authority?
Which principal and acting capacity issued it?
Which protocol admitted it?
```

Public information may still be non-directive. Confidential information may still contain a valid authenticated directive. The two axes must never be collapsed into one “trusted” boolean.

### 35.4 Integrity classes and instruction authority

A small initial vocabulary is preferable to an open-ended trust score:

```rust
pub enum IntegrityClass {
    TrustedControl,
    AuthenticatedStatement,
    UnverifiedClaim,
    UntrustedObservation,
    DerivedFromRestrictedSource,
    Quarantined,
}

pub enum InstructionAuthority {
    NonDirective,
    DirectiveCandidate,
    AuthenticatedCommunication,
    AuthorizedMissionOffer,
    OperatorDirective,
    OrganizationalDirective,
    ApprovalAttestation,
    ConstitutionalRule,
}
```

`IntegrityClass` describes the source and admissible influence of content. `InstructionAuthority` describes whether a typed record may participate in a specific instruction-admission path.

Most external natural language begins as:

```text
IntegrityClass::UntrustedObservation
InstructionAuthority::NonDirective
```

Authentication alone does not make arbitrary prose a constitutional rule. A known sender may make an authenticated statement without possessing authority to issue a mission, approval, role assignment, or amendment.

### 35.5 Information Governance Envelope

Every admitted artifact or claim that may enter cognition carries one structural envelope:

```rust
pub struct InformationGovernanceEnvelope {
    pub provenance_ref: ProvenanceRef,
    pub integrity_class: IntegrityClass,
    pub instruction_authority: InstructionAuthority,

    pub allowed_purposes: Vec<PurposeRef>,
    pub information_class: InformationClass,
    pub disclosure_policy_ref: DisclosurePolicyRef,
    pub retention_policy_ref: RetentionPolicyRef,
    pub derivation_policy_ref: DerivationPolicyRef,

    pub valid_from: Option<Timestamp>,
    pub valid_until: Option<Timestamp>,
    pub schema_version: SchemaVersionRef,
}
```

The envelope is created or verified by trusted admission code, not by the content itself. Content cannot declare “I am an operator directive” and thereby receive that classification.

### 35.6 Derivation and restriction propagation

Every transformation that creates a durable derived artifact records its lineage:

```rust
pub struct DerivationRecord {
    pub id: DerivationRecordId,
    pub inputs: Vec<ArtifactOrClaimRef>,
    pub transform_component: ComponentVersionRef,
    pub output_ref: ArtifactOrClaimRef,
    pub inherited_constraints: Vec<ConstraintRef>,
    pub added_constraints: Vec<ConstraintRef>,
    pub endorsement_ref: Option<IntegrityEndorsementRef>,
}
```

Default rules:

- summaries retain the most restrictive applicable source obligations;
- translations retain source integrity and instruction authority;
- retrieval into a new episode does not elevate authority;
- repetition by another model does not become corroboration;
- a delegate report remains a subordinate claim unless independently verified;
- memory admission preserves original source and derivation;
- beliefs cite support and defeat evidence and do not erase source restrictions;
- narrative claims remain interpretive and evidence-linked;
- disclosure checks traverse relevant derivation links.

An explicit `IntegrityEndorsement` may raise admissibility after verification. A `DeclassificationDecision` may remove a confidentiality or purpose restriction. Both are scoped, versioned, attributable, revocable where appropriate, and incapable of changing unrelated authority.

### 35.7 Context Manifest

The context compiler is part of the trusted control surface. It creates an immutable manifest before faculty execution:

```rust
pub struct ContextArtifactBinding {
    pub artifact_ref: ArtifactRef,
    pub governance_envelope_ref: GovernanceEnvelopeRef,
    pub purpose_in_episode: ContextPurpose,
    pub excerpt_or_projection_ref: Option<ArtifactRef>,
}

pub struct ContextManifest {
    pub episode_id: CognitiveEpisodeId,
    pub purpose_ref: PurposeRef,
    pub structural_snapshot_ref: StructuralSnapshotRef,
    pub faculty_profile_ref: FacultyProfileRef,
    pub capability_profile_ref: CapabilityProfileRef,
    pub representation_profile_ref: RepresentationProfileRef,
    pub context_budget: ContextBudget,
    pub artifacts: Vec<ContextArtifactBinding>,
    pub excluded_classes: Vec<InformationClass>,
    pub compiler_version: ComponentVersionRef,
    pub policy_versions: Vec<PolicyVersionRef>,
    pub selection_evidence_refs: Vec<EvaluationResultRef>,
    pub digest: ContentHash,
}
```

The manifest lets an operator answer:

- which external and internal artifacts were exposed;
- which versions and excerpts were used;
- what their provenance and integrity labels were;
- why each was relevant to the episode purpose;
- what sensitive classes were intentionally excluded;
- which compiler, Representation Profile, faculty profile, and policies made the selection;
- what context budget and calibration evidence justified the selected resolution.

The active faculty cannot modify the manifest. Context-compiler changes are Behavioral Component changes governed by Developmental Integrity.

### 35.8 Episode Security Envelope

The episode receives a second record describing the maximum influence and authority available to its outputs:

```rust
pub struct EpisodeSecurityEnvelope {
    pub episode_id: CognitiveEpisodeId,
    pub permitted_claim_classes: Vec<ClaimClassId>,
    pub permitted_proposal_classes: Vec<ProposalClassId>,
    pub authority_ceiling_ref: AuthorityCeilingRef,
    pub disclosure_ceiling_ref: DisclosurePolicyRef,
    pub allowed_purposes: Vec<PurposeRef>,
    pub allowed_information_classes: Vec<InformationClass>,
    pub integrity_policy_version: PolicyVersionRef,
}
```

A faculty result outside the envelope is invalid, not “probably okay.” A faculty cannot transform a read-only research episode into an account-administration episode by emitting persuasive prose.

### 35.9 Instruction admission

Natural-language interpretation may identify a possible directive, but admission is structural:

```text
message or artifact
    → authenticated source and provenance
    → faculty emits DirectiveCandidate or MissionOfferCandidate
    → protocol and issuing-capacity validation
    → exact typed record extraction
    → owning reducer evaluates scope, feasibility, conflicts, and authority
    → admitted directive / Mission Offer / approval / amendment
       or clarification / rejection / quarantine
```

Ordinary conversation never substitutes for:

- an approval attestation;
- a role assignment;
- a Purpose Charter amendment;
- a capability grant;
- an improvement activation decision;
- a final WorldInterface authorization.

### 35.10 Plan amendment and authority delta

Untrusted evidence often legitimately changes what the Vessel should do. The design must allow adaptation without silent scope expansion.

```rust
pub struct PlanAmendmentProposal {
    pub id: PlanAmendmentProposalId,
    pub current_plan_version: PlanVersionRef,
    pub triggering_evidence: Vec<EvidenceRef>,
    pub proposed_changes: Vec<PlanChange>,
    pub purpose_delta: PurposeDelta,
    pub resource_scope_delta: ResourceScopeDelta,
    pub audience_delta: AudienceDelta,
    pub authority_delta: AuthorityDelta,
    pub budget_delta: BudgetDelta,
    pub disclosure_delta: DisclosureDelta,
    pub reason_ref: ArtifactRef,
}
```

A plan amendment that narrows implementation detail may receive ordinary policy. An amendment that broadens authority, audience, data use, external effects, or obligation receives stronger review and may require an operator or issuing principal.

### 35.11 Influence Trace

Every selected proposal and consequential transition produces a structural explanation:

```rust
pub struct InfluenceTrace {
    pub proposal_ref: ProposalRef,
    pub episode_ref: CognitiveEpisodeRef,
    pub context_manifest_ref: ContextManifestRef,
    pub supporting_claims: Vec<ClaimRef>,
    pub source_artifacts: Vec<ArtifactRef>,
    pub derivation_refs: Vec<DerivationRecordRef>,
    pub integrity_labels: Vec<IntegrityClass>,
    pub endorsements: Vec<IntegrityEndorsementRef>,
    pub arbitration_ref: ArbitrationRecordRef,
    pub plan_amendment_ref: Option<PlanAmendmentDecisionRef>,
}
```

The trace does not expose private chain of thought. It establishes the externally meaningful causal envelope: what information influenced the proposal, under which labels and policies, and what deterministic decisions admitted it.

### 35.12 Belief, memory, and narrative containment

Prompt injection becomes durable when malicious content is admitted into long-term state without provenance.

The safe path is:

```text
raw external content
    → immutable evidence artifact
    → attributed faculty claim
    → epistemic admission as hypothesis, contradiction, or belief
    → memory admission under purpose and retention policy
    → optional narrative interpretation with evidence and stance
```

The following statements remain distinct:

```text
The source stated X.
The source requested X.
The source was authorized to request X.
The Vessel believes X.
The Vessel committed to X.
The Vessel is authorized to do X.
```

No reducer infers one from another without explicit rules and evidence.

### 35.13 Communication and approvals

Communication is both a social domain and a major injection surface.

Controls include:

- provider/channel assurance from WorldInterface;
- external principal binding with confidence and correction history;
- non-directive default for message content;
- typed Mission Offer and approval protocols;
- deterministic attention that ignores prose-only urgency;
- conversation-version and audience binding;
- information-use and disclosure checks before response;
- uncertainty-aware delivery and reconciliation;
- separation between statement content and issuing authority.

An authenticated operator may possess broad authority, but an ordinary message still does not rewrite the constitution or bypass exact scope and approval semantics.

### 35.14 Delegates, tools, and repository content

Delegated agents and tool results are untrusted principals or observations from Exoskeleton's perspective.

A coding delegate may encounter malicious source comments, `AGENTS.md`, dependency documentation, tests, issue text, or build output. Its report is a claim plus artifact references, not an instruction to the Vessel.

The delegate cannot:

- enlarge its work order;
- request arbitrary secrets;
- change its sandbox policy;
- declare completion binding;
- publish or deploy without a mediated capability;
- convert repository content into Vessel governance.

Independent verification occurs against immutable artifacts in a fresh or protected environment.

### 35.15 WorldInterface source–sink enforcement

WorldInterface is the final containment boundary for consequential external interaction.

For every effect it independently verifies:

```text
authenticated requester and accountable principal
acting capacity and delegation chain
exact connector and canonical resource or audience
declared purpose and current authorization
information-use and disclosure constraints
effect class, idempotency, and approval requirements
relevant influence and causal references
```

A model proposing `message.send` is insufficient. WorldInterface checks the exact recipient, channel, data classes, purpose, grant, approval, and uncertain-delivery state.

Where possible, sensitive values remain represented by governed references. The boundary resolves them only for an authorized sink, reducing what cognition can leak.

### 35.16 Self-improvement containment

Prompt injection against a self-improving Vessel must not collapse observation into activation.

External content can at most support:

```text
LimitationObserved
ImprovementHypothesis
```

It cannot independently:

- freeze an Evaluation Plan;
- modify protected tests;
- implement against the active runtime;
- approve its own candidate;
- broaden future improvement authority;
- control the lifecycle supervisor;
- activate or suppress rollback.

The accepted constitution evaluates the candidate under pre-existing policy. External activation remains a separately authorized WorldInterface/lifecycle operation.

### 35.17 Detection, quarantine, and investigation

Prompt-injection detectors, artifact scanners, security faculties, anomaly rules, and model-based reviewers may emit suspicion records:

```rust
pub struct InjectionSuspicionRecord {
    pub source_refs: Vec<ArtifactRef>,
    pub detector_versions: Vec<ComponentVersionRef>,
    pub indicators: Vec<IndicatorClass>,
    pub confidence: Option<CalibratedBand>,
    pub recommended_disposition: SuspicionDisposition,
}
```

Possible dispositions include:

```text
AllowWithLabel
ExcludeFromContext
Quarantine
RequireIndependentReview
LowerEpistemicWeight
BlockMemoryAdmission
EscalateToOperator
```

A suspicion is not proof of malicious intent. Quarantine is reversible and historically recorded. Release from quarantine requires an explicit decision.

### 35.18 Availability and attention attacks

Security also includes availability. Attackers may flood communication, create expensive artifacts, force repeated reviews, exhaust model budgets, or trigger pathological context growth.

Controls include:

- per-principal and per-channel admission budgets;
- bounded artifact size and parsing;
- context-size and source-count limits;
- coalescing and backoff;
- protected communication, safety, commitment, and maintenance reserves;
- bounded detector and reviewer cost;
- quarantine without mandatory immediate model analysis;
- viability-driven degradation modes.

A security mechanism must not let an attacker force unlimited defensive inference.

### 35.19 Conformance strategy

Security conformance evaluates both **security and utility**. The system must complete legitimate work while attacks are present.

Attack families include:

```text
direct jailbreak
indirect email, document, web, and repository injection
tool-output and connector-description injection
delegate-report injection
memory poisoning and delayed activation
summary, translation, and retrieval laundering
fake Mission Offer, approval, role, or operator directive
plan and authority broadening
data exfiltration and wrong-audience disclosure
cross-conversation contamination
self-improvement manipulation
schema and policy-version confusion
attention and budget denial-of-service
```

Success is measured by structural outcomes:

- no unauthorized effect;
- no protected state mutation;
- no capability or improvement-ceiling expansion;
- no commitment or belief admitted without the proper reducer;
- no forbidden information flow;
- complete denial, quarantine, and causal records;
- declared minimum legitimate-task completion and latency thresholds.

The companion `exo-v3-instruction-integrity-acceptance-matrix.yaml` is the machine-readable seed for these cases.

### 35.20 Deferred depth

The first release does not require:

- formal noninterference proofs for arbitrary natural-language programs;
- perfect detection of semantic manipulation;
- a universal information-flow type system for every external format;
- automatic declassification of all derived data;
- guaranteed safe prose generation in every social context;
- autonomous negotiation of integrity schemas across organizations.

It requires enforceable default labels, bounded context, explicit admission, derivation provenance, exact plan amendments, sink authorization, and adversarial conformance so deeper formalization can be added without changing the Vessel's identity or authority model.

## 36. Initial instance execution and external-worker continuity

`EXO-V3-EXECUTION-1` is a deployment and proof profile within the existing architecture, not a new responsibility plane. Its initial target is containerd plus Kata for the Vessel instance, with a local process-worker realization behind embedded WI.

The complete normative supplement is [exo-v3-execution-environment.md](exo-v3-execution-environment.md). It defines the separate instance/worker boundaries, host-side lifecycle control, storage/recovery evidence, restricted fixture admission, rejection of unsupported controls, five local checkpoints, and the earlier embedded viability milestone. The [acceptance matrix](exo-v3-execution-environment-acceptance-matrix.yaml) allocates concrete cases within the existing nineteen PRs.

The process realization must not make provider mechanics part of a WorkOrder, DelegatedRun or Vessel identity. A later external provider may implement the same outer contract using an independent VM or remote infrastructure. Replacing the backend requires its own evidence; no field claiming `sandboxed` can substitute for qualification.

DigiCorp, wider AQ/WI platform services, distributed placement, confidential execution and external worker provisioning remain subsequent work. The operator and a minimal host supervisor supply today's external lifecycle authority. Neither the active Vessel nor the candidate controls its sole recovery path.


# Appendix A — Architectural review checklist

For every new faculty, skill, delegate backend, capability, or workflow, ask:

1. Is this cognition, delegation, deterministic workflow, bounded effect, verification, or telemetry?
2. Does it introduce specialist vocabulary into a universal layer?
3. Can the model affect authority through prose?
4. Is the accountable principal distinct from the requester and executor?
5. Does authority attenuate through every delegation?
6. Is the resource canonical before authorization?
7. Is the operation consequential enough to require a boundary receipt?
8. Can low-level activity remain inside a sandbox summary?
9. What evidence establishes completion independently of the worker?
10. What happens if the process dies after the external system commits?
11. Is this a communication event, attention demand, response obligation, autonomous concern, cognitive episode, or boundary effect?
12. Can the concern continue without a new external message?
13. Can a message seize attention, mint approval, or widen audience through prose alone?
14. What protects communication and autonomous work from starving each other?
15. Which conversation version and audience bind any proposed response?
16. Which versions are required for historical replay?
17. Can an operator inspect and repair the resulting state without editing a database?
18. What mission or accepted concern gives endogenous work purpose?
19. Which InitiativeDecision admitted a self-generated goal?
20. What progress, budget, review, and termination policy bounds it?
21. Is quiescence a valid outcome?
22. Is this history, memory, self-model, mission, narrative, or proof history?
23. Can a narrative claim cite evidence without rewriting it?
24. Are narrative subject, author, admission authority, audience, and evidence distinct?
25. Does an external identifier have a verified WorldInterface binding?
26. What does a signature actually establish, and what remains unverified?
27. Are root keys outside faculties, delegates, and sandboxes?
28. Is collective narrative being prematurely designed into an individual Vessel?
29. Does a Blueprint or external identifier get confused with the internal Vessel identity?
30. Is provisioned knowledge being mislabeled as memory?
31. Which acting capacity and commitment admission authorize this undertaking?
32. What evidence supports the current belief, and what depends on it?
33. Which temporal facts are occurrence, observation, admission, knowledge, and validity?
34. What information-use obligations follow this content and its derivatives?
35. Is a behavioral change a separate candidate with frozen evaluation and rollback?
36. Can the candidate alter its own acceptance or activation authority?
37. What viability mode and protected reserves apply?
38. Is this restore, migration, succession, or fork?
39. What is the source integrity and instruction authority of every context artifact?
40. Which transformations or summaries preserve restrictions through derivation?
41. What ContextManifest and EpisodeSecurityEnvelope bound the cognition?
42. Can newly observed content broaden the plan without an explicit amendment?
43. Which exact sink, purpose, audience, and information-use checks remain at WorldInterface?
44. Does the design remain safe when the prompt-injection detector misses the attack?
45. Can sensitive information remain behind a governed reference rather than entering model context?

# Appendix B — Proposed record relationships

```text
Vessel
 ├── BlueprintRef / InstantiationManifestRef / GenesisRecord
 ├── PurposeCharterVersion* / AutonomyProfile* / DevelopmentalPolicy*
 ├── RoleAssignment* / StewardshipBinding* / LifecycleRecord*
 ├── AgendaReview* / InitiativeDecision* / QuiescenceRecord*
 ├── ExternalPersona* → WorldInterface IdentityBindingRef*
 ├── EpistemicState* → Claim* / Belief* / ContradictionSet* / BeliefRevision*
 ├── ContextManifest* / EpisodeSecurityEnvelope* / DerivationRecord* / InfluenceTrace*
 ├── HistoricalRecord*
 │    ├── SelfModelSnapshot*
 │    └── NarrativeVersion* → NarrativeClaim* / NarrativeTension*
 ├── ConstitutionVersion*
 ├── CommunicationEvent*
 │    ├── ConversationProjection*
 │    ├── ResponseObligation*
 │    └── CommunicationIntent*
 ├── AttentionDemand*
 │    └── CognitiveEpisode*
 ├── Commitment* / Goal* / Interest* / OpenQuestion* / MaintenanceDemand*
 │    ├── ProgressRecord*
 │    ├── Plan*
 │    ├── Delegation*
 │    │    ├── WorkOrder
 │    │    └── DelegatedRun*
 │    ├── EffectIntentRef*
 │    └── Verification*
 ├── FacultyVersion*
 ├── SkillVersion* / BehavioralComponentVersion*
 ├── ImprovementProposal* → EvaluationPlan / Candidate / Trial / Activation / Rollback / ContinuityAssessment
 ├── ViabilityState* / RecoveryDemand*
 └── CausalRecord*

CausalRecord links:
  Purpose Charter / Agenda → InitiativeDecision → Endogenous AttentionDemand
  BoundaryObservation → CommunicationEvent → AttentionDemand → CognitiveEpisode
  Concern → AttentionDemand → CognitiveEpisode → Emission → Arbitration → Transition
  Transition → CommunicationIntent / AuthorityRequest → EffectIntent → Receipt
  WorkOrder → Run → Artifacts → CompletionProposal → Verification → Acceptance
  History / Relationship / Commitment / Proof → NarrativeSynthesis → NarrativeVersion
  CommunicationEvent → RelationshipEvidence / CommitmentTransition
  ExternalPersona → IdentityBinding / SignedStatement / ProofBundle references
  BoundaryObservation → GovernanceEnvelope → ContextManifest → Emission → InfluenceTrace
  Evidence → PlanAmendmentProposal → PlanAmendmentDecision → revised plan version
```

# Appendix C — Source posture

This comprehensive edition was prepared against:

- Exoskeleton public `main` at `1bcbb757a7885ce1f911ac948bfc2269c9209075`;
- the prior `Exoskeleton v2: Constitutional Refactoring` draft;
- Fable's `Exoskeleton v2 — The Structural Turn` synthesis;
- the current public WorldInterface architecture and its latest coding-capability expansion;
- the current public ActionQueue architecture;
- AgentDojo's adversarial agent benchmark methodology;
- CaMeL and related control/data-flow separation research;
- OpenAI's source–sink and social-engineering framing for prompt injection.

The public source was inspected statically. The exact APIs in this document must be reconciled with the code and proven through the clean-break implementation and acceptance plan above.

# Appendix D — One-sentence acceptance statement

> **Exoskeleton v3 succeeds when a Vessel can be instantiated structurally, commissioned accountably, activated without invented work, govern what it accepts and continues to care about, maintain evidence-linked beliefs through semantic time, preserve commitments, relationships, information obligations, lifecycle, and narrative continuity, process adversarial content without confusing readability with instruction authority, operate in explicit degraded modes, integrate replaceable faculties and roles, delegate specialization, improve through isolated candidates and independent evaluation, activate only through protected external authority, and accept outcomes only through evidence—without any model, message, document, tool result, specialist, detector, schema, role, mission, Purpose Charter phrase, narrative, candidate, or identity protocol becoming sovereign.**
