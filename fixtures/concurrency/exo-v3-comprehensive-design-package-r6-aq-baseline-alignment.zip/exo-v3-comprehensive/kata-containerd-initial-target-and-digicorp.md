# Kata/containerd as the initial execution target
## A bottom-up path from a working Vessel to DigiCorp

**Decision date:** September 12, 2026  
**Scope:** Initial target preference and architectural direction; not a DigiCorp implementation plan  
**EXO planning baseline:** EXO-PLAN-6 / EXO-V3-COMPREHENSIVE-3  
**Execution profile:** EXO-V3-EXECUTION-1

## Decision

Prefer **containerd with Kata Containers for the Exoskeleton Vessel instance's first qualified VM-backed execution environment**. Initially prove delegation through **process-managed workers reached through embedded WorldInterface and its Agent Host adapter**. Preserve externally provisioned worker environments as a future implementation of that boundary.

These are two different decisions. The outer Kata VM contains the Vessel instance; it does **not** give every process worker an independent VM boundary. The first worker backend exists to prove supervision, causality, artifacts, limits, recovery, and acceptance. It is not a claim of safe execution of arbitrary hostile code beside the Vessel's own state.

DigiCorp is the eventual organizational and external execution authority. It is not a prerequisite, dependency, service to mock as if implemented, or new runtime plane in EXO-V3. Build the components, prove the Vessel thesis, and let that evidence inform subsequent platform work.

## 1. Sequence the investment correctly

The intended development path is:

```text
AQ-CONT-1 and its proven durable execution contract
    + the embedded WI-FABRIC-2 paths required by a real consumer
        -> a functional EXO-V3 Vessel and local delegation proof
            -> evidence-driven evolution of AQ/WI embedded and platform services
                -> DigiCorp, composed from those working components
```

This is a dependency direction, not a demand to serialize every engineering task. Pure domain work, fixtures, and host-environment qualification can overlap. New organization-wide orchestration, globally coordinated placement, distributed queue semantics, and arbitrary-provider federation should not be smuggled into the current implementation.

AQ-CONT-1 being nearly complete is project context supplied by the owner, not a new conformance result. It is also not the last possible ActionQueue contract. Later capabilities must earn their place through actual downstream requirements.

The initial embedded proof is a named milestone, **not** an assertion that every platform-oriented gate in the broader planning set has passed. Existing full-release, cross-stack, security, and daemon-parity obligations retain their meanings. Evidence from a narrower proof cannot satisfy an unimplemented stronger profile.

## 2. Terms that keep the architecture coherent

| Term | Meaning here |
|---|---|
| Vessel | Enduring identity, governed state, commitments, history, and responsibility. |
| Runtime instance | A particular execution of that Vessel with exact code and configuration. |
| Instance environment | The compute, storage bindings, network controls, and isolation hosting that execution. |
| Kata sandbox / VM | The outer hardware-virtualized execution boundary in the initial target. |
| Process-managed worker | A supervised child process with a bounded protocol and declared limits, initially inside the same instance environment. |
| Externally provided worker | A future resource created outside the Vessel's instance boundary by an authorized provider. |
| Agent Host | The backend-facing worker protocol adapter; not Kata's internal `kata-agent`. |
| External lifecycle authority | The actor able to start, stop, replace, and recover the Vessel from outside its control. Initially the operator and a small host-side supervisor; potentially DigiCorp later. |

Container images are packaging; containerd manages image and runtime lifecycle; Kata supplies a VM-backed runtime integration. They do not supply the Vessel's identity, constitutional authority, work acceptance, or durable application semantics. Kata supports containerd integration and can place multiple containers in a VM, so the boundary must be verified rather than inferred from a container count. [S1][S2]

## 3. Why this initial preference fits

The preference is an engineering judgment: a replaceable VM-backed instance fits the concept of persistent identity inhabiting a replaceable body. It also avoids making the host's ordinary container namespaces the only outer boundary around a potentially compromised Vessel.

Kata supplies a guest kernel and virtualization boundary while retaining container-oriented packaging and runtime integration. containerd's shim interface separates lifecycle management from the particular runtime implementation. Neither requires Exoskeleton to acquire a container-engine API in its core. [S1][S2]

The immediate goal is **one maintained, reproducible Linux host profile**, not a universal deployment substrate. Select and pin a tested host architecture, containerd/Kata combination, hypervisor, guest kernel/image, snapshotter, storage configuration, and networking setup during implementation. Do not equate an installation guide using the newest releases with a tested compatibility matrix. Kata's installation documentation itself warns about that distinction. [S3]

A standalone host and a small operator-controlled launcher/supervisor are sufficient for the first qualification. Kubernetes, a multi-cloud scheduler, custom VM management protocols, and a DigiCorp control plane are not required. The official integration documentation includes direct containerd-client use. [S4]

This choice is not a claim that Kata is invulnerable, that it is always faster than another runtime, or that every Kata configuration is equally secure. Runtime maintenance, mount scope, resource enforcement, credentials, and recovery remain implementation responsibilities.

## 4. Initial topology

```text
Operator-controlled Linux host
  containerd + Kata shim + selected hypervisor
  minimal host-side lifecycle supervisor / protected release records
  authoritative persistence bindings and protected backup location
  |
  +-- dedicated Kata VM for one Vessel instance
        Exoskeleton runtime
          Vessel AQ
          Vessel domain database / outboxes / artifact references
          embedded WorldInterface
            WorldInterface AQ
            local Agent Host adapter
              worker process A
              worker process B
```

The two AQ roles remain distinct even when embedded. The container runtime's lifecycle service is not a third task scheduler, and the process worker does not become another AQ engine.

The host retains its management sockets and activation credentials. Neither the Vessel nor a worker receives containerd, Docker, Podman, Kata control, or hypervisor management access. The first lifecycle supervisor can be a small operator-owned service/tool, not a general execution platform. If automated lifecycle effects are exercised, embedded WI reaches a narrowly authorized supervisor endpoint rather than a raw management socket.

Storage is not the disposable container root filesystem. The selected persistence profile must prove the semantics required by the Vessel database and both queue stores. Recreating the VM does not recreate Genesis or erase accepted commitments. Kata supports several storage paths; none should be assumed to provide the required database semantics without testing. [S5]

## 5. What process isolation proves—and what it does not

The initial backend uses separate processes, an explicit worker protocol, per-run directories, sanitized environments, non-inherited sensitive descriptors, bounded output, wall-clock limits, tracked process trees, and scoped artifact export. Those are useful controls for a **reviewed, non-sensitive demonstration workload**.

They are not an independent hostile-code boundary. In particular, a separate process or working directory alone is not proof that a worker cannot reach other state or sockets available under its operating-system identity. The same outer VM can contain both the trusted controller and the worker. The design must say this plainly in configuration, logs, and acceptance evidence.

The initial proof therefore uses approved fixture backends and safe synthetic or explicitly permitted data. It does not authorize unreviewed arbitrary shell/code execution, production credentials, sensitive repositories, or self-generated executable candidates inside the shared instance environment. Adversarial *messages and artifacts* can test structural admission without executing an adversarial binary.

The provider advertises only controls and lifecycle verbs that it actually implements. A request for an independent VM, strong per-worker network isolation, or an unsupported checkpoint/resume mode must be rejected—not silently mapped to a process. Application checkpoints are artifacts; they do not imply process-memory or VM snapshot support.

This limitation does not undo the general Agent Host boundary. It makes the first implementation honest and leaves a clean replacement point.

## 6. Preserve externally provided workers as the destination

Today:

```text
Vessel delegation -> embedded WI authorization -> local Agent Host -> process
```

Later:

```text
Vessel delegation -> authorized WI boundary -> external provider -> worker environment
```

The Vessel owns why the work exists, the requested bounds, supervision, and acceptance. WI owns the accountable crossing and final authorization. The Agent Host adapts worker technique. A provider owns the infrastructure-side realization. AQ retains durable opaque coordination.

Work orders, worker events, artifact references, cancellation, and acceptance must not require a local PID, host path, containerd namespace, or host socket in the Vessel's semantic records. Provider-specific handles stay in the adapter. Simulated remote-provider tests can prove lack of locality assumptions; they do not prove a deployed remote backend exists.

Eventually, the worker may be in a different VM, machine, cloud, or admitted administrative domain. It is a child in the delegation graph, not necessarily physically nested inside the Vessel's container. A resource request remains constrained by the parent's delegable grant and the provider's policy.

## 7. DigiCorp's place in the eventual system

DigiCorp will likely coordinate execution authority across functional AQ/WI embedded and platform deployments, Vessels, providers, organizational resources, and governance. It can decide where an approved workload may run and under what organizational budget and policy. That remains future composition, not a new EXO-V3 infrastructure dependency.

The current plan preserves the concepts needed to reach it: portable identity distinct from a host, explicit authority, opaque resource references, durable handoffs, independent acceptance, and external activation. It does not freeze a DigiCorp federation API, identity standard, provider marketplace, distributed lock service, or global scheduling algorithm.

Multiple AQ instances will not automatically be one distributed queue. Multiple WI instances will not automatically share authorization or idempotency records. Those future service contracts need their own design and evidence after embedded viability is demonstrated.

Likewise, an approved-operator VM is not a promise of protection against an untrusted infrastructure operator. Confidential execution, attestation, secret release to a verified instance, and cross-provider fencing are future security profiles. They are deliberately not prerequisites for this initial target. Confidential Containers describes that stronger host-threat model separately. [S6]

## 8. What to prove now

| Proof | Required outcome |
|---|---|
| Instance realization | Host evidence identifies the actual Kata runtime and its VM; no silent ordinary-container fallback. |
| Authority separation | No host management interface or activation credential is exposed to the guest workload. |
| Persistence | Stop/recreate/restart preserves the correct Vessel identity, state, queue histories, and outbox reconciliation. |
| Worker lifecycle | Duplicate start, cancellation, exit, late events, and restart converge through the real AQ/WI contracts. |
| Acceptance | Worker success remains evidence, not automatic commitment completion. |
| Limitation honesty | An unsupported strong-isolation request is refused; the process proof is never labeled hostile-code containment. |
| Portability seam | The Vessel uses worker references and artifacts without relying on process-local implementation details. |
| Viability | A representative bounded workload completes with inspectable costs, latency, failure behavior, and recovery. |

These are planned acceptance requirements, not results already obtained. The package accompanying this note contains a concrete case matrix and an allocation within the existing nineteen PRs.

## 9. Decision boundary

Adopt Kata/containerd as the **initial qualified instance target**, not an eternal monopoly on where a Vessel may run. Permit ordinary native unit tests and clearly labeled local fixtures; do not count them as Kata deployment conformance. No automatic fallback from an advertised VM profile is allowed.

Retain the process-managed worker backend long enough to prove the delegation design. Do not promote it into a security guarantee that it does not provide. Add an externally provided worker backend when the evidence and use case require one, without redefining Vessel identity or worker semantics.

The measure of success now is a functional, recoverable, governed Exoskeleton. DigiCorp becomes possible because those components work—not because its future infrastructure has been preemptively embedded into them.

## Sources and status

Technology facts are based on the following primary documentation consulted September 12, 2026. The referenced branches are living documentation, not release pins; implementation must select exact tested versions. Normative choices in this note are project decisions, not guarantees asserted by those projects.

- **[S1]** [Kata Containers architecture](https://github.com/kata-containers/kata-containers/blob/main/docs/design/architecture/README.md): VM-backed runtime, guest/workload/host boundaries, and multi-container sandbox behavior.
- **[S2]** [containerd Runtime v2](https://github.com/containerd/containerd/blob/main/docs/runtime-v2.md): manager/shim responsibility and runtime selection.
- **[S3]** [Kata with containerd installation guidance](https://github.com/kata-containers/kata-containers/blob/main/docs/install/container-manager/containerd/containerd-install.md): package maintenance and compatibility qualification.
- **[S4]** [Using Kata and containerd](https://github.com/kata-containers/kata-containers/blob/main/docs/how-to/containerd-kata.md): direct integration paths as well as CRI.
- **[S5]** [Kata storage architecture](https://github.com/kata-containers/kata-containers/blob/main/docs/design/architecture/storage.md): storage transport choices.
- **[S6]** [Confidential Containers trust model](https://confidentialcontainers.org/docs/architecture/trust-model/trust-model/): the distinct untrusted-host threat model.

The planning source is the supplied import-corrected EXO-V3 r3 package, its WI/AQ companion plans, and the owner's bottom-up sequencing clarification. No running infrastructure, repository completion status, or Kata deployment was tested while preparing this revision.
