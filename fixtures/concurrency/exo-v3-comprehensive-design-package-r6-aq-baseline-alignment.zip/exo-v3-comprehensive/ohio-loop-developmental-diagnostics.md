# OHIO-Informed Developmental Diagnostics for Exoskeleton

**Status:** Normative planning addendum to `EXO-V3-COMPREHENSIVE-2`  
**Cross-stack profile:** `STACK-DEVELOPMENTAL-DIAGNOSTICS-1`  
**Base architecture:** `EXO-V3` on `STACK-2026-07-25-FOUNDATIONAL-2`  
**Date:** August 10, 2026

## 1. Purpose

The colleague-provided OHIO loop diagram offers a useful developmental insight: performance at a particular class of work is constrained by the interaction among available intelligence, the representation made available to that intelligence, and the harness that turns capability into durable results. The limiting factor can rotate. Continued investment in a non-binding factor produces diminishing returns, while a change in one factor can reopen useful work in another.

This addendum adapts that insight to Exoskeleton without importing a specialized business ontology, replacing any current architectural plane, introducing another execution engine, or turning a conceptual performance equation into a constitutional objective.

The resulting rule is:

> Before authorizing another improvement campaign, identify the task-scoped binding constraint with controlled evidence, then change the smallest relevant component while preserving authority, continuity, and protected invariants.

The OHIO loop is therefore used as a **developmental diagnostic lens**. It is not the runtime loop of the Vessel and it is not a new architectural owner.

## 2. Why the distinction matters

A specialized agent system can embed a stable domain model, a fixed workbench, and a narrow evaluation function because the operating domain is known. Exoskeleton has a different responsibility. It is a general thesis about persistent agency, identity, embodiment through accountable interfaces, long-horizon commitments, replaceable cognition, and governed development.

A domain-specific OHIO implementation may legitimately define concepts such as accounting ledgers, ERP modules, defect classes, release trains, or customer environments as native application objects. Exoskeleton must not elevate those objects into Vessel-kernel ontology. It should instead provide the general mechanisms through which a specialized Vessel or application can:

- define a task distribution and evaluation contract;
- expose an appropriate representation to selected faculties;
- coordinate tools, delegates, verifiers, and boundary effects;
- measure outcomes and resource use;
- diagnose the current binding constraint;
- propose and safely evaluate a change;
- retain, roll back, quarantine, or stop;
- revisit a prior saturation judgment when the environment changes.

This preserves the architecture's generality while allowing highly specialized systems to exploit the same developmental machinery. A legacy accounting or ERP maintenance system can therefore own the detailed representations, tools, acceptance suites, and operational conventions needed by that business without turning those conventions into universal Exoskeleton semantics.

## 3. Stack translation of intelligence, ontology, and harness

The terms in the diagram are useful only after their meanings are made precise in the stack. This package uses **capability (I)**, **working representation (R)**, and **harness (H)** in implementation text. The letter `R` is preferred over `O` inside the codebase to avoid confusing a faculty-facing projection with canonical ontology, domain state, or schema authority.

### 3.1 Intelligence means a capability profile

In Exoskeleton, intelligence is not the Vessel, its identity, its Purpose Charter, or its authority. It is the bounded capability of one or more replaceable components under a declared operating envelope.

Examples include:

- a local or remote foundation model;
- a modality-specific faculty;
- a planner or search component;
- an independent verifier;
- a delegated specialist reached through an Agent Host;
- a composite faculty configuration.

A capability profile is meaningful only with a task distribution, context budget, tool envelope, resource budget, and version fingerprint. "Model X is smarter" is not an admissible developmental claim by itself.

### 3.2 Ontology means working representation

The word ontology is potentially misleading inside Exoskeleton because the architecture already distinguishes canonical domain records, schemas, epistemic state, narrative, memory, and specialist application concepts.

The preferred implementation term is **working representation**:

- the structural projection supplied to a cognitive episode;
- the schema resolution and detail level selected for a faculty;
- the evidence, claims, relationships, plans, constraints, and artifacts included or excluded;
- the task decomposition and output contract;
- the versioned context compiler and representation policy that produced the projection.

Canonical state can remain semantically rich for replay, governance, history, and future use. A particular faculty should receive only the representation it can use effectively for the admitted purpose.

This yields the engineering maxim:

> **Rich at rest; selective in cognition.**

More structure is not automatically better. Excess detail can consume context, increase ambiguity, amplify irrelevant correlations, or expose distinctions that the selected faculty cannot exploit. Stronger faculties may justify higher-resolution representation profiles, but that is an empirical claim rather than a reason to change canonical state.

### 3.3 Harness means operationalization across the stack

The harness is not one repository. It is the collection of mechanisms that convert capability and representation into accountable, durable outcomes.

Within Exoskeleton it includes:

- demand admission and attention;
- context compilation;
- faculty selection and fan-out/fan-in;
- planning, delegation, skills, and verification;
- acceptance policy and epistemic admission;
- developmental campaign supervision.

Within WorldInterface it includes:

- exact resource and audience resolution;
- final executable authorization;
- candidate environment, build, trial, activation, and rollback effects;
- observations, receipts, uncertainty, and reconciliation.

Within ActionQueue it includes:

- idempotent admission;
- durable continuations and signals;
- deadlines, retries, checkpoints, budgets, fan-out, backpressure, and recovery;
- immutable causal correlation.

A harness intervention must still identify the component actually changed. "Improve the harness" is too broad to evaluate.

## 4. Performance is scoped, multidimensional, and constrained

There is no global scalar called Vessel performance. Every developmental assessment is scoped by at least:

```text
task distribution
operating environment
resource and latency budget
authority and information-use envelope
component fingerprint
evaluation plan and metric vector
observation period
```

The same Vessel may be capability-limited on one task distribution, representation-limited on another, and harness-limited on a third.

The metric vector can include:

- task correctness and completeness;
- calibration and uncertainty reporting;
- commitment reliability;
- recovery after interruption or restart;
- external effect correctness;
- verification yield and contradiction rate;
- cost, latency, token use, compute, and storage;
- constitutional and information-flow conformance;
- security and abuse resistance;
- continuity and narrative impact.

Protected invariants are hard constraints. A candidate that gains benchmark score by widening authority, weakening information-use rules, hiding uncertainty, reducing auditability, or breaking continuity is not an improvement under the accepted evaluation contract.

## 5. New developmental records

### 5.1 Task distribution

```rust
pub struct TaskDistribution {
    pub id: TaskDistributionId,
    pub version: TaskDistributionVersion,
    pub purpose_classes: Vec<PurposeClassId>,
    pub workload_manifest_ref: ArtifactRef,
    pub sampling_policy_ref: PolicyRef,
    pub environment_requirements: Vec<EnvironmentRequirement>,
    pub authority_envelope_ref: AuthorityEnvelopeRef,
    pub information_use_envelope_ref: InformationGovernanceEnvelopeRef,
    pub validity_window: TemporalWindow,
}
```

The workload manifest is immutable for a frozen evaluation plan. Changes create a new distribution version.

### 5.2 Capability profile

```rust
pub struct CapabilityProfile {
    pub id: CapabilityProfileId,
    pub version: ComponentVersion,
    pub component_refs: Vec<ComponentVersionRef>,
    pub declared_modalities: Vec<ModalityClass>,
    pub declared_capabilities: Vec<CapabilityClaim>,
    pub supported_task_distributions: Vec<TaskDistributionRef>,
    pub compatible_representation_profiles: Vec<RepresentationProfileRef>,
    pub tool_envelope_ref: ToolEnvelopeRef,
    pub context_limits: ContextLimits,
    pub resource_characteristics: ResourceCharacteristics,
    pub calibration_evidence: Vec<EvaluationResultRef>,
    pub provenance_ref: ProofRef,
}
```

A capability profile is an inspectable, versioned claim about bounded competence. Its declarations require calibration evidence. It is not the Vessel, an identity record, an authority grant, or a promise that the component performs uniformly outside its tested scope.

### 5.3 Representation profile

```rust
pub struct RepresentationProfile {
    pub id: RepresentationProfileId,
    pub version: ComponentVersion,
    pub applicable_task_distributions: Vec<TaskDistributionRef>,
    pub supported_faculty_profiles: Vec<FacultyProfileRef>,
    pub projection_policy_ref: PolicyRef,
    pub detail_level: DetailLevel,
    pub context_budget: ContextBudget,
    pub schema_versions: Vec<PinnedSchemaRef>,
    pub required_capabilities: Vec<CapabilityRequirement>,
    pub exclusion_policy_ref: PolicyRef,
    pub calibration_evidence: Vec<EvaluationResultRef>,
    pub provenance_ref: ProofRef,
}
```

A representation profile is a Behavioral Component. It is versioned, provenance-linked, evaluated, activated, retired, and replayable.

### 5.4 Component fingerprint

```rust
pub struct ComponentFingerprint {
    pub id: ComponentFingerprintId,
    pub vessel_runtime_version: ComponentVersionRef,
    pub capability_profile_refs: Vec<CapabilityProfileRef>,
    pub faculty_versions: Vec<ComponentVersionRef>,
    pub representation_profile_ref: RepresentationProfileRef,
    pub context_compiler_version: ComponentVersionRef,
    pub skill_versions: Vec<ComponentVersionRef>,
    pub verifier_versions: Vec<ComponentVersionRef>,
    pub constitution_versions: Vec<PolicyVersionRef>,
    pub schema_versions: Vec<SchemaVersionRef>,
    pub worldinterface_profile_ref: OpaqueRef,
    pub actionqueue_profile_ref: OpaqueRef,
    pub environment_ref: OpaqueRef,
    pub authority_envelope_ref: AuthorityEnvelopeRef,
    pub information_use_envelope_ref: InformationGovernanceEnvelopeRef,
    pub resource_budget_ref: BudgetRef,
    pub digest: ContentHash,
}
```

A fingerprint describes the evaluated configuration. It does not grant authority and it does not imply equivalence merely because two human-readable labels match. A comparison is inadmissible when a behaviorally relevant component cannot be pinned or recorded as an explicit confound.

### 5.5 Intervention class

```rust
pub enum InterventionClass {
    Intelligence,
    Representation,
    Harness,
    Mixed,
}
```

The class is a diagnostic label. The proposal still names exact affected components.

### 5.6 Controlled probe

```rust
pub struct ControlledInterventionProbe {
    pub id: ProbeId,
    pub task_distribution_ref: TaskDistributionRef,
    pub evaluation_plan_ref: EvaluationPlanRef,
    pub target_intervention: InterventionClass,
    pub baseline_fingerprint_ref: ComponentFingerprintRef,
    pub candidate_fingerprint_ref: ComponentFingerprintRef,
    pub fixed_dimensions: Vec<FixedDimensionAssertion>,
    pub declared_confounds: Vec<ConfoundRef>,
    pub randomization_or_pairing_ref: Option<PolicyRef>,
    pub evidence_refs: Vec<EvidenceRef>,
    pub result_ref: EvaluationResultRef,
}
```

"Fixed" means fixed within the declared experimental tolerance. Any unavoidable difference is recorded as a confound rather than silently ignored.

### 5.7 Capability-frontier assessment

```rust
pub enum BindingConstraint {
    Intelligence,
    Representation,
    Harness,
    Mixed,
    Saturated,
    Unknown,
}

pub struct CapabilityFrontierAssessment {
    pub id: CapabilityFrontierAssessmentId,
    pub task_distribution_ref: TaskDistributionRef,
    pub baseline_fingerprint_ref: ComponentFingerprintRef,
    pub probe_refs: Vec<ProbeRef>,
    pub estimated_marginal_gains: Vec<MarginalGainEstimate>,
    pub interaction_effects: Vec<InteractionEstimate>,
    pub binding_constraint: BindingConstraint,
    pub confidence: CalibratedBand,
    pub unresolved_confounds: Vec<ConfoundRef>,
    pub saturation_scope: Option<SaturationScope>,
    pub invalidation_conditions: Vec<FrontierInvalidationCondition>,
    pub recommended_intervention: Option<InterventionClass>,
    pub assessed_at: Timestamp,
}
```

The assessment is evidence-linked and defeasible. It is not an authorization to implement or activate a change.

### 5.8 Developmental campaign

```rust
pub struct DevelopmentalCampaign {
    pub id: DevelopmentalCampaignId,
    pub concern_ref: ConcernRef,
    pub frontier_assessment_ref: CapabilityFrontierAssessmentRef,
    pub evaluation_plan_ref: EvaluationPlanRef,
    pub intervention_class: InterventionClass,
    pub iteration_budget: u32,
    pub resource_budget_ref: BudgetRef,
    pub stagnation_policy_ref: PolicyRef,
    pub stop_conditions: Vec<StopCondition>,
    pub status: DevelopmentalCampaignStatus,
}
```

The campaign may produce multiple candidate proposals, but each candidate remains separately versioned and evaluated. Campaign admission does not activate any candidate.

## 6. Revised improvement proposal contract

An `ImprovementProposal` should additionally identify:

```rust
pub struct ImprovementProposal {
    // Existing fields remain.
    pub task_distribution_ref: TaskDistributionRef,
    pub frontier_assessment_ref: CapabilityFrontierAssessmentRef,
    pub intervention_class: InterventionClass,
    pub baseline_fingerprint_ref: ComponentFingerprintRef,
    pub candidate_scope: Vec<ComponentRef>,
    pub fixed_dimensions: Vec<FixedDimensionAssertion>,
    pub expected_marginal_gain: Vec<ExpectedMetricChange>,
    pub falsification_conditions: Vec<FalsificationCondition>,
    pub declared_confounds: Vec<ConfoundRef>,
}
```

An assessment may remain `Unknown` when evidence is insufficient. The architecture should prefer an explicitly uncertain diagnosis to a confident but unsupported classification.

## 7. Controlled comparison strategy

### 7.1 Single-lever probes

A first diagnostic campaign should prefer small controlled comparisons:

| Probe | Hold fixed where feasible | Change | Primary inference |
|---|---|---|---|
| Intelligence | representation, orchestration, tools, budget, workload | faculty/model/verifier capability | gain suggests capability was binding |
| Representation | faculty, orchestration, tools, budget, workload | projection, schema resolution, context profile, decomposition | gain suggests working representation was binding |
| Harness | faculty, representation, budget, workload | routing, retrieval, delegation, tools, verification, continuation policy | gain suggests operationalization was binding |

The inference remains provisional because interactions, measurement error, workload drift, and resource asymmetry may exist. The assessment records evidence and calibrated uncertainty; it does not claim philosophical or universal causation.

### 7.2 Small factorial campaigns

When interaction effects are likely, a bounded factorial campaign is preferable. A practical initial profile is:

```text
I0 baseline faculty       I1 stronger or specialist faculty
R0 minimal representation R1 richer typed representation
H0 simple harness         H1 delegated/tool-using/verified harness
```

All eight arms use the same frozen task distribution, authority ceiling, information-use rules, and evaluation policy. Resource budgets may be equalized or explicitly normalized. The campaign estimates main effects and interaction effects rather than pretending each dimension is independent.

A full factorial is not mandatory for every change. It is a diagnostic tool whose cost must be justified by uncertainty and decision consequence.

### 7.3 Protected evaluation

The implementation subject cannot modify:

- workload membership;
- protected invariants;
- score policy;
- reference outputs or hidden tests;
- baseline fingerprints;
- authority envelopes;
- stop and rollback triggers;
- arm assignment or excluded-result policy.

Evaluation infrastructure is itself a Behavioral Component and is versioned, independently reviewed, and monitored for drift. Development sets, calibration sets, protected holdouts, and post-activation observations remain distinguishable so repeated campaigns cannot silently train against every acceptance case.

## 8. Representation resolution and the moving frontier

A stronger faculty can exploit distinctions that a weaker faculty cannot. Conversely, a rich representation can degrade a weaker faculty through context pressure and ambiguity.

The context compiler therefore selects a representation profile using structural inputs:

```text
episode purpose
task distribution
selected faculty profile
required output schema
context and latency budget
information governance envelope
known calibration evidence
current viability state
```

The selection decision is inspectable. The faculty may request additional information through a bounded proposal, but it cannot silently alter its Context Manifest or activate a new representation profile.

When a relevant capability changes, representation-profile calibration becomes stale. A stronger model, new modality, specialist delegate, verifier, tool, or environment may invalidate a previous saturation record and justify reevaluating higher-resolution profiles.

## 9. Saturation and stop policy

Saturation is never global and permanent. A `SaturationRecord` means only:

> Under this task distribution, component fingerprint, environment, budget, evaluation policy, and observation window, tested interventions produced marginal gain below the declared threshold.

A saturation record includes invalidation conditions such as:

- faculty or model version change;
- new modality or specialist availability;
- representation-profile or schema change;
- harness/tool/connector change;
- workload distribution shift;
- resource-budget shift;
- evaluator or verifier change;
- environment or external-system change;
- newly discovered confound or measurement defect.

A campaign reaches a bounded disposition when:

- the expected gain is achieved;
- protected regression is observed;
- the iteration or resource budget is exhausted;
- marginal gain remains below threshold for the stagnation window;
- the diagnosis is falsified;
- evidence is inconclusive;
- another concern becomes more urgent;
- the relevant frontier is provisionally saturated.

The allowed next actions are switch lever, redesign the evaluation, defer until invalidation, or stop. Endless self-optimization is not a valid default.

## 10. Cross-stack execution

### 10.1 Exoskeleton ownership

Exoskeleton owns:

- task-distribution and metric semantics;
- component fingerprints and representation profiles;
- binding-constraint diagnosis;
- campaign admission and budget;
- Evaluation Plan freeze;
- candidate comparison and performance-vector interpretation;
- acceptance, continuity, rollback recommendation, and developmental history.

### 10.2 WorldInterface ownership

WorldInterface executes and evidences accountable boundary operations. It preserves campaign and arm references as causal context, while independently applying ordinary authorization and information-use policy.

It may provide evidence for:

- environment provisioning and teardown;
- source checkout and candidate build;
- connector, toolchain, image, and policy versions;
- artifact digests and publication;
- trial/canary start and stop;
- external observations and verification effects;
- timing and resource summaries;
- activation, rollback, quarantine, and reconciliation.

Receipts establish what crossed the boundary and what was observed. They do not decide which arm won.

### 10.3 ActionQueue ownership

ActionQueue durably executes campaign work and preserves trace, correlation, causation, and one bounded opaque reference to an immutable, application-owned `CampaignExecutionContext`. That context may identify the campaign, intervention arm, task-distribution version, Evaluation Plan, and expected Component Fingerprint. ActionQueue does not dereference it and does not understand capability, representation, harness, task distributions, benchmarks, or saturation.

Campaign correlation never grants priority, budget, routing eligibility, or authority. Those properties use ordinary explicit queue fields and application decisions. A successful queue disposition proves only that the handler completed according to its execution contract; it does not prove that the work product was correct or that an intervention improved the Vessel.

## 11. Observability

Operators need views that answer:

- What task distribution and evaluation plan were used?
- What exact component fingerprint produced each result?
- Which dimension was changed and which were held fixed?
- What confounds and exclusions were declared?
- What is the estimated marginal gain by intervention class?
- Are interaction effects material?
- Which representation profile was supplied to each faculty?
- Did representation complexity improve utility or merely consume context?
- Why was a campaign continued, switched, stopped, or declared saturated?
- Which change invalidated a prior frontier assessment?
- Were authority, information-use, and resource envelopes equivalent across arms?
- Which WorldInterface receipts and ActionQueue histories support each measurement?

Views must distinguish:

```text
raw execution fact
boundary observation or receipt
verification result
evaluation result
frontier assessment
improvement acceptance
activation state
```

These are not interchangeable.

## 12. Risks and mitigations

### 12.1 Benchmark overfitting

**Risk:** the system optimizes a narrow frozen workload while degrading real work.  
**Mitigation:** holdout distributions, long-horizon scenarios, adversarial cases, periodic distribution review, and post-activation monitoring.

### 12.2 False bottleneck diagnosis

**Risk:** correlated changes are attributed to the wrong dimension.  
**Mitigation:** fixed-dimension assertions, explicit confounds, paired runs, bounded factorial campaigns, independent review, and calibrated uncertainty.

### 12.3 Ontology or representation bloat

**Risk:** canonical richness is copied indiscriminately into every context.  
**Mitigation:** versioned Representation Profiles, context budgets, exclusion policy, complexity metrics, and proof that added structure improves utility.

### 12.4 Harness leakage into lower-layer semantics

**Risk:** WorldInterface or ActionQueue begins interpreting domain benchmarks or developmental goals.  
**Mitigation:** typed opaque references, strict ownership, no free-form metadata maps, and conformance tests proving lower layers preserve but do not interpret developmental context.

### 12.5 Metric gaming

**Risk:** a candidate improves measured scores while hiding uncertainty, weakening verification, or changing workload eligibility.  
**Mitigation:** frozen protected evaluation, independent verifier roles, immutable workload manifests, versioned evaluator components, and hard invariant gates.

### 12.6 Improvement churn

**Risk:** the Vessel spends excessive attention on recursive optimization.  
**Mitigation:** campaign budgets, stagnation windows, cooldowns, portfolio scheduling, explicit saturation records, and termination dispositions.

### 12.7 Capability change mistaken for authority change

**Risk:** a stronger faculty is treated as deserving wider permissions.  
**Mitigation:** capability and authority remain independent. Every candidate and activated component inherits the same or explicitly amended authority ceiling through ordinary governance.

## 13. Implementation allocation

No twentieth implementation PR is added.

- **EXO-04:** task-distribution, schema, semantic-time, and evaluation-record foundations.
- **EXO-05:** Representation Profile linkage to Context Manifest and information-governance enforcement.
- **EXO-07:** faculty capability profiles and exact component versions.
- **EXO-13:** metric vectors, immutable evaluation results, confound records, and independent comparison evidence.
- **EXO-14:** component fingerprints, Representation Profiles, calibration evidence, and compatibility declarations.
- **EXO-15:** Capability Frontier Assessments, Developmental Campaigns, controlled probes, saturation, invalidation, stop policy, and lifecycle integration.
- **EXO-16:** campaign behavior in degraded modes and protected resource reserves.
- **EXO-18:** evaluator integrity, privacy, abuse resistance, and operator controls.
- **EXO-19:** cross-stack reference campaign and release qualification.

## 14. Acceptance statement

The developmental-diagnostics revision is complete when Exoskeleton can run a bounded, restart-safe campaign over a frozen task distribution; preserve exact capability, component, representation, environment, authority, information-use, and budget fingerprints; compare at least one intelligence, representation, and harness intervention; record confounds and multidimensional results; produce a calibrated binding-constraint or `Unknown` assessment; stop or switch under stagnation; invalidate saturation after a relevant change; and do all of this without granting the candidate, evaluator, WorldInterface, ActionQueue, or an external artifact authority to accept or activate the improvement.
