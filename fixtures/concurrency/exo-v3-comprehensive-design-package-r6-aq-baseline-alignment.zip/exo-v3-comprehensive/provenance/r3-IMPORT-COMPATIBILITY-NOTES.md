# Exoskeleton work-breakdown import correction

**Artifact revision:** `r3-import-fix`  
**Patch ID:** `EXO-PLAN-4-IMPORT-FIX-1`  
**Supersedes for import:** `exo-v3-comprehensive-design-package-r2.zip`  
**Planning revision retained:** `EXO-PLAN-4`  
**Architecture profile retained:** `EXO-V3-COMPREHENSIVE-2`  
**Cross-stack profile retained:** `STACK-DEVELOPMENTAL-DIAGNOSTICS-1`

## Cause and correction

The r2 work breakdown used `work_items` as its collection key and did not
include `document`. The application reported these two missing top-level fields
and stopped without creating a project, plan version, or work item. Previous
package validation checked the internal planning structure, not this import
contract. This patch corrects the package rather than requiring the importer
to accept a separate Exoskeleton layout.

| Field | Correction | Count |
|---|---|---:|
| `document` | Add `EXO-V3 Comprehensive Implementation Plan`, matching the existing implementation-plan heading. | 1 |
| `pull_requests` | Rename `work_items`; retain the same ordered collection, not a second list or alias. | 1 collection / 19 PRs |
| `pull_requests[*].primary_areas` | Add non-empty string lists naming existing implementation scope and logical ownership. | 19 |
| `pull_requests[*].risk` | Add non-empty planning risk ratings with the rationale below. | 19 |
| `pull_requests[*].exit_gate` | Copy each PR's existing Section 7 exit gate verbatim from the implementation plan. | 19 |

The `primary_areas` and `risk` checks come from the prior WorldInterface import
report. Fixing only the two top-level fields would leave all 38 of those
per-PR fields absent. The `exit_gate` fields are also populated to match the
companion packages and the local shared structural validator. The application
has not reported `exit_gate` as an error here; including it is a preventive
normalization of existing plan content, not a claim about its unpublished schema.

Area labels refer to existing scope and logical boundaries in implementation-plan
Sections 5 and 7, including the retained developmental-diagnostics allocation.
They do not mandate new physical crates, create directories, expand scope, or
override the physical-crate staging rule in Section 5.14. All assignments and
source references are recorded in `exo-v3-import-validation.json`.

## Preservation and package boundaries

All nineteen PR IDs, titles, sequence values, dependencies, statuses, and
`developmental_diagnostics_scope` values are unchanged. All original top-level
values are retained; only the collection key changes. Removing the added fields
and reversing the collection-key rename reproduces the original parsed r2 YAML
exactly. The YAML contains one canonical PR list and the package contains one
work-breakdown YAML; no invalid legacy fixture is bundled for the importer to find.

The implementation plan, architectural design, contract, threat model,
OHIO-derived addendum, shared cross-stack profile, and both acceptance matrices
remain byte-for-byte identical to r2. Their eight source hashes and equality
checks are included in the import-validation report. The schema/profile labels
and plan revision are retained; the artifact revision identifies this packaging
correction. No runtime architecture, work-item identity, dependency graph,
implementation sequence, acceptance criterion, or authority boundary is redesigned.

Updated support artifacts are the README, import notes, local validator and
regression tests, validation reports, and checksum manifests. The optional
combined distribution is `r4-exo-import-fix`: it includes this Exoskeleton
correction while retaining the WorldInterface `r3-import-fix` and ActionQueue
`r2` package contents unchanged. Any older WorldInterface note referring to
Exoskeleton's `work_items` layout describes the prior r2 artifact and is
superseded by this patch.

## Risk metadata

These are editorial planning judgments drawn from the existing scope, tests,
exit gates, and risk register in the implementation plan, not measured
probabilities or previously assigned values. `medium` denotes baseline/control
work; `high` denotes substantial semantic, integration, or decontamination risk;
`critical` denotes load-bearing persistence, authority, external-effect,
evaluation, lifecycle, recovery, security, or release-conformance boundaries.
The validator requires only a non-empty string and does not invent an importer
enumeration or make a rating an authorization or merge decision.

| Work item | Risk | Rationale |
|---|---|---|
| EXO-01 | `medium` | Baseline, archive, disposition, and conformance omissions can misdirect later work, but this PR establishes controls rather than changing target runtime behavior. |
| EXO-02 | `critical` | Atomic domain transitions, fresh persistence, replay, revisions, and outboxes underpin the authoritative state and recovery guarantees of every later PR. |
| EXO-03 | `critical` | Genesis, activation, role separation, commissioning, and lifecycle transitions establish enduring identity and must not mix local instantiation with external-effect authority. |
| EXO-04 | `high` | Incorrect temporal, schema, evidence, or workload semantics can corrupt replay, current beliefs, dependent-plan review, and later developmental comparisons. |
| EXO-05 | `critical` | Instruction admission, context envelopes, derivation, and source-sink restrictions prevent untrusted prose from becoming authority or unauthorized disclosure. |
| EXO-06 | `high` | Ingress deduplication, durable attention, interruption, and stale-response handling must preserve obligations and avoid losing or misrouting work. |
| EXO-07 | `critical` | Structural faculty contracts and pure arbitration must block prose control, unsupported claim types, and upward-authority edges while preserving model-independent identity. |
| EXO-08 | `high` | Commitment admission, portfolio conflicts, capacity, initiative, and quiescence must sustain obligations without bypassing feasibility, authority, or protected reserves. |
| EXO-09 | `high` | Continuity projections must preserve evidence, history, trust distinctions, and information-use restrictions rather than inventing autobiography or unrestricted reuse. |
| EXO-10 | `critical` | Local authority ceilings, approval binding, acting capacities, persona disclosure, and key exclusion are security boundaries and cannot replace final WorldInterface authorization. |
| EXO-11 | `critical` | Cross-store handoffs, idempotent admission, waits, acknowledgments, and uncertain effects must converge under crashes without lost wakes, duplicate effects, or compatibility authority paths. |
| EXO-12 | `critical` | Delegation crosses sandbox, identity, artifact, cancellation, and nested-authority boundaries; run supervision must remain durable and attenuate scope and budget. |
| EXO-13 | `critical` | Independent, version-bound evidence and protected evaluation criteria must prevent self-certified completion, stale acceptance, or metric gains overriding hard invariants. |
| EXO-14 | `high` | Component provenance, fingerprints, compatibility, and calibrated capability/representation profiles must track behavior changes without silently changing canonical state or authority. |
| EXO-15 | `critical` | Self-improvement diagnosis, candidate evaluation, activation, rollback, and campaign control must preserve separated roles, protected roots, immutable criteria, and non-amplifying authority. |
| EXO-16 | `critical` | Partial failure, compromised components, depleted reserves, and recovery must not disable governance, protected service, or durable reconstruction of operational mode. |
| EXO-17 | `high` | Incomplete decontamination can retain selectable legacy control paths, pre-v3 readers, or specialist runtime semantics alongside the intended single target architecture. |
| EXO-18 | `critical` | Identity/proof, sensitive stores, lifecycle credentials, operator controls, protected evaluations, and restore drills form the release security and operational trust boundary. |
| EXO-19 | `critical` | The final release gate must expose cross-stack, crash, replay, security, developmental, continuity, and restore failures against exact upstream revisions before publishing a breaking release. |

## Validation and limits

The local validator reproduces exactly the two reported missing-field errors
on the source r2 YAML. The corrected YAML passes **40 known/reported field
checks** (two top-level plus 38 per-PR) and **174 local structural checks**, with
zero errors. The original 83 Exoskeleton package checks still pass within the
updated 125-check package report. The new checks additionally verify the import
fields, structural integrity, and exact correspondence of all nineteen exit
gates with the unchanged Markdown implementation plan.

**26 regression tests pass.** Parameterized cases cover missing/invalid top-level
and per-PR fields, the original two-error shape, the incomplete top-level-only
fix, non-mapping input, invalid IDs/titles/gates, duplicate YAML keys, unsafe or
malformed YAML, dependency errors, sequence drift, duplicate list aliases,
verbatim exit gates, exact inverse preservation of the original parsed data,
and CLI return codes and nonmutation. The WorldInterface 17-test import suite
also continues to pass in the combined package. These are planning-artifact
checks, not implemented-software conformance tests.

The combined validator now reads Exoskeleton's `pull_requests` directly and
runs the same minimum field and structural checks against all three work
breakdowns. Its 305 checks pass: 125 Exoskeleton, 97 WorldInterface, 59
ActionQueue, and 24 cross-stack. Counts include aggregate checks and should
not be confused with 305 independent runtime tests. The existing 180 acceptance
cases remain planning specifications.

**The application importer itself was not executed and its complete schema
was not supplied.** Passing these checks establishes the reported corrections
and the explicitly described local safeguards, not undisclosed importer
requirements or correctness of the future runtime implementation.

## Use and verification

Import the complete `exo-v3-comprehensive-design-package-r3-import-fix.zip`
instead of r2. The internal directory is still `exo-v3-comprehensive/` and the
work-breakdown filename is still `exo-v3-comprehensive-work-breakdown.yaml`.
Do not merge old and corrected extracted trees or supply both package versions
in one import. The standalone YAML is also provided for direct-file import.

From the extracted Exoskeleton directory, with Python and PyYAML available:

```sh
python validate_work_breakdown.py
python -m unittest -v test_work_breakdown_import
sha256sum -c SHA256SUMS
```

The local validator emits JSON without modifying the package and accepts an
optional work-breakdown path. It exits 0 for success, 1 for validation failure,
and 2 for unreadable or unparseable input. The same script accepts the
WorldInterface and ActionQueue work-breakdown files for minimum common-field
checks without changing either package.

From the optional combined package root:

```sh
python validate_revision.py
sha256sum -c SHA256SUMS
```

`validate_revision.py` refreshes the package reports deterministically. ZIP
integrity, complete manifest coverage, checksums, preserved companion trees,
and fresh-extraction validation are also checked during release packaging.
