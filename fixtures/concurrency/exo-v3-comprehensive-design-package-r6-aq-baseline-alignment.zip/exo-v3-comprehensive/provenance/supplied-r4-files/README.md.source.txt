# EXO-V3 Comprehensive Design Package — Kata Instance Revision

**Artifact:** r4-kata-instance  
**Plan:** EXO-PLAN-5  
**Architecture profile:** EXO-V3-COMPREHENSIVE-3  
**Execution profile:** EXO-V3-EXECUTION-1  
**Date:** September 12, 2026

This package supersedes `exo-v3-comprehensive-design-package-r3-import-fix.zip` as the Exoskeleton planning baseline. It retains the import-corrected work-breakdown shape and the nineteen PR identities/dependencies. It is planning material, not an implemented runtime or a qualified Kata deployment.

## The decision

The **Vessel instance** initially targets a dedicated Kata Containers VM managed by containerd. The **initial workers** are process-managed through embedded WorldInterface and its Agent Host adapter, normally inside that same outer VM. Process-worker evidence proves the bounded management/delegation contract, not independent hostile-code containment.

Prove a functional Exoskeleton with embedded AQ/WI before expanding them into wider platform services. DigiCorp is the eventual composition and likely external execution authority; it is not a prerequisite for the current work. A minimal operator-owned host supervisor supplies the initial external lifecycle authority.

Externally provisioned worker environments remain a first-class future implementation seam. The local process backend must not make PID, local path, container engine or physical nesting part of Vessel/work-order semantics.

## Read first

1. [Initial target preference and DigiCorp direction](kata-containerd-initial-target-and-digicorp.md).
2. [Normative instance/worker execution supplement](exo-v3-execution-environment.md).
3. [Revision notes and limits](EXECUTION-REVISION-NOTES.md).
4. [Implementation plan](exo-v3-comprehensive-implementation-plan.md) and [work breakdown](exo-v3-comprehensive-work-breakdown.yaml).
5. [Execution profile](exo-v3-execution-profile.yaml), [acceptance cases](exo-v3-execution-environment-acceptance-matrix.yaml), and [qualification runbook](KATA-INSTANCE-QUALIFICATION-RUNBOOK.md).
6. [Concurrency rebinding note](EXECUTION-CONCURRENCY-REBINDING.md) before attaching the earlier draft scheduling sidecar.

The full [architecture](exoskeleton-v3-comprehensive-design.md), [contract](exo-v3-comprehensive-contract.yaml), instruction-integrity threat model, OHIO addendum and inherited acceptance matrices remain part of the package.

## Bottom-up milestone, not a hidden platform project

`EXO-EMBEDDED-VIABILITY-1` is the initial evidence milestone: a Kata-hosted Vessel, actual embedded AQ/WI, reviewed coding and non-coding worker fixtures, independent acceptance, and restart/recovery. It requires no DigiCorp, Kubernetes, external provider fleet, confidential computing or further platform-service implementation.

That narrower milestone is not equivalent to full parent-PR acceptance or the complete EXO-V3 release. Original upstream G1–G5 definitions, dependency lists, security obligations, and release order retain their meaning. When a parent contains outstanding broader work, it remains open. A later decision to publish an embedded-only release needs explicit scope approval; this package does not quietly grant it.

## Import

Import the complete ZIP as a new plan version rather than merging it into an extracted old package. The internal root is still `exo-v3-comprehensive` and the single work-breakdown filename is still `exo-v3-comprehensive-work-breakdown.yaml`.

The work breakdown retains `document`, `pull_requests`, and every PR's `primary_areas`, nonempty `risk`, `depends_on`, `sequence`, `status`, and `exit_gate`. This revision adds execution-profile metadata and scope, and appends execution acceptance obligations to selected gates. [Import notes](IMPORT-COMPATIBILITY-NOTES.md) explain what was preserved and changed.

The profile and acceptance YAML files are supplementary planning records, not additional work-item lists. The application's complete import schema has not been supplied or executed here.

## Validation

With Python 3.10+ and PyYAML available, from this directory:

```sh
python validate_work_breakdown.py
python validate_package.py
python -m unittest -v test_work_breakdown_import test_execution_profile
sha256sum -c SHA256SUMS
```

These are static package/import/regression checks. They do not compile Exoskeleton or execute any runtime security, Kata, hardware, crash, worker, or conformance test. The current reports are `exo-v3-comprehensive-validation.json` and `exo-v3-import-validation.json`. Historical r3 reports under `provenance/` are evidence about that older artifact only.

## Preserved and extended inventory

| Planning inventory | Count |
|---|---:|
| Original implementation PRs | 19 |
| Original constitutional invariants | 104 |
| Original numbered vocabulary entries | 73 |
| Required pre-merge ADRs | 38 (36 retained, 2 execution decisions added) |
| Instruction-integrity acceptance cases | 103 |
| Developmental-diagnostics acceptance cases | 39 |
| Execution-environment acceptance cases | 36 |
| Total represented acceptance cases | 178 |
| Local execution-profile checkpoints | 5 |

All acceptance cases are specifications to be implemented/proved, not passed tests. The inherited matrices retain their original profile labels as provenance and are incorporated unchanged into this profile by the contract.

## Boundaries retained

No new AQ primitive, WI wire type, architectural plane or top-level implementation PR is introduced. The shared `STACK-DEVELOPMENTAL-DIAGNOSTICS-1` profile and the OHIO addendum remain unchanged. AQ and WI packages themselves are not modified or implicitly re-released here.

The code-review source baseline remains `zed-colonel/exoskeleton@1bcbb757a7885ce1f911ac948bfc2269c9209075`; this planning revision does not claim to re-audit current repository progress. Runtime versions and host configuration must be selected and qualified during implementation, not inferred from this package date.
