import copy,json,shutil,tempfile,unittest
from pathlib import Path
import yaml
from validate_aq_alignment import validate
ROOT=Path(__file__).resolve().parent
class AQAlignmentTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)/'p';shutil.copytree(ROOT,self.root,ignore=shutil.ignore_patterns('__pycache__'));self.addCleanup(self.tmp.cleanup)
 def mutate_lock(self,key,value):
  p=self.root/'aq-baseline.lock.json';d=json.loads(p.read_text());d[key]=value;p.write_text(json.dumps(d))
 def test_valid(self):self.assertTrue(validate(self.root)['valid'])
 def test_archive_tamper(self):self.mutate_lock('archive_sha256','0'*64);self.assertFalse(validate(self.root)['valid'])
 def test_tree_tamper(self):
  p=self.root/'aq-source-tree.sha256';p.write_text(p.read_text()+'bad\n');self.assertFalse(validate(self.root)['valid'])
 def test_historical_commit_is_not_current(self):self.mutate_lock('historical_commit_is_current_implementation_pin',True);self.assertFalse(validate(self.root)['valid'])
 def test_no_implicit_publication(self):self.mutate_lock('publication_status','passed');self.assertFalse(validate(self.root)['valid'])
 def test_no_implicit_consumer_pass(self):self.mutate_lock('consumer_conformance_status','passed');self.assertFalse(validate(self.root)['valid'])
 def test_no_returned_run_ids(self):
  p=self.root/'aq-baseline.lock.json';d=json.loads(p.read_text());d['contract_facts']['ensure_task_returns_run_ids']=True;p.write_text(json.dumps(d));self.assertFalse(validate(self.root)['valid'])
 def test_case_cannot_disappear(self):
  p=self.root/'aq-baseline-integration-acceptance-matrix.yaml';d=yaml.safe_load(p.read_text());d['cases'].pop();p.write_text(yaml.safe_dump(d));self.assertFalse(validate(self.root)['valid'])
 def test_case_cannot_auto_pass(self):
  p=self.root/'aq-baseline-integration-acceptance-matrix.yaml';d=yaml.safe_load(p.read_text());d['cases'][0]['status']='passed';p.write_text(yaml.safe_dump(d));self.assertFalse(validate(self.root)['valid'])
 def test_owner_must_enforce_cases(self):
  p=next(self.root.glob('*work-breakdown.yaml'));d=yaml.safe_load(p.read_text());next(i for i in d['pull_requests'] if i.get('aq_baseline_acceptance_cases'))['aq_baseline_acceptance_cases']=[];p.write_text(yaml.safe_dump(d));self.assertFalse(validate(self.root)['valid'])
 def test_unknown_importer_cannot_activate(self):
  p=next(self.root.glob('*work-breakdown.yaml'));d=yaml.safe_load(p.read_text());d['aq_baseline_alignment']['importer_policy']='ignore';p.write_text(yaml.safe_dump(d));self.assertFalse(validate(self.root)['valid'])
if __name__=='__main__':unittest.main()
