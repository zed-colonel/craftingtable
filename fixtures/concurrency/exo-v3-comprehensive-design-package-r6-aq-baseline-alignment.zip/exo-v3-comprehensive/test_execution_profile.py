"""Static regression tests for planning assertions. These do not run Kata or workers."""
from __future__ import annotations

import copy
import json
from pathlib import Path
import subprocess
import sys
import unittest

from validate_package import (
    ROOT, expected_work_breakdown, profile_errors, validate_package, yaml_load,
)


class ExecutionProfileTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.original_profile=yaml_load(ROOT/'exo-v3-execution-profile.yaml')
        cls.original_matrix=yaml_load(ROOT/'exo-v3-execution-environment-acceptance-matrix.yaml')
        cls.work=yaml_load(ROOT/'exo-v3-comprehensive-work-breakdown.yaml')
        cls.ids={i['id'] for i in cls.work['pull_requests']}

    def setUp(self):
        self.profile=copy.deepcopy(self.original_profile)
        self.matrix=copy.deepcopy(self.original_matrix)

    def errors(self):
        return profile_errors(self.profile,self.matrix,self.ids)

    def change(self,path,value):
        target=self.profile
        parts=path.split('.')
        for p in parts[:-1]:target=target[p]
        target[parts[-1]]=value
        self.assertTrue(self.errors(),path)

    def test_valid_planning_profile(self):
        self.assertEqual(self.errors(),[])

    def test_wrong_container_manager(self):
        self.change('instance.container_manager','Docker')

    def test_wrong_runtime(self):
        self.change('instance.runtime_type','io.containerd.runc.v2')

    def test_silent_fallback_rejected(self):
        self.change('instance.silent_runtime_fallback',True)

    def test_unqualified_runtime_cannot_be_claimed_qualified(self):
        self.change('instance.qualification_status','passed')

    def test_host_privilege_not_delegated(self):
        for key in ('host_management_access_from_guest','host_management_access_from_worker'):
            with self.subTest(key=key):
                self.setUp();self.change('instance.'+key,True)

    def test_instance_is_dedicated_vm(self):
        self.change('instance.isolation_unit','shared-pod-for-all-vessels')

    def test_actual_vm_precondition_retained(self):
        self.change('instance.hardware_virtualization_required',False)

    def test_untrusted_host_security_not_implied(self):
        self.change('instance.operator_trust','untrusted-host-attested')

    def test_external_lifecycle_authority_required(self):
        self.change('instance.host_supervisor_required',False)

    def test_process_backend_does_not_claim_own_vm(self):
        self.change('workers.independent_worker_vm',True)

    def test_shared_outer_boundary_is_disclosed(self):
        self.change('workers.same_outer_vm_as_vessel',False)

    def test_arbitrary_hostile_code_not_admitted(self):
        self.change('workers.arbitrary_hostile_code_allowed',True)

    def test_sensitive_production_data_not_admitted(self):
        self.change('workers.sensitive_production_data_allowed',True)

    def test_generated_executable_candidates_not_admitted(self):
        self.change('workers.unreviewed_executable_candidates_allowed',True)

    def test_no_direct_vessel_process_authority(self):
        self.change('workers.direct_exoskeleton_spawn_authority',True)

    def test_no_locality_in_domain_contract(self):
        self.change('workers.domain_records_may_require_local_pid_or_host_path',True)

    def test_external_provider_seam_preserved(self):
        self.change('workers.future_external_provider.preserve_seam',False)

    def test_external_provider_not_current_dependency(self):
        self.change('workers.future_external_provider.required_for_initial_proof',True)

    def test_no_false_external_provider_implementation(self):
        self.change('workers.future_external_provider.implementation_status','implemented')

    def test_stronger_requests_cannot_fall_back(self):
        self.change('workers.future_external_provider.stronger_assurance_may_not_fall_back_to_process',False)

    def test_no_platform_dependencies_for_initial_proof(self):
        for key in ('platform_actionqueue_required_for_initial_proof','platform_worldinterface_required_for_initial_proof'):
            with self.subTest(key=key):
                self.setUp();self.change('embedded_composition.'+key,True)

    def test_no_digicorp_or_kubernetes_prerequisite(self):
        for key in ('digicorp_required','kubernetes_required'):
            with self.subTest(key=key):
                self.setUp();self.change('instance.'+key,True)

    def test_proof_not_parent_acceptance_or_release(self):
        for key in ('marks_all_parent_prs_accepted','satisfies_full_release_gates'):
            with self.subTest(key=key):
                self.setUp();self.change('milestones.initial_embedded_viability.'+key,True)

    def test_no_new_upstream_primitive(self):
        self.change('embedded_composition.new_actionqueue_primitives',['VMRun'])

    def test_real_embedded_runtime_evidence_required(self):
        self.change('milestones.initial_embedded_viability.requires_real_embedded_aq_wi_evidence',False)

    def test_manifest_requirements_cannot_be_empty(self):
        self.change('instance.qualification_manifest_required',[])

    def test_missing_fields_rejected(self):
        del self.profile['instance']['runtime']
        self.assertTrue(self.errors())

    def test_wrong_scalar_types_rejected(self):
        self.change('instance.hardware_virtualization_required','true')

    def test_planned_cases_not_execution_results(self):
        self.matrix['cases'][0]['status']='passed'
        self.assertTrue(self.errors())

    def test_checkpoint_does_not_pass_from_planning(self):
        self.profile['checkpoints'][0]['status']='passed'
        self.assertTrue(self.errors())

    def test_all_checkpoints_required(self):
        self.profile['milestones']['initial_embedded_viability']['requires_checkpoints'].pop()
        self.assertTrue(self.errors())

    def test_no_checkpoint_case_can_be_lost(self):
        self.profile['checkpoints'][0]['acceptance_cases'].pop()
        self.assertTrue(self.errors())

    def test_unknown_case_owner_rejected(self):
        self.matrix['cases'][0]['owner_pr']='EXO-99'
        self.assertTrue(self.errors())

    def test_unknown_checkpoint_rejected(self):
        self.matrix['cases'][0]['checkpoint']='EXO-ENV-G99'
        self.assertTrue(self.errors())

    def test_duplicate_or_missing_case_rejected(self):
        self.matrix['cases'][1]['id']=self.matrix['cases'][0]['id']
        self.assertTrue(self.errors())

    def test_wrong_case_count_rejected(self):
        self.matrix['case_count']=35
        self.assertTrue(self.errors())

    def test_missing_acceptance_criterion_rejected(self):
        self.matrix['cases'][0]['expected']=''
        self.assertTrue(self.errors())

    def test_hardware_requirement_must_be_boolean(self):
        self.matrix['cases'][1]['requires_kata_host']='true'
        self.assertTrue(self.errors())

    def test_only_declared_source_amendments(self):
        base=json.loads((ROOT/'provenance/r3-work-breakdown.json').read_text())
        rules=json.loads((ROOT/'provenance/revision-rules.json').read_text())
        self.assertEqual(self.work,expected_work_breakdown(base,rules))

    def test_full_package_static_validation(self):
        result=validate_package(ROOT)
        self.assertEqual(result['failed_count'],0,[c for c in result['checks'] if not c['passed']])
        self.assertFalse(result['application_importer_executed'])
        self.assertFalse(result['runtime_tests_executed'])
        self.assertFalse(result['kata_host_qualified'])
        self.assertEqual(result['acceptance_case_counts']['total'],178)

    def test_cli_nonmutating_and_successful(self):
        names=['exo-v3-comprehensive-work-breakdown.yaml','exo-v3-execution-profile.yaml']
        before={name:(ROOT/name).read_bytes() for name in names}
        result=subprocess.run([sys.executable,str(ROOT/'validate_package.py')],capture_output=True,text=True,check=False)
        self.assertEqual(result.returncode,0,result.stderr)
        self.assertEqual(json.loads(result.stdout)['failed_count'],0)
        for name in names:self.assertEqual((ROOT/name).read_bytes(),before[name])


if __name__=='__main__':
    unittest.main()
