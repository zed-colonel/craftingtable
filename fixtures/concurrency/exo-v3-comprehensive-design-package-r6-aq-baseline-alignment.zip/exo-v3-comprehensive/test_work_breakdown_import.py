"""Local import-regression tests; not execution of the application importer."""
from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import unittest

import yaml
from validate_work_breakdown import DEFAULT_DOCUMENT, UniqueKeyLoader, load_work_breakdown, validate_work_breakdown

ROOT = Path(__file__).resolve().parent
ORIGINAL_CANONICAL_SHA256 = 'e2abeaa103d403e3502176527e3d69e7fa45b34a8cbd9ac3fbbda8a8724107c0'
ADDED_ITEM_FIELDS = ('primary_areas', 'risk', 'exit_gate')


def original_form(data):
    restored = copy.deepcopy(data)
    restored.pop('document')
    restored['work_items'] = restored.pop('pull_requests')
    for item in restored['work_items']:
        for key in ADDED_ITEM_FIELDS:
            item.pop(key)
    return restored


class ImportRegressionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.current = load_work_breakdown(DEFAULT_DOCUMENT)

    def setUp(self):
        self.data = copy.deepcopy(self.current)

    def assert_error(self, data, path):
        result = validate_work_breakdown(data)
        self.assertGreater(result['error_count'], 0)
        self.assertIn(path, [error['path'] for error in result['errors']])

    def test_corrected_document(self):
        result = validate_work_breakdown(self.data)
        self.assertEqual(result['error_count'], 0)
        self.assertEqual(result['work_item_count'], 19)
        self.assertEqual(result['known_field_check_count'], 40)
        self.assertEqual(result['known_field_passed_count'], 40)
        self.assertFalse(result['application_importer_executed'])

    def test_original_two_error_shape(self):
        result = validate_work_breakdown(original_form(self.data))
        self.assertEqual(result['error_count'], 2)
        self.assertEqual([error['path'] for error in result['errors']], ['document', 'pull_requests'])
        for error in result['errors']:
            self.assertEqual(error['code'], 'invalid-work-breakdown')
            self.assertEqual(error['message'], f'Required top-level field "{error["path"]}" is missing')

    def test_top_level_only_fix_exposes_per_item_omissions(self):
        for item in self.data['pull_requests']:
            for key in ADDED_ITEM_FIELDS:
                item.pop(key)
        result = validate_work_breakdown(self.data)
        self.assertEqual(sum(not check['passed'] for check in result['known_field_checks']), 38)
        self.assertEqual(sum(not check['passed'] for check in result['structural_checks']), 19)

    def test_each_required_top_level_field(self):
        for key in ('document', 'pull_requests'):
            with self.subTest(key=key):
                data = copy.deepcopy(self.current)
                data.pop(key)
                self.assert_error(data, key)

    def test_each_required_item_field(self):
        for index in range(19):
            for key in ('primary_areas', 'risk'):
                with self.subTest(index=index, key=key):
                    data = copy.deepcopy(self.current)
                    data['pull_requests'][index].pop(key)
                    self.assert_error(data, f'pull_requests[{index}].{key}')

    def test_invalid_document_values(self):
        for value in (None, '', '  ', 1, True, [], {}):
            with self.subTest(value=value):
                self.data['document'] = value
                self.assert_error(self.data, 'document')

    def test_invalid_pull_requests_values(self):
        for value in (None, '', '  ', 1, True, [], {}):
            with self.subTest(value=value):
                self.data['pull_requests'] = value
                self.assert_error(self.data, 'pull_requests')

    def test_invalid_root_and_items(self):
        for value in (None, 'text', 3, [], True):
            with self.subTest(root=value):
                self.assert_error(value, '$')
            with self.subTest(item=value):
                self.data['pull_requests'][0] = value
                self.assert_error(self.data, 'pull_requests[0]')

    def test_invalid_primary_areas_values(self):
        for index in range(19):
            for value in (None, '', 'core', [], [''], [' '], [None], [1], [True], [{}], {}):
                with self.subTest(index=index, value=value):
                    data = copy.deepcopy(self.current)
                    data['pull_requests'][index]['primary_areas'] = value
                    self.assert_error(data, f'pull_requests[{index}].primary_areas')

    def test_invalid_risk_values(self):
        for index in range(19):
            for value in (None, '', '  ', 1, True, [], {}):
                with self.subTest(index=index, value=value):
                    data = copy.deepcopy(self.current)
                    data['pull_requests'][index]['risk'] = value
                    self.assert_error(data, f'pull_requests[{index}].risk')

    def test_risk_is_not_an_undocumented_enum(self):
        self.data['pull_requests'][0]['risk'] = 'Reviewed narrative assessment'
        self.assertEqual(validate_work_breakdown(self.data)['error_count'], 0)

    def test_missing_identity_title_or_gate(self):
        for key in ('id', 'title', 'exit_gate'):
            data = copy.deepcopy(self.current)
            data['pull_requests'][0].pop(key)
            self.assert_error(data, f'pull_requests[0].{key}')

    def test_invalid_identity_title_or_gate(self):
        for key in ('id', 'title', 'exit_gate'):
            for value in (None, '', ' ', [], {}, 1, True):
                with self.subTest(key=key, value=value):
                    data = copy.deepcopy(self.current)
                    data['pull_requests'][0][key] = value
                    self.assert_error(data, f'pull_requests[0].{key}')

    def test_invalid_dependencies(self):
        for value in (None, 'EXO-01', 1, {}, [''], [None], [[]]):
            with self.subTest(value=value):
                self.data['pull_requests'][1]['depends_on'] = value
                self.assert_error(self.data, 'pull_requests[1].depends_on')

    def test_duplicate_ids(self):
        self.data['pull_requests'][1]['id'] = self.data['pull_requests'][0]['id']
        self.assert_error(self.data, 'pull_requests[*].id')

    def test_duplicate_dependencies(self):
        self.data['pull_requests'][1]['depends_on'] = ['EXO-01', 'EXO-01']
        self.assert_error(self.data, 'pull_requests[1].depends_on')

    def test_unknown_dependency(self):
        self.data['pull_requests'][1]['depends_on'] = ['EXO-99']
        self.assert_error(self.data, 'pull_requests[1].depends_on')

    def test_self_forward_and_cyclic_dependencies(self):
        for dependency in ('EXO-01', 'EXO-02', 'EXO-19'):
            with self.subTest(dependency=dependency):
                self.data['pull_requests'][0]['depends_on'] = [dependency]
                self.assert_error(self.data, 'pull_requests[0].depends_on')

    def test_optional_sequence_values(self):
        for value in (0, 2, '1', None, True):
            self.data['pull_requests'][0]['sequence'] = value
            self.assert_error(self.data, 'pull_requests[0].sequence')

    def test_no_duplicate_work_item_alias(self):
        self.data['work_items'] = copy.deepcopy(self.data['pull_requests'])
        self.assert_error(self.data, 'work_items')

    def test_areas_alias_does_not_satisfy_primary_areas(self):
        item = self.data['pull_requests'][0]
        item['areas'] = item.pop('primary_areas')
        self.assert_error(self.data, 'pull_requests[0].primary_areas')

    def test_duplicate_yaml_keys_rejected(self):
        for source in ('document: one\ndocument: two\n',
                       'pull_requests:\n- id: EXO-01\n  risk: high\n  risk: low\n'):
            with self.subTest(source=source), self.assertRaises(yaml.YAMLError):
                yaml.load(source, Loader=UniqueKeyLoader)

    def test_malformed_and_unsafe_yaml_rejected(self):
        for source in ('pull_requests: [\n', '!!python/object/apply:os.system ["echo bad"]', '? [x, y]\n: z\n'):
            with self.subTest(source=source), self.assertRaises(yaml.YAMLError):
                yaml.load(source, Loader=UniqueKeyLoader)

    def test_plan_profile_order_and_exact_exit_gates(self):
        plan = (ROOT / 'exo-v3-comprehensive-implementation-plan.md').read_text(encoding='utf-8')
        self.assertEqual(self.data['document'], plan.splitlines()[0][2:])
        self.assertEqual(self.data['profile'], 'EXO-V3-COMPREHENSIVE-3')
        self.assertEqual(self.data['cross_stack_profile'], 'STACK-DEVELOPMENTAL-DIAGNOSTICS-1')
        self.assertEqual([item['id'] for item in self.data['pull_requests']], [f'EXO-{i:02d}' for i in range(1,20)])
        self.assertEqual([item['sequence'] for item in self.data['pull_requests']], list(range(1,20)))
        sections = re.findall(r'^### (EXO-\d{2}) — [^\n]+\n(.*?)(?=^### EXO-|^## 8\.|\Z)', plan, re.M | re.S)
        gates = {key: re.search(r'^\*\*Exit gate:\*\* (.+)$', body, re.M)[1] for key, body in sections}
        self.assertEqual(len(gates), 19)
        for item in self.data['pull_requests']:
            self.assertEqual(item['exit_gate'], gates[item['id']])

    def test_original_parsed_planning_data_preserved(self):
        from validate_package import expected_work_breakdown
        baseline = json.loads((ROOT / 'provenance/r3-work-breakdown.json').read_text())
        rules = json.loads((ROOT / 'provenance/revision-rules.json').read_text())
        # The historical import correction still reconstructs the exact r2 source.
        canonical = json.dumps(original_form(baseline), sort_keys=True, ensure_ascii=False, separators=(',', ':')).encode()
        self.assertEqual(hashlib.sha256(canonical).hexdigest(), ORIGINAL_CANONICAL_SHA256)
        # The new profile is allowed only its documented additive scope/gate and metadata changes.
        self.assertEqual(self.data, expected_work_breakdown(baseline, rules))

    def test_cli_exit_codes_and_nonmutation(self):
        before = DEFAULT_DOCUMENT.read_bytes()
        command = [sys.executable, str(ROOT / 'validate_work_breakdown.py')]
        result = subprocess.run(command, capture_output=True, text=True, check=False)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout)['error_count'], 0)
        self.assertEqual(DEFAULT_DOCUMENT.read_bytes(), before)
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / 'fixture.yaml'
            for text, expected in [('schema_version: 2\n', 1), ('pull_requests: [\n', 2)]:
                path.write_text(text, encoding='utf-8')
                result = subprocess.run(command + [str(path)], capture_output=True, text=True, check=False)
                self.assertEqual(result.returncode, expected, result.stderr)
                self.assertGreater(json.loads(result.stdout)['error_count'], 0)
                self.assertEqual(path.read_text(), text)
            result = subprocess.run(command + [str(Path(temp) / 'missing.yaml')], capture_output=True, text=True, check=False)
            self.assertEqual(result.returncode, 2)
            self.assertGreater(json.loads(result.stdout)['error_count'], 0)


if __name__ == '__main__':
    unittest.main(verbosity=2)
