#!/usr/bin/env python3
"""Static baseline alignment checks. This does not build AQ or execute a consumer."""
from pathlib import Path
import argparse,hashlib,json,yaml
from validate_work_breakdown import UniqueKeyLoader
ROOT=Path(__file__).resolve().parent
EXPECTED_ARCHIVE='f91f496f22772e8dda044b0cf2cf05cf2eafa9f86d6f0c7e0061b46e3926ffb1'
EXPECTED_TREE='a6a8f87272d76e94e69e10d8bcf0992296d1bf8e28ff3d9222374c3b8cdcc34e'
EXPECTED_FACTS={'ensure_task_request': 'AdmissionKey + stable TaskSpec (including persisted TaskId) + dependencies + causal_context + control_context; high-level digest is computed', 'canonical_admission_format': 'CanonicalAdmissionV2', 'ensure_task_outcome_fields': ['sequence', 'task_id', 'admission_key', 'digest'], 'ensure_task_returns_run_ids': False, 'active_waits_per_run': 1, 'wait_target_alternatives': ['one exact SignalFilter with FirstMatch', 'bounded direct Children target'], 'any_retained_requires_correlation': True, 'signal_identity': ['host tenant', 'SignalId'], 'signal_principal_filter': False, 'deadline_resolution': 'first committed eligible resolution wins; retained signals reconciled before remaining deadlines', 'wake_delivery_exactly_once': False, 'signal_sequence_is_wal_sequence': False, 'limits': {'inline_bytes': 65536, 'dependencies_per_task': 64, 'children_per_disposition': 64, 'emitted_signals_per_disposition': 32, 'runs_per_admission': 64, 'child_wait_targets': 64, 'consumption_entries': 64, 'hierarchy_depth': 8}, 'http_api_version': 2, 'remote_actor_protocol_version': 1, 'storage_versions': {'manifest': 1, 'wal_frame': 1, 'snapshot': 9, 'projection': 9}, 'snapshot_only_restore_supported': False, 'wal_compaction_supported': False, 'base_supports_continuations_dag_hierarchy_children': True, 'workflow_required_for_cron': True, 'daemon_automatically_dispatches_application_handlers': False, 'opaque_refs_confer_authority': False, 'new_actionqueue_primitives': []}
def load(p):return yaml.load(p.read_text(),Loader=UniqueKeyLoader)
def validate(root=ROOT,aq_root=None):
 root=Path(root);errors=[]
 def check(ok,msg):
  if not ok:errors.append(msg)
 try:
  lock=json.loads((root/'aq-baseline.lock.json').read_text());manifest=(root/'aq-source-tree.sha256').read_bytes()
  check(lock['archive_sha256']==EXPECTED_ARCHIVE,'AQ archive identity changed')
  check(lock['source_tree_sha256']==EXPECTED_TREE==hashlib.sha256(manifest).hexdigest(),'AQ complete tree identity changed')
  check(lock['implementation_commit'] is None and not lock['historical_commit_is_current_implementation_pin'],'Historical commit was promoted to implementation pin')
  check(lock['conformance_package_revision']==16 and lock['contract']=='AQ-CONT-1' and lock['crate_version']=='0.2.0','AQ contract pin changed')
  check(lock['contract_facts']==EXPECTED_FACTS,'Source-backed contract facts changed')
  check(lock['consumer_conformance_status']=='not-run' and lock['publication_status']=='not-verified' and lock['aq_rust_tests_executed_in_review'] is False,'Planning data asserts runtime/publication evidence')
  entries={line[66:]:line[:64] for line in manifest.decode().splitlines()}
  check(len(entries)==lock['source_tree_file_count'],'Incomplete source manifest')
  check(all(entries.get(p)==h for p,h in lock['source_files'].items()),'Curated sources not in exact tree')
  if aq_root:
   aq_root=Path(aq_root).resolve()
   for p,h in entries.items():
    target=(aq_root/p).resolve()
    check(target.is_relative_to(aq_root) and target.is_file() and hashlib.sha256(target.read_bytes()).hexdigest()==h,'AQ source mismatch: '+p)
  matrix=load(root/'aq-baseline-integration-acceptance-matrix.yaml');w=load(next(root.glob('*work-breakdown.yaml')))
  cases=matrix['cases'];prefix=matrix['owner'];ids=[c['id'] for c in cases]
  check(ids==[f'AB-{prefix}-{i:03d}' for i in range(1,25)],'All 24 baseline cases required')
  owners={i['id']:i for i in w['pull_requests']};assigned=[]
  for i in owners.values():
   want=[c['id'] for c in cases if c['owner_pr']==i['id']]
   check(i.get('aq_baseline_acceptance_cases',[])==want,'Incorrect baseline case assignment: '+i['id']);assigned+=i.get('aq_baseline_acceptance_cases',[])
  check(sorted(assigned)==sorted(ids),'Baseline case missing/duplicated/unknown owner')
  for c in cases:
   check(c['status']=='planned-not-run' and c['runtime_evidence_required'] is True and c['owner_pr'] in owners,'Invalid baseline case evidence/owner: '+c['id'])
   check(bool(c['pass_criterion'].strip()) and c['capability_gate'] in [f'{prefix}-AQ-G{i}' for i in range(1,6)],'Invalid baseline case criterion/gate')
   check(all(p in lock['source_files'] for p in c['source_paths']),'Unbound source in '+c['id'])
  binding=w['aq_baseline_alignment']
  check(binding['importer_policy']=='reject-activation-if-unrecognized' and binding['scheduling_role']=='completed-upstream-not-runnable','Importer or completed-upstream obligations dropped')
  check(binding['consumer_evidence_status']=='not-run','Consumer conformance falsely asserted')
 except (OSError,KeyError,ValueError,TypeError,yaml.YAMLError) as exc:errors.append(str(exc))
 return {'valid':not errors,'scope':'static-source-binding-and-planned-obligations-only','runtime_tests_executed':False,'errors':errors}
if __name__=='__main__':
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--root',type=Path,default=ROOT);ap.add_argument('--aq-root',type=Path);args=ap.parse_args();r=validate(args.root,args.aq_root);print(json.dumps(r,indent=2));raise SystemExit(0 if r['valid'] else 1)
