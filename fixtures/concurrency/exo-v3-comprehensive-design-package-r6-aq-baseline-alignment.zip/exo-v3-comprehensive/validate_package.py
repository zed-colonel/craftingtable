#!/usr/bin/env python3
"""Static validation of EXO-V3 r4 planning artifacts. No runtime tests are executed.

Requires Python 3.10+ and PyYAML. Run from any directory. This is not the user's
application importer, a sandbox security test, or an Exoskeleton implementation.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
from pathlib import Path
import re
from typing import Any

import yaml
from validate_work_breakdown import UniqueKeyLoader, validate_work_breakdown

ROOT = Path(__file__).resolve().parent
PROFILE = 'EXO-V3-COMPREHENSIVE-3'
EXECUTION = 'EXO-V3-EXECUTION-1'
PLAN = 'EXO-PLAN-6'


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def text(value: Any) -> bool:
    return isinstance(value, str) and bool(value.strip())


def yaml_load(path: Path) -> Any:
    return yaml.load(path.read_text(encoding='utf-8'), Loader=UniqueKeyLoader)


def extract_semantics(design: str, plan: str) -> dict[str, Any]:
    def sections(pattern: str) -> dict[str, str]:
        return {m.group(1): hashlib.sha256(m.group(0).strip().encode()).hexdigest()
                for m in re.finditer(pattern, design, re.M | re.S)}
    return {
        'invariants': sections(r'^### (C\d+)\. [^\n]+\n.*?(?=^### C\d+\.|^## |\Z)'),
        'vocabulary': sections(r'^### (7\.\d+) [^\n]+\n.*?(?=^### |^## |\Z)'),
        'adr_rows': re.findall(r'^\| `EXO-ADR-\d{3}`[^\n]*$', plan, re.M),
        'upstream_gate_rows': re.findall(r'^\| `EXO-(?:AQ|WI)-G\d`[^\n]*$', plan, re.M),
    }


def profile_errors(profile: Any, matrix: Any, item_ids: set[str]) -> list[str]:
    """Check the declared planning profile, not any actual runtime configuration."""
    errors: list[str] = []
    if not isinstance(profile, dict) or not isinstance(matrix, dict):
        return ['profile and matrix must be mappings']

    def get(path: str) -> Any:
        node: Any = profile
        for part in path.split('.'):
            if not isinstance(node, dict) or part not in node:
                return None
            node = node[part]
        return node

    expected = {
        'schema_version': 1,
        'kind': 'execution_environment_planning_profile',
        'profile_id': EXECUTION, 'base_profile': PROFILE,
        'status': 'planning-not-runtime-evidence',
        'instance.container_manager': 'containerd',
        'instance.runtime': 'Kata Containers',
        'instance.runtime_type': 'io.containerd.kata.v2',
        'instance.isolation_unit': 'dedicated-kata-vm-per-vessel-instance',
        'instance.operator_trust': 'approved-host-operator',
        'instance.hardware_virtualization_required': True,
        'instance.silent_runtime_fallback': False,
        'instance.host_management_access_from_guest': False,
        'instance.host_management_access_from_worker': False,
        'instance.host_supervisor_required': True,
        'instance.digicorp_required': False,
        'instance.kubernetes_required': False,
        'instance.versions_selected': False,
        'instance.qualification_status': 'not-run',
        'embedded_composition.vessel_actionqueue': True,
        'embedded_composition.worldinterface': 'embedded-WI-FABRIC-2',
        'embedded_composition.worldinterface_actionqueue': True,
        'embedded_composition.queue_semantic_domains': 2,
        'embedded_composition.platform_actionqueue_required_for_initial_proof': False,
        'embedded_composition.platform_worldinterface_required_for_initial_proof': False,
        'embedded_composition.new_actionqueue_primitives': [],
        'embedded_composition.new_worldinterface_wire_types': [],
        'workers.profile_id': 'process-managed-proof-1',
        'workers.same_outer_vm_as_vessel': True,
        'workers.independent_worker_vm': False,
        'workers.arbitrary_hostile_code_allowed': False,
        'workers.sensitive_production_data_allowed': False,
        'workers.unreviewed_executable_candidates_allowed': False,
        'workers.managed_via_worldinterface': True,
        'workers.direct_exoskeleton_spawn_authority': False,
        'workers.domain_records_may_require_local_pid_or_host_path': False,
        'workers.future_external_provider.preserve_seam': True,
        'workers.future_external_provider.required_for_initial_proof': False,
        'workers.future_external_provider.implementation_status': 'deferred',
        'workers.future_external_provider.logical_parent_does_not_require_physical_nesting': True,
        'workers.future_external_provider.stronger_assurance_may_not_fall_back_to_process': True,
        'milestones.initial_embedded_viability.id': 'EXO-EMBEDDED-VIABILITY-1',
        'milestones.initial_embedded_viability.requires_real_embedded_aq_wi_evidence': True,
        'milestones.initial_embedded_viability.requires_platform_service_implementation': False,
        'milestones.initial_embedded_viability.requires_digicorp': False,
        'milestones.initial_embedded_viability.marks_all_parent_prs_accepted': False,
        'milestones.initial_embedded_viability.satisfies_full_release_gates': False,
        'milestones.full_release.existing_gate_meaning_preserved': True,
        'milestones.full_release.narrow_proof_cannot_satisfy_unimplemented_profiles': True,
        'milestones.full_release.scope_change_requires_explicit_release_plan_amendment': True,
        'checkpoint_semantics.these_are_acceptance_barriers_not_top_level_prs': True,
        'checkpoint_semantics.evidence_in_owner_pr_may_pass_before_parent_acceptance': True,
        'checkpoint_semantics.planning_status_does_not_count_as_evidence': True,
        'checkpoint_semantics.candidate_runtime_and_worker_fingerprints_required': True,
        'checkpoint_semantics.native_only_tests_do_not_pass_vm_barriers': True,
        'checkpoint_semantics.old_concurrency_sidecar_requires_reviewed_rebinding': True,
    }
    for path, wanted in expected.items():
        actual = get(path)
        if type(actual) is not type(wanted) or actual != wanted:
            errors.append(f'{path}: expected {wanted!r}, got {actual!r}')
    for path, minimum in [('instance.qualification_manifest_required', 8),
                          ('workers.required_controls', 7), ('future_not_prerequisites', 8)]:
        actual = get(path)
        if not isinstance(actual, list) or len(actual) < minimum or not all(text(v) for v in actual):
            errors.append(f'{path}: missing substantive required entries')
    for path in ('workers.assurance', 'workers.admission', 'workers.checkpoint_semantics',
                 'instance.persistence', 'instance.recovery'):
        if not text(get(path)):
            errors.append(f'{path}: missing nonempty statement')
    gates = profile.get('checkpoints')
    if not isinstance(gates, list) or len(gates) != 5:
        errors.append('checkpoints: expected five definitions')
        gates = []
    expected_gates = [f'EXO-ENV-G{i}' for i in range(1, 6)]
    if [g.get('id') if isinstance(g, dict) else None for g in gates] != expected_gates:
        errors.append('checkpoints: identifiers/order differ')
    if get('milestones.initial_embedded_viability.requires_checkpoints') != expected_gates:
        errors.append('milestone requires all five checkpoints')
    case_list = matrix.get('cases')
    if not isinstance(case_list, list):
        return errors + ['cases: must be a list']
    if type(matrix.get('case_count')) is not int or matrix.get('case_count') != len(case_list) or len(case_list) != 36:
        errors.append('case_count: expected exactly 36 planned cases')
    if matrix.get('profile_revision') != EXECUTION or matrix.get('base_profile') != PROFILE:
        errors.append('matrix profile mismatch')
    if matrix.get('status') != 'planned-not-executed':
        errors.append('matrix must remain planned-not-executed')
    ids = [c.get('id') if isinstance(c, dict) else None for c in case_list]
    if ids != [f'EE-{i:03d}' for i in range(1,37)]:
        errors.append('case identifiers: missing, duplicate or reordered')
    gate_by_id = {g['id']: g for g in gates if isinstance(g, dict) and text(g.get('id'))}
    for c in case_list:
        if not isinstance(c, dict):
            errors.append('case must be a mapping'); continue
        for key in ('id','group','checkpoint','owner_pr','title','setup','expected'):
            if not text(c.get(key)):
                errors.append(f'case {c.get("id")}: {key} must be nonempty')
        if c.get('status') != 'planned':
            errors.append(f'{c.get("id")}: no runtime pass may be claimed in the planning matrix')
        if type(c.get('requires_kata_host')) is not bool:
            errors.append(f'{c.get("id")}: requires_kata_host must be boolean')
        if c.get('owner_pr') not in item_ids:
            errors.append(f'{c.get("id")}: unknown owner')
        gate = gate_by_id.get(c.get('checkpoint'))
        if gate is None or c.get('owner_pr') not in gate.get('evidence_owners', []):
            errors.append(f'{c.get("id")}: checkpoint or owner mismatch')
    for gate in gates:
        if not isinstance(gate, dict):
            errors.append('checkpoint must be mapping'); continue
        for key in ('id','title','applies','criterion'):
            if not text(gate.get(key)):
                errors.append(f'checkpoint {gate.get("id")}: missing {key}')
        owners = gate.get('evidence_owners')
        if not isinstance(owners, list) or not owners or not all(o in item_ids for o in owners):
            errors.append(f'{gate.get("id")}: invalid owners')
        if gate.get('status') != 'planned':
            errors.append(f'{gate.get("id")}: checkpoint pass cannot be inferred from planning')
        expected_cases = [c['id'] for c in case_list if isinstance(c, dict) and c.get('checkpoint') == gate.get('id')]
        if gate.get('acceptance_cases') != expected_cases or not expected_cases:
            errors.append(f'{gate.get("id")}: case mapping mismatch')
    groups = sorted({c['group'] for c in case_list if isinstance(c, dict) and text(c.get('group'))})
    if matrix.get('groups') != groups:
        errors.append('groups: do not match case inventory')
    return errors


def expected_work_breakdown(baseline: dict, rules: dict) -> dict:
    expected = copy.deepcopy(baseline)
    expected.update(rules['allowed_top_level_changes'])
    for item in expected['pull_requests']:
        key = item['id']
        if key in rules['scope_additions']:
            item['execution_environment_scope'] = rules['scope_additions'][key]
        if key in rules['aq_baseline_cases_by_id']:
            item['aq_baseline_acceptance_cases'] = rules['aq_baseline_cases_by_id'][key]
        if key in rules['exit_gate_suffixes']:
            item['exit_gate'] += rules['exit_gate_suffixes'][key]
    return expected


def validate_package(root: Path = ROOT) -> dict[str, Any]:
    checks: list[dict[str, Any]] = []
    def check(name: str, passed: bool, detail: Any = '') -> None:
        checks.append({'name': name, 'passed': bool(passed), 'detail': detail})
    # Required inputs exclude reports produced by this validation, avoiding self-hash cycles.
    required = [
        'README.md','IMPORT-COMPATIBILITY-NOTES.md','EXECUTION-REVISION-NOTES.md',
        'EXECUTION-CONCURRENCY-REBINDING.md','KATA-INSTANCE-QUALIFICATION-RUNBOOK.md',
        'kata-containerd-initial-target-and-digicorp.md','exo-v3-execution-environment.md',
        'exo-v3-execution-profile.yaml','exo-v3-execution-environment-acceptance-matrix.yaml',
        'exo-v3-comprehensive-work-breakdown.yaml','exo-v3-comprehensive-contract.yaml',
        'exo-v3-comprehensive-implementation-plan.md','exoskeleton-v3-comprehensive-design.md',
        'exo-v3-instruction-integrity-threat-model.md','ohio-loop-developmental-diagnostics.md',
        'developmental-diagnostics-cross-stack-profile.yaml',
        'exo-v3-instruction-integrity-acceptance-matrix.yaml',
        'exo-v3-developmental-diagnostics-acceptance-matrix.yaml',
        'provenance/source-manifest.json','provenance/revision-rules.json',
        'provenance/r3-work-breakdown.json','provenance/r3-core-semantics.json',
        'validate_package.py','validate_work_breakdown.py','test_work_breakdown_import.py','test_execution_profile.py',
    ]
    for name in required:
        path=root/name
        check(f'{name}: exists and nonempty', path.is_file() and path.stat().st_size > 0)
    if any(not c['passed'] for c in checks):
        return make_report(checks)
    for path in sorted(root.rglob('*.md')):
        content=path.read_text(encoding='utf-8')
        check(f'{path.relative_to(root)}: no NUL', '\0' not in content)
        check(f'{path.relative_to(root)}: fenced blocks balanced',
              len(re.findall(r'^```', content, re.M)) % 2 == 0)
    loaded={}
    for path in sorted(root.glob('*.yaml')):
        try:
            loaded[path.name]=yaml_load(path)
            check(f'{path.name}: unique-key safe YAML', True)
        except (OSError, yaml.YAMLError, UnicodeError) as exc:
            check(f'{path.name}: unique-key safe YAML', False, str(exc))
    if any(not c['passed'] for c in checks):
        return make_report(checks)
    for path in sorted(root.rglob('*.json')):
        # Current generated reports are ignored as inputs; archived reports are syntax checked.
        if path.parent == root and path.name.endswith('validation.json'):
            continue
        try: json.loads(path.read_text(encoding='utf-8')); check(f'{path.relative_to(root)}: JSON',True)
        except (OSError,ValueError) as exc:check(f'{path.relative_to(root)}: JSON',False,str(exc))
    wbd=loaded['exo-v3-comprehensive-work-breakdown.yaml']
    imp=validate_work_breakdown(wbd)
    check('known importer fields',imp['known_field_check_count']==40 and imp['known_field_passed_count']==40,
          {'checks':imp['known_field_check_count'],'passed':imp['known_field_passed_count']})
    check('work-breakdown structural safeguards',imp['error_count']==0,imp['errors'])
    check('one canonical importable work breakdown',
          len(list(root.rglob('*work-breakdown.yaml')))==1 and 'work_items' not in wbd)
    baseline=json.loads((root/'provenance/r3-work-breakdown.json').read_text())
    rules=json.loads((root/'provenance/revision-rules.json').read_text())
    source=json.loads((root/'provenance/source-manifest.json').read_text())
    check('only declared work-breakdown changes', wbd==expected_work_breakdown(baseline,rules))
    check('all nineteen IDs/order preserved',
          [i['id'] for i in wbd['pull_requests']]==[f'EXO-{n:02d}' for n in range(1,20)])
    for old,new in zip(baseline['pull_requests'],wbd['pull_requests']):
        for key in rules['retained_item_fields']:
            check(f'{old["id"]}: {key} preserved', old.get(key)==new.get(key))
        check(f'{old["id"]}: original exit gate retained',new['exit_gate'].startswith(old['exit_gate']))
    for name in rules['unchanged_files']:
        check(f'{name}: byte-identical to r3',sha(root/name)==source['source_files'][name])
    plan=(root/'exo-v3-comprehensive-implementation-plan.md').read_text()
    design=(root/'exoskeleton-v3-comprehensive-design.md').read_text()
    check('plan/profile metadata',f'`{PLAN}`' in plan and f'`{PROFILE}`' in plan and f'`{PROFILE}`' in design)
    check('document equals plan title',wbd['document']==plan.splitlines()[0][2:])
    sections=re.findall(r'^### (EXO-\d{2}) — [^\n]+\n(.*?)(?=^### EXO-|^## 8\.|\Z)',plan,re.M|re.S)
    gates={}
    for key,body in sections:
        m=re.search(r'^\*\*Exit gate:\*\* (.+)$',body,re.M)
        if m:gates[key]=m[1]
    check('nineteen implementation sections with gates',len(gates)==19)
    for item in wbd['pull_requests']:
        check(f'{item["id"]}: YAML gate equals plan',gates.get(item['id'])==item['exit_gate'])
        for scope in item.get('execution_environment_scope',[]):
            check(f'{item["id"]}: scope appears in plan',scope in plan)
    semantics=extract_semantics(design,plan)
    original=json.loads((root/'provenance/r3-core-semantics.json').read_text())
    check('104 invariant bodies preserved',len(semantics['invariants'])==104 and semantics['invariants']==original['invariants'])
    check('73 vocabulary entries preserved',len(semantics['vocabulary'])==73 and semantics['vocabulary']==original['vocabulary'])
    check('36 existing ADR definitions preserved',semantics['adr_rows'][:36]==original['adr_rows'])
    check('two deployment ADRs added',len(semantics['adr_rows'])==38 and 'EXO-ADR-037' in semantics['adr_rows'][36] and 'EXO-ADR-038' in semantics['adr_rows'][37])
    check('ten original full upstream gate definitions preserved',len(semantics['upstream_gate_rows'])==10 and semantics['upstream_gate_rows']==original['upstream_gate_rows'])
    contract=loaded['exo-v3-comprehensive-contract.yaml']
    check('contract profile metadata',contract['profile_revision']==PROFILE and contract['execution_environment_profile']==EXECUTION)
    check('no new AQ/WI primitives',contract['new_actionqueue_requirements']==[] and contract['new_worldinterface_protocol_requirements']==[])
    check('no initial platform or DigiCorp dependency',contract['initial_proof_requires_platform_services'] is False and contract['initial_proof_requires_digicorp'] is False)
    counts={}
    for field,name,expected in [
        ('instruction_integrity','exo-v3-instruction-integrity-acceptance-matrix.yaml',103),
        ('developmental_diagnostics','exo-v3-developmental-diagnostics-acceptance-matrix.yaml',39),
        ('execution_environment','exo-v3-execution-environment-acceptance-matrix.yaml',36)]:
        matrix=loaded[name]; entries=matrix['cases'];ids=[x['id'] for x in entries]
        counts[field]=len(entries)
        check(f'{name}: case count and uniqueness',len(entries)==expected and len(ids)==len(set(ids)))
        check(f'{name}: contract includes matrix',name in contract['conformance_seeds'])
    check('acceptance totals',contract['acceptance_case_counts']=={**counts,'total':sum(counts.values())})
    execution_errors=profile_errors(loaded['exo-v3-execution-profile.yaml'],loaded['exo-v3-execution-environment-acceptance-matrix.yaml'],{i['id'] for i in wbd['pull_requests']})
    check('execution-profile planning safeguards',not execution_errors,execution_errors)
    rebind=(root/'EXECUTION-CONCURRENCY-REBINDING.md').read_text()
    for name in ('exo-v3-comprehensive-work-breakdown.yaml','exo-v3-comprehensive-implementation-plan.md'):
        check(f'{name}: concurrency old/new hashes',sha(root/name) in rebind and source['source_files'][name] in rebind)
    # Validate newly introduced local documentation links; inherited external companion references are not bundled files.
    new_docs=['README.md','IMPORT-COMPATIBILITY-NOTES.md','EXECUTION-REVISION-NOTES.md',
              'EXECUTION-CONCURRENCY-REBINDING.md','KATA-INSTANCE-QUALIFICATION-RUNBOOK.md',
              'kata-containerd-initial-target-and-digicorp.md','exo-v3-execution-environment.md']
    for name in new_docs:
        for target in re.findall(r'\]\(([^)]+)\)',(root/name).read_text()):
            if '://' in target or target.startswith('#'):continue
            local=target.split('#',1)[0]
            check(f'{name}: local link {local}',(root/local).is_file())
    from validate_aq_alignment import validate as validate_aq
    from validate_provider_alignment import validate as validate_provider
    aq_result=validate_aq(root)
    provider_result=validate_provider(root)
    check('AQ baseline alignment obligations',aq_result['valid'],aq_result['errors'])
    check('WI producer reference integrity',provider_result['valid'],provider_result['errors'])
    result=make_report(checks)
    result.update({
        'implementation_pr_count':19,'constitutional_invariant_count':len(semantics['invariants']),
        'vocabulary_count':len(semantics['vocabulary']),'required_adr_count':len(semantics['adr_rows']),
        'acceptance_case_counts':{**counts,'total':sum(counts.values())},
        'execution_checkpoint_count':5,'known_import_field_check_count':imp['known_field_check_count'],
        'import_structural_check_count':imp['structural_check_count'],
        'source_archive_sha256':source['source_archive_sha256'],
        'work_breakdown_sha256':sha(root/'exo-v3-comprehensive-work-breakdown.yaml'),
        'implementation_plan_sha256':sha(root/'exo-v3-comprehensive-implementation-plan.md'),
    })
    return result


def make_report(checks: list[dict[str,Any]]) -> dict[str,Any]:
    passed=sum(c['passed'] for c in checks)
    return {
        'package':'exo-v3-comprehensive','artifact_revision':'r6-aq-baseline-alignment',
        'profile':PROFILE,'plan_revision':PLAN,'execution_profile':EXECUTION,
        'validation_scope':'Static planning/import/source-preservation checks only; no runtime conformance.',
        'application_importer_executed':False,'runtime_tests_executed':False,
        'kata_host_qualified':False,'check_count':len(checks),'passed_count':passed,
        'failed_count':len(checks)-passed,'checks':checks,
    }


def main() -> int:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,default=ROOT)
    parser.add_argument('--report',type=Path)
    args=parser.parse_args()
    try: report=validate_package(args.root)
    except (OSError,ValueError,KeyError,TypeError,yaml.YAMLError) as exc:
        print(json.dumps({'validation_error':str(exc),'runtime_tests_executed':False},indent=2));return 2
    output=json.dumps(report,indent=2,ensure_ascii=False)+'\n'
    if args.report:args.report.write_text(output,encoding='utf-8')
    print(output,end='')
    return 1 if report['failed_count'] else 0


if __name__=='__main__':
    raise SystemExit(main())
