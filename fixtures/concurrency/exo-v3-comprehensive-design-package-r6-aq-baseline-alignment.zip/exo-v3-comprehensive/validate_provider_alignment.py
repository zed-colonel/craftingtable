#!/usr/bin/env python3
"""Validate the immutable WI-owned definition reference, not provider qualification."""
from pathlib import Path
import argparse,hashlib,json,yaml
ROOT=Path(__file__).resolve().parent
REFERENCE='wi-worker-provider-reference.json'
def validate(root=ROOT,wi_root=None):
 root=Path(root);errors=[]
 try:
  r=json.loads((root/REFERENCE).read_text());profile=yaml.safe_load((root/'exo-v3-execution-profile.yaml').read_text())
  if r['owner_plan_revision']!='WI-PLAN-5' or r['owner_package_artifact']!='r5-aq-baseline-alignment' or r['provider_contract_id']!='WI-WORKER-EXECUTION-1':errors.append('Wrong WI producer binding')
  if r['runtime_qualification_status']!='not-run' or r['authoritative_definition_copied'] is not False or r['consumer_role']!='reference-and-tighten-only':errors.append('Ownership/qualification misrepresented')
  if set(r['files'])!={'wi-fabric-2-worker-execution-profile.md','wi-fabric-2-worker-execution-profile.yaml','wi-fabric-2-worker-execution-acceptance-matrix.yaml'}:errors.append('Incomplete provider definition binding')
  for n,h in r['files'].items():
   p=Path(wi_root)/n if wi_root else root/'provenance/wi-provider-definition'/(n+'.source.txt')
   if hashlib.sha256(p.read_bytes()).hexdigest()!=h:errors.append('Provider byte mismatch: '+n)
  ref=profile['workers']['provider_contract_reference']
  if ref['file']!=REFERENCE:errors.append('Execution profile points to another reference')
 except (OSError,KeyError,ValueError,TypeError,yaml.YAMLError) as exc:errors.append(str(exc))
 return {'valid':not errors,'cross_package_bytes_checked':bool(wi_root),'runtime_qualification_performed':False,'errors':errors}
if __name__=='__main__':
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--root',type=Path,default=ROOT);ap.add_argument('--wi-root',type=Path);a=ap.parse_args();r=validate(a.root,a.wi_root);print(json.dumps(r,indent=2));raise SystemExit(0 if r['valid'] else 1)
