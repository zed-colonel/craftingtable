# Import compatibility — WI r4 worker-provider amendment

This revision retains the corrected `document`, `pull_requests`, `primary_areas`, `risk` and `exit_gate` fields. Every original work-item field/value and ordered list entry is unchanged. The plan metadata advances to WI-PLAN-5; selected items add `worker_execution_scope`. The work breakdown points to WI-WORKER-EXECUTION-1 and the partial proof milestone.

There is one canonical work-breakdown YAML and no legacy alias/duplicate list. New profile, acceptance and assumption YAMLs are typed supplemental documents; do not route them to a `pull_requests` importer. Support-document dispatch must distinguish file role or `kind`. No claim is made that the unavailable full application schema accepts every supplement automatically.

The original WI-PLAN-3 import correction history is retained as `provenance/r3-IMPORT-COMPATIBILITY-NOTES.md`. Current validators and reports supersede the r3 reports at the package root. Runtime statuses remain planned/unqualified; no previous validator result is completion evidence.

## AQ baseline alignment import contract
The canonical work breakdown now includes `aq_baseline_alignment` and per-owner `aq_baseline_acceptance_cases`. These fields impose additional integration evidence. An importer may parse them additively but MUST reject scheduling activation when it cannot enforce them. The v0.3.0 concurrency schema removes completed AQ implementation nodes; do not fall back to v0.2.0 or reuse approvals. This local validator is not the actual orchestration application importer.
