# WI planning package — r5-aq-baseline-alignment

**Current plan:** WI-PLAN-5  
**Revision date:** 2026-09-15  
**Status:** planning aligned to the supplied implemented AQ-CONT-1 source; no consumer runtime or publication pass asserted.

## Start here
Read [AQ-BASELINE-ALIGNMENT.md](AQ-BASELINE-ALIGNMENT.md) before implementing AQ adapters. The [source lock](aq-baseline.lock.json) and `aq-source-tree.sha256` bind the exact supplied ActionQueue 0.2.0 tree and conformance revision 16. Its current Git implementation commit was not supplied. The historical pre-contract commit is not the completed-source pin.

Use this package with **cross-stack concurrency v0.3.0**. Do not activate the old v0.2.0 bindings. The revised sidecar schedules WI/EXO work, not completed AQ implementation work; baseline acceptance, consumer contract evidence and actual publication remain separate.

## What is preserved and added
59 constitutional invariants; 14 PRs; 40 worker and 20 developmental cases are preserved. Original application work identities, dependencies and full exit obligations remain. The [24 additional AQ adapter cases](aq-baseline-integration-acceptance-matrix.yaml) are specifications, all planned-not-run, with explicit owners in the single canonical work breakdown. They supplement rather than replace the existing cases.

No new ActionQueue primitive is required by this alignment. Domain authority remains with WI/EXO. The process worker profile does not claim hostile-code isolation, and embedded proof does not certify full daemon/platform parity or publication.

## Validation
```sh
python -B validate_work_breakdown.py
python -B validate_worker_package.py
python -B validate_aq_alignment.py --aq-root ../actionqueue-main
python -B -m unittest discover -v
```

These are static package/source-preservation and Python regression checks, not an execution of your orchestration application's importer. Importers must understand `aq_baseline_alignment` and per-owner `aq_baseline_acceptance_cases`, or reject activation. See [IMPORT-COMPATIBILITY-NOTES.md](IMPORT-COMPATIBILITY-NOTES.md).

## Provenance and revision scope
[AQ-ALIGNMENT-REVISION-NOTES.md](AQ-ALIGNMENT-REVISION-NOTES.md) records the changes. Exact supplied r4 top-level files remain under `provenance/supplied-r4-files/` as inert `.source.txt` files; the original r3 constitutional/source fingerprints are retained. Current checksum and validation reports cover this revised package, not a previously supplied revision.
