# WI → EXO worker-provider handoff

**Producer:** WI-PLAN-5 / WI-WORKER-EXECUTION-1 / process-managed-proof-1  
**Consumer:** EXO-PLAN-6 / EXO-V3-EXECUTION-1; artifact r6-aq-baseline-alignment

WI owns provider definition, operation eligibility, exact boundary authorization, lifecycle facts and artifact provenance. EXO owns work purpose, worker supervision, epistemic consequence, verification and acceptance. Both use existing AQ semantics. Actual producer runtime evidence is still pending.

## Exact planning definition

| File | SHA-256 |
|---|---|
| `wi-fabric-2-worker-execution-profile.md` | `e335632129f3a3ba4556fcfc70e0e52eaef7d7b175702aacafb882c2be483cd3` |
| `wi-fabric-2-worker-execution-profile.yaml` | `6c1f9f526ec53b0c7153083dd242fdee049593447153a4aebb20818308a5765e` |
| `wi-fabric-2-worker-execution-acceptance-matrix.yaml` | `9c11d92d056b0411ed4af00a8f076182d95c500acd6e360f42a3a0bdd8aec2eb` |

EXO pins these in `wi-worker-provider-reference.json`. The machine files are planning definitions, not claimed wire schemas or deployment manifests. WI-ADR-016 reviews faithful field mapping; an actual wire gap requires a narrow contract amendment before freeze.

## Evidence flow without a circular dependency

WI owns the test consumer. It proves G1–G4 with real embedded AQ/WI and reviewed fixtures, independent of EXO, Kata or platform services. EXO then consumes `WI-EMBEDDED-WORKER-PROOF-1` and proves its own supervision and independent acceptance. G5 separately proves the bounded supervisor boundary for EXO lifecycle work; EXO still qualifies real Kata and state recovery.

Producer tests may issue deterministic pass/fail assertions about protocol and provider controls. They do not implement task-quality scoring, commitment acceptance or improvement judgment. Full WI parent gates remain open if stronger worker security, remote/platform profiles or publication are incomplete.

## Implemented handoff must additionally carry

Exact WI/AQ binary and conformance pins; fixture/image/executable/configuration identities; qualified operations and controls; profile/adapter/environment digests; explicit unsupported features and residual risk; denial examples; real crash/cancel/output/cleanup results; scoped artifact fixtures; and independent review. A matching planning profile digest alone is insufficient.

The external-provider seam fixture reveals neither local PID nor shared filesystem. It proves replaceability only, not implemented external resources. Kata/containerd remains the EXO instance target; WI does not acquire its management socket or a mandatory runtime-engine dependency.

## Current producer binding — WI-PLAN-5 / r5-aq-baseline-alignment

- `wi-fabric-2-worker-execution-profile.md`: `9f597cffb7117dc679e9f001c25c7d54f2a6157f6ead563b0c7cbd11f45a04f9`
- `wi-fabric-2-worker-execution-profile.yaml`: `6523baf56d14dafa4b199c7493dc030461cc061754c180b4c83006308e633986`
- `wi-fabric-2-worker-execution-acceptance-matrix.yaml`: `9c11d92d056b0411ed4af00a8f076182d95c500acd6e360f42a3a0bdd8aec2eb`

Profile capabilities/limits and planned-not-qualified status are unchanged; plan metadata now reflects AQ alignment. EXO r6 references these exact bytes.
