# WI current concurrency rebinding — AQ baseline alignment

Use this package with concurrency v0.3.0. The supplied AQ source is an implemented dependency, not pending AQ development work. Original WI parents, dependencies, full exit obligations and G1–G5 evidence meanings remain in force. Embedded proof does not waive release or full deployment parity. No previous map approval or runtime qualification is inherited.

## Current core source hashes

| File | Original r3 | Supplied r4 | Current |
|---|---|---|---|
| `wi-fabric-2-foundational-work-breakdown.yaml` | `5a9337822fac8e16019e926c146544bb31ab42375031a38f4177b728d9cc0ae4` | `a987a91441f4b630c8deff11bbf3026fad6232518d16279240b26dc3a61f28b0` | `39adb49f1ebc0a5b11650315417857286bd3a34cb7bc6f7d0ad6f4a34c1d3ec4` |
| `wi-fabric-2-foundational-implementation-plan.md` | `81ad8108101837b9f7d0da1a34e9625cdac3ddba750afb7c5436dd1fee45cf50` | `c19f4f96bb5ebef54b40fe8fb14dd49775ac0c1e7adf45673406e98251c19e36` | `32564920d4cb1fa43fcecf996ef7897aa38b5c70fe4c04ca89adbedde86e608e` |

The original rebinding document is retained in `provenance/supplied-r4-files/`. All current provider/execution supplements and AQ baseline cases are independently source-bound by the v0.3.0 map; matching parent IDs alone is insufficient.
