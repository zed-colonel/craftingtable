# Qualifying the initial worker provider

This is a test/runbook specification, not an executable runtime or a passed qualification.

## 1. Definition and capability freeze

Approve WI-ADR-016 with authorization/evidence reviewers. Bind profile and schema mapping, operation support, approved fixture executable/dependency digests, input classification, credentials, workspace/export rules, process ownership and cleanup. Resolve WP-A01–WP-A08 with owned evidence. Decisions can be reviewed before the owning PR is complete; they do not depend on completed EXO.

## 2. Controlled implementation fixtures

Use a WI-owned consumer harness and reviewed fixture processes. An operator-approved evaluation-only registration permits these controlled qualification runs without demanding a prior completed qualification. Ordinary use remains disabled; profile exclusions and ordinary authorization are not bypassed, and the candidate cannot approve its own promotion. Denial tests must fail before execution, including arbitrary/generated executables, sensitive data/credentials and unenforced required controls. Malicious text may test structural authority without running arbitrary malicious binaries. Clearly separate test-double results from real provider results.

## 3. Real embedded integration

Pin actual AQ and WI implementation/conformance revisions. Require applicable WI-AQ-G1–G4 before merging real runtime adapters. Exercise one coding fixture and one non-coding fixture, then every WP-017–WP-034 failure case. Include crash cuts before/after start intent, spawn, ownership persistence, acknowledgement, event commit, wake publication, artifact publication, cancel and cleanup. Record kernel/OS, execution identity, process controls and actual limits used in the tests.

No broad host permission or engine socket is needed. If a required control cannot be enforced, deny the associated profile request and keep the evidence gap open. Test process output and file artifacts against the actual bounds. Do not intentionally expose production secrets or authoritative Vessel data to proof fixtures.

## 4. Evidence record

For each checkpoint bind its definition digest, required upstream evidence, code/adapter/executable/configuration and fixture digests, effective policy/grant, actual applied controls, environment, result artifacts, negative cases, residual risks and independent reviewer. Never write `passed` into a planning matrix as a substitute for retained executable evidence. A receipt, exit code or application score is not a sandbox qualification.

G1–G4 jointly support WI-EMBEDDED-WORKER-PROOF-1. They do not claim all parent PRs, platform services, stronger isolation, or published-release conformance are complete. The code-level WI harness must work without an EXO binary. EXO later supplies consumer integration evidence.

## 5. Separate lifecycle-supervisor tests

WP-035–WP-040 test a distinct bounded supervisor interface. Persist results outside the stopped target. Verify allowed instance/image/operation bounds, denial of arbitrary flags and credentials, accepted-versus-completed milestones, callback loss, polling/reconciliation and operator recovery independent of the guest. Interface fixtures may use a separate process-domain target; record that limit. EXO's actual Kata stop/recreate/storage tests remain separate.

## 6. Qualification invalidation and safe shutdown

Requalify affected controls after profile, adapter, executable/configuration, policy, AQ/WI-pin or material environment changes. Block new starts on invalid evidence or quarantine. Preserve authorized inspect/stop/reconcile access so revocation does not strand processes. A failed cleanup is not a released resource. Uncertain ownership must not cause adoption or termination of unrelated processes.

## 7. Future provider tests

The no-shared-filesystem asynchronous provider fixture validates the interface only. External worker VM, platform, multi-tenant, confidential-host and hostile-code conformance require separate real implementations and qualifications. Do not promote the proof profile by renaming it.
