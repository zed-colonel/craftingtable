# Revision provenance — r5-aq-baseline-alignment

Input was the supplied WI r4 archive. Current plan is WI-PLAN-5. Exact prior top-level files are retained under `provenance/supplied-r4-files/` with `.source.txt` suffixes, not as duplicate importable plans. Original r3 provenance and constitutional fingerprints are unchanged. The allowed-change rules now explicitly include AQ source binding and 24 additional case assignments. Neither original exit tests nor runtime gate meanings are removed.

All AQ-facing API sketches defer to the source-pinned amendment. No ActionQueue source file is edited. No application runtime, Kata host or actual importer is executed by this package revision.

## Preserved original revision
The previous full revision notes are retained under `provenance/supplied-r4-files/` as inert source text. The bounded worker/execution profiles, original acceptance cases and original full exit obligations remain in force.
