# Foundational coherence — worker-provider amendment

This report supplements the historical r3 report preserved under provenance. The current scope is WI-PLAN-5 / WI-WORKER-EXECUTION-1.

WorldInterface still owns accountable boundaries, ActionQueue still owns durable generic execution, and Exoskeleton still owns meaning and acceptance. The new process provider definition removes an ambiguity between generic lifecycle support and strong worker isolation; it does not erase broader conformance requirements.

Instance provenance (Kata for the EXO consumer) and worker enforcement (reviewed local process) are distinct. Externally provided workers remain a later realization of the existing Agent Host contract. The provider test harness is WI-owned, eliminating an EXO-to-WI producer-proof dependency. The initial embedded composition may produce partial evidence without completing remote/platform parent work.

The immutable stack contract and existing AQ assumptions are unchanged. Representation details need WI-ADR-016 review; no hidden wire-schema alteration is sanctioned. New authoritative files are the provider supplement, typed profile and forty-case acceptance plan. The EXO companion references their exact hashes rather than supplying a conflicting provider definition.

Planning checks and prior reports do not establish runtime correctness. Qualification, threat-model limits and unresolved assumptions remain explicit.
