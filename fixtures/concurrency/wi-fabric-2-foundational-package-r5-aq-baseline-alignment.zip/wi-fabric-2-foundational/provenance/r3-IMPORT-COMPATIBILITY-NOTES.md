# WorldInterface work-breakdown import correction

**Artifact revision:** `r3-import-fix`  
**Patch ID:** `WI-PLAN-3-IMPORT-FIX-1`  
**Supersedes for import:** `wi-fabric-2-foundational-package-r2.zip`  
**Planning revision retained:** `WI-PLAN-3`  
**Architecture contract retained:** `WI-FABRIC-2`  
**Cross-stack profile retained:** `STACK-DEVELOPMENTAL-DIAGNOSTICS-1`

## Cause and correction

The application's error report identified 29 missing required fields in
`wi-fabric-2-foundational-work-breakdown.yaml`: one top-level `document`, fourteen
`primary_areas` fields, and fourteen `risk` fields. The r2 YAML used `areas` for the
work-item scope. The earlier package checks did not validate these importer
requirements; their success did not demonstrate application-import compatibility.

This correction makes exactly these planning-data changes:

| Field | Correction | Count |
|---|---|---:|
| `document` | Add the non-empty title `WI-FABRIC-2 Foundational Implementation Plan`, matching the implementation-plan heading. | 1 |
| `pull_requests[*].primary_areas` | Rename each existing `areas` field and preserve its string list and ordering exactly. | 14 |
| `pull_requests[*].risk` | Add a non-empty severity string for each work item. Ratings and rationale appear below. | 14 |

`primary_areas` is encoded as a non-empty list of non-empty strings, consistent
with the ActionQueue companion work breakdown. The importer errors require a
non-empty string for `risk`; no undocumented enumeration is imposed by the
validator. This package uses `medium`, `high`, and `critical` as planning ratings.

There is one work-breakdown YAML in this package. No duplicate legacy work-item
list, invalid sample YAML, compatibility alias, or second planning authority is
introduced. Reversing the `areas` field rename and removing the new `document`
and `risk` values reproduces the original parsed r2 work breakdown exactly.

## Scope retained

All 14 work-item IDs, titles, dependencies, upstream gates, primary-area values,
exit gates, maturity labels, foundational additions, clean-break rules, and the
critical path are preserved. The architecture document, implementation plan,
frozen base contract, assumption ledger, acceptance matrix, and cross-stack
profile are unchanged byte for byte. The artifact revision changes; the
architecture and planning contract revisions do not.

No Exoskeleton or ActionQueue planning data is changed. The optional rebuilt
combined archive contains the same WorldInterface correction and an updated
portable validator, manifest, and checksums. It is not a claim that every package
conforms to an application-specific import schema.

## Added risk ratings

These ratings are explicit planning judgments based on the existing PR scope,
required tests, and risk register (implementation plan Section 7, Section 15,
and Appendix A), not measured probabilities or changes to scope or authority.
`medium` marks baseline/control work with no runtime change; `high` marks
substantial integration or release risk; `critical` marks load-bearing authority,
persistence, external-effect, isolation, or final-conformance boundaries.

| Work item | Risk | Rationale |
|---|---|---|
| WI-01 | `medium` | Baseline, inventory, CI, and contract omissions can misdirect later work, but this PR does not change runtime behavior. |
| WI-02 | `critical` | Fresh persistence, canonical serialization, state machines, and authoritative records underpin every later durability and authorization guarantee. |
| WI-03 | `high` | Store-before-wake, delivery deduplication, acknowledgments, and recovery must avoid lost or duplicated ingress. |
| WI-04 | `critical` | Exact resource resolution, final authorization, durable intent, and idempotent admission protect against unauthorized or unaccounted external effects. |
| WI-05 | `critical` | Receipt and artifact publication must converge after crashes without false completion, missing evidence, or evidence being promoted into task-quality judgments. |
| WI-06 | `critical` | Commit ambiguity, external idempotency, and reconciliation mistakes can duplicate consequential effects or incorrectly retry non-repeatable operations. |
| WI-07 | `high` | Direct and Flow execution must share one plan and authority path; compiler and coordinator mistakes can change effect ordering or bypass constraints. |
| WI-08 | `critical` | Replacing process-local waits with durable continuations exposes lost-wakeup, cancellation, deadline, and crash-recovery races. |
| WI-09 | `critical` | Worker and candidate environments cross isolation, credential, artifact-export, and lifecycle boundaries; failures can expose protected data or permit sandbox escape. |
| WI-10 | `high` | Catalog rationalization must remove forbidden connectors while admitting only capabilities with complete declarations, isolation, and conformance. |
| WI-11 | `critical` | Embedded and remote parity, authentication, tenancy, secrets, and operator controls must preserve one semantic runtime without cross-principal authority or information leakage. |
| WI-12 | `high` | Optional identity and proof integration must handle keys, bindings, signatures, and disclosure without widening authority or equating provenance with truth. |
| WI-13 | `critical` | The release gate must expose cross-stack durability, security, privacy, load, and restore failures against the exact AQ release candidate before API and schema freeze. |
| WI-14 | `high` | Incorrect release pins, artifacts, fixtures, or handoff documentation can make the published clean-break release non-reproducible or incompatible downstream. |

## Validation and its limits

The supplied error conditions were reproduced against the actual r2 work
breakdown: 29 errors. The corrected YAML passes all 29 known field checks and
the local structural checks. The original 67 WorldInterface package checks also
pass; the updated combined validator additionally checks each of the 29 fields
and aggregates the local structural checks, for 97 WorldInterface checks.

Seventeen regression tests cover the original 29-error shape; deletion of each
of the 29 required fields; blank, null, and wrong-type values; the obsolete
`areas` spelling; duplicate keys and IDs; invalid dependencies; malformed YAML;
CLI exit status; and preservation of the planned PR order and profile labels.
Parameterized cases run within these 17 tests.

**The application importer itself was not executed, and its complete schema was
not available.** Validation establishes the reported field corrections and the
local checks described above, not undocumented importer requirements or runtime
implementation correctness. The prior acceptance cases remain planning
specifications, not evidence that the target software has been implemented.

For reference, the ActionQueue companion already uses `document`,
`pull_requests`, `primary_areas`, and `risk`. The Exoskeleton companion uses
`work_items` and does not include the same `document`, `primary_areas`, and
`risk` fields. It may need separate normalization if the application applies the
same contract there; this WorldInterface-only patch deliberately leaves it
unchanged.

## Use and verification

Import the complete `wi-fabric-2-foundational-package-r3-import-fix.zip` to keep
the corrected YAML, validation artifacts, and checksum manifest together. The
internal package directory and work-breakdown filename are unchanged. Avoid
merging extracted r2 and r3 trees or supplying both versions to one import.

From the extracted `wi-fabric-2-foundational` directory, with Python and PyYAML
available:

```sh
python validate_work_breakdown.py
python -m unittest -v test_work_breakdown_import
sha256sum -c wi-fabric-2-foundational-checksums.sha256
```

The validator writes a JSON result to standard output and leaves package files
unchanged. It exits 0 on success, 1 for validation failures, and 2 for input or
YAML parsing errors. It accepts an optional path to a work-breakdown YAML.

The bundled `wi-fabric-2-import-validation.json` records the before/after results,
source and corrected hashes, preservation checks, and regression-test summary.
The package's normal `wi-fabric-2-foundational-validation.json` records the
updated combined-validator results.
