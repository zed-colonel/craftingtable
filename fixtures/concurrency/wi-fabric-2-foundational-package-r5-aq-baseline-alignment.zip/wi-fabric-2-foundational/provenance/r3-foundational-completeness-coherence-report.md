# Constitutional Stack Foundational-Completeness and Developmental-Diagnostics Review

**Base revision:** `STACK-2026-07-25-FOUNDATIONAL-2`  
**Additive profile:** `STACK-DEVELOPMENTAL-DIAGNOSTICS-1`  
**Date:** August 10, 2026  
**Scope:** additions required for Vessel instantiation, epistemic continuity, role-bearing missions, information governance, lifecycle, viability, governed self-improvement, and task-scoped developmental diagnostics.

## Executive conclusion

The new concepts do not require a fourth runtime or a redesign of the dependency direction.

```text
AQ-CONT-1
    durable opaque execution
        ↓
WI-FABRIC-2
    accountable external agency and evidence
        ↓
EXO-V3
    enduring governed identity, meaning, development, and acceptance
```

ActionQueue requires no semantic amendment. Its existing target primitives—idempotent admission, schedules, `Awaiting`, durable signals, checkpoints, causal references, budgets, and recovery—support commissioning, lifecycle coordination, epistemic review demands, and candidate-development workflows without understanding any of those meanings.

WorldInterface receives the previously planned foundational protocol expansion. Exoskeleton receives the substantive domain additions.

The later developmental-diagnostics clarification does **not** expand the ActionQueue or WorldInterface protocol contracts. It assigns Exoskeleton ownership of task distributions, capability/representation profiles, component fingerprints, controlled probes, frontier assessments, campaigns, saturation, metric interpretation, and acceptance. WorldInterface preserves comparable boundary evidence through existing records; ActionQueue preserves durable opaque execution and causality.

## OHIO-derived diagnostic clarification

The useful insight is that the binding developmental constraint can rotate among capability, working representation, and harness. The stack adopts this as a scoped improvement-search policy, not as a new runtime architecture or universal performance equation.

```text
Exoskeleton
    task distribution · capability/representation profiles · evaluation
    binding-constraint diagnosis · campaign admission · acceptance
        ↓ ordinary accountable effects
WorldInterface
    exact agency/resource/policy/connector/environment evidence
    receipts · uncertainty · reconciliation · lifecycle effects
        ↓ durable opaque work
ActionQueue
    admission · causal correlation · waits · fan-out · retries · recovery
```

The specialized domain ontology and evaluation function of an accounting/ERP development system remain application-owned. Exoskeleton supplies general developmental machinery without embedding that domain in the Vessel kernel.

## Ownership matrix

| Concept | Authoritative owner | Boundary support |
|---|---|---|
| Blueprint, Manifest, Genesis, internal `VesselId` | Exoskeleton | WorldInterface performs post-Genesis commissioning effects only |
| Purpose Charter, roles, Mission Offers, commitment admission | Exoskeleton | WorldInterface verifies external role/stewardship evidence and exact acting capacity |
| Beliefs, assumptions, contradiction, semantic validity, narrative | Exoskeleton | WorldInterface supplies timestamped provenance and receipts |
| Information-use meaning and derived obligations | Exoskeleton | WorldInterface enforces audience/export/disclosure/proof constraints at crossings |
| Candidate proposal, task distribution, capability/representation profiles, component fingerprint, frontier assessment, evaluation plan, acceptance, continuity | Exoskeleton | WorldInterface builds, trials, activates, rolls back, quarantines, and receipts through exact effects |
| Runtime activation authority | External lifecycle supervisor under policy | WorldInterface mediates; Exoskeleton requests and records meaning |
| Task scheduling, waits, signals, checkpoints, crash recovery | ActionQueue | All domain references remain opaque |
| Viability and degraded operation | Exoskeleton | Upstream health and receipt evidence are inputs |
| Schema meaning | Owning domain: WI or EXO | ActionQueue interprets none of it |

## Critical shared distinctions

```text
Blueprint ≠ Vessel
Genesis ≠ commissioning
Purpose Charter ≠ mission
Role ≠ identity
Mission Offer ≠ commitment
Access ≠ information use
Claim ≠ belief
History ≠ current world model
Candidate ≠ accepted version ≠ active runtime
Build provenance ≠ improvement verdict
Restore ≠ migration ≠ succession ≠ fork
Quiescent ≠ unhealthy
Active cognition ≠ viable
```

## Self-improvement boundary

The stack supports governed development without granting recursive sovereignty:

```text
Exoskeleton
    detects limitation
    freezes ImprovementProposal and EvaluationPlan
    delegates isolated candidate work
    admits independent evidence
    decides acceptance and continuity
        ↓
WorldInterface
    provisions candidate environment
    records build/trial provenance
    mediates activation/rollback/quarantine
        ↓
External lifecycle supervisor
    performs protected runtime transition
        ↓
ActionQueue
    durably schedules and resumes opaque work
```

The currently active Vessel cannot modify the active trusted runtime in place, modify the protected evaluation contract, self-amplify improvement authority, or hold the only activation and rollback root.

## Implementation impact

### ActionQueue

No PR-plan or contract change. Add an opaque developmental-campaign execution profile and downstream conformance cases proving that campaign correlation grants no authority, priority, or task-quality meaning.

### WorldInterface

Retain the fourteen-PR plan and existing protocol. Allocate developmental evidence, authorization-parity, candidate-environment provenance, uncertainty, privacy, inspection, and conformance responsibilities across the existing PRs.

### Exoskeleton

Retain the current nineteen-PR comprehensive sequence. Allocate developmental records and conformance across the existing schema, context, faculty, verification, component-registry, self-improvement, viability, hardening, and release PRs:

```text
core store
→ instantiation/lifecycle
→ epistemic/time/schema
→ interaction
→ faculties
→ mission/commitment/initiative
→ relationship/narrative/information
→ capability/persona
→ AQ/WI integration
→ delegation
→ verification
→ component registry
→ governed improvement
→ viability
→ predecessor deletion
→ hardening
→ release
```

## Deferred but enabled

The amendments deliberately preserve seams for:

- multi-Vessel institutional improvement review;
- organizational role and lifecycle services;
- collective narrative and mythos;
- portable identity and transparency systems;
- progressively broader self-improvement authority;
- future embodiment and sensor faculties;
- NetCorp separation of duties and succession.

They do not implement those future institutions prematurely.
