# WI-FABRIC-2 — bounded embedded worker-provider revision

**Artifact:** `r4-worker-provider`  
**Plan:** `WI-PLAN-4`  
**Base contract:** `WI-FABRIC-2` (unchanged)  
**Worker profile:** `WI-WORKER-EXECUTION-1` / `process-managed-proof-1`  
**Developmental profile:** `STACK-DEVELOPMENTAL-DIAGNOSTICS-1` (unchanged)

## Decision

WI now owns the first embedded worker-provider definition. It proves bounded, approved process delegation using real WI/AQ without requiring EXO, platform services, an external worker provider or DigiCorp. It does not claim hostile-code confinement or turn the Vessel's outer Kata VM into an independent worker VM. Future workers remain externally provided resources behind the same generic control/event/artifact contract.

The fourteen original work items, all existing item fields/exit gates, local dependencies, AQ gates, base constitutional invariant bodies and release order are preserved. New scope and profile-specific acceptance supplement them. A partial embedded proof does not complete broader parents. No AQ package, new AQ primitive or WI wire family is introduced.

## Reading order

1. [Revision notes](WORKER-PROVIDER-REVISION-NOTES.md).
2. [Authoritative provider supplement](wi-fabric-2-worker-execution-profile.md) and [typed definition](wi-fabric-2-worker-execution-profile.yaml).
3. [Implementation plan](wi-fabric-2-foundational-implementation-plan.md) and [work breakdown](wi-fabric-2-foundational-work-breakdown.yaml).
4. [Acceptance matrix](wi-fabric-2-worker-execution-acceptance-matrix.yaml) and [qualification runbook](WORKER-PROVIDER-QUALIFICATION.md).
5. [Downstream handoff](WI-EXO-WORKER-HANDOFF.md) and [concurrency rebinding guidance](WORKER-CONCURRENCY-REBINDING.md).
6. [Worker assumption ledger](wi-fabric-2-worker-boundary-assumption-ledger.yaml), retained architecture and OHIO evidence materials.

## Import

Import this complete archive in place of the WI r3 package. One canonical `document`/`pull_requests` work-breakdown YAML remains. New supplement YAMLs have distinct `kind` values and are supporting planning material, not work-item lists or deployment manifests. The known import fields are preserved; the actual application importer and its full schema were not available.

Use the companion EXO `r5-wi-provider-alignment` artifact for pinned producer references. It leaves EXO work items and execution scope unchanged. Do not combine either new plan with the old hash-bound concurrency sidecar without reviewed rebinding. The prior combined-stack archives are not updated by these standalone releases.

## Validate

With Python 3.10+ and PyYAML, from this directory:

```sh
python validate_work_breakdown.py
python validate_worker_package.py
python -m unittest -v test_work_breakdown_import test_worker_profile
sha256sum -c wi-fabric-2-foundational-checksums.sha256
```

Static checks validate planning definitions, source preservation, known importer fields and consistency only. Forty worker acceptance cases are planned, not executed. Historical r3 reports under `provenance/` are evidence of earlier packaging checks, never present implementation status. Host/provider/AQ/WI runtime qualification remains pending.
