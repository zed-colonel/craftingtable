"""Regression coverage for the reported WorldInterface importer omissions.

Run: python -m unittest -v test_work_breakdown_import
No invalid work-breakdown YAML is shipped alongside the importable document.
"""
from __future__ import annotations

import copy
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

import yaml

from validate_work_breakdown import DEFAULT_DOCUMENT, load_work_breakdown, validate_work_breakdown


class WorkBreakdownImportTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.valid = load_work_breakdown(DEFAULT_DOCUMENT)

    def assert_one_error(self, data, path):
        result = validate_work_breakdown(data)
        self.assertEqual(result['error_count'], 1, result['errors'])
        self.assertEqual(result['errors'][0]['path'], path)

    def test_corrected_document_has_29_passing_field_checks(self):
        result = validate_work_breakdown(self.valid)
        self.assertEqual(result['work_item_count'], 14)
        self.assertEqual(result['known_field_check_count'], 29)
        self.assertEqual(result['known_field_passed_count'], 29)
        self.assertEqual(result['error_count'], 0, result['errors'])

    def test_original_shape_reproduces_exactly_29_reported_errors(self):
        legacy = copy.deepcopy(self.valid)
        legacy.pop('document')
        for item in legacy['pull_requests']:
            item['areas'] = item.pop('primary_areas')
            item.pop('risk')
        result = validate_work_breakdown(legacy)
        self.assertEqual(result['error_count'], 29)
        self.assertEqual(result['structural_check_count'], result['structural_passed_count'])
        expected = ['document']
        for index in range(14):
            expected.extend([f'pull_requests[{index}].primary_areas', f'pull_requests[{index}].risk'])
        self.assertEqual([error['path'] for error in result['errors']], expected)
        self.assertEqual(result['errors'][0]['code'], 'invalid-work-breakdown')
        self.assertTrue(all(error['code'] == 'invalid-work-item-field' for error in result['errors'][1:]))

    def test_removing_any_one_required_field_is_detected(self):
        changed = copy.deepcopy(self.valid)
        changed.pop('document')
        self.assert_one_error(changed, 'document')
        for index in range(14):
            for field in ('primary_areas', 'risk'):
                with self.subTest(index=index, field=field):
                    changed = copy.deepcopy(self.valid)
                    changed['pull_requests'][index].pop(field)
                    self.assert_one_error(changed, f'pull_requests[{index}].{field}')

    def test_document_rejects_blank_null_and_wrong_types(self):
        for value in ('', '  ', None, 1, False, [], {}):
            with self.subTest(value=value):
                changed = copy.deepcopy(self.valid)
                changed['document'] = value
                self.assert_one_error(changed, 'document')

    def test_primary_areas_rejects_empty_or_malformed_lists(self):
        for index in range(14):
            for value in (None, '', 'protocol', [], [''], ['  '], [1], [None], {}, False):
                with self.subTest(index=index, value=value):
                    changed = copy.deepcopy(self.valid)
                    changed['pull_requests'][index]['primary_areas'] = value
                    self.assert_one_error(changed, f'pull_requests[{index}].primary_areas')

    def test_risk_rejects_blank_null_and_wrong_types(self):
        for index in range(14):
            for value in ('', '  ', None, 1, False, [], {}):
                with self.subTest(index=index, value=value):
                    changed = copy.deepcopy(self.valid)
                    changed['pull_requests'][index]['risk'] = value
                    self.assert_one_error(changed, f'pull_requests[{index}].risk')

    def test_risk_does_not_assume_an_undocumented_importer_enum(self):
        changed = copy.deepcopy(self.valid)
        changed['pull_requests'][0]['risk'] = 'A non-empty risk description'
        self.assertEqual(validate_work_breakdown(changed)['error_count'], 0)

    def test_legacy_areas_does_not_substitute_for_primary_areas(self):
        changed = copy.deepcopy(self.valid)
        changed['pull_requests'][0]['areas'] = changed['pull_requests'][0].pop('primary_areas')
        self.assert_one_error(changed, 'pull_requests[0].primary_areas')

    def test_exact_worldinterface_order_and_plan_metadata_preserved(self):
        expected = [f'WI-{index:02d}' for index in range(1, 15)]
        self.assertEqual([item['id'] for item in self.valid['pull_requests']], expected)
        self.assertEqual(self.valid['critical_path'], expected)
        self.assertEqual(self.valid['plan_revision'], 'WI-PLAN-5')
        self.assertEqual(self.valid['contract'], 'WI-FABRIC-2')
        self.assertEqual(self.valid['cross_stack_profile'], 'STACK-DEVELOPMENTAL-DIAGNOSTICS-1')
        self.assertFalse(self.valid['normative_protocol_change'])
        self.assertTrue(all('areas' not in item for item in self.valid['pull_requests']))

    def test_dependency_errors_are_detected(self):
        for dependencies in (['WI-99'], ['WI-01'], ['WI-14'], ['WI-02', 'WI-02']):
            with self.subTest(dependencies=dependencies):
                changed = copy.deepcopy(self.valid)
                changed['pull_requests'][0]['depends_on'] = dependencies
                self.assertGreater(validate_work_breakdown(changed)['error_count'], 0)

    def test_duplicate_work_item_ids_are_detected(self):
        changed = copy.deepcopy(self.valid)
        changed['pull_requests'][1]['id'] = changed['pull_requests'][0]['id']
        self.assertGreater(validate_work_breakdown(changed)['error_count'], 0)

    def test_invalid_root_and_collection_types_are_rejected(self):
        for value in (None, '', [], 1, {'document': 'Example', 'pull_requests': [None]}):
            with self.subTest(value=value):
                self.assertGreater(validate_work_breakdown(value)['error_count'], 0)

    def test_duplicate_yaml_keys_are_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'input.yaml'
            path.write_text('document: first\ndocument: second\n', encoding='utf-8')
            with self.assertRaises(yaml.YAMLError):
                load_work_breakdown(path)

    def test_validation_does_not_mutate_input(self):
        original = copy.deepcopy(self.valid)
        validate_work_breakdown(original)
        self.assertEqual(original, self.valid)

    def test_cli_accepts_corrected_document(self):
        script = DEFAULT_DOCUMENT.parent / 'validate_work_breakdown.py'
        result = subprocess.run([sys.executable, str(script)], capture_output=True, text=True, check=False)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout)['error_count'], 0)

    def test_cli_rejects_missing_field_with_nonzero_exit(self):
        changed = copy.deepcopy(self.valid)
        changed.pop('document')
        script = DEFAULT_DOCUMENT.parent / 'validate_work_breakdown.py'
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'input.yaml'
            path.write_text(yaml.safe_dump(changed), encoding='utf-8')
            result = subprocess.run([sys.executable, str(script), str(path)], capture_output=True, text=True, check=False)
            self.assertEqual(result.returncode, 1)
            self.assertEqual(json.loads(result.stdout)['error_count'], 1)

    def test_cli_rejects_malformed_yaml(self):
        script = DEFAULT_DOCUMENT.parent / 'validate_work_breakdown.py'
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'input.yaml'
            path.write_text('document: [unterminated\n', encoding='utf-8')
            result = subprocess.run([sys.executable, str(script), str(path)], capture_output=True, text=True, check=False)
            self.assertEqual(result.returncode, 2)
            self.assertEqual(json.loads(result.stdout)['error_count'], 1)


if __name__ == '__main__':
    unittest.main()
