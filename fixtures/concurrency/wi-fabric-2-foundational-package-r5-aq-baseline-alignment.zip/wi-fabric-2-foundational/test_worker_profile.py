"""Static profile mutation tests. These do not launch workers or test isolation."""
from __future__ import annotations
import copy,json,subprocess,sys,tempfile,unittest
from pathlib import Path
from validate_worker_package import ROOT,load,validate
from worker_profile_validation import worker_profile_errors

class WorkerProfileTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.p=load(ROOT/'wi-fabric-2-worker-execution-profile.yaml');cls.m=load(ROOT/'wi-fabric-2-worker-execution-acceptance-matrix.yaml');cls.ids={f'WI-{i:02d}' for i in range(1,15)}
    def setUp(self):self.profile=copy.deepcopy(self.p);self.matrix=copy.deepcopy(self.m)
    def errors(self):return worker_profile_errors(self.profile,self.matrix,self.ids)
    def mutation(self,path,value):
        p=path.split('.');d=self.profile
        for k in p[:-1]:d=d[k]
        d[p[-1]]=value;self.assertTrue(self.errors(),path)
    def test_evaluation_not_ordinary_enablement(self):self.mutation('qualification_evaluation.ordinary_admission_enabled',True)
    def test_evaluation_cannot_waive_controls(self):self.mutation('qualification_evaluation.may_waive_missing_mandatory_enforcement',True)
    def test_no_self_qualification(self):self.mutation('qualification_evaluation.may_self_promote_to_qualified',True)
    def test_no_qualification_cycle(self):self.mutation('qualification_evaluation.requires_prior_completed_provider_qualification',True)
    def test_valid_profile(self):self.assertEqual(self.errors(),[])
    def test_owner_is_wi_not_exo(self):self.mutation('owner_repository','zed-colonel/exoskeleton')
    def test_consumer_cannot_weaken(self):self.mutation('authority.consumer_may_weaken_restrictions',True)
    def test_unsafe_admission_mutations(self):
        for key in ['arbitrary_generated_executables_allowed','production_credentials_allowed','sensitive_production_data_allowed','unreviewed_executable_candidates_allowed','silent_downgrade_allowed','caller_profile_claim_authoritative']:
            with self.subTest(key=key):self.setUp();self.mutation('admission.'+key,True)
    def test_no_implied_independent_isolation(self):
        for path in ['provider.independent_worker_vm','provider.hostile_code_containment_claim','evidence.enclosing_kata_implies_worker_vm','evidence.worker_report_is_host_attestation']:
            with self.subTest(path=path):self.setUp();self.mutation(path,True)
    def test_no_host_runtime_authority(self):
        for path in ['provider.host_or_platform_management_socket_access','provider.arbitrary_engine_flags_accepted','host_lifecycle_adapter.guest_engine_socket_allowed','host_lifecycle_adapter.candidate_owns_activation_credentials']:
            with self.subTest(path=path):self.setUp();self.mutation(path,True)
    def test_no_locality_required(self):self.mutation('provider.local_pid_or_host_path_required_by_consumer',True)
    def test_no_current_external_dependency(self):self.mutation('provider.external_provider_required_now',True)
    def test_unknown_control_denied(self):self.mutation('admission.unknown_mandatory_control_action','ignore')
    def test_reauthorization_on_drift(self):self.mutation('admission.provider_change_requires_reauthorization',False)
    def test_optional_operations_not_pretend_supported(self):self.mutation('operation_contract.unqualified_optional_operation_available',True)
    def test_no_memory_restore_claim(self):self.mutation('operation_contract.process_memory_restore_claim',True)
    def test_lifecycle_guarantees_not_lost(self):
        for key in ['durable_intent_before_start','stable_run_identity_not_pid','pid_reuse_safe_ownership_required','event_durable_before_wake','process_tree_cleanup_required','cleanup_failure_reported']:
            with self.subTest(key=key):self.setUp();self.mutation('lifecycle.'+key,False)
    def test_no_blind_retry(self):self.mutation('lifecycle.unconditional_duplicate_start_allowed',True)
    def test_requested_stop_not_confirmed_exit(self):self.mutation('lifecycle.termination_request_is_confirmed_exit',True)
    def test_no_task_acceptance(self):self.mutation('evidence.receipt_is_task_quality_or_acceptance',True)
    def test_no_new_aq_primitive(self):self.mutation('authority.new_actionqueue_primitives',['spawn_vm'])
    def test_no_platform_exo_or_kata_dependency(self):
        for key in ['requires_exoskeleton_implementation','requires_platform_services','requires_kata_host','requires_external_worker_provider','requires_digicorp']:
            with self.subTest(key=key):self.setUp();self.mutation('milestones.embedded_worker_proof.'+key,True)
    def test_partial_proof_not_parent_release(self):
        for key in ['marks_parent_prs_accepted','satisfies_full_release_or_stronger_isolation']:
            with self.subTest(key=key):self.setUp();self.mutation('milestones.embedded_worker_proof.'+key,True)
    def test_host_boundary_not_worker_proof_prerequisite(self):self.mutation('host_lifecycle_adapter.required_for_process_provider_proof',True)
    def test_results_survive_guest(self):self.mutation('host_lifecycle_adapter.results_queryable_outside_stopped_guest',False)
    def test_bad_scalar_type(self):self.mutation('admission.reviewed_executables_only','true')
    def test_missing_required_property(self):del self.profile['evidence']['requested_advertised_enforced_observed_distinct'];self.assertTrue(self.errors())
    def test_no_pretend_qualification(self):self.mutation('status','qualified')
    def test_cases_and_checkpoints_planned_only(self):
        self.matrix['cases'][0]['status']='passed';self.assertTrue(self.errors());self.setUp();self.profile['checkpoints'][0]['status']='passed';self.assertTrue(self.errors())
    def test_unknown_case_ref_owner_or_duplicate(self):
        for k,v in [('checkpoint','WI-WORKER-G99'),('owner_pr','EXO-12'),('id','WP-002')]:
            with self.subTest(key=k):self.setUp();self.matrix['cases'][0][k]=v;self.assertTrue(self.errors())
    def test_no_case_coverage_drop(self):self.profile['checkpoints'][0]['cases'].pop();self.assertTrue(self.errors())
    def test_real_embedded_evidence_not_mock(self):self.matrix['cases'][16]['requires_real_embedded_aq_wi']=False;self.assertTrue(self.errors())
    def test_upstream_gate_cannot_be_lost(self):self.profile['checkpoints'][2]['required_aq_gates_for_real_integration'].pop();self.assertTrue(self.errors())
    def test_no_exo_completion_cycle(self):self.profile['checkpoints'][0]['requires_completed_exo_prs']=['EXO-12'];self.assertTrue(self.errors())
    def test_no_parent_self_dependency(self):self.profile['checkpoints'][2]['requires_completed_parent_prs']=['WI-09'];self.assertTrue(self.errors())
    def test_cycle_detected(self):self.profile['checkpoints'][0]['requires_checkpoints']=['WI-WORKER-G4'];self.assertTrue(any('cycle' in x for x in self.errors()))
    def test_checkpoint_missing_rejected(self):self.profile['checkpoints'].pop();self.assertTrue(self.errors())
    def test_input_not_mutated(self):p=copy.deepcopy(self.profile);m=copy.deepcopy(self.matrix);self.errors();self.assertEqual(self.profile,p);self.assertEqual(self.matrix,m)
    def test_invalid_roots(self):self.assertTrue(worker_profile_errors(None,self.matrix,self.ids))
    def test_full_package_static_validation(self):
        r=validate(ROOT);self.assertEqual(r['failed_count'],0,[c for c in r['checks'] if not c['passed']]);self.assertFalse(r['runtime_tests_executed']);self.assertFalse(r['application_importer_executed'])
    def test_cli_succeeds_nonmutating(self):
        p=ROOT/'wi-fabric-2-worker-execution-profile.yaml';b=p.read_bytes();r=subprocess.run([sys.executable,str(ROOT/'validate_worker_package.py')],capture_output=True,text=True);self.assertEqual(r.returncode,0,r.stdout+r.stderr);self.assertEqual(p.read_bytes(),b)
if __name__=='__main__':unittest.main()
