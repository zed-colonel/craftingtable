#!/usr/bin/env python3
"""Check the reported importer fields and basic planning-document integrity.

Requires PyYAML, as does the combined planning-package validator.
This is NOT the user's importer or a reconstruction of its full schema.
Running this script never modifies the planning document.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import yaml

DEFAULT_DOCUMENT = Path(__file__).resolve().parent / 'wi-fabric-2-foundational-work-breakdown.yaml'
VALIDATION_SCOPE = (
    'Reported document/primary_areas/risk requirements, nonempty string-list '
    'representation inferred from the ActionQueue companion, and local structural '
    'checks. The application importer and its complete schema were not available.'
)


class UniqueKeyLoader(yaml.SafeLoader):
    """Reject duplicate mapping keys rather than silently dropping a value."""


def _unique_mapping(loader: UniqueKeyLoader, node: yaml.MappingNode, deep: bool = False) -> dict[Any, Any]:
    result: dict[Any, Any] = {}
    for key_node, value_node in node.value:
        key = loader.construct_object(key_node, deep=deep)
        try:
            duplicate = key in result
        except TypeError as exc:
            raise yaml.constructor.ConstructorError(
                'while reading a mapping', node.start_mark,
                'mapping keys must be hashable', key_node.start_mark,
            ) from exc
        if duplicate:
            raise yaml.constructor.ConstructorError(
                'while reading a mapping', node.start_mark,
                f'duplicate mapping key {key!r}', key_node.start_mark,
            )
        result[key] = loader.construct_object(value_node, deep=deep)
    return result


UniqueKeyLoader.add_constructor(
    yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG, _unique_mapping,
)


def load_work_breakdown(path: Path) -> Any:
    return yaml.load(path.read_text(encoding='utf-8'), Loader=UniqueKeyLoader)


def _nonempty_string(value: Any) -> bool:
    return isinstance(value, str) and bool(value.strip())


def _string_list(value: Any, *, allow_empty: bool = False) -> bool:
    return (
        isinstance(value, list)
        and (allow_empty or bool(value))
        and all(_nonempty_string(item) for item in value)
    )


def validate_work_breakdown(data: Any) -> dict[str, Any]:
    """Return explicit field checks, structural checks, and path-addressed errors."""
    field_checks: list[dict[str, Any]] = []
    structural_checks: list[dict[str, Any]] = []

    def add(target: list[dict[str, Any]], path: str, passed: bool, code: str,
            message: str, item_id: str | None = None) -> None:
        target.append({
            'path': path, 'work_item_id': item_id, 'passed': bool(passed),
            'code': code, 'message': message,
        })

    add(structural_checks, '$', isinstance(data, dict), 'invalid-work-breakdown',
        'The work breakdown must be a YAML mapping')
    mapping = data if isinstance(data, dict) else {}
    document_message = (
        'Required top-level field "document" is missing' if 'document' not in mapping
        else '"document" must be a non-empty string'
    )
    add(field_checks, 'document', _nonempty_string(mapping.get('document')),
        'invalid-work-breakdown', document_message)
    items = mapping.get('pull_requests')
    add(structural_checks, 'pull_requests', isinstance(items, list) and bool(items),
        'invalid-work-breakdown', '"pull_requests" must be a non-empty list')
    items = items if isinstance(items, list) else []
    ids: list[str] = []
    usable: list[tuple[int, dict[str, Any]]] = []
    for index, item in enumerate(items):
        prefix = f'pull_requests[{index}]'
        add(structural_checks, prefix, isinstance(item, dict),
            'invalid-work-item-field', 'Each pull request must be a mapping')
        if not isinstance(item, dict):
            continue
        item_id = item.get('id') if _nonempty_string(item.get('id')) else None
        usable.append((index, item))
        if item_id is not None:
            ids.append(item_id)
        add(field_checks, f'{prefix}.primary_areas',
            _string_list(item.get('primary_areas')), 'invalid-work-item-field',
            '"primary_areas" is required' if 'primary_areas' not in item else
            '"primary_areas" must be a non-empty list of non-empty strings', item_id)
        add(field_checks, f'{prefix}.risk', _nonempty_string(item.get('risk')),
            'invalid-work-item-field', '"risk" is required and must be a non-empty string', item_id)
        for key in ('id', 'title', 'exit_gate'):
            add(structural_checks, f'{prefix}.{key}', _nonempty_string(item.get(key)),
                'invalid-work-item-field', f'"{key}" must be a non-empty string', item_id)
        add(structural_checks, f'{prefix}.depends_on',
            _string_list(item.get('depends_on'), allow_empty=True),
            'invalid-work-item-field', '"depends_on" must be a list of non-empty strings', item_id)

    add(structural_checks, 'pull_requests[*].id', len(ids) == len(set(ids)),
        'invalid-work-breakdown', 'Work-item IDs must be unique')
    positions = {item_id: index for index, item_id in enumerate(
        [item.get('id') if isinstance(item, dict) else None for item in items]
    ) if isinstance(item_id, str)}
    for index, item in usable:
        dependencies = item.get('depends_on')
        if not _string_list(dependencies, allow_empty=True):
            continue
        prefix = f'pull_requests[{index}].depends_on'
        item_id = item.get('id') if _nonempty_string(item.get('id')) else None
        add(structural_checks, prefix, len(dependencies) == len(set(dependencies)),
            'invalid-work-item-field', 'Dependencies must not be repeated', item_id)
        add(structural_checks, prefix, all(dep in positions for dep in dependencies),
            'invalid-work-item-field', 'Every dependency must name an existing work item', item_id)
        add(structural_checks, prefix,
            all(dep in positions and positions[dep] < index for dep in dependencies),
            'invalid-work-item-field', 'Dependencies must precede their dependents', item_id)

    if 'critical_path' in mapping:
        critical = mapping['critical_path']
        valid_critical = _string_list(critical)
        add(structural_checks, 'critical_path', valid_critical,
            'invalid-work-breakdown', '"critical_path" must be a non-empty list of IDs')
        if valid_critical:
            add(structural_checks, 'critical_path',
                len(critical) == len(set(critical)) and all(item_id in positions for item_id in critical),
                'invalid-work-breakdown', 'Critical-path IDs must be unique and reference existing work items')

    checks = field_checks + structural_checks
    errors = [dict(check) for check in checks if not check['passed']]
    return {
        'scope': VALIDATION_SCOPE,
        'application_importer_executed': False,
        'work_item_count': len(items),
        'known_field_check_count': len(field_checks),
        'known_field_passed_count': sum(check['passed'] for check in field_checks),
        'structural_check_count': len(structural_checks),
        'structural_passed_count': sum(check['passed'] for check in structural_checks),
        'error_count': len(errors),
        'errors': errors,
        'known_field_checks': field_checks,
        'structural_checks': structural_checks,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('document', type=Path, nargs='?', default=DEFAULT_DOCUMENT)
    args = parser.parse_args()
    try:
        data = load_work_breakdown(args.document)
    except (OSError, UnicodeError, yaml.YAMLError) as exc:
        print(json.dumps({'document': args.document.name, 'error_count': 1,
                          'errors': [{'code': 'unreadable-work-breakdown', 'message': str(exc)}]}, indent=2))
        return 2
    result = validate_work_breakdown(data)
    print(json.dumps({'document': args.document.name, **result}, indent=2))
    return 1 if result['error_count'] else 0


if __name__ == '__main__':
    raise SystemExit(main())
