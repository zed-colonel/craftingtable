#!/usr/bin/env python3
"""Static WI-PLAN-5 packaging checks, not runtime conformance or the user's importer."""
from __future__ import annotations
import argparse,copy,hashlib,json,re
from pathlib import Path
from typing import Any
import yaml
from validate_work_breakdown import UniqueKeyLoader,validate_work_breakdown
from worker_profile_validation import worker_profile_errors
ROOT=Path(__file__).resolve().parent

def sha(p: Path)->str:return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p: Path)->Any:return yaml.load(p.read_text(encoding='utf-8'),Loader=UniqueKeyLoader)
def invariant_hashes(s):return {m.group(1):hashlib.sha256(m.group(0).strip().encode()).hexdigest() for m in re.finditer(r'^### (W\d+)\. [^\n]+\n.*?(?=^### W\d+\.|^## |\Z)',s,re.M|re.S)}
def validate(root:Path=ROOT)->dict[str,Any]:
    checks=[]
    def check(name,ok,detail=None):checks.append({'name':name,'passed':bool(ok),'detail':detail})
    required=['README.md','IMPORT-COMPATIBILITY-NOTES.md','WORKER-PROVIDER-REVISION-NOTES.md','WORKER-PROVIDER-QUALIFICATION.md','WORKER-CONCURRENCY-REBINDING.md','WI-EXO-WORKER-HANDOFF.md','wi-fabric-2-worker-execution-profile.md','wi-fabric-2-worker-execution-profile.yaml','wi-fabric-2-worker-execution-acceptance-matrix.yaml','wi-fabric-2-worker-boundary-assumption-ledger.yaml','wi-fabric-2-foundational-implementation-plan.md','wi-fabric-2-foundational-work-breakdown.yaml','worldinterface-v2-foundational-design.md','provenance/source-manifest.json','provenance/r3-work-breakdown.json','provenance/r3-core-semantics.json','provenance/revision-rules.json','worker_profile_validation.py','test_worker_profile.py']
    for n in required:check(n+' exists', (root/n).is_file() and (root/n).stat().st_size>0)
    if any(not c['passed'] for c in checks):return report(checks)
    parsed={}
    for p in sorted(root.glob('*.yaml')):
        try:parsed[p.name]=load(p);check(p.name+' safe unique-key YAML',True)
        except (OSError,yaml.YAMLError,UnicodeError) as e:check(p.name+' safe unique-key YAML',False,str(e))
    if any(not c['passed'] for c in checks):return report(checks)
    for p in sorted(root.rglob('*.json')):
        if p.parent==root and (p.name.endswith('validation.json') or p.name=='regression-tests.json'):continue
        try:json.loads(p.read_text());check(str(p.relative_to(root))+' JSON',True)
        except (OSError,ValueError) as e:check(str(p.relative_to(root))+' JSON',False,str(e))
    for p in sorted(root.glob('*.md')):
        s=p.read_text();check(p.name+' fenced blocks balanced',len(re.findall(r'^```',s,re.M))%2==0)
        check(p.name+' no NUL','\0' not in s)
    w=parsed['wi-fabric-2-foundational-work-breakdown.yaml'];imp=validate_work_breakdown(w)
    check('29 known required importer fields',imp['known_field_check_count']==29 and imp['known_field_passed_count']==29)
    check('work-breakdown structural checks',imp['error_count']==0,imp['errors'])
    check('one canonical work breakdown',len(list(root.rglob('*work-breakdown.yaml')))==1 and 'work_items' not in w)
    src=json.loads((root/'provenance/source-manifest.json').read_text());rules=json.loads((root/'provenance/revision-rules.json').read_text());base=json.loads((root/'provenance/r3-work-breakdown.json').read_text())
    want=copy.deepcopy(base);want.update(rules['top_level_changes'])
    for item in want['pull_requests']:
        if item['id'] in rules['scope_by_id']:item['worker_execution_scope']=rules['scope_by_id'][item['id']]
        if item['id'] in rules['aq_baseline_cases_by_id']:item['aq_baseline_acceptance_cases']=rules['aq_baseline_cases_by_id'][item['id']]
    check('only declared work-breakdown changes',w==want)
    check('all fourteen original work identities',[i['id'] for i in w['pull_requests']]==[f'WI-{i:02d}' for i in range(1,15)])
    for original,new in zip(base['pull_requests'],w['pull_requests']):
        check(original['id']+' all original fields unchanged',all(k in new and new[k]==v for k,v in original.items()))
    for name in rules['unchanged_files']:check(name+' byte-identical to r3',sha(root/name)==src['source_files'][name])
    sem=json.loads((root/'provenance/r3-core-semantics.json').read_text());design=(root/'worldinterface-v2-foundational-design.md').read_text();plan=(root/'wi-fabric-2-foundational-implementation-plan.md').read_text()
    inv=invariant_hashes(design);check('59 constitutional bodies preserved',len(inv)==59 and inv==sem['invariants'])
    gate_rows=re.findall(r'^\| \*\*WI-AQ-G\d[^\n]*$',plan,re.M)
    check('original upstream AQ gate definitions preserved',gate_rows==sem['aq_gate_rows'] and len(gate_rows)==5)
    pg={}
    for m in re.finditer(r'^### (WI-\d{2}) — [^\n]+\n(.*?)(?=^### WI-|^## 8\.|\Z)',plan,re.M|re.S):
        g=re.search(r'^\*\*Exit gate:\*\* (.+)$',m[2],re.M)
        if g:pg[m[1]]=g[1]
    check('fourteen detailed plan exits preserved',len(pg)==14 and pg==sem['plan_exit_gates'])
    check('unchanged ADR identities and all other ADR text', [x for x in re.findall(r'^\| `WI-ADR-\d{3}`[^\n]*$',plan,re.M) if 'WI-ADR-016' not in x] == [x for x in sem['adr_rows'] if 'WI-ADR-016' not in x])
    check('ADR016 producer ownership clarified','authoritative process-managed-proof-1 profile' in plan)
    check('document title and metadata',plan.splitlines()[0][2:]==w['document'] and '`WI-PLAN-5`' in plan)
    for ident,scopes in rules['scope_by_id'].items():
        for s in scopes:check(ident+' scope present in plan',s in plan)
    profile=parsed['wi-fabric-2-worker-execution-profile.yaml'];matrix=parsed['wi-fabric-2-worker-execution-acceptance-matrix.yaml']
    errors=worker_profile_errors(profile,matrix,{i['id'] for i in w['pull_requests']})
    check('profile/cases/checkpoint semantic safeguards',not errors,errors)
    ledger=parsed['wi-fabric-2-worker-boundary-assumption-ledger.yaml']
    check('eight pending non-AQ implementation assumptions',ledger['new_actionqueue_assumptions']==[] and len(ledger['assumptions'])==8 and all(x['status']=='pending' and x['consumer_completion_required'] is False for x in ledger['assumptions']))
    handoff=(root/'WI-EXO-WORKER-HANDOFF.md').read_text()
    for n in ['wi-fabric-2-worker-execution-profile.md','wi-fabric-2-worker-execution-profile.yaml','wi-fabric-2-worker-execution-acceptance-matrix.yaml']:check(n+' handoff hash',sha(root/n) in handoff)
    rebind=(root/'WORKER-CONCURRENCY-REBINDING.md').read_text()
    for n in ['wi-fabric-2-foundational-work-breakdown.yaml','wi-fabric-2-foundational-implementation-plan.md']:check(n+' old/new rebinding hashes',src['source_files'][n] in rebind and sha(root/n) in rebind)
    for name in required:
        if not name.endswith('.md') or name.startswith('provenance'):continue
        for target in re.findall(r'\]\(([^)]+)\)',(root/name).read_text()):
            if '://' in target or target.startswith('#'):continue
            check(name+' local link '+target,(root/target.split('#')[0]).is_file())
    from validate_aq_alignment import validate as validate_aq
    aq_result=validate_aq(root)
    check('AQ baseline alignment obligations',aq_result['valid'],aq_result['errors'])
    result=report(checks)
    result.update(work_item_count=14,worker_acceptance_case_count=40,existing_developmental_case_count=20,worker_checkpoint_count=5,known_import_field_check_count=29,constitutional_invariant_count=59,source_archive_sha256=src['source_archive_sha256'],work_breakdown_sha256=sha(root/'wi-fabric-2-foundational-work-breakdown.yaml'))
    return result

def report(checks):
    passed=sum(x['passed'] for x in checks)
    return {'artifact_revision':'r5-aq-baseline-alignment','plan_revision':'WI-PLAN-5','worker_profile':'WI-WORKER-EXECUTION-1','validation_scope':'Static planning preservation and consistency only. No live provider, Kata, AQ/WI runtime, application importer or conformance executed.','runtime_tests_executed':False,'application_importer_executed':False,'check_count':len(checks),'passed_count':passed,'failed_count':len(checks)-passed,'checks':checks}

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--root',type=Path,default=ROOT);ap.add_argument('--report',type=Path);args=ap.parse_args()
    try:r=validate(args.root)
    except (OSError,ValueError,KeyError,TypeError,yaml.YAMLError) as e:print(json.dumps({'error':str(e),'runtime_tests_executed':False}));return 2
    text=json.dumps(r,indent=2)+'\n'
    if args.report:args.report.write_text(text)
    print(text,end='');return 1 if r['failed_count'] else 0
if __name__=='__main__':raise SystemExit(main())
