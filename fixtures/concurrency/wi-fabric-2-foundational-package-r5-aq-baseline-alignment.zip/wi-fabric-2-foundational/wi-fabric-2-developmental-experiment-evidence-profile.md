# WI-FABRIC-2 Developmental Experiment Evidence Profile

**Status:** Additive planning and conformance clarification; no `WI-FABRIC-2` protocol expansion  
**Cross-stack profile:** `STACK-DEVELOPMENTAL-DIAGNOSTICS-1`  
**Base architecture:** `WI-FABRIC-2` on `STACK-2026-07-25-FOUNDATIONAL-2`  
**Date:** August 10, 2026

## 1. Purpose

The OHIO-derived learning relevant to WorldInterface is narrow but important: controlled developmental comparisons require trustworthy evidence about the boundary conditions under which each intervention arm ran.

WorldInterface already owns accountable crossings, exact resource resolution, final executable authorization, effect and observation lifecycles, receipts, uncertainty, reconciliation, component provenance, and lifecycle operations. It should use those existing responsibilities to make developmental evidence comparable and inspectable.

It must not become the owner of:

- the task distribution or benchmark;
- the meaning of capability, representation, or harness;
- the claim that a particular component is the binding constraint;
- metric aggregation or statistical interpretation;
- improvement acceptance, continuity, or activation policy;
- specialized accounting, ERP, software-maintenance, or other business ontology.

The governing rule is:

> WorldInterface proves what crossed a boundary, under which resolved resource, policy, connector, environment, authority, and uncertainty state. Exoskeleton decides what that evidence means for development.

## 2. No new protocol primitive

This profile uses existing `WI-FABRIC-2` seams:

```text
EffectSubmission.causal_refs
AgencyContext.causal_refs
ObservationDelivery.causal_refs
ReceiptEnvelope.causal_refs
EffectIntent and ResolvedEffect
AuthorizationEnvelope
BoundaryObservation
BoundaryReceipt and EvidenceRef
Uncertain and Reconciliation
candidate / build / trial / activation / rollback capabilities
component, connector, schema, resolver, and policy provenance
```

No new developmental request, receipt, authorization, scheduler, or workflow type is required. The profile is a conformance rule for how existing records are populated and interpreted when an Exoskeleton-owned developmental campaign uses them.

The causal-reference set remains bounded. It should normally contain opaque references to an immutable campaign execution context, the intervention arm, and the frozen evaluation plan. A free-form metadata map is prohibited.

## 3. Developmental correlation is not authority

A campaign or arm reference is attribution only. It cannot:

- authenticate the requester;
- identify the accountable principal by itself;
- widen a grant or role;
- bypass canonical resource or audience resolution;
- alter information-use constraints;
- change connector eligibility;
- suppress an approval;
- increase budget or priority;
- cause activation or rollback;
- convert a candidate into accepted runtime.

Every experimental operation follows the same path as comparable non-experimental work:

```text
authenticated caller
    → verified AgencyContext
    → durable EffectIntent
    → canonical resource resolution
    → ordinary policy and information-use evaluation
    → final AuthorizationEnvelope
    → execution
    → receipt, denial, failure, or Uncertain
    → reconciliation where required
```

“Evaluation,” “trial,” “benchmark,” “research,” or “self-improvement” in a purpose or causal reference never weakens that path.

## 4. Evidence needed for controlled comparison

For a developmental arm that crosses WorldInterface, the evidence chain should make the following reconstructible where applicable:

### 4.1 Identity and agency

- authenticated host or actor;
- accountable principal;
- delegation chain;
- acting capacity;
- purpose reference;
- campaign and arm causal references.

### 4.2 Resource and policy

- unresolved selector and canonical resolved resource;
- resolver and registry-snapshot versions;
- effect or observation class;
- policy, grant, approval, and information-use versions;
- final authorization decision and constraints;
- any difference in authority envelope between arms.

### 4.3 Execution environment

- connector instance and version;
- capability descriptor and execution profile;
- sandbox, worker, image, toolchain, or provider profile where relevant;
- source and candidate artifact digests;
- input and output artifact hashes;
- provider or external-system version when observable;
- resource and timing summary appropriate to the configured receipt profile.

### 4.4 Outcome and uncertainty

- attempt identity and external idempotency identity;
- provider acceptance or commit milestone actually established;
- failure classification;
- `Uncertain` state and reconciliation history;
- excluded, repeated, or superseded observations;
- evidence assurance and known gaps.

WorldInterface does not need to compute a benchmark score. It needs to make material execution differences visible so Exoskeleton can treat them as intended interventions or confounds.

## 5. Authorization parity

A controlled comparison often intends to hold authority and information-use conditions fixed. WorldInterface supports that claim by preserving exact decisions and versions, not by accepting a caller assertion that the arms were equivalent.

Two arms have inspectable authorization parity only when their evidence shows either:

```text
same canonical resource class and scope
same accountable principal and acting capacity
same policy/grant/approval versions
same information-use envelope
same execution constraints
```

or an explicitly declared and justified difference.

If resource resolution, policy, approvals, or information-use conditions differ, the records expose the difference as a potential confound. WorldInterface does not conceal it in a normalized “experiment succeeded” result.

## 6. Boundary success is not developmental success

The following distinctions remain mandatory:

```text
queue task succeeded
    ≠ external effect was semantically correct

provider accepted request
    ≠ intended real-world outcome occurred

boundary receipt exists
    ≠ output passed verification

trial completed
    ≠ candidate improved the task distribution

activation receipt exists
    ≠ continuity or long-term acceptance was established
```

A receipt proves the recorded boundary fact to the assurance level of its evidence. Exoskeleton-owned verification and evaluation determine task quality. Exoskeleton and the lifecycle supervisor determine acceptance and activation.

## 7. Experimental environments and lifecycle effects

Candidate development and comparison may use ordinary governed effects such as:

```text
source.checkout
sandbox.provision
worker.start
candidate.build
candidate.sign
candidate.publish
trial.start
trial.stop
runtime.checkpoint
runtime.activate
runtime.rollback
component.quarantine
backup.verify
```

The exact capability catalog remains deployment-specific. Each operation still has an ordinary intent, canonical target, final authorization, execution outcome, and receipt.

Environment provisioning evidence should identify the immutable environment or capture enough versioned inputs to reproduce it. Teardown and cleanup are also accountable effects when they cross a meaningful boundary.

The candidate cannot activate itself. A passing evaluation reference in `causal_refs` is not an activation grant. The lifecycle supervisor verifies a separately authorized activation request and preserves a rollback target.

## 8. Ingress and external observations

Developmental campaigns may depend on callbacks, logs, test-system events, provider responses, or human review. These enter as ordinary `BoundaryObservation` records.

The record preserves:

- canonical source;
- connector and version;
- provider event identity and deduplication;
- asserted sender and audience;
- authentication assurance;
- content and attachment hashes;
- observed and received times;
- delivery and acknowledgment history.

An observation is evidence about what was received. It is not automatically a benchmark label, verifier judgment, instruction, or truth claim. Exoskeleton admits it under the frozen evaluation plan.

## 9. Uncertainty and reconciliation

Comparative evidence is invalid when an ambiguous external effect is silently treated as success or blindly repeated.

When commit status is unknown:

1. WorldInterface records `Uncertain`;
2. the campaign arm remains unresolved under Exoskeleton policy;
3. connector-specific reconciliation runs under ordinary authority;
4. the reconciled result, remaining ambiguity, or exclusion is preserved;
5. Exoskeleton applies the frozen missing-evidence and exclusion policy.

A retry that could duplicate a real-world consequence is not justified by experimental convenience.

## 10. Data minimization and information use

Developmental observability does not justify copying sensitive business data into receipts, logs, evaluator contexts, or public proof bundles.

The profile therefore requires:

- references and hashes instead of raw sensitive content where possible;
- receipt profiles appropriate to the purpose and audience;
- redaction and governed artifact access;
- information-use envelopes on exports and evaluator disclosures;
- retention and deletion behavior consistent with source obligations;
- no high-cardinality campaign metadata in ordinary telemetry by default.

A specialized accounting or ERP system may require detailed fixtures and logs. Those remain protected application artifacts, not generic Fabric ontology.

## 11. Observability

Operator surfaces should answer:

- Which campaign and intervention arm caused this boundary operation?
- Which authenticated principal and acting capacity were used?
- What exact canonical resource was resolved?
- Which policy, grant, approval, information-use, resolver, connector, and schema versions governed it?
- Were the intended fixed boundary conditions actually equal across arms?
- What artifact and environment digests support reproduction?
- Which outcomes are succeeded, failed, denied, uncertain, reconciled, excluded, or superseded?
- Which differences should Exoskeleton consider as confounds?
- Did any experimental label alter ordinary authorization? The required answer is no.

Views must not display a WorldInterface-computed “winning arm” or “binding constraint.”

## 12. Risks and mitigations

### 12.1 Evidence inflation

**Risk:** every internal worker step becomes a high-volume boundary receipt.  
**Mitigation:** preserve the existing consequential-boundary rule. Internal sandbox telemetry remains telemetry or protected artifacts unless it crosses an accountable boundary.

### 12.2 Hidden execution drift

**Risk:** connector, provider, image, resolver, or policy changes make arms incomparable.  
**Mitigation:** pin exact versions where possible, preserve observed external versions, and surface every unresolved difference as a confound.

### 12.3 Experimental authorization bypass

**Risk:** trial or research labels are treated as privileged.  
**Mitigation:** ordinary resolution, authorization, information-use, approval, and reconciliation paths remain mandatory; conformance tests compare experimental and ordinary submissions.

### 12.4 Receipt interpreted as quality

**Risk:** a successful boundary crossing is treated as task correctness.  
**Mitigation:** separate boundary facts, verification, evaluation, acceptance, and activation in types, APIs, views, and tests.

### 12.5 Sensitive benchmark leakage

**Risk:** protected workload or customer data is exposed through evidence.  
**Mitigation:** artifact references, receipt profiles, redaction, information-use policy, audience controls, and protected evaluator channels.

## 13. Implementation allocation

The fourteen-PR implementation sequence is retained.

- **WI-02:** ensure causal references, schema versions, and immutable effect/observation identities can support the profile.
- **WI-04:** prove experimental labels cannot alter resource resolution or authorization.
- **WI-05:** add the developmental evidence conformance profile over existing receipt and evidence records.
- **WI-06:** preserve connector, environment, idempotency, uncertainty, and reconciliation evidence.
- **WI-09:** preserve sandbox, worker, image, and candidate-environment provenance without importing specialist ontology.
- **WI-10:** classify lifecycle and developmental capabilities without expanding Fabric into a domain workbench.
- **WI-11:** add operator correlation and parity inspection while keeping task-quality interpretation absent.
- **WI-13:** run the developmental evidence, authorization-parity, uncertainty, privacy, crash, and replay suites.
- **WI-14:** publish the profile and exact downstream handoff for `EXO-V3-COMPREHENSIVE-2`.

## 14. Acceptance statement

This profile is complete when WorldInterface can execute a multi-arm developmental campaign through ordinary boundary paths; preserve bounded campaign causality; prove exact resource, agency, policy, information-use, connector, environment, artifact, timing, outcome, and uncertainty evidence; reveal material differences as confounds; recover without duplicate effects or lost evidence; and do so without interpreting task quality, selecting a winning arm, accepting a candidate, widening authority, or adding a developmental protocol primitive.


## Worker execution provenance clarification (WI-PLAN-5)

Apply `WI-WORKER-EXECUTION-1` when a developmental arm uses a worker. Bind the provider profile definition, adapter and approved executable/configuration to the grant and artifacts. Preserve requested, advertised, enforced and observed controls separately. A host-supplied enclosing Kata-instance reference is not proof of an independently isolated process worker. Unknown evidence remains unknown; never normalize either environment to a generic sandboxed flag. `process-managed-proof-1` excludes newly generated unreviewed executables and sensitive production inputs. Its fixture results cannot qualify arbitrary candidate trials, and a boundary receipt still cannot choose a winning arm or accept an improvement.
