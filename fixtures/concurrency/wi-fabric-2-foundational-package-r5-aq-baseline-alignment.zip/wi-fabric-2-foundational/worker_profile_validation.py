"""Pure checks of the WI worker planning profile; not a runtime admission engine."""
from __future__ import annotations
from typing import Any


def worker_profile_errors(profile: Any, matrix: Any, item_ids: set[str]) -> list[str]:
    errors: list[str] = []
    if not isinstance(profile, dict) or not isinstance(matrix, dict):
        return ['profile and matrix must be mappings']
    def at(path: str) -> Any:
        node: Any = profile
        for k in path.split('.'):
            if not isinstance(node, dict): return None
            node = node.get(k)
        return node
    # These are fixed assertions of this particular initial planning profile.
    # Future qualification results belong in separate evidence, not these flags.
    expected = {
        'schema_version': 1, 'kind': 'worker_execution_planning_profile',
        'profile_id': 'WI-WORKER-EXECUTION-1', 'provider_profile_id': 'process-managed-proof-1',
        'owner_repository': 'zed-colonel/worldinterface', 'plan_revision': 'WI-PLAN-5',
        'base_contract': 'WI-FABRIC-2', 'status': 'planned-not-qualified',
        'authority.definition_owner': 'WI / Agent Host',
        'authority.consumer_may_tighten_restrictions': True,
        'authority.consumer_may_weaken_restrictions': False,
        'authority.wire_contract_changed': False,
        'authority.field_mapping_requires_review': 'WI-ADR-016',
        'authority.new_actionqueue_primitives': [],
        'authority.public_runtime_orchestration_api_added': False,
        'provider.realization': 'reviewed-local-process',
        'provider.managed_through_worldinterface': True,
        'provider.independent_worker_vm': False,
        'provider.hostile_code_containment_claim': False,
        'provider.enclosing_instance_required_runtime': None,
        'provider.kata_host_required_for_provider_conformance': False,
        'provider.host_or_platform_management_socket_access': False,
        'provider.arbitrary_engine_flags_accepted': False,
        'provider.local_pid_or_host_path_required_by_consumer': False,
        'provider.external_provider_required_now': False,
        'provider.external_provider_seam_required': True,
        'provider.new_scheduler': False,
        'admission.reviewed_executables_only': True,
        'admission.approved_nonsensitive_inputs_only': True,
        'admission.arbitrary_generated_executables_allowed': False,
        'admission.production_credentials_allowed': False,
        'admission.sensitive_production_data_allowed': False,
        'admission.unreviewed_executable_candidates_allowed': False,
        'admission.silent_downgrade_allowed': False,
        'admission.unknown_mandatory_control_action': 'deny-before-launch',
        'admission.unsupported_operation_action': 'unavailable-with-no-side-effect',
        'admission.qualification_evidence_required': True,
        'admission.caller_profile_claim_authoritative': False,
        'admission.approval_cannot_override_missing_enforcement': True,
        'admission.profile_selection_bound_to_authorization': True,
        'admission.provider_change_requires_reauthorization': True,
        'admission.forbid_inherited_authority': ['vessel-root','operator-supervisor','deployment','organization-admin'],
        'admission.network_restrictions_inferred_from_workdir': False,
        'operation_contract.required': ['provision','start','inspect','terminate','collect_artifacts','release'],
        'operation_contract.optional_until_qualified': ['command','checkpoint','suspend','resume'],
        'operation_contract.process_memory_restore_claim': False,
        'operation_contract.checkpoint_kind': 'explicitly-admitted-application-artifact-only',
        'operation_contract.unqualified_optional_operation_available': False,
        'operation_contract.terminal_exit_is_task_acceptance': False,
        'lifecycle.durable_intent_before_start': True,
        'lifecycle.stable_run_identity_not_pid': True,
        'lifecycle.pid_reuse_safe_ownership_required': True,
        'lifecycle.unconditional_duplicate_start_allowed': False,
        'lifecycle.creation_ack_ambiguity_action': 'reconcile-owned-process-or-quarantine-before-replacement',
        'lifecycle.event_durable_before_wake': True,
        'lifecycle.deduplicate_events': True,
        'lifecycle.late_cancel_and_event_races_required': True,
        'lifecycle.bounded_output_and_walltime': True,
        'lifecycle.process_tree_cleanup_required': True,
        'lifecycle.termination_request_is_confirmed_exit': False,
        'lifecycle.cleanup_failure_reported': True,
        'lifecycle.no_deliberate_sensitive_descriptor_inheritance': True,
        'lifecycle.recovery_uses_existing_aq_wi_semantics': True,
        'evidence.separate_enclosing_instance_from_worker': True,
        'evidence.enclosing_kata_implies_worker_vm': False,
        'evidence.worker_report_is_host_attestation': False,
        'evidence.missing_evidence_remains_unknown': True,
        'evidence.receipt_is_task_quality_or_acceptance': False,
        'evidence.requested_advertised_enforced_observed_distinct': True,
        'evidence.bounded_structured_profile_no_freeform_metadata_map': True,
        'artifacts.opaque_refs_required': True,
        'artifacts.consumer_direct_local_path_access_required': False,
        'artifacts.export_scope_validation_required': True,
        'artifacts.quarantine_on_invalid_export': True,
        'artifacts.worker_self_acceptance_allowed': False,
        'host_lifecycle_adapter.required_for_process_provider_proof': False,
        'host_lifecycle_adapter.required_for_claimed_host_lifecycle_support': True,
        'host_lifecycle_adapter.containerd_client_in_fabric_core_required': False,
        'host_lifecycle_adapter.bounded_operations_only': True,
        'host_lifecycle_adapter.guest_engine_socket_allowed': False,
        'host_lifecycle_adapter.results_queryable_outside_stopped_guest': True,
        'host_lifecycle_adapter.recovery_depends_on_failed_guest': False,
        'host_lifecycle_adapter.supervisor_owns_platform_runtime_access': True,
        'host_lifecycle_adapter.candidate_owns_activation_credentials': False,
        'milestones.embedded_worker_proof.id': 'WI-EMBEDDED-WORKER-PROOF-1',
        'milestones.embedded_worker_proof.requires_checkpoints': [f'WI-WORKER-G{i}' for i in range(1,5)],
        'milestones.embedded_worker_proof.requires_real_embedded_aq_wi': True,
        'milestones.embedded_worker_proof.requires_exoskeleton_implementation': False,
        'milestones.embedded_worker_proof.requires_platform_services': False,
        'milestones.embedded_worker_proof.requires_kata_host': False,
        'milestones.embedded_worker_proof.requires_external_worker_provider': False,
        'milestones.embedded_worker_proof.requires_digicorp': False,
        'milestones.embedded_worker_proof.marks_parent_prs_accepted': False,
        'milestones.embedded_worker_proof.satisfies_full_release_or_stronger_isolation': False,
        'milestones.embedded_worker_proof.test_consumer_owner': 'WI conformance harness',
        'milestones.host_lifecycle_support.requires_checkpoints': ['WI-WORKER-G5'],
        'milestones.host_lifecycle_support.separate_from_worker_proof': True,
        'milestones.full_release.existing_gate_meanings_preserved': True,
        'milestones.full_release.scope_reduction_requires_separate_review': True,
        'qualification_evaluation.explicit_operator_approval_required': True,
        'qualification_evaluation.registration_state': 'evaluation-only',
        'qualification_evaluation.ordinary_admission_enabled': False,
        'qualification_evaluation.may_run_only_reviewed_fixture_cases': True,
        'qualification_evaluation.requires_prior_completed_provider_qualification': False,
        'qualification_evaluation.non_sensitive_test_environment_required': True,
        'qualification_evaluation.profile_exclusions_and_ordinary_authorization_still_apply': True,
        'qualification_evaluation.may_waive_missing_mandatory_enforcement': False,
        'qualification_evaluation.may_self_promote_to_qualified': False,
        'qualification_evaluation.qualification_reviewer_separate_from_candidate': True,
        'checkpoint_semantics.states_initially_planned': True,
        'checkpoint_semantics.evidence_from_partial_pr_slices_allowed': True,
        'checkpoint_semantics.parent_acceptance_not_own_checkpoint_prerequisite': True,
        'checkpoint_semantics.work_owner_ids_are_attribution_not_parent_dependencies': True,
        'checkpoint_semantics.existing_upstream_gates_preserved': True,
        'checkpoint_semantics.no_runtime_pass_inferred_from_plan_or_stub': True,
        'checkpoint_semantics.concurrency_map_requires_reviewed_rebinding': True,
    }
    for path, value in expected.items():
        found = at(path)
        if type(found) is not type(value) or found != value:
            errors.append(f'{path}: expected {value!r}, got {found!r}')
    def strings(v: Any, minimum: int=1) -> bool:
        return isinstance(v,list) and len(v)>=minimum and all(isinstance(x,str) and x.strip() for x in v) and len(v)==len(set(v))
    for path, minimum in [('evidence.required_binding_fields',10),('evidence.requalification_triggers',5),('future_not_prerequisites',9)]:
        if not strings(at(path), minimum): errors.append(f'{path}: incomplete/duplicate reference list')
    gates = profile.get('checkpoints')
    if not isinstance(gates,list): return errors+['checkpoints must be a list']
    ids=[g.get('id') if isinstance(g,dict) else None for g in gates]
    if ids != [f'WI-WORKER-G{i}' for i in range(1,6)]: errors.append('checkpoints: wrong IDs/order/count')
    case_list=matrix.get('cases')
    if not isinstance(case_list,list): return errors+['cases must be a list']
    if matrix.get('status')!='planned-not-executed': errors.append('matrix status is not planned')
    if matrix.get('profile_id')!=expected['profile_id'] or matrix.get('provider_profile_id')!=expected['provider_profile_id']: errors.append('matrix profile mismatch')
    if type(matrix.get('case_count')) is not int or matrix['case_count']!=len(case_list) or len(case_list)!=40: errors.append('matrix expected 40 cases')
    cids=[c.get('id') if isinstance(c,dict) else None for c in case_list]
    if cids != [f'WP-{i:03d}' for i in range(1,41)]: errors.append('cases: wrong IDs/order/count')
    adjacency={}
    gate_expectations={1:[],2:['WI-WORKER-G1'],3:['WI-WORKER-G1','WI-WORKER-G2'],4:['WI-WORKER-G3'],5:['WI-WORKER-G1','WI-WORKER-G2']}
    for n,g in enumerate(gates,1):
        if not isinstance(g,dict):errors.append('gate must be mapping');continue
        gid=g.get('id')
        for k in ('title','criterion'):
            if not isinstance(g.get(k),str) or not g[k].strip():errors.append(f'{gid}: missing {k}')
        if g.get('status')!='planned':errors.append(f'{gid}: cannot claim pass from a plan')
        if not strings(g.get('evidence_owners')) or not set(g['evidence_owners']).issubset(item_ids):errors.append(f'{gid}: invalid evidence owners')
        for k in ('requires_completed_parent_prs','requires_completed_exo_prs'):
            if g.get(k)!=[]:errors.append(f'{gid}: owner/consumer completion cannot gate producer evidence')
        deps=g.get('requires_checkpoints')
        if not isinstance(deps,list) or any(x not in ids for x in deps):errors.append(f'{gid}: invalid dependencies');deps=[]
        if deps!=gate_expectations.get(n):errors.append(f'{gid}: checkpoint dependency semantics changed')
        adjacency[gid]=deps
        aq=g.get('required_aq_gates_for_real_integration')
        wanted=[] if n<=2 else [f'WI-AQ-G{i}' for i in range(1,5)]
        if aq!=wanted:errors.append(f'{gid}: AQ gate barrier changed')
        actual_cases=g.get('cases')
        wanted_cases=[c['id'] for c in case_list if isinstance(c,dict) and c.get('checkpoint')==gid]
        if not strings(actual_cases) or actual_cases!=wanted_cases:errors.append(f'{gid}: case coverage mismatch')
    visiting=set();done=set()
    def visit(node):
        if node in visiting:errors.append(f'checkpoint cycle at {node}');return
        if node in done:return
        visiting.add(node)
        for d in adjacency.get(node,[]):visit(d)
        visiting.remove(node);done.add(node)
    for node in adjacency:visit(node)
    for c in case_list:
        if not isinstance(c,dict):errors.append('case must be mapping');continue
        for k in ('id','checkpoint','group','owner_pr','title','setup','expected','evidence_class'):
            if not isinstance(c.get(k),str) or not c[k].strip():errors.append(f'{c.get("id")}: missing {k}')
        if c.get('checkpoint') not in ids or c.get('owner_pr') not in item_ids:errors.append(f'{c.get("id")}: invalid owner/checkpoint')
        if c.get('status')!='planned' or c.get('runtime_pass_asserted') is not False:errors.append(f'{c.get("id")}: runtime pass not allowed')
        if c.get('requires_exoskeleton') is not False or c.get('requires_kata_host') is not False:errors.append(f'{c.get("id")}: provider proof cannot require EXO/Kata')
        if type(c.get('requires_real_embedded_aq_wi')) is not bool:errors.append(f'{c.get("id")}: real-runtime requirement must be boolean')
        if c.get('checkpoint') in ('WI-WORKER-G3','WI-WORKER-G4') and c.get('requires_real_embedded_aq_wi') is not True:errors.append(f'{c.get("id")}: real embedded runtime evidence required')
    return errors
